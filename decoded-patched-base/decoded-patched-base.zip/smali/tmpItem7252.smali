.class public final LtmpItem7252;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final DDù8:Ljava/lang/Object;

.field public final JKEoÙX:Ljava/lang/Object;

.field public final POOl:Ljava/lang/Object;

.field public e8$mp_s$:Z

.field public final rz__9J_:Ljava/lang/Object;

.field public final sKey7917:Ljava/util/AbstractCollection;

.field public final tmpData3485:Ljava/lang/Object;

.field public waiBKÀ:Z

.field public final yON3x:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;LsQze;)V
    .locals 2

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LtmpItem7252;->sKey7917:Ljava/util/AbstractCollection;

    .line 7
    new-instance v0, LIIi;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p0}, LIIi;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LtmpItem7252;->DDù8:Ljava/lang/Object;

    .line 8
    new-instance v0, LjPos9358;

    const/16 v1, 0x11

    invoke-direct {v0, v1, p0}, LjPos9358;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, LtmpItem7252;->yON3x:Ljava/lang/Object;

    .line 9
    iput-object p1, p0, LtmpItem7252;->rz__9J_:Ljava/lang/Object;

    .line 10
    iput-object p2, p0, LtmpItem7252;->POOl:Ljava/lang/Object;

    .line 11
    new-instance p2, Landroid/os/Handler;

    invoke-direct {p2}, Landroid/os/Handler;-><init>()V

    iput-object p2, p0, LtmpItem7252;->JKEoÙX:Ljava/lang/Object;

    .line 12
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    iput-object p1, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/os/Looper;Lbu$S0$;LgCount7138;)V
    .locals 6

    .line 1
    new-instance v1, Ljava/util/concurrent/CopyOnWriteArraySet;

    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>()V

    const/4 v5, 0x1

    move-object v0, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    invoke-direct/range {v0 .. v5}, LtmpItem7252;-><init>(Ljava/util/concurrent/CopyOnWriteArraySet;Landroid/os/Looper;Lbu$S0$;LgCount7138;Z)V

    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/CopyOnWriteArraySet;Landroid/os/Looper;Lbu$S0$;LgCount7138;Z)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, LtmpItem7252;->rz__9J_:Ljava/lang/Object;

    iput-object p1, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    iput-object p4, p0, LtmpItem7252;->JKEoÙX:Ljava/lang/Object;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LtmpItem7252;->yON3x:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayDeque;

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, LtmpItem7252;->sKey7917:Ljava/util/AbstractCollection;

    new-instance p1, Ljava/util/ArrayDeque;

    .line 3
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    iput-object p1, p0, LtmpItem7252;->DDù8:Ljava/lang/Object;

    .line 4
    new-instance p1, LjCount2747;

    const/4 p4, 0x1

    invoke-direct {p1, p4, p0}, LjCount2747;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p3, p2, p1}, Lbu$S0$;->e8$mp_s$(Landroid/os/Looper;Landroid/os/Handler$Callback;)LkKey6390;

    move-result-object p1

    iput-object p1, p0, LtmpItem7252;->POOl:Ljava/lang/Object;

    iput-boolean p5, p0, LtmpItem7252;->waiBKÀ:Z

    return-void
.end method


# virtual methods
.method public JKEoÙX()V
    .locals 5

    .line 1
    invoke-virtual {p0}, LtmpItem7252;->tmpData3485()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LtmpItem7252;->yON3x:Ljava/lang/Object;

    .line 5
    .line 6
    monitor-enter v0

    .line 7
    const/4 v1, 0x1

    .line 8
    :try_start_0
    iput-boolean v1, p0, LtmpItem7252;->e8$mp_s$:Z

    .line 9
    .line 10
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    iget-object v0, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_1

    .line 24
    .line 25
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    check-cast v2, LhasCount9848;

    .line 30
    .line 31
    iget-object v3, p0, LtmpItem7252;->JKEoÙX:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast v3, LgCount7138;

    .line 34
    .line 35
    iput-boolean v1, v2, LhasCount9848;->POOl:Z

    .line 36
    .line 37
    iget-boolean v4, v2, LhasCount9848;->rz__9J_:Z

    .line 38
    .line 39
    if-eqz v4, :cond_0

    .line 40
    .line 41
    const/4 v4, 0x0

    .line 42
    iput-boolean v4, v2, LhasCount9848;->rz__9J_:Z

    .line 43
    .line 44
    iget-object v4, v2, LhasCount9848;->e8$mp_s$:Ljava/lang/Object;

    .line 45
    .line 46
    iget-object v2, v2, LhasCount9848;->waiBKÀ:LFDhÌkì;

    .line 47
    .line 48
    invoke-virtual {v2}, LFDhÌkì;->JKEoÙX()Lli1il1i;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    invoke-interface {v3, v4, v2}, LgCount7138;->sKey7917(Ljava/lang/Object;Lli1il1i;)V

    .line 53
    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_1
    iget-object v0, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 59
    .line 60
    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArraySet;->clear()V

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :catchall_0
    move-exception v1

    .line 65
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    throw v1
.end method

.method public POOl(ILjma$E_vf$;)V
    .locals 3

    .line 1
    invoke-virtual {p0}, LtmpItem7252;->tmpData3485()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 5
    .line 6
    iget-object v1, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v1, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 9
    .line 10
    invoke-direct {v0, v1}, Ljava/util/concurrent/CopyOnWriteArraySet;-><init>(Ljava/util/Collection;)V

    .line 11
    .line 12
    .line 13
    new-instance v1, LlQ;

    .line 14
    .line 15
    const/4 v2, 0x6

    .line 16
    invoke-direct {v1, v0, p1, p2, v2}, LlQ;-><init>(Ljava/lang/Object;ILjava/lang/Object;I)V

    .line 17
    .line 18
    .line 19
    iget-object p1, p0, LtmpItem7252;->DDù8:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p1, Ljava/util/ArrayDeque;

    .line 22
    .line 23
    invoke-virtual {p1, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public e8$mp_s$()V
    .locals 15

    .line 1
    iget-object v0, p0, LtmpItem7252;->POOl:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LsQze;

    .line 4
    .line 5
    iget-object v1, p0, LtmpItem7252;->rz__9J_:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroid/content/Context;

    .line 8
    .line 9
    iget-object v2, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Landroid/content/pm/PackageManager;

    .line 12
    .line 13
    iget-object v3, p0, LtmpItem7252;->sKey7917:Ljava/util/AbstractCollection;

    .line 14
    .line 15
    check-cast v3, Ljava/util/ArrayList;

    .line 16
    .line 17
    iget-boolean v4, p0, LtmpItem7252;->waiBKÀ:Z

    .line 18
    .line 19
    if-nez v4, :cond_0

    .line 20
    .line 21
    goto/16 :goto_9

    .line 22
    .line 23
    :cond_0
    new-instance v4, Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 26
    .line 27
    .line 28
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 29
    .line 30
    const/16 v6, 0x1e

    .line 31
    .line 32
    const/4 v7, 0x0

    .line 33
    if-lt v5, v6, :cond_3

    .line 34
    .line 35
    new-instance v4, Landroid/content/Intent;

    .line 36
    .line 37
    const-string v5, "android.media.MediaRoute2ProviderService"

    .line 38
    .line 39
    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    new-instance v5, Ljava/util/ArrayList;

    .line 43
    .line 44
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v2, v4, v7}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 56
    .line 57
    .line 58
    move-result v6

    .line 59
    if-eqz v6, :cond_2

    .line 60
    .line 61
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v6

    .line 65
    check-cast v6, Landroid/content/pm/ResolveInfo;

    .line 66
    .line 67
    iget-object v6, v6, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    .line 68
    .line 69
    iget-boolean v8, p0, LtmpItem7252;->e8$mp_s$:Z

    .line 70
    .line 71
    if-eqz v8, :cond_1

    .line 72
    .line 73
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v8

    .line 77
    iget-object v9, v6, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 78
    .line 79
    invoke-static {v8, v9}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 80
    .line 81
    .line 82
    move-result v8

    .line 83
    if-nez v8, :cond_1

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_1
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    goto :goto_0

    .line 90
    :cond_2
    move-object v4, v5

    .line 91
    :cond_3
    new-instance v5, Landroid/content/Intent;

    .line 92
    .line 93
    const-string v6, "android.media.MediaRouteProviderService"

    .line 94
    .line 95
    invoke-direct {v5, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v2, v5, v7}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 103
    .line 104
    .line 105
    move-result-object v2

    .line 106
    const/4 v5, 0x0

    .line 107
    :cond_4
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v6

    .line 111
    const/4 v8, 0x1

    .line 112
    if-eqz v6, :cond_12

    .line 113
    .line 114
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v6

    .line 118
    check-cast v6, Landroid/content/pm/ResolveInfo;

    .line 119
    .line 120
    iget-object v6, v6, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    .line 121
    .line 122
    if-nez v6, :cond_5

    .line 123
    .line 124
    goto :goto_1

    .line 125
    :cond_5
    sget-object v9, LILA_l$V_;->rz__9J_:LsQze;

    .line 126
    .line 127
    if-nez v9, :cond_6

    .line 128
    .line 129
    const/4 v9, 0x0

    .line 130
    goto :goto_2

    .line 131
    :cond_6
    invoke-static {}, LILA_l$V_;->rz__9J_()LsQze;

    .line 132
    .line 133
    .line 134
    move-result-object v9

    .line 135
    invoke-virtual {v9}, LsQze;->DDù8()Z

    .line 136
    .line 137
    .line 138
    move-result v9

    .line 139
    :goto_2
    if-eqz v9, :cond_9

    .line 140
    .line 141
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 142
    .line 143
    .line 144
    move-result v9

    .line 145
    if-eqz v9, :cond_7

    .line 146
    .line 147
    goto :goto_3

    .line 148
    :cond_7
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 149
    .line 150
    .line 151
    move-result v9

    .line 152
    const/4 v10, 0x0

    .line 153
    :cond_8
    if-ge v10, v9, :cond_9

    .line 154
    .line 155
    invoke-virtual {v4, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v11

    .line 159
    add-int/lit8 v10, v10, 0x1

    .line 160
    .line 161
    check-cast v11, Landroid/content/pm/ServiceInfo;

    .line 162
    .line 163
    iget-object v12, v6, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 164
    .line 165
    iget-object v13, v11, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 166
    .line 167
    invoke-virtual {v12, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v12

    .line 171
    if-eqz v12, :cond_8

    .line 172
    .line 173
    iget-object v12, v6, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    .line 174
    .line 175
    iget-object v11, v11, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    .line 176
    .line 177
    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    move-result v11

    .line 181
    if-eqz v11, :cond_8

    .line 182
    .line 183
    goto :goto_1

    .line 184
    :cond_9
    :goto_3
    iget-object v9, v6, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 185
    .line 186
    iget-object v10, v6, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    .line 187
    .line 188
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 189
    .line 190
    .line 191
    move-result v11

    .line 192
    const/4 v12, 0x0

    .line 193
    :goto_4
    if-ge v12, v11, :cond_b

    .line 194
    .line 195
    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v13

    .line 199
    check-cast v13, LgValue8122;

    .line 200
    .line 201
    iget-object v13, v13, LgValue8122;->yàÒZ:Landroid/content/ComponentName;

    .line 202
    .line 203
    invoke-virtual {v13}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v14

    .line 207
    invoke-virtual {v14, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 208
    .line 209
    .line 210
    move-result v14

    .line 211
    if-eqz v14, :cond_a

    .line 212
    .line 213
    invoke-virtual {v13}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object v13

    .line 217
    invoke-virtual {v13, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 218
    .line 219
    .line 220
    move-result v13

    .line 221
    if-eqz v13, :cond_a

    .line 222
    .line 223
    goto :goto_5

    .line 224
    :cond_a
    add-int/lit8 v12, v12, 0x1

    .line 225
    .line 226
    goto :goto_4

    .line 227
    :cond_b
    const/4 v12, -0x1

    .line 228
    :goto_5
    if-gez v12, :cond_d

    .line 229
    .line 230
    new-instance v9, LgValue8122;

    .line 231
    .line 232
    new-instance v10, Landroid/content/ComponentName;

    .line 233
    .line 234
    iget-object v11, v6, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    .line 235
    .line 236
    iget-object v6, v6, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    .line 237
    .line 238
    invoke-direct {v10, v11, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 239
    .line 240
    .line 241
    invoke-direct {v9, v1, v10}, LgValue8122;-><init>(Landroid/content/Context;Landroid/content/ComponentName;)V

    .line 242
    .line 243
    .line 244
    new-instance v6, LzdS_N$B_;

    .line 245
    .line 246
    invoke-direct {v6, p0, v9}, LzdS_N$B_;-><init>(LtmpItem7252;LgValue8122;)V

    .line 247
    .line 248
    .line 249
    iput-object v6, v9, LgValue8122;->$ÒcdS:LzdS_N$B_;

    .line 250
    .line 251
    iget-boolean v6, v9, LgValue8122;->K0I:Z

    .line 252
    .line 253
    if-nez v6, :cond_c

    .line 254
    .line 255
    iput-boolean v8, v9, LgValue8122;->K0I:Z

    .line 256
    .line 257
    invoke-virtual {v9}, LgValue8122;->iOffset934()V

    .line 258
    .line 259
    .line 260
    :cond_c
    add-int/lit8 v6, v5, 0x1

    .line 261
    .line 262
    invoke-virtual {v3, v5, v9}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v0, v9, v7}, LsQze;->e8$mp_s$(LbQ4_le_;Z)V

    .line 266
    .line 267
    .line 268
    :goto_6
    move v5, v6

    .line 269
    goto/16 :goto_1

    .line 270
    .line 271
    :cond_d
    if-lt v12, v5, :cond_4

    .line 272
    .line 273
    invoke-virtual {v3, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v6

    .line 277
    check-cast v6, LgValue8122;

    .line 278
    .line 279
    iget-boolean v9, v6, LgValue8122;->K0I:Z

    .line 280
    .line 281
    if-nez v9, :cond_e

    .line 282
    .line 283
    iput-boolean v8, v6, LgValue8122;->K0I:Z

    .line 284
    .line 285
    invoke-virtual {v6}, LgValue8122;->iOffset934()V

    .line 286
    .line 287
    .line 288
    :cond_e
    iget-object v9, v6, LgValue8122;->UC_n_:LiSize3480;

    .line 289
    .line 290
    if-nez v9, :cond_11

    .line 291
    .line 292
    iget-boolean v9, v6, LgValue8122;->K0I:Z

    .line 293
    .line 294
    if-eqz v9, :cond_10

    .line 295
    .line 296
    iget-object v9, v6, LbQ4_le_;->kQy:LbllQl;

    .line 297
    .line 298
    if-eqz v9, :cond_f

    .line 299
    .line 300
    goto :goto_7

    .line 301
    :cond_f
    iget-object v9, v6, LgValue8122;->kO_6X_:Ljava/util/ArrayList;

    .line 302
    .line 303
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    .line 304
    .line 305
    .line 306
    move-result v9

    .line 307
    if-nez v9, :cond_10

    .line 308
    .line 309
    goto :goto_7

    .line 310
    :cond_10
    const/4 v8, 0x0

    .line 311
    :goto_7
    if-eqz v8, :cond_11

    .line 312
    .line 313
    invoke-virtual {v6}, LgValue8122;->jPos3709()V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v6}, LgValue8122;->DDù8()V

    .line 317
    .line 318
    .line 319
    :cond_11
    add-int/lit8 v6, v5, 0x1

    .line 320
    .line 321
    invoke-static {v3, v12, v5}, Ljava/util/Collections;->swap(Ljava/util/List;II)V

    .line 322
    .line 323
    .line 324
    goto :goto_6

    .line 325
    :cond_12
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 326
    .line 327
    .line 328
    move-result v1

    .line 329
    if-ge v5, v1, :cond_15

    .line 330
    .line 331
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 332
    .line 333
    .line 334
    move-result v1

    .line 335
    sub-int/2addr v1, v8

    .line 336
    :goto_8
    if-lt v1, v5, :cond_15

    .line 337
    .line 338
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 339
    .line 340
    .line 341
    move-result-object v2

    .line 342
    check-cast v2, LgValue8122;

    .line 343
    .line 344
    invoke-virtual {v0, v2}, LsQze;->POOl(LbQ4_le_;)Lo9k$Z$;

    .line 345
    .line 346
    .line 347
    move-result-object v4

    .line 348
    const/4 v6, 0x0

    .line 349
    if-eqz v4, :cond_13

    .line 350
    .line 351
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 352
    .line 353
    .line 354
    invoke-static {}, LILA_l$V_;->waiBKÀ()V

    .line 355
    .line 356
    .line 357
    iput-object v6, v2, LbQ4_le_;->iOffset934:LTCyD9È5;

    .line 358
    .line 359
    invoke-virtual {v2, v6}, LbQ4_le_;->sKey7917(LbllQl;)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v0, v4, v6}, LsQze;->Ialue(Lo9k$Z$;LkPos3720;)V

    .line 363
    .line 364
    .line 365
    iget-object v8, v0, LsQze;->e8$mp_s$:LoXMÌS;

    .line 366
    .line 367
    const/16 v9, 0x202

    .line 368
    .line 369
    invoke-virtual {v8, v9, v4}, LoXMÌS;->waiBKÀ(ILjava/lang/Object;)V

    .line 370
    .line 371
    .line 372
    iget-object v8, v0, LsQze;->iOffset934:Ljava/util/ArrayList;

    .line 373
    .line 374
    invoke-virtual {v8, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 375
    .line 376
    .line 377
    :cond_13
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 378
    .line 379
    .line 380
    iput-object v6, v2, LgValue8122;->$ÒcdS:LzdS_N$B_;

    .line 381
    .line 382
    iget-boolean v4, v2, LgValue8122;->K0I:Z

    .line 383
    .line 384
    if-eqz v4, :cond_14

    .line 385
    .line 386
    iput-boolean v7, v2, LgValue8122;->K0I:Z

    .line 387
    .line 388
    invoke-virtual {v2}, LgValue8122;->iOffset934()V

    .line 389
    .line 390
    .line 391
    :cond_14
    add-int/lit8 v1, v1, -0x1

    .line 392
    .line 393
    goto :goto_8

    .line 394
    :cond_15
    :goto_9
    return-void
.end method

.method public rz__9J_()V
    .locals 6

    .line 1
    iget-object v0, p0, LtmpItem7252;->POOl:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LkKey6390;

    .line 4
    .line 5
    iget-object v1, p0, LtmpItem7252;->sKey7917:Ljava/util/AbstractCollection;

    .line 6
    .line 7
    check-cast v1, Ljava/util/ArrayDeque;

    .line 8
    .line 9
    invoke-virtual {p0}, LtmpItem7252;->tmpData3485()V

    .line 10
    .line 11
    .line 12
    iget-object v2, p0, LtmpItem7252;->DDù8:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v2, Ljava/util/ArrayDeque;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-eqz v3, :cond_0

    .line 21
    .line 22
    goto :goto_1

    .line 23
    :cond_0
    iget-object v3, v0, LkKey6390;->e8$mp_s$:Landroid/os/Handler;

    .line 24
    .line 25
    const/4 v4, 0x1

    .line 26
    invoke-virtual {v3, v4}, Landroid/os/Handler;->hasMessages(I)Z

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-nez v3, :cond_1

    .line 31
    .line 32
    iget-object v3, v0, LkKey6390;->e8$mp_s$:Landroid/os/Handler;

    .line 33
    .line 34
    invoke-static {}, LkKey6390;->JKEoÙX()LbD8y;

    .line 35
    .line 36
    .line 37
    move-result-object v5

    .line 38
    invoke-virtual {v3, v4}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    .line 39
    .line 40
    .line 41
    move-result-object v3

    .line 42
    iput-object v3, v5, LbD8y;->e8$mp_s$:Landroid/os/Message;

    .line 43
    .line 44
    iget-object v0, v0, LkKey6390;->e8$mp_s$:Landroid/os/Handler;

    .line 45
    .line 46
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0, v3}, Landroid/os/Handler;->sendMessageAtFrontOfQueue(Landroid/os/Message;)Z

    .line 50
    .line 51
    .line 52
    const/4 v0, 0x0

    .line 53
    iput-object v0, v5, LbD8y;->e8$mp_s$:Landroid/os/Message;

    .line 54
    .line 55
    invoke-static {v5}, LkKey6390;->POOl(LbD8y;)V

    .line 56
    .line 57
    .line 58
    :cond_1
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->addAll(Ljava/util/Collection;)Z

    .line 63
    .line 64
    .line 65
    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    .line 66
    .line 67
    .line 68
    if-eqz v0, :cond_2

    .line 69
    .line 70
    :goto_0
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-nez v0, :cond_2

    .line 75
    .line 76
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->peekFirst()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Ljava/lang/Runnable;

    .line 81
    .line 82
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_2
    :goto_1
    return-void
.end method

.method public tmpData3485()V
    .locals 2

    .line 1
    iget-boolean v0, p0, LtmpItem7252;->waiBKÀ:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, LtmpItem7252;->POOl:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LkKey6390;

    .line 9
    .line 10
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    iget-object v0, v0, LkKey6390;->e8$mp_s$:Landroid/os/Handler;

    .line 15
    .line 16
    invoke-virtual {v0}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-ne v1, v0, :cond_1

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    const/4 v0, 0x0

    .line 29
    :goto_0
    invoke-static {v0}, LvItem3158;->xlOI(Z)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public waiBKÀ(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget-object v0, p0, LtmpItem7252;->yON3x:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-boolean v1, p0, LtmpItem7252;->e8$mp_s$:Z

    .line 5
    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    monitor-exit v0

    .line 9
    return-void

    .line 10
    :catchall_0
    move-exception p1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object v1, p0, LtmpItem7252;->tmpData3485:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Ljava/util/concurrent/CopyOnWriteArraySet;

    .line 15
    .line 16
    new-instance v2, LhasCount9848;

    .line 17
    .line 18
    invoke-direct {v2, p1}, LhasCount9848;-><init>(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1, v2}, Ljava/util/concurrent/CopyOnWriteArraySet;->add(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    monitor-exit v0

    .line 25
    return-void

    .line 26
    :goto_0
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 27
    throw p1
.end method
