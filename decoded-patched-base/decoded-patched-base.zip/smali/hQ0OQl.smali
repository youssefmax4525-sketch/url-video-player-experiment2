.class public final LhQ0OQl;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LXXìMLÙe;


# instance fields
.field public final e8$mp_s$:LisData5781;

.field public final waiBKÀ:LWY_einx;


# direct methods
.method public constructor <init>(LisData5781;LjPos3798;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LhQ0OQl;->e8$mp_s$:LisData5781;

    .line 5
    .line 6
    iput-object p2, p0, LhQ0OQl;->waiBKÀ:LWY_einx;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final bridge synthetic POOl()Ljava/lang/Object;
    .locals 1

    .line 1
    invoke-virtual {p0}, LhQ0OQl;->e8$mp_s$()LKkmORP;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    return-object v0
.end method

.method public final e8$mp_s$()LKkmORP;
    .locals 5

    .line 1
    iget-object v0, p0, LhQ0OQl;->e8$mp_s$:LisData5781;

    .line 2
    .line 3
    invoke-virtual {v0}, LisData5781;->e8$mp_s$()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, LhQ0OQl;->waiBKÀ:LWY_einx;

    .line 8
    .line 9
    invoke-interface {v1}, LWY_einx;->POOl()Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, LtmpPos3658;

    .line 14
    .line 15
    sget-object v2, LvItem598;->tzKù7Ol1:LvItem598;

    .line 16
    .line 17
    iget-object v3, v2, LvItem598;->yàÒZ:LIl11l;

    .line 18
    .line 19
    invoke-static {}, LxED$DU_3A$;->rz__9J_()LxED$DU_3A$;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v3, v0, v4, v1}, LIl11l;->kO_6X_(Landroid/content/Context;LxED$DU_3A$;LtmpPos3658;)LIlil;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    sget-object v4, LI$_z3$1_;->waiBKÀ:LnData6800;

    .line 28
    .line 29
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 30
    .line 31
    .line 32
    iget-object v2, v2, LvItem598;->yàÒZ:LIl11l;

    .line 33
    .line 34
    invoke-static {}, LxED$DU_3A$;->rz__9J_()LxED$DU_3A$;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    invoke-virtual {v2, v0, v3, v1}, LIl11l;->kO_6X_(Landroid/content/Context;LxED$DU_3A$;LtmpPos3658;)LIlil;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    const-string v2, "google.afma.sdkConstants.getSdkConstants"

    .line 43
    .line 44
    invoke-virtual {v1, v2, v4, v4}, LIlil;->e8$mp_s$(Ljava/lang/String;LvItem7183;LfIQ;)Lqlxj;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    new-instance v2, LKkmORP;

    .line 49
    .line 50
    invoke-static {}, LxED$DU_3A$;->rz__9J_()LxED$DU_3A$;

    .line 51
    .line 52
    .line 53
    move-result-object v3

    .line 54
    invoke-direct {v2, v0, v1, v3}, LKkmORP;-><init>(Landroid/content/Context;Lqlxj;LxED$DU_3A$;)V

    .line 55
    .line 56
    .line 57
    return-object v2
.end method
