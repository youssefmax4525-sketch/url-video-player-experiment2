.class public final Lt00;
.super LKeC7;
.source "SourceFile"


# static fields
.field public static final synthetic Qp_Hp$i_:I


# instance fields
.field public final Ialue:Z

.field public final K0I:Landroid/util/SparseBooleanArray;

.field public final gKey4112:Z

.field public final iOffset934:Z

.field public final kO_6X_:Landroid/util/SparseArray;

.field public final kQy:Z

.field public final pCXDYg:Z

.field public final valuI:Z

.field public final yàÒZ:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LfN_AT_;

    .line 2
    .line 3
    invoke-direct {v0}, LfN_AT_;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v1, Lt00;

    .line 7
    .line 8
    invoke-direct {v1, v0}, Lt00;-><init>(LfN_AT_;)V

    .line 9
    .line 10
    .line 11
    const/16 v0, 0x3e8

    .line 12
    .line 13
    const/16 v1, 0x24

    .line 14
    .line 15
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    const/16 v0, 0x3e9

    .line 19
    .line 20
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    const/16 v0, 0x3ea

    .line 24
    .line 25
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    const/16 v0, 0x3eb

    .line 29
    .line 30
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    const/16 v0, 0x3ec

    .line 34
    .line 35
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    const/16 v0, 0x3ed

    .line 39
    .line 40
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    const/16 v0, 0x3ee

    .line 44
    .line 45
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    const/16 v0, 0x3ef

    .line 49
    .line 50
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    const/16 v0, 0x3f0

    .line 54
    .line 55
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    const/16 v0, 0x3f1

    .line 59
    .line 60
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    const/16 v0, 0x3f2

    .line 64
    .line 65
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    const/16 v0, 0x3f3

    .line 69
    .line 70
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    const/16 v0, 0x3f4

    .line 74
    .line 75
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    const/16 v0, 0x3f5

    .line 79
    .line 80
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    const/16 v0, 0x3f6

    .line 84
    .line 85
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    const/16 v0, 0x3f7

    .line 89
    .line 90
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    const/16 v0, 0x3f8

    .line 94
    .line 95
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    const/16 v0, 0x3f9

    .line 99
    .line 100
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    const/16 v0, 0x3fa

    .line 104
    .line 105
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    return-void
.end method

.method public constructor <init>(LfN_AT_;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, LKeC7;-><init>(LpEò4;)V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p1, LfN_AT_;->iOffset934:Z

    .line 5
    .line 6
    iput-boolean v0, p0, Lt00;->iOffset934:Z

    .line 7
    .line 8
    iget-boolean v0, p1, LfN_AT_;->kQy:Z

    .line 9
    .line 10
    iput-boolean v0, p0, Lt00;->kQy:Z

    .line 11
    .line 12
    iget-boolean v0, p1, LfN_AT_;->Ialue:Z

    .line 13
    .line 14
    iput-boolean v0, p0, Lt00;->Ialue:Z

    .line 15
    .line 16
    iget-boolean v0, p1, LfN_AT_;->valuI:Z

    .line 17
    .line 18
    iput-boolean v0, p0, Lt00;->valuI:Z

    .line 19
    .line 20
    iget-boolean v0, p1, LfN_AT_;->pCXDYg:Z

    .line 21
    .line 22
    iput-boolean v0, p0, Lt00;->pCXDYg:Z

    .line 23
    .line 24
    iget-boolean v0, p1, LfN_AT_;->yàÒZ:Z

    .line 25
    .line 26
    iput-boolean v0, p0, Lt00;->yàÒZ:Z

    .line 27
    .line 28
    iget-boolean v0, p1, LfN_AT_;->gKey4112:Z

    .line 29
    .line 30
    iput-boolean v0, p0, Lt00;->gKey4112:Z

    .line 31
    .line 32
    iget-object v0, p1, LfN_AT_;->kO_6X_:Landroid/util/SparseArray;

    .line 33
    .line 34
    iput-object v0, p0, Lt00;->kO_6X_:Landroid/util/SparseArray;

    .line 35
    .line 36
    iget-object p1, p1, LfN_AT_;->K0I:Landroid/util/SparseBooleanArray;

    .line 37
    .line 38
    iput-object p1, p0, Lt00;->K0I:Landroid/util/SparseBooleanArray;

    .line 39
    .line 40
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 9

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto/16 :goto_2

    .line 4
    .line 5
    :cond_0
    const/4 v0, 0x0

    .line 6
    if-eqz p1, :cond_7

    .line 7
    .line 8
    const-class v1, Lt00;

    .line 9
    .line 10
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    if-eq v1, v2, :cond_1

    .line 15
    .line 16
    goto/16 :goto_3

    .line 17
    .line 18
    :cond_1
    check-cast p1, Lt00;

    .line 19
    .line 20
    invoke-super {p0, p1}, LKeC7;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_7

    .line 25
    .line 26
    iget-boolean v1, p0, Lt00;->iOffset934:Z

    .line 27
    .line 28
    iget-boolean v2, p1, Lt00;->iOffset934:Z

    .line 29
    .line 30
    if-ne v1, v2, :cond_7

    .line 31
    .line 32
    iget-boolean v1, p0, Lt00;->kQy:Z

    .line 33
    .line 34
    iget-boolean v2, p1, Lt00;->kQy:Z

    .line 35
    .line 36
    if-ne v1, v2, :cond_7

    .line 37
    .line 38
    iget-boolean v1, p0, Lt00;->Ialue:Z

    .line 39
    .line 40
    iget-boolean v2, p1, Lt00;->Ialue:Z

    .line 41
    .line 42
    if-ne v1, v2, :cond_7

    .line 43
    .line 44
    iget-boolean v1, p0, Lt00;->valuI:Z

    .line 45
    .line 46
    iget-boolean v2, p1, Lt00;->valuI:Z

    .line 47
    .line 48
    if-ne v1, v2, :cond_7

    .line 49
    .line 50
    iget-boolean v1, p0, Lt00;->pCXDYg:Z

    .line 51
    .line 52
    iget-boolean v2, p1, Lt00;->pCXDYg:Z

    .line 53
    .line 54
    if-ne v1, v2, :cond_7

    .line 55
    .line 56
    iget-boolean v1, p0, Lt00;->yàÒZ:Z

    .line 57
    .line 58
    iget-boolean v2, p1, Lt00;->yàÒZ:Z

    .line 59
    .line 60
    if-ne v1, v2, :cond_7

    .line 61
    .line 62
    iget-boolean v1, p0, Lt00;->gKey4112:Z

    .line 63
    .line 64
    iget-boolean v2, p1, Lt00;->gKey4112:Z

    .line 65
    .line 66
    if-ne v1, v2, :cond_7

    .line 67
    .line 68
    iget-object v1, p1, Lt00;->K0I:Landroid/util/SparseBooleanArray;

    .line 69
    .line 70
    iget-object v2, p0, Lt00;->K0I:Landroid/util/SparseBooleanArray;

    .line 71
    .line 72
    invoke-virtual {v2}, Landroid/util/SparseBooleanArray;->size()I

    .line 73
    .line 74
    .line 75
    move-result v3

    .line 76
    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->size()I

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    if-ne v4, v3, :cond_7

    .line 81
    .line 82
    const/4 v4, 0x0

    .line 83
    :goto_0
    if-ge v4, v3, :cond_3

    .line 84
    .line 85
    invoke-virtual {v2, v4}, Landroid/util/SparseBooleanArray;->keyAt(I)I

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    invoke-virtual {v1, v5}, Landroid/util/SparseBooleanArray;->indexOfKey(I)I

    .line 90
    .line 91
    .line 92
    move-result v5

    .line 93
    if-gez v5, :cond_2

    .line 94
    .line 95
    goto :goto_3

    .line 96
    :cond_2
    add-int/lit8 v4, v4, 0x1

    .line 97
    .line 98
    goto :goto_0

    .line 99
    :cond_3
    iget-object p1, p1, Lt00;->kO_6X_:Landroid/util/SparseArray;

    .line 100
    .line 101
    iget-object v1, p0, Lt00;->kO_6X_:Landroid/util/SparseArray;

    .line 102
    .line 103
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 104
    .line 105
    .line 106
    move-result v2

    .line 107
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    if-ne v3, v2, :cond_7

    .line 112
    .line 113
    const/4 v3, 0x0

    .line 114
    :goto_1
    if-ge v3, v2, :cond_6

    .line 115
    .line 116
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->keyAt(I)I

    .line 117
    .line 118
    .line 119
    move-result v4

    .line 120
    invoke-virtual {p1, v4}, Landroid/util/SparseArray;->indexOfKey(I)I

    .line 121
    .line 122
    .line 123
    move-result v4

    .line 124
    if-ltz v4, :cond_7

    .line 125
    .line 126
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object v5

    .line 130
    check-cast v5, Ljava/util/Map;

    .line 131
    .line 132
    invoke-virtual {p1, v4}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v4

    .line 136
    check-cast v4, Ljava/util/Map;

    .line 137
    .line 138
    invoke-interface {v5}, Ljava/util/Map;->size()I

    .line 139
    .line 140
    .line 141
    move-result v6

    .line 142
    invoke-interface {v4}, Ljava/util/Map;->size()I

    .line 143
    .line 144
    .line 145
    move-result v7

    .line 146
    if-ne v7, v6, :cond_7

    .line 147
    .line 148
    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 149
    .line 150
    .line 151
    move-result-object v5

    .line 152
    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    :cond_4
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 157
    .line 158
    .line 159
    move-result v6

    .line 160
    if-eqz v6, :cond_5

    .line 161
    .line 162
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v6

    .line 166
    check-cast v6, Ljava/util/Map$Entry;

    .line 167
    .line 168
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v7

    .line 172
    check-cast v7, LmoÈmc;

    .line 173
    .line 174
    invoke-interface {v4, v7}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 175
    .line 176
    .line 177
    move-result v8

    .line 178
    if-eqz v8, :cond_7

    .line 179
    .line 180
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v6

    .line 184
    invoke-interface {v4, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v7

    .line 188
    invoke-static {v6, v7}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    move-result v6

    .line 192
    if-nez v6, :cond_4

    .line 193
    .line 194
    goto :goto_3

    .line 195
    :cond_5
    add-int/lit8 v3, v3, 0x1

    .line 196
    .line 197
    goto :goto_1

    .line 198
    :cond_6
    :goto_2
    const/4 p1, 0x1

    .line 199
    return p1

    .line 200
    :cond_7
    :goto_3
    return v0
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    invoke-super {p0}, LKeC7;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    add-int/lit8 v0, v0, 0x1f

    .line 6
    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-boolean v1, p0, Lt00;->iOffset934:Z

    .line 10
    .line 11
    add-int/2addr v0, v1

    .line 12
    mul-int/lit16 v0, v0, 0x3c1

    .line 13
    .line 14
    iget-boolean v1, p0, Lt00;->kQy:Z

    .line 15
    .line 16
    add-int/2addr v0, v1

    .line 17
    mul-int/lit16 v0, v0, 0x3c1

    .line 18
    .line 19
    iget-boolean v1, p0, Lt00;->Ialue:Z

    .line 20
    .line 21
    add-int/2addr v0, v1

    .line 22
    const v1, 0x1b4d89f

    .line 23
    .line 24
    .line 25
    mul-int v0, v0, v1

    .line 26
    .line 27
    iget-boolean v1, p0, Lt00;->valuI:Z

    .line 28
    .line 29
    add-int/2addr v0, v1

    .line 30
    mul-int/lit8 v0, v0, 0x1f

    .line 31
    .line 32
    iget-boolean v1, p0, Lt00;->pCXDYg:Z

    .line 33
    .line 34
    add-int/2addr v0, v1

    .line 35
    mul-int/lit8 v0, v0, 0x1f

    .line 36
    .line 37
    iget-boolean v1, p0, Lt00;->yàÒZ:Z

    .line 38
    .line 39
    add-int/2addr v0, v1

    .line 40
    mul-int/lit16 v0, v0, 0x3c1

    .line 41
    .line 42
    iget-boolean v1, p0, Lt00;->gKey4112:Z

    .line 43
    .line 44
    add-int/2addr v0, v1

    .line 45
    mul-int/lit8 v0, v0, 0x1f

    .line 46
    .line 47
    return v0
.end method
