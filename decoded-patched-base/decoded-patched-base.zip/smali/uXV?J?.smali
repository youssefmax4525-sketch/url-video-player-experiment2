.class public final synthetic LuXVÌJÒ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LeAs;
.implements LT4_Mx$be_;
.implements LkValue4602;
.implements L_z_e$r_;
.implements LkItem6218;
.implements LnA$3g_00$;
.implements LhasKey5903;
.implements LsData8261;
.implements LtmpOffset2707;
.implements LbesqìA;
.implements LSOO1O;
.implements LO9q$c$;


# instance fields
.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LuXVÌJÒ;->yON3x:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public DDù8(LnPos7306;)LPni$zp$;
    .locals 6

    .line 1
    iget v0, p0, LuXVÌJÒ;->yON3x:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LisOffset5675;

    .line 7
    .line 8
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-string v1, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    .line 13
    .line 14
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-static {}, LIili1i;->$ÒcdS()LIili1i;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 26
    .line 27
    .line 28
    iget-object p1, p1, LisOffset5675;->e8$mp_s$:LnPos4111;

    .line 29
    .line 30
    invoke-static {p1}, LPIlDQ;->waiBKÀ(LnPos4111;)Lkòè;

    .line 31
    .line 32
    .line 33
    move-result-object p1

    .line 34
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    check-cast p1, LjPT$NJ$;

    .line 42
    .line 43
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    return-object p1

    .line 48
    :sswitch_0
    check-cast p1, LhasKey8276;

    .line 49
    .line 50
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    const-string v1, "type.googleapis.com/google.crypto.tink.AesGcmSivKey"

    .line 55
    .line 56
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-static {}, LNùIÀS;->Q1_f_()LSEg_xV_;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    iget v2, p1, LhasKey8276;->e8$mp_s$:I

    .line 64
    .line 65
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 66
    .line 67
    .line 68
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 69
    .line 70
    check-cast v3, LNùIÀS;

    .line 71
    .line 72
    invoke-static {v3, v2}, LNùIÀS;->sKey6064(LNùIÀS;I)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1}, Lw1I;->waiBKÀ()LHU$B$;

    .line 76
    .line 77
    .line 78
    move-result-object v1

    .line 79
    check-cast v1, LNùIÀS;

    .line 80
    .line 81
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 86
    .line 87
    .line 88
    iget-object p1, p1, LhasKey8276;->waiBKÀ:LTa$A4$;

    .line 89
    .line 90
    invoke-static {p1}, LvData9200;->waiBKÀ(LTa$A4$;)Lkòè;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    check-cast p1, LjPT$NJ$;

    .line 102
    .line 103
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    return-object p1

    .line 108
    :sswitch_1
    check-cast p1, L$_V$X_6S$;

    .line 109
    .line 110
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 111
    .line 112
    .line 113
    move-result-object v0

    .line 114
    const-string v1, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    .line 115
    .line 116
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    invoke-static {}, LhOOIDD;->kCount1402()LO9_ww$Ol_;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    invoke-static {}, Ldij;->$ÒcdS()LnData8944;

    .line 124
    .line 125
    .line 126
    move-result-object v2

    .line 127
    invoke-static {}, LjData2289;->$ÒcdS()LPI1D;

    .line 128
    .line 129
    .line 130
    move-result-object v3

    .line 131
    iget v4, p1, L$_V$X_6S$;->rz__9J_:I

    .line 132
    .line 133
    invoke-virtual {v3}, Lw1I;->POOl()V

    .line 134
    .line 135
    .line 136
    iget-object v5, v3, Lw1I;->vaIue:LHU$B$;

    .line 137
    .line 138
    check-cast v5, LjData2289;

    .line 139
    .line 140
    invoke-static {v5, v4}, LjData2289;->tmpSize211(LjData2289;I)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v3}, Lw1I;->waiBKÀ()LHU$B$;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    check-cast v3, LjData2289;

    .line 148
    .line 149
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 150
    .line 151
    .line 152
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 153
    .line 154
    check-cast v4, Ldij;

    .line 155
    .line 156
    invoke-static {v4, v3}, Ldij;->tzKù7Ol1(Ldij;LjData2289;)V

    .line 157
    .line 158
    .line 159
    iget v3, p1, L$_V$X_6S$;->e8$mp_s$:I

    .line 160
    .line 161
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 162
    .line 163
    .line 164
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 165
    .line 166
    check-cast v4, Ldij;

    .line 167
    .line 168
    invoke-static {v4, v3}, Ldij;->sKey6064(Ldij;I)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    .line 172
    .line 173
    .line 174
    move-result-object v2

    .line 175
    check-cast v2, Ldij;

    .line 176
    .line 177
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 178
    .line 179
    .line 180
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 181
    .line 182
    check-cast v3, LhOOIDD;

    .line 183
    .line 184
    invoke-static {v3, v2}, LhOOIDD;->sKey6064(LhOOIDD;Ldij;)V

    .line 185
    .line 186
    .line 187
    invoke-static {}, LWasIjTc;->Q1_f_()LR0I;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    invoke-static {p1}, LUW$4b_A$;->rz__9J_(L$_V$X_6S$;)LQll;

    .line 192
    .line 193
    .line 194
    move-result-object v3

    .line 195
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 196
    .line 197
    .line 198
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 199
    .line 200
    check-cast v4, LWasIjTc;

    .line 201
    .line 202
    invoke-static {v4, v3}, LWasIjTc;->oy_R$Xx_(LWasIjTc;LQll;)V

    .line 203
    .line 204
    .line 205
    iget v3, p1, L$_V$X_6S$;->waiBKÀ:I

    .line 206
    .line 207
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 208
    .line 209
    .line 210
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 211
    .line 212
    check-cast v4, LWasIjTc;

    .line 213
    .line 214
    invoke-static {v4, v3}, LWasIjTc;->ll(LWasIjTc;I)V

    .line 215
    .line 216
    .line 217
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    .line 218
    .line 219
    .line 220
    move-result-object v2

    .line 221
    check-cast v2, LWasIjTc;

    .line 222
    .line 223
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 224
    .line 225
    .line 226
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 227
    .line 228
    check-cast v3, LhOOIDD;

    .line 229
    .line 230
    invoke-static {v3, v2}, LhOOIDD;->tzKù7Ol1(LhOOIDD;LWasIjTc;)V

    .line 231
    .line 232
    .line 233
    invoke-virtual {v1}, Lw1I;->waiBKÀ()LHU$B$;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    check-cast v1, LhOOIDD;

    .line 238
    .line 239
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 240
    .line 241
    .line 242
    move-result-object v1

    .line 243
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 244
    .line 245
    .line 246
    iget-object p1, p1, L$_V$X_6S$;->JKEoÙX:LgOffset1083;

    .line 247
    .line 248
    invoke-static {p1}, LUW$4b_A$;->POOl(LgOffset1083;)Lkòè;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 256
    .line 257
    .line 258
    move-result-object p1

    .line 259
    check-cast p1, LjPT$NJ$;

    .line 260
    .line 261
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 262
    .line 263
    .line 264
    move-result-object p1

    .line 265
    return-object p1

    .line 266
    :sswitch_2
    check-cast p1, LSXX$fW$;

    .line 267
    .line 268
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    const-string v1, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    .line 273
    .line 274
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 275
    .line 276
    .line 277
    invoke-static {p1}, Lf53$O$;->waiBKÀ(LSXX$fW$;)LgSize7297;

    .line 278
    .line 279
    .line 280
    move-result-object v1

    .line 281
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 282
    .line 283
    .line 284
    move-result-object v1

    .line 285
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 286
    .line 287
    .line 288
    iget-object p1, p1, LSXX$fW$;->e8$mp_s$:LgOffset1083;

    .line 289
    .line 290
    invoke-static {p1}, Lf53$O$;->rz__9J_(LgOffset1083;)Lkòè;

    .line 291
    .line 292
    .line 293
    move-result-object p1

    .line 294
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 295
    .line 296
    .line 297
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 298
    .line 299
    .line 300
    move-result-object p1

    .line 301
    check-cast p1, LjPT$NJ$;

    .line 302
    .line 303
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 304
    .line 305
    .line 306
    move-result-object p1

    .line 307
    return-object p1

    .line 308
    nop

    .line 309
    :sswitch_data_0
    .sparse-switch
        0xc -> :sswitch_2
        0xe -> :sswitch_1
        0x12 -> :sswitch_0
    .end sparse-switch
.end method

.method public JKEoÙX(Landroid/content/Context;Ljava/lang/String;LeQ;)Lke1;
    .locals 3

    .line 1
    new-instance v0, Lke1;

    .line 2
    .line 3
    invoke-direct {v0}, Lke1;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    invoke-interface {p3, p1, p2, v1}, LeQ;->waiBKÀ(Landroid/content/Context;Ljava/lang/String;Z)I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    iput v2, v0, Lke1;->waiBKÀ:I

    .line 12
    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    iput v1, v0, Lke1;->rz__9J_:I

    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_0
    invoke-interface {p3, p1, p2}, LeQ;->POOl(Landroid/content/Context;Ljava/lang/String;)I

    .line 19
    .line 20
    .line 21
    move-result p1

    .line 22
    iput p1, v0, Lke1;->e8$mp_s$:I

    .line 23
    .line 24
    if-eqz p1, :cond_1

    .line 25
    .line 26
    const/4 p1, -0x1

    .line 27
    iput p1, v0, Lke1;->rz__9J_:I

    .line 28
    .line 29
    :cond_1
    return-object v0
.end method

.method public POOl(LBDO;)LvB$7$;
    .locals 4

    .line 1
    iget v0, p0, LuXVÌJÒ;->yON3x:I

    .line 2
    .line 3
    const-string v1, "Only version 0 keys are accepted"

    .line 4
    .line 5
    sparse-switch v0, :sswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 9
    .line 10
    const-string v2, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    .line 11
    .line 12
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_1

    .line 17
    .line 18
    :try_start_0
    iget-object v0, p1, LBDO;->rz__9J_:Lll11I;

    .line 19
    .line 20
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 21
    .line 22
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 23
    .line 24
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 25
    .line 26
    invoke-static {v0, v2}, LE_Y_mV_;->Q1_f_(Lll11I;LOìJÒ6;)LE_Y_mV_;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-virtual {v0}, LE_Y_mV_;->kCount1402()I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-nez v2, :cond_0

    .line 35
    .line 36
    iget-object v1, p1, LBDO;->JKEoÙX:Lkòè;

    .line 37
    .line 38
    invoke-static {v1}, LPIlDQ;->e8$mp_s$(Lkòè;)LnPos4111;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-virtual {v0}, LE_Y_mV_;->tmpSize211()Lll11I;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    invoke-virtual {v0}, Lll11I;->e8$mp_s$()[B

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-static {v0}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 55
    .line 56
    invoke-static {v1, v0, p1}, LzèOÌz;->oy_R$Xx_(LnPos4111;LkGd_Gk_;Ljava/lang/Integer;)LzèOÌz;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    return-object p1

    .line 61
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 62
    .line 63
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    throw p1
    :try_end_0
    .catch LtbdÀ7Ì; {:try_start_0 .. :try_end_0} :catch_0

    .line 67
    :catch_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 68
    .line 69
    const-string v0, "Parsing XChaCha20Poly1305Key failed"

    .line 70
    .line 71
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    throw p1

    .line 75
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 76
    .line 77
    const-string v0, "Wrong type URL in call to XChaCha20Poly1305ProtoSerialization.parseKey"

    .line 78
    .line 79
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    throw p1

    .line 83
    :sswitch_0
    iget-object v0, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 84
    .line 85
    const-string v2, "type.googleapis.com/google.crypto.tink.AesGcmSivKey"

    .line 86
    .line 87
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_5

    .line 92
    .line 93
    :try_start_1
    iget-object v0, p1, LBDO;->rz__9J_:Lll11I;

    .line 94
    .line 95
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 96
    .line 97
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 98
    .line 99
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 100
    .line 101
    invoke-static {v0, v2}, LvIlll;->Q1_f_(Lll11I;LOìJÒ6;)LvIlll;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    invoke-virtual {v0}, LvIlll;->kCount1402()I

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    if-nez v2, :cond_4

    .line 110
    .line 111
    invoke-virtual {v0}, LvIlll;->tmpSize211()Lll11I;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-virtual {v1}, Lll11I;->tmpData3485()I

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    const/16 v2, 0x10

    .line 120
    .line 121
    if-eq v1, v2, :cond_3

    .line 122
    .line 123
    const/16 v2, 0x20

    .line 124
    .line 125
    if-ne v1, v2, :cond_2

    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_2
    new-instance p1, Ljava/security/InvalidAlgorithmParameterException;

    .line 129
    .line 130
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    const/4 v1, 0x1

    .line 135
    new-array v1, v1, [Ljava/lang/Object;

    .line 136
    .line 137
    const/4 v2, 0x0

    .line 138
    aput-object v0, v1, v2

    .line 139
    .line 140
    const-string v0, "Invalid key size %d; only 16-byte and 32-byte AES keys are supported"

    .line 141
    .line 142
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    invoke-direct {p1, v0}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    throw p1

    .line 150
    :cond_3
    :goto_0
    iget-object v2, p1, LBDO;->JKEoÙX:Lkòè;

    .line 151
    .line 152
    invoke-static {v2}, LvData9200;->e8$mp_s$(Lkòè;)LTa$A4$;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    new-instance v3, LhasKey8276;

    .line 157
    .line 158
    invoke-direct {v3, v1, v2}, LhasKey8276;-><init>(ILTa$A4$;)V

    .line 159
    .line 160
    .line 161
    new-instance v1, LMl;

    .line 162
    .line 163
    const/16 v2, 0x1b

    .line 164
    .line 165
    invoke-direct {v1, v2}, LMl;-><init>(I)V

    .line 166
    .line 167
    .line 168
    iput-object v3, v1, LMl;->vaIue:Ljava/lang/Object;

    .line 169
    .line 170
    invoke-virtual {v0}, LvIlll;->tmpSize211()Lll11I;

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-virtual {v0}, Lll11I;->e8$mp_s$()[B

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    invoke-static {v0}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 179
    .line 180
    .line 181
    move-result-object v0

    .line 182
    iput-object v0, v1, LMl;->jPos3709:Ljava/lang/Object;

    .line 183
    .line 184
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 185
    .line 186
    iput-object p1, v1, LMl;->iOffset934:Ljava/lang/Object;

    .line 187
    .line 188
    invoke-virtual {v1}, LMl;->yPN$A_n$()LCBUP;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    return-object p1

    .line 193
    :cond_4
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 194
    .line 195
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    throw p1
    :try_end_1
    .catch LtbdÀ7Ì; {:try_start_1 .. :try_end_1} :catch_1

    .line 199
    :catch_1
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 200
    .line 201
    const-string v0, "Parsing AesGcmSivKey failed"

    .line 202
    .line 203
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    throw p1

    .line 207
    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 208
    .line 209
    const-string v0, "Wrong type URL in call to AesGcmSivProtoSerialization.parseKey"

    .line 210
    .line 211
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    throw p1

    .line 215
    :sswitch_1
    iget-object v0, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 216
    .line 217
    const-string v2, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    .line 218
    .line 219
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result v0

    .line 223
    if-eqz v0, :cond_9

    .line 224
    .line 225
    :try_start_2
    iget-object v0, p1, LBDO;->rz__9J_:Lll11I;

    .line 226
    .line 227
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 228
    .line 229
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 230
    .line 231
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 232
    .line 233
    invoke-static {v0, v2}, LtLBuO;->Q1_f_(Lll11I;LOìJÒ6;)LtLBuO;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    invoke-virtual {v0}, LtLBuO;->kCount1402()I

    .line 238
    .line 239
    .line 240
    move-result v2

    .line 241
    if-nez v2, :cond_8

    .line 242
    .line 243
    invoke-virtual {v0}, LtLBuO;->tmpSize211()LbIIOID;

    .line 244
    .line 245
    .line 246
    move-result-object v1

    .line 247
    invoke-virtual {v1}, LbIIOID;->kCount1402()I

    .line 248
    .line 249
    .line 250
    move-result v1

    .line 251
    if-nez v1, :cond_7

    .line 252
    .line 253
    invoke-virtual {v0}, LtLBuO;->sKey6064()LOM_o$vs_;

    .line 254
    .line 255
    .line 256
    move-result-object v1

    .line 257
    invoke-virtual {v1}, LOM_o$vs_;->kCount1402()I

    .line 258
    .line 259
    .line 260
    move-result v1

    .line 261
    if-nez v1, :cond_6

    .line 262
    .line 263
    new-instance v1, LIiII11I;

    .line 264
    .line 265
    const/16 v2, 0xc

    .line 266
    .line 267
    invoke-direct {v1, v2}, LIiII11I;-><init>(I)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v0}, LtLBuO;->tmpSize211()LbIIOID;

    .line 271
    .line 272
    .line 273
    move-result-object v2

    .line 274
    invoke-virtual {v2}, LbIIOID;->sKey6064()Lll11I;

    .line 275
    .line 276
    .line 277
    move-result-object v2

    .line 278
    invoke-virtual {v2}, Lll11I;->tmpData3485()I

    .line 279
    .line 280
    .line 281
    move-result v2

    .line 282
    invoke-virtual {v1, v2}, LIiII11I;->gKey4112(I)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v0}, LtLBuO;->sKey6064()LOM_o$vs_;

    .line 286
    .line 287
    .line 288
    move-result-object v2

    .line 289
    invoke-virtual {v2}, LOM_o$vs_;->tzKù7Ol1()Lll11I;

    .line 290
    .line 291
    .line 292
    move-result-object v2

    .line 293
    invoke-virtual {v2}, Lll11I;->tmpData3485()I

    .line 294
    .line 295
    .line 296
    move-result v2

    .line 297
    invoke-virtual {v1, v2}, LIiII11I;->UC_n_(I)V

    .line 298
    .line 299
    .line 300
    invoke-virtual {v0}, LtLBuO;->tmpSize211()LbIIOID;

    .line 301
    .line 302
    .line 303
    move-result-object v2

    .line 304
    invoke-virtual {v2}, LbIIOID;->tmpSize211()LjData2289;

    .line 305
    .line 306
    .line 307
    move-result-object v2

    .line 308
    invoke-virtual {v2}, LjData2289;->kCount1402()I

    .line 309
    .line 310
    .line 311
    move-result v2

    .line 312
    invoke-virtual {v1, v2}, LIiII11I;->$ÒcdS(I)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v0}, LtLBuO;->sKey6064()LOM_o$vs_;

    .line 316
    .line 317
    .line 318
    move-result-object v2

    .line 319
    invoke-virtual {v2}, LOM_o$vs_;->sKey6064()LQll;

    .line 320
    .line 321
    .line 322
    move-result-object v2

    .line 323
    invoke-virtual {v2}, LQll;->kCount1402()I

    .line 324
    .line 325
    .line 326
    move-result v2

    .line 327
    invoke-virtual {v1, v2}, LIiII11I;->tmpSize211(I)V

    .line 328
    .line 329
    .line 330
    invoke-virtual {v0}, LtLBuO;->sKey6064()LOM_o$vs_;

    .line 331
    .line 332
    .line 333
    move-result-object v2

    .line 334
    invoke-virtual {v2}, LOM_o$vs_;->sKey6064()LQll;

    .line 335
    .line 336
    .line 337
    move-result-object v2

    .line 338
    invoke-virtual {v2}, LQll;->$ÒcdS()LhasIndex1121;

    .line 339
    .line 340
    .line 341
    move-result-object v2

    .line 342
    invoke-static {v2}, LUW$4b_A$;->e8$mp_s$(LhasIndex1121;)LXK__E$$1_;

    .line 343
    .line 344
    .line 345
    move-result-object v2

    .line 346
    iput-object v2, v1, LIiII11I;->Ialue:Ljava/lang/Object;

    .line 347
    .line 348
    iget-object v2, p1, LBDO;->JKEoÙX:Lkòè;

    .line 349
    .line 350
    invoke-static {v2}, LUW$4b_A$;->waiBKÀ(Lkòè;)LgOffset1083;

    .line 351
    .line 352
    .line 353
    move-result-object v2

    .line 354
    iput-object v2, v1, LIiII11I;->valuI:Ljava/lang/Object;

    .line 355
    .line 356
    invoke-virtual {v1}, LIiII11I;->ll()L$_V$X_6S$;

    .line 357
    .line 358
    .line 359
    move-result-object v1

    .line 360
    new-instance v2, LIl11l;

    .line 361
    .line 362
    const/16 v3, 0x17

    .line 363
    .line 364
    invoke-direct {v2, v3}, LIl11l;-><init>(I)V

    .line 365
    .line 366
    .line 367
    iput-object v1, v2, LIl11l;->vaIue:Ljava/lang/Object;

    .line 368
    .line 369
    invoke-virtual {v0}, LtLBuO;->tmpSize211()LbIIOID;

    .line 370
    .line 371
    .line 372
    move-result-object v1

    .line 373
    invoke-virtual {v1}, LbIIOID;->sKey6064()Lll11I;

    .line 374
    .line 375
    .line 376
    move-result-object v1

    .line 377
    invoke-virtual {v1}, Lll11I;->e8$mp_s$()[B

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    invoke-static {v1}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 382
    .line 383
    .line 384
    move-result-object v1

    .line 385
    iput-object v1, v2, LIl11l;->jPos3709:Ljava/lang/Object;

    .line 386
    .line 387
    invoke-virtual {v0}, LtLBuO;->sKey6064()LOM_o$vs_;

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    invoke-virtual {v0}, LOM_o$vs_;->tzKù7Ol1()Lll11I;

    .line 392
    .line 393
    .line 394
    move-result-object v0

    .line 395
    invoke-virtual {v0}, Lll11I;->e8$mp_s$()[B

    .line 396
    .line 397
    .line 398
    move-result-object v0

    .line 399
    invoke-static {v0}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 400
    .line 401
    .line 402
    move-result-object v0

    .line 403
    iput-object v0, v2, LIl11l;->iOffset934:Ljava/lang/Object;

    .line 404
    .line 405
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 406
    .line 407
    iput-object p1, v2, LIl11l;->kQy:Ljava/lang/Object;

    .line 408
    .line 409
    invoke-virtual {v2}, LIl11l;->tzKù7Ol1()LUnZmKt;

    .line 410
    .line 411
    .line 412
    move-result-object p1

    .line 413
    return-object p1

    .line 414
    :cond_6
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 415
    .line 416
    const-string v0, "Only version 0 keys inner HMAC keys are accepted"

    .line 417
    .line 418
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 419
    .line 420
    .line 421
    throw p1

    .line 422
    :cond_7
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 423
    .line 424
    const-string v0, "Only version 0 keys inner AES CTR keys are accepted"

    .line 425
    .line 426
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 427
    .line 428
    .line 429
    throw p1

    .line 430
    :cond_8
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 431
    .line 432
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    throw p1
    :try_end_2
    .catch LtbdÀ7Ì; {:try_start_2 .. :try_end_2} :catch_2

    .line 436
    :catch_2
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 437
    .line 438
    const-string v0, "Parsing AesCtrHmacAeadKey failed"

    .line 439
    .line 440
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 441
    .line 442
    .line 443
    throw p1

    .line 444
    :cond_9
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 445
    .line 446
    const-string v0, "Wrong type URL in call to AesCtrHmacAeadProtoSerialization.parseKey"

    .line 447
    .line 448
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 449
    .line 450
    .line 451
    throw p1

    .line 452
    :sswitch_2
    const-string v0, "KmsEnvelopeAeadKeys are only accepted with version 0, got "

    .line 453
    .line 454
    iget-object v1, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 455
    .line 456
    const-string v2, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    .line 457
    .line 458
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 459
    .line 460
    .line 461
    move-result v1

    .line 462
    if-eqz v1, :cond_b

    .line 463
    .line 464
    :try_start_3
    iget-object v1, p1, LBDO;->rz__9J_:Lll11I;

    .line 465
    .line 466
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 467
    .line 468
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 469
    .line 470
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 471
    .line 472
    invoke-static {v1, v2}, LtmpCount1788;->Q1_f_(Lll11I;LOìJÒ6;)LtmpCount1788;

    .line 473
    .line 474
    .line 475
    move-result-object v1

    .line 476
    invoke-virtual {v1}, LtmpCount1788;->kCount1402()I

    .line 477
    .line 478
    .line 479
    move-result v2

    .line 480
    if-nez v2, :cond_a

    .line 481
    .line 482
    invoke-virtual {v1}, LtmpCount1788;->tmpSize211()LgSize7297;

    .line 483
    .line 484
    .line 485
    move-result-object v0

    .line 486
    iget-object v1, p1, LBDO;->JKEoÙX:Lkòè;

    .line 487
    .line 488
    invoke-static {v0, v1}, Lf53$O$;->e8$mp_s$(LgSize7297;Lkòè;)LSXX$fW$;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 493
    .line 494
    invoke-static {v0, p1}, LaQ00Il;->oy_R$Xx_(LSXX$fW$;Ljava/lang/Integer;)LaQ00Il;

    .line 495
    .line 496
    .line 497
    move-result-object p1

    .line 498
    return-object p1

    .line 499
    :catch_3
    move-exception p1

    .line 500
    goto :goto_1

    .line 501
    :cond_a
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 502
    .line 503
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 504
    .line 505
    .line 506
    move-result-object v1

    .line 507
    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 508
    .line 509
    .line 510
    move-result-object v0

    .line 511
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 512
    .line 513
    .line 514
    throw p1
    :try_end_3
    .catch LtbdÀ7Ì; {:try_start_3 .. :try_end_3} :catch_3

    .line 515
    :goto_1
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 516
    .line 517
    const-string v1, "Parsing KmsEnvelopeAeadKey failed: "

    .line 518
    .line 519
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 520
    .line 521
    .line 522
    throw v0

    .line 523
    :cond_b
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 524
    .line 525
    const-string v0, "Wrong type URL in call to LegacyKmsEnvelopeAeadProtoSerialization.parseKey"

    .line 526
    .line 527
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    throw p1

    .line 531
    :sswitch_data_0
    .sparse-switch
        0xd -> :sswitch_2
        0xf -> :sswitch_1
        0x13 -> :sswitch_0
    .end sparse-switch
.end method

.method public Q1_f_(ZLandroid/content/Context;Lcz$Y$;)V
    .locals 0

    .line 1
    return-void
.end method

.method public e8$mp_s$()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LuXVÌJÒ;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    .line 9
    .line 10
    .line 11
    throw v0

    .line 12
    :pswitch_0
    new-instance v0, Landroid/os/HandlerThread;

    .line 13
    .line 14
    const-string v1, "OverlayDisplayService"

    .line 15
    .line 16
    const/16 v2, 0xa

    .line 17
    .line 18
    invoke-direct {v0, v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 22
    .line 23
    .line 24
    new-instance v1, Landroid/os/Handler;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 31
    .line 32
    .line 33
    return-object v1

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x7
        :pswitch_0
    .end packed-switch
.end method

.method public kQy(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LuXVÌJÒ;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LIIi1ll;

    .line 7
    .line 8
    invoke-interface {p1}, LIIi1ll;->rz__9J_()V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    check-cast p1, LTh_X$2_;

    .line 13
    .line 14
    invoke-interface {p1}, LTh_X$2_;->tmpData3485()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_1
    check-cast p1, LisIndex2213;

    .line 19
    .line 20
    invoke-interface {p1}, LisIndex2213;->e8$mp_s$()V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    nop

    .line 25
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public rz__9J_(LPni$zp$;)LnPos7306;
    .locals 3

    .line 1
    iget v0, p0, LuXVÌJÒ;->yON3x:I

    .line 2
    .line 3
    const-string v1, "Only version 0 parameters are accepted"

    .line 4
    .line 5
    sparse-switch v0, :sswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 9
    .line 10
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v1, "type.googleapis.com/google.crypto.tink.HmacKey"

    .line 15
    .line 16
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :try_start_0
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sget-object v1, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 27
    .line 28
    sget-object v1, LLKmiA;->rz__9J_:LLKmiA;

    .line 29
    .line 30
    sget-object v1, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 31
    .line 32
    invoke-static {v0, v1}, LWasIjTc;->sKey6064(Lll11I;LOìJÒ6;)LWasIjTc;

    .line 33
    .line 34
    .line 35
    move-result-object v0
    :try_end_0
    .catch LtbdÀ7Ì; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    invoke-virtual {v0}, LWasIjTc;->$ÒcdS()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    if-nez v1, :cond_0

    .line 41
    .line 42
    new-instance v1, LIl11l;

    .line 43
    .line 44
    const/16 v2, 0x19

    .line 45
    .line 46
    invoke-direct {v1, v2}, LIl11l;-><init>(I)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, LWasIjTc;->kCount1402()I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    invoke-virtual {v1, v2}, LIl11l;->K0I(I)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v0}, LWasIjTc;->tzKù7Ol1()LQll;

    .line 57
    .line 58
    .line 59
    move-result-object v2

    .line 60
    invoke-virtual {v2}, LQll;->kCount1402()I

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    invoke-virtual {v1, v2}, LIl11l;->kCount1402(I)V

    .line 65
    .line 66
    .line 67
    sget-object v2, LTW$mG_5$;->waiBKÀ:LVF$4t_2$;

    .line 68
    .line 69
    invoke-virtual {v0}, LWasIjTc;->tzKù7Ol1()LQll;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v0}, LQll;->$ÒcdS()LhasIndex1121;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    invoke-virtual {v2, v0}, LVF$4t_2$;->rz__9J_(Ljava/lang/Enum;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v0

    .line 81
    check-cast v0, LFER_Ag$V_;

    .line 82
    .line 83
    iput-object v0, v1, LIl11l;->iOffset934:Ljava/lang/Object;

    .line 84
    .line 85
    sget-object v0, LTW$mG_5$;->e8$mp_s$:LVF$4t_2$;

    .line 86
    .line 87
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    invoke-virtual {v0, p1}, LVF$4t_2$;->rz__9J_(Ljava/lang/Enum;)Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, LxsQmI;

    .line 96
    .line 97
    iput-object p1, v1, LIl11l;->kQy:Ljava/lang/Object;

    .line 98
    .line 99
    invoke-virtual {v1}, LIl11l;->oy_R$Xx_()L_lQ0D;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    return-object p1

    .line 104
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 105
    .line 106
    invoke-virtual {v0}, LWasIjTc;->$ÒcdS()I

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    const-string v1, "Parsing HmacParameters failed: unknown Version "

    .line 111
    .line 112
    invoke-static {v0, v1}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    throw p1

    .line 120
    :catch_0
    move-exception p1

    .line 121
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 122
    .line 123
    const-string v1, "Parsing HmacParameters failed: "

    .line 124
    .line 125
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 126
    .line 127
    .line 128
    throw v0

    .line 129
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 130
    .line 131
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object p1

    .line 135
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    const-string v1, "Wrong type URL in call to HmacProtoSerialization.parseParameters: "

    .line 140
    .line 141
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    throw v0

    .line 149
    :sswitch_0
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 150
    .line 151
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    const-string v2, "type.googleapis.com/google.crypto.tink.XAesGcmKey"

    .line 156
    .line 157
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 158
    .line 159
    .line 160
    move-result v0

    .line 161
    if-eqz v0, :cond_3

    .line 162
    .line 163
    :try_start_1
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 168
    .line 169
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 170
    .line 171
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 172
    .line 173
    invoke-static {v0, v2}, LNlQ;->Q1_f_(Lll11I;LOìJÒ6;)LNlQ;

    .line 174
    .line 175
    .line 176
    move-result-object v0
    :try_end_1
    .catch LtbdÀ7Ì; {:try_start_1 .. :try_end_1} :catch_1

    .line 177
    invoke-virtual {v0}, LNlQ;->kCount1402()I

    .line 178
    .line 179
    .line 180
    move-result v2

    .line 181
    if-nez v2, :cond_2

    .line 182
    .line 183
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    invoke-static {p1}, LeeNl2èPO;->e8$mp_s$(Lkòè;)LIIII;

    .line 188
    .line 189
    .line 190
    move-result-object p1

    .line 191
    invoke-virtual {v0}, LNlQ;->tmpSize211()LBE$Yk$;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    invoke-virtual {v0}, LBE$Yk$;->kCount1402()I

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    invoke-static {p1, v0}, LL1QIl;->waiBKÀ(LIIII;I)LL1QIl;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    return-object p1

    .line 204
    :cond_2
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 205
    .line 206
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    throw p1

    .line 210
    :catch_1
    move-exception p1

    .line 211
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 212
    .line 213
    const-string v1, "Parsing XAesGcmParameters failed: "

    .line 214
    .line 215
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 216
    .line 217
    .line 218
    throw v0

    .line 219
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 220
    .line 221
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 226
    .line 227
    .line 228
    move-result-object p1

    .line 229
    const-string v1, "Wrong type URL in call to XAesGcmProtoSerialization.parseParameters: "

    .line 230
    .line 231
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object p1

    .line 235
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    throw v0

    .line 239
    :sswitch_1
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 240
    .line 241
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object v0

    .line 245
    const-string v2, "type.googleapis.com/google.crypto.tink.AesGcmKey"

    .line 246
    .line 247
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v0

    .line 251
    if-eqz v0, :cond_5

    .line 252
    .line 253
    :try_start_2
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 254
    .line 255
    .line 256
    move-result-object v0

    .line 257
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 258
    .line 259
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 260
    .line 261
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 262
    .line 263
    invoke-static {v0, v2}, LvKey3916;->tmpSize211(Lll11I;LOìJÒ6;)LvKey3916;

    .line 264
    .line 265
    .line 266
    move-result-object v0
    :try_end_2
    .catch LtbdÀ7Ì; {:try_start_2 .. :try_end_2} :catch_2

    .line 267
    invoke-virtual {v0}, LvKey3916;->$ÒcdS()I

    .line 268
    .line 269
    .line 270
    move-result v2

    .line 271
    if-nez v2, :cond_4

    .line 272
    .line 273
    new-instance v1, LIl11l;

    .line 274
    .line 275
    const/16 v2, 0x18

    .line 276
    .line 277
    invoke-direct {v1, v2}, LIl11l;-><init>(I)V

    .line 278
    .line 279
    .line 280
    invoke-virtual {v0}, LvKey3916;->kCount1402()I

    .line 281
    .line 282
    .line 283
    move-result v0

    .line 284
    invoke-virtual {v1, v0}, LIl11l;->K0I(I)V

    .line 285
    .line 286
    .line 287
    invoke-virtual {v1}, LIl11l;->e8$mp_s$()V

    .line 288
    .line 289
    .line 290
    invoke-virtual {v1}, LIl11l;->Qp_Hp$i_()V

    .line 291
    .line 292
    .line 293
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 294
    .line 295
    .line 296
    move-result-object p1

    .line 297
    invoke-static {p1}, LvKey4797;->e8$mp_s$(Lkòè;)LnPos4111;

    .line 298
    .line 299
    .line 300
    move-result-object p1

    .line 301
    iput-object p1, v1, LIl11l;->kQy:Ljava/lang/Object;

    .line 302
    .line 303
    invoke-virtual {v1}, LIl11l;->ll()Lh1OO;

    .line 304
    .line 305
    .line 306
    move-result-object p1

    .line 307
    return-object p1

    .line 308
    :cond_4
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 309
    .line 310
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 311
    .line 312
    .line 313
    throw p1

    .line 314
    :catch_2
    move-exception p1

    .line 315
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 316
    .line 317
    const-string v1, "Parsing AesGcmParameters failed: "

    .line 318
    .line 319
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 320
    .line 321
    .line 322
    throw v0

    .line 323
    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 324
    .line 325
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object p1

    .line 329
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 330
    .line 331
    .line 332
    move-result-object p1

    .line 333
    const-string v1, "Wrong type URL in call to AesGcmProtoSerialization.parseParameters: "

    .line 334
    .line 335
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 336
    .line 337
    .line 338
    move-result-object p1

    .line 339
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 340
    .line 341
    .line 342
    throw v0

    .line 343
    :sswitch_2
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 344
    .line 345
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 346
    .line 347
    .line 348
    move-result-object v0

    .line 349
    const-string v1, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    .line 350
    .line 351
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 352
    .line 353
    .line 354
    move-result v0

    .line 355
    if-eqz v0, :cond_6

    .line 356
    .line 357
    :try_start_3
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 358
    .line 359
    .line 360
    move-result-object v0

    .line 361
    sget-object v1, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 362
    .line 363
    sget-object v1, LLKmiA;->rz__9J_:LLKmiA;

    .line 364
    .line 365
    sget-object v1, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 366
    .line 367
    invoke-static {v0, v1}, LnItem6218;->Q1_f_(Lll11I;LOìJÒ6;)LnItem6218;

    .line 368
    .line 369
    .line 370
    move-result-object v0
    :try_end_3
    .catch LtbdÀ7Ì; {:try_start_3 .. :try_end_3} :catch_3

    .line 371
    invoke-virtual {v0}, LnItem6218;->tmpSize211()Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 376
    .line 377
    .line 378
    move-result-object p1

    .line 379
    invoke-static {p1}, LMSEqVZ;->e8$mp_s$(Lkòè;)LwYm_BE$mL_;

    .line 380
    .line 381
    .line 382
    move-result-object p1

    .line 383
    new-instance v1, LjValue555;

    .line 384
    .line 385
    invoke-direct {v1, v0, p1}, LjValue555;-><init>(Ljava/lang/String;LwYm_BE$mL_;)V

    .line 386
    .line 387
    .line 388
    return-object v1

    .line 389
    :catch_3
    move-exception p1

    .line 390
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 391
    .line 392
    const-string v1, "Parsing KmsAeadKeyFormat failed: "

    .line 393
    .line 394
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 395
    .line 396
    .line 397
    throw v0

    .line 398
    :cond_6
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 399
    .line 400
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 401
    .line 402
    .line 403
    move-result-object p1

    .line 404
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 405
    .line 406
    .line 407
    move-result-object p1

    .line 408
    const-string v1, "Wrong type URL in call to LegacyKmsAeadProtoSerialization.parseParameters: "

    .line 409
    .line 410
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 411
    .line 412
    .line 413
    move-result-object p1

    .line 414
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 415
    .line 416
    .line 417
    throw v0

    .line 418
    nop

    .line 419
    :sswitch_data_0
    .sparse-switch
        0xb -> :sswitch_2
        0x11 -> :sswitch_1
        0x15 -> :sswitch_0
    .end sparse-switch
.end method

.method public sKey7917(LGIlO;)Ljava/lang/Object;
    .locals 0

    .line 1
    invoke-virtual {p1}, LGIlO;->tmpData3485()Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    return-object p1
.end method

.method public bridge synthetic tmpData3485(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .locals 0

    .line 1
    if-nez p2, :cond_0

    .line 2
    .line 3
    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1

    .line 8
    :cond_0
    invoke-static {p1, p2}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyFactory;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    return-object p1
.end method

.method public waiBKÀ(LvB$7$;)LBDO;
    .locals 4

    iget v0, p0, LuXVÌJÒ;->yON3x:I

    sparse-switch v0, :sswitch_data_0

    check-cast p1, LtmpSize266;

    .line 68
    invoke-static {}, LnKey6895;->$ÒcdS()Lfs_g_;

    move-result-object v0

    .line 69
    iget-object v1, p1, LtmpSize266;->BCIm:LA_g_b$CS_;

    .line 70
    invoke-static {}, LtmpIndex5460;->$ÒcdS()LOKHSJQG;

    move-result-object v2

    .line 71
    iget v1, v1, LA_g_b$CS_;->waiBKÀ:I

    .line 72
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 73
    iget-object v3, v2, Lw1I;->vaIue:LHU$B$;

    .line 74
    check-cast v3, LtmpIndex5460;

    invoke-static {v3, v1}, LtmpIndex5460;->tmpSize211(LtmpIndex5460;I)V

    .line 75
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v1

    check-cast v1, LtmpIndex5460;

    .line 76
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 77
    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 78
    check-cast v2, LnKey6895;

    invoke-static {v2, v1}, LnKey6895;->oy_R$Xx_(LnKey6895;LtmpIndex5460;)V

    .line 79
    iget-object v1, p1, LtmpSize266;->zAt$p:LkGd_Gk_;

    .line 80
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 81
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 82
    array-length v2, v1

    const/4 v3, 0x0

    .line 83
    invoke-static {v1, v3, v2}, Lll11I;->yàÒZ([BII)LDtc_7t_;

    move-result-object v1

    .line 84
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 85
    check-cast v2, LnKey6895;

    invoke-static {v2, v1}, LnKey6895;->ll(LnKey6895;LDtc_7t_;)V

    .line 86
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LnKey6895;

    .line 87
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    .line 88
    iget-object v1, p1, LtmpSize266;->BCIm:LA_g_b$CS_;

    .line 89
    iget-object v1, v1, LA_g_b$CS_;->rz__9J_:LTa$A4$;

    .line 90
    invoke-static {v1}, LqB_y0$j_;->waiBKÀ(LTa$A4$;)Lkòè;

    move-result-object v1

    .line 91
    iget-object p1, p1, LtmpSize266;->iSize4906:Ljava/lang/Integer;

    .line 92
    const-string v2, "type.googleapis.com/google.crypto.tink.AesCmacKey"

    const/4 v3, 0x2

    .line 93
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    .line 94
    :sswitch_0
    check-cast p1, LgValue5267;

    .line 95
    invoke-static {}, LvSize1769;->$ÒcdS()LKÌDig;

    move-result-object v0

    .line 96
    iget-object v1, p1, LgValue5267;->zAt$p:LkGd_Gk_;

    .line 97
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 98
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 99
    array-length v2, v1

    const/4 v3, 0x0

    .line 100
    invoke-static {v1, v3, v2}, Lll11I;->yàÒZ([BII)LDtc_7t_;

    move-result-object v1

    .line 101
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 102
    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 103
    check-cast v2, LvSize1769;

    invoke-static {v2, v1}, LvSize1769;->tzKù7Ol1(LvSize1769;LDtc_7t_;)V

    .line 104
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LvSize1769;

    .line 105
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    .line 106
    iget-object v1, p1, LgValue5267;->BCIm:LBI;

    .line 107
    iget-object v1, v1, LBI;->e8$mp_s$:LgOffset2847;

    .line 108
    invoke-static {v1}, LozFAqI;->waiBKÀ(LgOffset2847;)Lkòè;

    move-result-object v1

    .line 109
    iget-object p1, p1, LgValue5267;->iSize4906:Ljava/lang/Integer;

    .line 110
    const-string v2, "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key"

    const/4 v3, 0x2

    .line 111
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    .line 112
    :sswitch_1
    check-cast p1, LHllD;

    .line 113
    invoke-static {}, LvSize7856;->$ÒcdS()LHIlIOI;

    move-result-object v0

    .line 114
    iget-object v1, p1, LHllD;->BCIm:LIx_OW_;

    .line 115
    invoke-static {}, LSQI;->$ÒcdS()LfO_T_;

    move-result-object v2

    .line 116
    iget v1, v1, LIx_OW_;->waiBKÀ:I

    .line 117
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 118
    iget-object v3, v2, Lw1I;->vaIue:LHU$B$;

    .line 119
    check-cast v3, LSQI;

    invoke-static {v3, v1}, LSQI;->tmpSize211(LSQI;I)V

    .line 120
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v1

    check-cast v1, LSQI;

    .line 121
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 122
    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 123
    check-cast v2, LvSize7856;

    invoke-static {v2, v1}, LvSize7856;->oy_R$Xx_(LvSize7856;LSQI;)V

    .line 124
    iget-object v1, p1, LHllD;->zAt$p:LkGd_Gk_;

    .line 125
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 126
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 127
    array-length v2, v1

    const/4 v3, 0x0

    .line 128
    invoke-static {v1, v3, v2}, Lll11I;->yàÒZ([BII)LDtc_7t_;

    move-result-object v1

    .line 129
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 130
    check-cast v2, LvSize7856;

    invoke-static {v2, v1}, LvSize7856;->ll(LvSize7856;LDtc_7t_;)V

    .line 131
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LvSize7856;

    .line 132
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    .line 133
    iget-object v1, p1, LHllD;->BCIm:LIx_OW_;

    .line 134
    iget-object v1, v1, LIx_OW_;->rz__9J_:LIIII;

    .line 135
    invoke-static {v1}, LvDmnuNT;->waiBKÀ(LIIII;)Lkòè;

    move-result-object v1

    .line 136
    iget-object p1, p1, LHllD;->iSize4906:Ljava/lang/Integer;

    .line 137
    const-string v2, "type.googleapis.com/google.crypto.tink.AesEaxKey"

    const/4 v3, 0x2

    .line 138
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    nop

    :sswitch_data_0
    .sparse-switch
        0x10 -> :sswitch_1
        0x14 -> :sswitch_0
    .end sparse-switch
.end method

.method public waiBKÀ(LvB$7$;)Ljava/lang/Object;
    .locals 8

    iget v0, p0, LuXVÌJÒ;->yON3x:I

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    sparse-switch v0, :sswitch_data_0

    check-cast p1, LfDXÙ6Z1ih;

    .line 1
    iget-object p1, p1, LfDXÙ6Z1ih;->BCIm:LBDO;

    .line 2
    sget-object v0, LRo_4_;->waiBKÀ:[I

    .line 3
    iget v5, p1, LBDO;->POOl:I

    iget-object v6, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 4
    invoke-static {v5}, LBRK_m_;->UC_n_(I)I

    move-result v5

    aget v0, v0, v5

    .line 5
    invoke-static {}, LcB_9A$V_;->kCount1402()Ld3w_Tj$C_;

    move-result-object v0

    .line 6
    iget-object v5, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 7
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 8
    iget-object v7, v0, Lw1I;->vaIue:LHU$B$;

    .line 9
    check-cast v7, LcB_9A$V_;

    invoke-static {v7, v5}, LcB_9A$V_;->ll(LcB_9A$V_;Ljava/lang/String;)V

    .line 10
    iget-object v5, p1, LBDO;->rz__9J_:Lll11I;

    .line 11
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v7, v0, Lw1I;->vaIue:LHU$B$;

    .line 12
    check-cast v7, LcB_9A$V_;

    invoke-static {v7, v5}, LcB_9A$V_;->oy_R$Xx_(LcB_9A$V_;Lll11I;)V

    .line 13
    iget v5, p1, LBDO;->POOl:I

    .line 14
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v7, v0, Lw1I;->vaIue:LHU$B$;

    .line 15
    check-cast v7, LcB_9A$V_;

    invoke-static {v7, v5}, LcB_9A$V_;->tzKù7Ol1(LcB_9A$V_;I)V

    .line 16
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LcB_9A$V_;

    const-class v5, LsLt4;

    .line 17
    invoke-static {v0, v5}, LoM_a$AW_;->e8$mp_s$(LcB_9A$V_;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 18
    check-cast v0, LsLt4;

    .line 19
    iget-object p1, p1, LBDO;->JKEoÙX:Lkòè;

    .line 20
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-eq p1, v4, :cond_3

    if-eq p1, v3, :cond_2

    if-eq p1, v2, :cond_1

    if-ne p1, v1, :cond_0

    goto :goto_0

    .line 21
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "unknown output prefix type"

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 22
    :cond_1
    sget-object p1, Lpm$Dd$;->e8$mp_s$:LrlI;

    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    goto :goto_1

    .line 23
    :cond_2
    :goto_0
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lpm$Dd$;->e8$mp_s$(I)LrlI;

    move-result-object p1

    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    goto :goto_1

    .line 24
    :cond_3
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lpm$Dd$;->waiBKÀ(I)LrlI;

    move-result-object p1

    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    :goto_1
    new-instance p1, Lf1D;

    .line 25
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    return-object p1

    .line 26
    :sswitch_0
    check-cast p1, LtmpSize266;

    .line 27
    iget-object v0, p1, LtmpSize266;->BCIm:LA_g_b$CS_;

    .line 28
    iget v0, v0, LA_g_b$CS_;->e8$mp_s$:I

    const/16 v1, 0x20

    if-ne v0, v1, :cond_4

    .line 29
    new-instance v0, LBÌ7Sì;

    invoke-direct {v0, p1}, LBÌ7Sì;-><init>(LtmpSize266;)V

    return-object v0

    .line 30
    :cond_4
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "AesCmacKey size wrong, must be 32 bytes"

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 31
    :sswitch_1
    check-cast p1, LlO_q_;

    sget-object v0, LoI1;->e8$mp_s$:L$òuj;

    .line 32
    iget-object p1, p1, LlO_q_;->BCIm:LjValue555;

    .line 33
    iget-object p1, p1, LjValue555;->e8$mp_s$:Ljava/lang/String;

    .line 34
    invoke-static {p1}, LpswIHQfiW;->e8$mp_s$(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    .line 35
    :sswitch_2
    check-cast p1, LsValue8721;

    .line 36
    new-instance v0, LI1I1l;

    .line 37
    iget-object v1, p1, LsValue8721;->zAt$p:LkGd_Gk_;

    .line 38
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 39
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 40
    iget-object p1, p1, LsValue8721;->gSy_FG$D_:LrlI;

    .line 41
    invoke-direct {v0, v1, p1}, LI1I1l;-><init>([BLrlI;)V

    return-object v0

    .line 42
    :sswitch_3
    check-cast p1, LfDXÙ6Z1ih;

    .line 43
    iget-object p1, p1, LfDXÙ6Z1ih;->BCIm:LBDO;

    .line 44
    sget-object v0, LRo_4_;->waiBKÀ:[I

    .line 45
    iget v5, p1, LBDO;->POOl:I

    iget-object v6, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 46
    invoke-static {v5}, LBRK_m_;->UC_n_(I)I

    move-result v5

    aget v0, v0, v5

    .line 47
    invoke-static {}, LcB_9A$V_;->kCount1402()Ld3w_Tj$C_;

    move-result-object v0

    .line 48
    iget-object v5, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 49
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 50
    iget-object v7, v0, Lw1I;->vaIue:LHU$B$;

    .line 51
    check-cast v7, LcB_9A$V_;

    invoke-static {v7, v5}, LcB_9A$V_;->ll(LcB_9A$V_;Ljava/lang/String;)V

    .line 52
    iget-object v5, p1, LBDO;->rz__9J_:Lll11I;

    .line 53
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v7, v0, Lw1I;->vaIue:LHU$B$;

    .line 54
    check-cast v7, LcB_9A$V_;

    invoke-static {v7, v5}, LcB_9A$V_;->oy_R$Xx_(LcB_9A$V_;Lll11I;)V

    .line 55
    iget v5, p1, LBDO;->POOl:I

    .line 56
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v7, v0, Lw1I;->vaIue:LHU$B$;

    .line 57
    check-cast v7, LcB_9A$V_;

    invoke-static {v7, v5}, LcB_9A$V_;->tzKù7Ol1(LcB_9A$V_;I)V

    .line 58
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LcB_9A$V_;

    const-class v5, Lfòei;

    .line 59
    invoke-static {v0, v5}, LoM_a$AW_;->e8$mp_s$(LcB_9A$V_;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v0

    .line 60
    check-cast v0, Lfòei;

    .line 61
    iget-object p1, p1, LBDO;->JKEoÙX:Lkòè;

    .line 62
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    if-eq v5, v4, :cond_8

    if-eq v5, v3, :cond_7

    if-eq v5, v2, :cond_6

    if-ne v5, v1, :cond_5

    goto :goto_2

    .line 63
    :cond_5
    new-instance v0, Ljava/security/GeneralSecurityException;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string v1, "unknown output prefix type "

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 64
    :cond_6
    sget-object p1, Lpm$Dd$;->e8$mp_s$:LrlI;

    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    move-result-object p1

    goto :goto_3

    .line 65
    :cond_7
    :goto_2
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lpm$Dd$;->e8$mp_s$(I)LrlI;

    move-result-object p1

    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    move-result-object p1

    goto :goto_3

    .line 66
    :cond_8
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result p1

    invoke-static {p1}, Lpm$Dd$;->waiBKÀ(I)LrlI;

    move-result-object p1

    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    move-result-object p1

    :goto_3
    new-instance v1, LI1I1l;

    .line 67
    invoke-direct {v1, v0, p1}, LI1I1l;-><init>(Lfòei;[B)V

    return-object v1

    nop

    :sswitch_data_0
    .sparse-switch
        0x8 -> :sswitch_3
        0x9 -> :sswitch_2
        0xa -> :sswitch_1
        0x18 -> :sswitch_0
    .end sparse-switch
.end method
