.class public final LOÈzTLM;
.super LIQ;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public iOffset934:J


# virtual methods
.method public final DDù8(LZN$P$;Ljava/util/List;)V
    .locals 6

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    if-nez p2, :cond_0

    .line 7
    .line 8
    goto :goto_1

    .line 9
    :cond_0
    invoke-interface {p2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    :cond_1
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    if-eqz v2, :cond_2

    .line 18
    .line 19
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    check-cast v2, LBDQ1;

    .line 24
    .line 25
    const-string v3, "include"

    .line 26
    .line 27
    iget-object v4, v2, LBDQ1;->e8$mp_s$:Ljava/lang/String;

    .line 28
    .line 29
    invoke-virtual {v3, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 30
    .line 31
    .line 32
    move-result v3

    .line 33
    if-nez v3, :cond_1

    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    goto :goto_0

    .line 39
    :cond_2
    :goto_1
    new-instance v1, LoOx_YC_;

    .line 40
    .line 41
    const/4 v2, 0x0

    .line 42
    invoke-direct {v1, v2}, LoOx_YC_;-><init>(I)V

    .line 43
    .line 44
    .line 45
    iget-object v2, p0, LIQ;->vaIue:LZN$P$;

    .line 46
    .line 47
    invoke-virtual {v1, v2}, LIQ;->waiBKÀ(LZN$P$;)V

    .line 48
    .line 49
    .line 50
    iget-object v2, p0, LIQ;->vaIue:LZN$P$;

    .line 51
    .line 52
    invoke-static {v2}, LplQQD0;->waiBKÀ(LZN$P$;)LtmpPos8215;

    .line 53
    .line 54
    .line 55
    move-result-object v2

    .line 56
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    new-instance v3, LtmpPos8215;

    .line 60
    .line 61
    invoke-direct {v3}, LtmpPos8215;-><init>()V

    .line 62
    .line 63
    .line 64
    iget-object v4, v2, LtmpPos8215;->iOffset934:Ljava/net/URL;

    .line 65
    .line 66
    iput-object v4, v3, LtmpPos8215;->iOffset934:Ljava/net/URL;

    .line 67
    .line 68
    new-instance v4, Ljava/util/ArrayList;

    .line 69
    .line 70
    iget-object v5, v2, LtmpPos8215;->kQy:Ljava/util/ArrayList;

    .line 71
    .line 72
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 73
    .line 74
    .line 75
    iput-object v4, v3, LtmpPos8215;->kQy:Ljava/util/ArrayList;

    .line 76
    .line 77
    new-instance v4, Ljava/util/ArrayList;

    .line 78
    .line 79
    iget-object v2, v2, LtmpPos8215;->Ialue:Ljava/util/ArrayList;

    .line 80
    .line 81
    invoke-direct {v4, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 82
    .line 83
    .line 84
    iput-object v4, v3, LtmpPos8215;->Ialue:Ljava/util/ArrayList;

    .line 85
    .line 86
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    if-eqz v2, :cond_3

    .line 91
    .line 92
    const-string p1, "No previous configuration to fall back on."

    .line 93
    .line 94
    invoke-virtual {p0, p1}, LIQ;->sKey7917(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :cond_3
    const-string v2, "Given previous errors, falling back to previously registered safe configuration."

    .line 99
    .line 100
    invoke-virtual {p0, v2}, LIQ;->sKey7917(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    :try_start_0
    invoke-virtual {p1}, LZN$P$;->JKEoÙX()V

    .line 104
    .line 105
    .line 106
    iget-object p1, p0, LIQ;->vaIue:LZN$P$;

    .line 107
    .line 108
    const-string v2, "CONFIGURATION_WATCH_LIST"

    .line 109
    .line 110
    invoke-virtual {p1, v2, v3}, LZN$P$;->POOl(Ljava/lang/String;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v1, v0}, LoOx_YC_;->jPos3709(Ljava/util/List;)V

    .line 114
    .line 115
    .line 116
    const-string p1, "Re-registering previous fallback configuration once more as a fallback configuration point"

    .line 117
    .line 118
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    iget-object p1, v1, LIQ;->vaIue:LZN$P$;

    .line 122
    .line 123
    const-string v0, "SAFE_JORAN_CONFIGURATION"

    .line 124
    .line 125
    invoke-virtual {p1, v0, p2}, LZN$P$;->POOl(Ljava/lang/String;Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    new-instance p1, Ljava/lang/StringBuilder;

    .line 129
    .line 130
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 131
    .line 132
    .line 133
    const-string v0, "after registerSafeConfiguration: "

    .line 134
    .line 135
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V
    :try_end_0
    .catch LOD; {:try_start_0 .. :try_end_0} :catch_0

    .line 146
    .line 147
    .line 148
    return-void

    .line 149
    :catch_0
    move-exception p1

    .line 150
    const-string p2, "Unexpected exception thrown by a configuration considered safe."

    .line 151
    .line 152
    invoke-virtual {p0, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 153
    .line 154
    .line 155
    return-void
.end method

.method public final run()V
    .locals 9

    .line 1
    iget-object v0, p0, LIQ;->vaIue:LZN$P$;

    .line 2
    .line 3
    invoke-static {v0}, LplQQD0;->waiBKÀ(LZN$P$;)LtmpPos8215;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    const-string v0, "Empty ConfigurationWatchList in context"

    .line 10
    .line 11
    invoke-virtual {p0, v0}, LIQ;->sKey7917(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    new-instance v1, Ljava/util/ArrayList;

    .line 16
    .line 17
    iget-object v2, v0, LtmpPos8215;->kQy:Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    const-string v0, "Empty watch file list. Disabling "

    .line 29
    .line 30
    invoke-virtual {p0, v0}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_1
    iget-object v1, v0, LtmpPos8215;->kQy:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    const/4 v2, 0x0

    .line 41
    const/4 v3, 0x0

    .line 42
    :goto_0
    if-ge v3, v1, :cond_6

    .line 43
    .line 44
    iget-object v4, v0, LtmpPos8215;->Ialue:Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v4

    .line 50
    check-cast v4, Ljava/lang/Long;

    .line 51
    .line 52
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 53
    .line 54
    .line 55
    move-result-wide v4

    .line 56
    iget-object v6, v0, LtmpPos8215;->kQy:Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v6

    .line 62
    check-cast v6, Ljava/io/File;

    .line 63
    .line 64
    invoke-virtual {v6}, Ljava/io/File;->lastModified()J

    .line 65
    .line 66
    .line 67
    move-result-wide v6

    .line 68
    cmp-long v8, v4, v6

    .line 69
    .line 70
    if-eqz v8, :cond_5

    .line 71
    .line 72
    iget-object v0, v0, LtmpPos8215;->iOffset934:Ljava/net/URL;

    .line 73
    .line 74
    const-string v1, "Detected change in configuration files."

    .line 75
    .line 76
    invoke-virtual {p0, v1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    new-instance v1, Ljava/lang/StringBuilder;

    .line 80
    .line 81
    const-string v3, "Will reset and reconfigure context named ["

    .line 82
    .line 83
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    iget-object v3, p0, LIQ;->vaIue:LZN$P$;

    .line 87
    .line 88
    iget-object v3, v3, LZN$P$;->vaIue:Ljava/lang/String;

    .line 89
    .line 90
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    const-string v3, "]"

    .line 94
    .line 95
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    move-result-object v1

    .line 102
    invoke-virtual {p0, v1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    iget-object v1, p0, LIQ;->vaIue:LZN$P$;

    .line 106
    .line 107
    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v3

    .line 111
    const-string v4, "xml"

    .line 112
    .line 113
    invoke-virtual {v3, v4}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 114
    .line 115
    .line 116
    move-result v3

    .line 117
    if-eqz v3, :cond_4

    .line 118
    .line 119
    new-instance v3, LoOx_YC_;

    .line 120
    .line 121
    const/4 v4, 0x0

    .line 122
    invoke-direct {v3, v4}, LoOx_YC_;-><init>(I)V

    .line 123
    .line 124
    .line 125
    iget-object v4, p0, LIQ;->vaIue:LZN$P$;

    .line 126
    .line 127
    invoke-virtual {v3, v4}, LIQ;->waiBKÀ(LZN$P$;)V

    .line 128
    .line 129
    .line 130
    iget-object v4, p0, LIQ;->vaIue:LZN$P$;

    .line 131
    .line 132
    iget-object v4, v4, LZN$P$;->jPos3709:LZID1;

    .line 133
    .line 134
    iget-object v5, v3, LIQ;->vaIue:LZN$P$;

    .line 135
    .line 136
    iget-object v5, v5, LZN$P$;->kQy:Ljava/util/HashMap;

    .line 137
    .line 138
    const-string v6, "SAFE_JORAN_CONFIGURATION"

    .line 139
    .line 140
    invoke-virtual {v5, v6}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 141
    .line 142
    .line 143
    move-result-object v5

    .line 144
    check-cast v5, Ljava/util/List;

    .line 145
    .line 146
    iget-object v6, p0, LIQ;->vaIue:LZN$P$;

    .line 147
    .line 148
    invoke-static {v6}, LplQQD0;->waiBKÀ(LZN$P$;)LtmpPos8215;

    .line 149
    .line 150
    .line 151
    invoke-virtual {v1}, LZN$P$;->JKEoÙX()V

    .line 152
    .line 153
    .line 154
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 155
    .line 156
    .line 157
    move-result-wide v6

    .line 158
    :try_start_0
    invoke-virtual {v3, v0}, LoOx_YC_;->vaIue(Ljava/net/URL;)V

    .line 159
    .line 160
    .line 161
    const-string v0, "XML_PARSING"

    .line 162
    .line 163
    invoke-virtual {v4}, LZID1;->jPos3709()Ljava/util/ArrayList;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    invoke-static {v3, v6, v7}, LvData2646;->yON3x(Ljava/util/ArrayList;J)Ljava/util/ArrayList;

    .line 168
    .line 169
    .line 170
    move-result-object v3

    .line 171
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 176
    .line 177
    .line 178
    move-result v4

    .line 179
    :cond_2
    :goto_1
    if-ge v2, v4, :cond_6

    .line 180
    .line 181
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v6

    .line 185
    add-int/lit8 v2, v2, 0x1

    .line 186
    .line 187
    check-cast v6, LGLQ$hz$;

    .line 188
    .line 189
    check-cast v6, LNxccOS;

    .line 190
    .line 191
    iget v7, v6, LNxccOS;->e8$mp_s$:I

    .line 192
    .line 193
    const/4 v8, 0x2

    .line 194
    if-eq v8, v7, :cond_3

    .line 195
    .line 196
    goto :goto_1

    .line 197
    :cond_3
    iget-object v6, v6, LNxccOS;->waiBKÀ:Ljava/lang/String;

    .line 198
    .line 199
    invoke-virtual {v0, v6}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 200
    .line 201
    .line 202
    move-result-object v6

    .line 203
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->lookingAt()Z

    .line 204
    .line 205
    .line 206
    move-result v6

    .line 207
    if-eqz v6, :cond_2

    .line 208
    .line 209
    invoke-virtual {p0, v1, v5}, LOÈzTLM;->DDù8(LZN$P$;Ljava/util/List;)V
    :try_end_0
    .catch LOD; {:try_start_0 .. :try_end_0} :catch_0

    .line 210
    .line 211
    .line 212
    return-void

    .line 213
    :catch_0
    invoke-virtual {p0, v1, v5}, LOÈzTLM;->DDù8(LZN$P$;Ljava/util/List;)V

    .line 214
    .line 215
    .line 216
    return-void

    .line 217
    :cond_4
    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 218
    .line 219
    .line 220
    move-result-object v0

    .line 221
    const-string v1, "groovy"

    .line 222
    .line 223
    invoke-virtual {v0, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 224
    .line 225
    .line 226
    move-result v0

    .line 227
    if-eqz v0, :cond_6

    .line 228
    .line 229
    const-string v0, "Groovy classes are not available on the class path. ABORTING INITIALIZATION."

    .line 230
    .line 231
    invoke-virtual {p0, v0}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 232
    .line 233
    .line 234
    return-void

    .line 235
    :cond_5
    add-int/lit8 v3, v3, 0x1

    .line 236
    .line 237
    goto/16 :goto_0

    .line 238
    .line 239
    :cond_6
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .locals 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "ReconfigureOnChangeTask(born:"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-wide v1, p0, LOÈzTLM;->iOffset934:J

    .line 9
    .line 10
    const-string v3, ")"

    .line 11
    .line 12
    invoke-static {v0, v1, v2, v3}, LRQU_K6$Kv_;->Ialue(Ljava/lang/StringBuilder;JLjava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0
.end method
