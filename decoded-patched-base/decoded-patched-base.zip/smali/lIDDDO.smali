.class public final LlIDDDO;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# instance fields
.field public final synthetic vaIue:Ljava/lang/Object;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LlIDDDO;->yON3x:I

    iput-object p2, p0, LlIDDDO;->vaIue:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final e8$mp_s$(Landroid/view/View;)V
    .locals 0

    .line 1
    return-void
.end method

.method private final rz__9J_(Landroid/view/View;)V
    .locals 0

    .line 1
    return-void
.end method

.method private final waiBKÀ(Landroid/view/View;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final onViewAttachedToWindow(Landroid/view/View;)V
    .locals 2

    .line 1
    iget p1, p0, LlIDDDO;->yON3x:I

    .line 2
    .line 3
    iget-object v0, p0, LlIDDDO;->vaIue:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch p1, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :pswitch_0
    check-cast v0, Landroid/view/View;

    .line 10
    .line 11
    invoke-virtual {v0, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 12
    .line 13
    .line 14
    sget-object p1, Ll11Il;->e8$mp_s$:Ljava/util/WeakHashMap;

    .line 15
    .line 16
    invoke-static {v0}, LisValue982;->rz__9J_(Landroid/view/View;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_1
    check-cast v0, LiIdex;

    .line 21
    .line 22
    iget-object p1, v0, LiIdex;->tzKù7Ol1:Landroid/view/accessibility/AccessibilityManager;

    .line 23
    .line 24
    iget-object v1, v0, LiIdex;->ll:LzdS_N$B_;

    .line 25
    .line 26
    if-eqz v1, :cond_0

    .line 27
    .line 28
    if-eqz p1, :cond_0

    .line 29
    .line 30
    sget-object v1, Ll11Il;->e8$mp_s$:Ljava/util/WeakHashMap;

    .line 31
    .line 32
    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    if-eqz v1, :cond_0

    .line 37
    .line 38
    iget-object v0, v0, LiIdex;->ll:LzdS_N$B_;

    .line 39
    .line 40
    new-instance v1, LxlOI;

    .line 41
    .line 42
    invoke-direct {v1, v0}, LxlOI;-><init>(LzdS_N$B_;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {p1, v1}, Landroid/view/accessibility/AccessibilityManager;->addTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z

    .line 46
    .line 47
    .line 48
    :cond_0
    :pswitch_2
    return-void

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 2

    .line 1
    iget v0, p0, LlIDDDO;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LlIDDDO;->vaIue:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LpO4$GQ_C$;

    .line 9
    .line 10
    iget-object v1, v0, LpO4$GQ_C$;->kCount1402:Landroid/view/ViewTreeObserver;

    .line 11
    .line 12
    if-eqz v1, :cond_1

    .line 13
    .line 14
    invoke-virtual {v1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-nez v1, :cond_0

    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    iput-object v1, v0, LpO4$GQ_C$;->kCount1402:Landroid/view/ViewTreeObserver;

    .line 25
    .line 26
    :cond_0
    iget-object v1, v0, LpO4$GQ_C$;->kCount1402:Landroid/view/ViewTreeObserver;

    .line 27
    .line 28
    iget-object v0, v0, LpO4$GQ_C$;->yàÒZ:LisIndex2898;

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 31
    .line 32
    .line 33
    :cond_1
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 34
    .line 35
    .line 36
    :pswitch_0
    return-void

    .line 37
    :pswitch_1
    iget-object p1, p0, LlIDDDO;->vaIue:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p1, LiIdex;

    .line 40
    .line 41
    iget-object v0, p1, LiIdex;->ll:LzdS_N$B_;

    .line 42
    .line 43
    if-eqz v0, :cond_2

    .line 44
    .line 45
    iget-object p1, p1, LiIdex;->tzKù7Ol1:Landroid/view/accessibility/AccessibilityManager;

    .line 46
    .line 47
    if-eqz p1, :cond_2

    .line 48
    .line 49
    new-instance v1, LxlOI;

    .line 50
    .line 51
    invoke-direct {v1, v0}, LxlOI;-><init>(LzdS_N$B_;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p1, v1}, Landroid/view/accessibility/AccessibilityManager;->removeTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z

    .line 55
    .line 56
    .line 57
    :cond_2
    return-void

    .line 58
    :pswitch_2
    iget-object v0, p0, LlIDDDO;->vaIue:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v0, LfO;

    .line 61
    .line 62
    iget-object v1, v0, LfO;->Oey:Landroid/view/ViewTreeObserver;

    .line 63
    .line 64
    if-eqz v1, :cond_4

    .line 65
    .line 66
    invoke-virtual {v1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    if-nez v1, :cond_3

    .line 71
    .line 72
    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    iput-object v1, v0, LfO;->Oey:Landroid/view/ViewTreeObserver;

    .line 77
    .line 78
    :cond_3
    iget-object v1, v0, LfO;->Oey:Landroid/view/ViewTreeObserver;

    .line 79
    .line 80
    iget-object v0, v0, LfO;->yàÒZ:LisIndex2898;

    .line 81
    .line 82
    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 83
    .line 84
    .line 85
    :cond_4
    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 86
    .line 87
    .line 88
    return-void

    .line 89
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
