.class public final Lvl;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LRv$0$;


# direct methods
.method public synthetic constructor <init>(LRv$0$;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvl;->e8$mp_s$:LRv$0$;

    .line 5
    .line 6
    return-void
.end method
