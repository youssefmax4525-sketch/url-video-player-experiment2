.class public final Lf8H$E_t$;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final DDù8:LI1O1;

.field public JKEoÙX:J

.field public POOl:I

.field public e8$mp_s$:J

.field public jPos3709:I

.field public rz__9J_:I

.field public final sKey7917:Ljava/lang/String;

.field public final tmpData3485:Ljava/lang/Object;

.field public vaIue:I

.field public waiBKÀ:J

.field public yON3x:I


# direct methods
.method public constructor <init>(Ljava/lang/String;LI1O1;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const-wide/16 v0, -0x1

    .line 5
    .line 6
    iput-wide v0, p0, Lf8H$E_t$;->e8$mp_s$:J

    .line 7
    .line 8
    iput-wide v0, p0, Lf8H$E_t$;->waiBKÀ:J

    .line 9
    .line 10
    const/4 v0, -0x1

    .line 11
    iput v0, p0, Lf8H$E_t$;->rz__9J_:I

    .line 12
    .line 13
    iput v0, p0, Lf8H$E_t$;->POOl:I

    .line 14
    .line 15
    const-wide/16 v0, 0x0

    .line 16
    .line 17
    iput-wide v0, p0, Lf8H$E_t$;->JKEoÙX:J

    .line 18
    .line 19
    new-instance v0, Ljava/lang/Object;

    .line 20
    .line 21
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    iput v0, p0, Lf8H$E_t$;->yON3x:I

    .line 28
    .line 29
    iput v0, p0, Lf8H$E_t$;->vaIue:I

    .line 30
    .line 31
    iput v0, p0, Lf8H$E_t$;->jPos3709:I

    .line 32
    .line 33
    iput-object p1, p0, Lf8H$E_t$;->sKey7917:Ljava/lang/String;

    .line 34
    .line 35
    iput-object p2, p0, Lf8H$E_t$;->DDù8:LI1O1;

    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final JKEoÙX(LfO0;J)V
    .locals 10

    .line 1
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, Lf8H$E_t$;->DDù8:LI1O1;

    .line 5
    .line 6
    invoke-virtual {v1}, LI1O1;->gKey4112()J

    .line 7
    .line 8
    .line 9
    move-result-wide v1

    .line 10
    sget-object v3, LvItem598;->tzKù7Ol1:LvItem598;

    .line 11
    .line 12
    iget-object v3, v3, LvItem598;->vaIue:LkOffset8539;

    .line 13
    .line 14
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v3

    .line 21
    iget-wide v5, p0, Lf8H$E_t$;->waiBKÀ:J

    .line 22
    .line 23
    const-wide/16 v7, -0x1

    .line 24
    .line 25
    cmp-long v9, v5, v7

    .line 26
    .line 27
    if-nez v9, :cond_1

    .line 28
    .line 29
    sub-long v1, v3, v1

    .line 30
    .line 31
    sget-object v5, LisIndex2415;->I11illi:LSdE$n$;

    .line 32
    .line 33
    sget-object v6, LIl1il;->POOl:LIl1il;

    .line 34
    .line 35
    iget-object v6, v6, LIl1il;->rz__9J_:LnCount1076;

    .line 36
    .line 37
    invoke-virtual {v6, v5}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v5

    .line 41
    check-cast v5, Ljava/lang/Long;

    .line 42
    .line 43
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 44
    .line 45
    .line 46
    move-result-wide v5

    .line 47
    cmp-long v7, v1, v5

    .line 48
    .line 49
    if-lez v7, :cond_0

    .line 50
    .line 51
    const/4 v1, -0x1

    .line 52
    iput v1, p0, Lf8H$E_t$;->POOl:I

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :catchall_0
    move-exception p1

    .line 56
    goto :goto_3

    .line 57
    :cond_0
    iget-object v1, p0, Lf8H$E_t$;->DDù8:LI1O1;

    .line 58
    .line 59
    invoke-virtual {v1}, LI1O1;->yàÒZ()I

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    iput v1, p0, Lf8H$E_t$;->POOl:I

    .line 64
    .line 65
    :goto_0
    iput-wide p2, p0, Lf8H$E_t$;->waiBKÀ:J

    .line 66
    .line 67
    iput-wide p2, p0, Lf8H$E_t$;->e8$mp_s$:J

    .line 68
    .line 69
    goto :goto_1

    .line 70
    :cond_1
    iput-wide p2, p0, Lf8H$E_t$;->e8$mp_s$:J

    .line 71
    .line 72
    :goto_1
    sget-object p2, LisIndex2415;->hlO:LSdE$n$;

    .line 73
    .line 74
    sget-object p3, LIl1il;->POOl:LIl1il;

    .line 75
    .line 76
    iget-object p3, p3, LIl1il;->rz__9J_:LnCount1076;

    .line 77
    .line 78
    invoke-virtual {p3, p2}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p2

    .line 82
    check-cast p2, Ljava/lang/Boolean;

    .line 83
    .line 84
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 85
    .line 86
    .line 87
    move-result p2

    .line 88
    const/4 p3, 0x1

    .line 89
    if-nez p2, :cond_2

    .line 90
    .line 91
    iget-object p1, p1, LfO0;->jPos3709:Landroid/os/Bundle;

    .line 92
    .line 93
    if-eqz p1, :cond_2

    .line 94
    .line 95
    const-string p2, "gw"

    .line 96
    .line 97
    const/4 v1, 0x2

    .line 98
    invoke-virtual {p1, p2, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 99
    .line 100
    .line 101
    move-result p1

    .line 102
    if-ne p1, p3, :cond_2

    .line 103
    .line 104
    monitor-exit v0

    .line 105
    return-void

    .line 106
    :cond_2
    iget p1, p0, Lf8H$E_t$;->rz__9J_:I

    .line 107
    .line 108
    add-int/2addr p1, p3

    .line 109
    iput p1, p0, Lf8H$E_t$;->rz__9J_:I

    .line 110
    .line 111
    iget p1, p0, Lf8H$E_t$;->POOl:I

    .line 112
    .line 113
    add-int/2addr p1, p3

    .line 114
    iput p1, p0, Lf8H$E_t$;->POOl:I

    .line 115
    .line 116
    if-nez p1, :cond_3

    .line 117
    .line 118
    const-wide/16 p1, 0x0

    .line 119
    .line 120
    iput-wide p1, p0, Lf8H$E_t$;->JKEoÙX:J

    .line 121
    .line 122
    iget-object p1, p0, Lf8H$E_t$;->DDù8:LI1O1;

    .line 123
    .line 124
    invoke-virtual {p1, v3, v4}, LI1O1;->yPN$A_n$(J)V

    .line 125
    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_3
    iget-object p1, p0, Lf8H$E_t$;->DDù8:LI1O1;

    .line 129
    .line 130
    invoke-virtual {p1}, LI1O1;->kO_6X_()J

    .line 131
    .line 132
    .line 133
    move-result-wide p1

    .line 134
    sub-long/2addr v3, p1

    .line 135
    iput-wide v3, p0, Lf8H$E_t$;->JKEoÙX:J

    .line 136
    .line 137
    :goto_2
    monitor-exit v0

    .line 138
    return-void

    .line 139
    :goto_3
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 140
    throw p1
.end method

.method public final POOl()V
    .locals 2

    .line 1
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget v1, p0, Lf8H$E_t$;->vaIue:I

    .line 5
    .line 6
    add-int/lit8 v1, v1, 0x1

    .line 7
    .line 8
    iput v1, p0, Lf8H$E_t$;->vaIue:I

    .line 9
    .line 10
    monitor-exit v0

    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    throw v1
.end method

.method public final e8$mp_s$()I
    .locals 2

    .line 1
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget v1, p0, Lf8H$E_t$;->jPos3709:I

    .line 5
    .line 6
    monitor-exit v0

    .line 7
    return v1

    .line 8
    :catchall_0
    move-exception v1

    .line 9
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    throw v1
.end method

.method public final rz__9J_()V
    .locals 2

    .line 1
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget v1, p0, Lf8H$E_t$;->yON3x:I

    .line 5
    .line 6
    add-int/lit8 v1, v1, 0x1

    .line 7
    .line 8
    iput v1, p0, Lf8H$E_t$;->yON3x:I

    .line 9
    .line 10
    monitor-exit v0

    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    throw v1
.end method

.method public final sKey7917()V
    .locals 2

    .line 1
    sget-object v0, LjIndex1180;->e8$mp_s$:LvSize4545;

    .line 2
    .line 3
    invoke-virtual {v0}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 16
    .line 17
    monitor-enter v0

    .line 18
    :try_start_0
    iget v1, p0, Lf8H$E_t$;->rz__9J_:I

    .line 19
    .line 20
    add-int/lit8 v1, v1, -0x1

    .line 21
    .line 22
    iput v1, p0, Lf8H$E_t$;->rz__9J_:I

    .line 23
    .line 24
    iget v1, p0, Lf8H$E_t$;->POOl:I

    .line 25
    .line 26
    add-int/lit8 v1, v1, -0x1

    .line 27
    .line 28
    iput v1, p0, Lf8H$E_t$;->POOl:I

    .line 29
    .line 30
    monitor-exit v0

    .line 31
    return-void

    .line 32
    :catchall_0
    move-exception v1

    .line 33
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 34
    throw v1

    .line 35
    :cond_0
    return-void
.end method

.method public final tmpData3485()V
    .locals 2

    .line 1
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget v1, p0, Lf8H$E_t$;->jPos3709:I

    .line 5
    .line 6
    add-int/lit8 v1, v1, 0x1

    .line 7
    .line 8
    iput v1, p0, Lf8H$E_t$;->jPos3709:I

    .line 9
    .line 10
    monitor-exit v0

    .line 11
    return-void

    .line 12
    :catchall_0
    move-exception v1

    .line 13
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    throw v1
.end method

.method public final waiBKÀ(Landroid/content/Context;Ljava/lang/String;)Landroid/os/Bundle;
    .locals 7

    .line 1
    iget-object v0, p0, Lf8H$E_t$;->tmpData3485:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    new-instance v1, Landroid/os/Bundle;

    .line 5
    .line 6
    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    .line 7
    .line 8
    .line 9
    iget-object v2, p0, Lf8H$E_t$;->DDù8:LI1O1;

    .line 10
    .line 11
    invoke-virtual {v2}, LI1O1;->Ialue()Z

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-nez v2, :cond_0

    .line 16
    .line 17
    const-string v2, "session_id"

    .line 18
    .line 19
    iget-object v3, p0, Lf8H$E_t$;->sKey7917:Ljava/lang/String;

    .line 20
    .line 21
    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :catchall_0
    move-exception p1

    .line 26
    goto/16 :goto_3

    .line 27
    .line 28
    :cond_0
    :goto_0
    const-string v2, "basets"

    .line 29
    .line 30
    iget-wide v3, p0, Lf8H$E_t$;->waiBKÀ:J

    .line 31
    .line 32
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 33
    .line 34
    .line 35
    const-string v2, "currts"

    .line 36
    .line 37
    iget-wide v3, p0, Lf8H$E_t$;->e8$mp_s$:J

    .line 38
    .line 39
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 40
    .line 41
    .line 42
    const-string v2, "seq_num"

    .line 43
    .line 44
    invoke-virtual {v1, v2, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    const-string p2, "preqs"

    .line 48
    .line 49
    iget v2, p0, Lf8H$E_t$;->rz__9J_:I

    .line 50
    .line 51
    invoke-virtual {v1, p2, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 52
    .line 53
    .line 54
    const-string p2, "preqs_in_session"

    .line 55
    .line 56
    iget v2, p0, Lf8H$E_t$;->POOl:I

    .line 57
    .line 58
    invoke-virtual {v1, p2, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 59
    .line 60
    .line 61
    const-string p2, "time_in_session"

    .line 62
    .line 63
    iget-wide v2, p0, Lf8H$E_t$;->JKEoÙX:J

    .line 64
    .line 65
    invoke-virtual {v1, p2, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 66
    .line 67
    .line 68
    const-string p2, "pclick"

    .line 69
    .line 70
    iget v2, p0, Lf8H$E_t$;->yON3x:I

    .line 71
    .line 72
    invoke-virtual {v1, p2, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 73
    .line 74
    .line 75
    const-string p2, "pimp"

    .line 76
    .line 77
    iget v2, p0, Lf8H$E_t$;->vaIue:I

    .line 78
    .line 79
    invoke-virtual {v1, p2, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 80
    .line 81
    .line 82
    const-string p2, "support_transparent_background"

    .line 83
    .line 84
    sget v2, LYQ0;->waiBKÀ:I

    .line 85
    .line 86
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    if-nez v2, :cond_1

    .line 91
    .line 92
    goto :goto_1

    .line 93
    :cond_1
    move-object p1, v2

    .line 94
    :goto_1
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 95
    .line 96
    .line 97
    move-result-object v2

    .line 98
    const-string v3, "Theme.Translucent"

    .line 99
    .line 100
    const-string v4, "style"

    .line 101
    .line 102
    const-string v5, "android"

    .line 103
    .line 104
    invoke-virtual {v2, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    const/4 v3, 0x0

    .line 109
    if-nez v2, :cond_2

    .line 110
    .line 111
    const-string p1, "Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad."

    .line 112
    .line 113
    invoke-static {p1}, LPJNypàa;->lIl1(Ljava/lang/String;)V

    .line 114
    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_2
    new-instance v4, Landroid/content/ComponentName;

    .line 118
    .line 119
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v5

    .line 123
    const-string v6, "com.google.android.gms.ads.AdActivity"

    .line 124
    .line 125
    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 126
    .line 127
    .line 128
    :try_start_1
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 129
    .line 130
    .line 131
    move-result-object p1

    .line 132
    invoke-virtual {p1, v4, v3}, Landroid/content/pm/PackageManager;->getActivityInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    iget p1, p1, Landroid/content/pm/ActivityInfo;->theme:I

    .line 137
    .line 138
    if-ne v2, p1, :cond_3

    .line 139
    .line 140
    const/4 v3, 0x1

    .line 141
    goto :goto_2

    .line 142
    :cond_3
    const-string p1, "Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad."

    .line 143
    .line 144
    invoke-static {p1}, LPJNypàa;->lIl1(Ljava/lang/String;)V
    :try_end_1
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 145
    .line 146
    .line 147
    goto :goto_2

    .line 148
    :catch_0
    :try_start_2
    const-string p1, "Fail to fetch AdActivity theme"

    .line 149
    .line 150
    invoke-static {p1}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    const-string p1, "Please set theme of AdActivity to @android:style/Theme.Translucent to enable transparent background interstitial ad."

    .line 154
    .line 155
    invoke-static {p1}, LPJNypàa;->lIl1(Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    :goto_2
    invoke-virtual {v1, p2, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 159
    .line 160
    .line 161
    const-string p1, "consent_form_action_identifier"

    .line 162
    .line 163
    invoke-virtual {p0}, Lf8H$E_t$;->e8$mp_s$()I

    .line 164
    .line 165
    .line 166
    move-result p2

    .line 167
    invoke-virtual {v1, p1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 168
    .line 169
    .line 170
    monitor-exit v0

    .line 171
    return-object v1

    .line 172
    :goto_3
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 173
    throw p1
.end method
