.class public interface abstract LADD1D;
.super Ljava/lang/Object;
.source "SourceFile"
