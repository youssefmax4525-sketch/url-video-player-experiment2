.class public final synthetic LlllIll;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lb0Q;
.implements LsIndex8461;
.implements Ljma$E_vf$;


# instance fields
.field public jPos3709:Ljava/lang/Object;

.field public vaIue:Ljava/lang/Object;

.field public final synthetic yON3x:I


# direct methods
.method public constructor <init>(II)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LlllIll;->yON3x:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    if-nez p1, :cond_0

    .line 5
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    invoke-direct {v0, p1}, Ljava/util/ArrayList;-><init>(I)V

    move-object p1, v0

    .line 7
    :goto_0
    iput-object p1, p0, LlllIll;->vaIue:Ljava/lang/Object;

    if-nez p2, :cond_1

    .line 8
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    goto :goto_1

    :cond_1
    new-instance p1, Ljava/util/ArrayList;

    .line 9
    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(I)V

    .line 10
    :goto_1
    iput-object p1, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LlllIll;->yON3x:I

    iput-object p2, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 2
    iput p1, p0, LlllIll;->yON3x:I

    iput-object p2, p0, LlllIll;->vaIue:Ljava/lang/Object;

    iput-object p3, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, LlllIll;->yON3x:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LlllIll;->vaIue:Ljava/lang/Object;

    return-void
.end method

.method public static e8$mp_s$(LlllIll;)Ljava/lang/String;
    .locals 11

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "com.google.android.gms.cast.CATEGORY_CAST"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, LlllIll;->vaIue:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Ljava/lang/String;

    .line 11
    .line 12
    const-string v2, "/"

    .line 13
    .line 14
    if-eqz v1, :cond_1

    .line 15
    .line 16
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 17
    .line 18
    invoke-virtual {v1, v3}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    const-string v4, "[A-F0-9]+"

    .line 23
    .line 24
    invoke-virtual {v3, v4}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 25
    .line 26
    .line 27
    move-result v4

    .line 28
    if-eqz v4, :cond_0

    .line 29
    .line 30
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_0
    const-string p0, "Invalid application ID: "

    .line 38
    .line 39
    invoke-virtual {p0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 44
    .line 45
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    throw v0

    .line 49
    :cond_1
    :goto_0
    iget-object p0, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p0, Ljava/util/Collection;

    .line 52
    .line 53
    const/4 v3, 0x0

    .line 54
    const/4 v4, 0x1

    .line 55
    if-eqz p0, :cond_e

    .line 56
    .line 57
    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    if-nez v5, :cond_d

    .line 62
    .line 63
    if-nez v1, :cond_2

    .line 64
    .line 65
    const/4 v5, 0x0

    .line 66
    goto :goto_1

    .line 67
    :cond_2
    const/4 v5, 0x1

    .line 68
    :goto_1
    if-nez v1, :cond_3

    .line 69
    .line 70
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    :cond_3
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-interface {p0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    const/4 v6, 0x1

    .line 81
    :goto_2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 82
    .line 83
    .line 84
    move-result v7

    .line 85
    if-eqz v7, :cond_c

    .line 86
    .line 87
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    check-cast v7, Ljava/lang/String;

    .line 92
    .line 93
    invoke-static {v7}, LtmpData2913;->waiBKÀ(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    if-nez v6, :cond_4

    .line 97
    .line 98
    const-string v6, ","

    .line 99
    .line 100
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    :cond_4
    sget-object v6, LtmpData2913;->e8$mp_s$:Ljava/util/regex/Pattern;

    .line 104
    .line 105
    invoke-virtual {v6, v7}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    invoke-virtual {v6}, Ljava/util/regex/Matcher;->matches()Z

    .line 110
    .line 111
    .line 112
    move-result v6

    .line 113
    if-eqz v6, :cond_5

    .line 114
    .line 115
    goto :goto_6

    .line 116
    :cond_5
    new-instance v6, Ljava/lang/StringBuilder;

    .line 117
    .line 118
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 119
    .line 120
    .line 121
    move-result v8

    .line 122
    invoke-direct {v6, v8}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 123
    .line 124
    .line 125
    const/4 v8, 0x0

    .line 126
    :goto_3
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 127
    .line 128
    .line 129
    move-result v9

    .line 130
    if-ge v8, v9, :cond_b

    .line 131
    .line 132
    invoke-virtual {v7, v8}, Ljava/lang/String;->charAt(I)C

    .line 133
    .line 134
    .line 135
    move-result v9

    .line 136
    const/16 v10, 0x41

    .line 137
    .line 138
    if-lt v9, v10, :cond_6

    .line 139
    .line 140
    const/16 v10, 0x5a

    .line 141
    .line 142
    if-le v9, v10, :cond_a

    .line 143
    .line 144
    :cond_6
    const/16 v10, 0x61

    .line 145
    .line 146
    if-lt v9, v10, :cond_7

    .line 147
    .line 148
    const/16 v10, 0x7a

    .line 149
    .line 150
    if-le v9, v10, :cond_a

    .line 151
    .line 152
    :cond_7
    const/16 v10, 0x30

    .line 153
    .line 154
    if-lt v9, v10, :cond_8

    .line 155
    .line 156
    const/16 v10, 0x39

    .line 157
    .line 158
    if-le v9, v10, :cond_a

    .line 159
    .line 160
    :cond_8
    const/16 v10, 0x5f

    .line 161
    .line 162
    if-eq v9, v10, :cond_a

    .line 163
    .line 164
    const/16 v10, 0x2d

    .line 165
    .line 166
    if-ne v9, v10, :cond_9

    .line 167
    .line 168
    goto :goto_4

    .line 169
    :cond_9
    const/16 v10, 0x2e

    .line 170
    .line 171
    if-eq v9, v10, :cond_a

    .line 172
    .line 173
    const/16 v10, 0x3a

    .line 174
    .line 175
    if-eq v9, v10, :cond_a

    .line 176
    .line 177
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 178
    .line 179
    .line 180
    move-result-object v9

    .line 181
    new-array v10, v4, [Ljava/lang/Object;

    .line 182
    .line 183
    aput-object v9, v10, v3

    .line 184
    .line 185
    const-string v9, "%%%04x"

    .line 186
    .line 187
    invoke-static {v9, v10}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v9

    .line 191
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    goto :goto_5

    .line 195
    :cond_a
    :goto_4
    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 196
    .line 197
    .line 198
    :goto_5
    add-int/lit8 v8, v8, 0x1

    .line 199
    .line 200
    goto :goto_3

    .line 201
    :cond_b
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v7

    .line 205
    :goto_6
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 206
    .line 207
    .line 208
    const/4 v6, 0x0

    .line 209
    goto/16 :goto_2

    .line 210
    .line 211
    :cond_c
    move v3, v5

    .line 212
    goto :goto_7

    .line 213
    :cond_d
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 214
    .line 215
    const-string v0, "Must specify at least one namespace"

    .line 216
    .line 217
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    throw p0

    .line 221
    :cond_e
    if-nez v1, :cond_f

    .line 222
    .line 223
    goto :goto_7

    .line 224
    :cond_f
    const/4 v3, 0x1

    .line 225
    :goto_7
    if-eq v4, v3, :cond_10

    .line 226
    .line 227
    if-nez p0, :cond_10

    .line 228
    .line 229
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 230
    .line 231
    .line 232
    :cond_10
    if-nez p0, :cond_11

    .line 233
    .line 234
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 235
    .line 236
    .line 237
    :cond_11
    const-string p0, "//ALLOW_IPV6"

    .line 238
    .line 239
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 240
    .line 241
    .line 242
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object p0

    .line 246
    return-object p0
.end method


# virtual methods
.method public POOl()LtmpCount7582;
    .locals 3

    .line 1
    new-instance v0, LtmpCount7582;

    .line 2
    .line 3
    iget-object v1, p0, LlllIll;->vaIue:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Ljava/util/List;

    .line 6
    .line 7
    iget-object v2, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Ljava/util/List;

    .line 10
    .line 11
    invoke-direct {v0, v1, v2}, LtmpCount7582;-><init>(Ljava/util/List;Ljava/util/List;)V

    .line 12
    .line 13
    .line 14
    return-object v0
.end method

.method public kQy(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget v0, p0, LlllIll;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lsyirkh;

    .line 7
    .line 8
    iget-object v0, p0, LlllIll;->vaIue:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LjPRÒÒI;

    .line 11
    .line 12
    iget-object v1, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Ldl1OI;

    .line 15
    .line 16
    invoke-interface {p1, v0, v1}, Lsyirkh;->POOl(LjPRÒÒI;Ldl1OI;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_0
    iget-object v0, p0, LlllIll;->vaIue:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, LhasValue6126;

    .line 23
    .line 24
    check-cast p1, Ll0;

    .line 25
    .line 26
    iget-object v1, v0, LhasValue6126;->yON3x:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, LzDZZZEI;

    .line 29
    .line 30
    iget-object v0, v0, LhasValue6126;->vaIue:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v2, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v2, Ljava/lang/Throwable;

    .line 35
    .line 36
    invoke-interface {p1, v1, v0, v2}, Ll0;->l1(LzDZZZEI;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 37
    .line 38
    .line 39
    return-void

    .line 40
    nop

    .line 41
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public pCXDYg(Ljava/lang/String;)LqyYXftcJ;
    .locals 4

    .line 1
    sget-object v0, LQ__wr_;->iOffset934:Lrd0_e_;

    .line 2
    .line 3
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 4
    .line 5
    iget-object v0, v0, LvItem598;->rz__9J_:LQ__wr_;

    .line 6
    .line 7
    iget-object v0, p0, LlllIll;->vaIue:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Landroid/content/Context;

    .line 10
    .line 11
    iget-object v1, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Ljava/lang/String;

    .line 14
    .line 15
    new-instance v2, Lp1D;

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    invoke-direct {v2, v0, v1, p1, v3}, Lp1D;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lln0kb;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v2}, LHDl0DI;->Iii11()LeO;

    .line 22
    .line 23
    .line 24
    sget-object p1, LqyYXftcJ;->yON3x:LqyYXftcJ;

    .line 25
    .line 26
    return-object p1
.end method

.method public rz__9J_(LWY_einx;)V
    .locals 1

    .line 1
    iget-object v0, p0, LlllIll;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public waiBKÀ(LWY_einx;)V
    .locals 1

    .line 1
    iget-object v0, p0, LlllIll;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/List;

    .line 4
    .line 5
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    return-void
.end method
