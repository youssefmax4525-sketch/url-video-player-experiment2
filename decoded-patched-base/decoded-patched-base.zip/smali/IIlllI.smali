.class public final LIIlllI;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lenb;


# instance fields
.field public final e8$mp_s$:LgItem9321;


# direct methods
.method public constructor <init>(LgItem9321;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LIIlllI;->e8$mp_s$:LgItem9321;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final e8$mp_s$()I
    .locals 1

    .line 1
    const v0, 0x66727473

    .line 2
    .line 3
    .line 4
    return v0
.end method
