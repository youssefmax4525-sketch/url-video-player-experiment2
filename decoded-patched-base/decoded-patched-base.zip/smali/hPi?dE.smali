.class public final LhPiìdE;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:Ljava/util/concurrent/Executor;

.field public volatile rz__9J_:Z

.field public final waiBKÀ:Ljava/util/concurrent/ScheduledExecutorService;


# direct methods
.method public constructor <init>(LgID0;Ljava/util/concurrent/ScheduledExecutorService;LhasValue6126;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 p3, 0x1

    .line 5
    iput-boolean p3, p0, LhPiìdE;->rz__9J_:Z

    .line 6
    .line 7
    iput-object p1, p0, LhPiìdE;->e8$mp_s$:Ljava/util/concurrent/Executor;

    .line 8
    .line 9
    iput-object p2, p0, LhPiìdE;->waiBKÀ:Ljava/util/concurrent/ScheduledExecutorService;

    .line 10
    .line 11
    return-void
.end method
