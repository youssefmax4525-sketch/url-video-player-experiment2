.class public final LiItem7095;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LXXìMLÙe;


# instance fields
.field public final POOl:LWY_einx;

.field public final synthetic e8$mp_s$:I

.field public final rz__9J_:LWY_einx;

.field public final waiBKÀ:LbNg$__c$;


# direct methods
.method public constructor <init>(LbNg$__c$;LjPos3798;Lcg_D$7_;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LiItem7095;->e8$mp_s$:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LiItem7095;->waiBKÀ:LbNg$__c$;

    iput-object p2, p0, LiItem7095;->rz__9J_:LWY_einx;

    iput-object p3, p0, LiItem7095;->POOl:LWY_einx;

    return-void
.end method

.method public constructor <init>(LjPos3798;LbNg$__c$;LjPos3798;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LiItem7095;->e8$mp_s$:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LiItem7095;->rz__9J_:LWY_einx;

    iput-object p2, p0, LiItem7095;->waiBKÀ:LbNg$__c$;

    iput-object p3, p0, LiItem7095;->POOl:LWY_einx;

    return-void
.end method


# virtual methods
.method public final POOl()Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, LiItem7095;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    sget-object v2, LBòtZ;->e8$mp_s$:LgID0;

    .line 7
    .line 8
    invoke-static {v2}, LnItem4702;->ll(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, LiItem7095;->waiBKÀ:LbNg$__c$;

    .line 12
    .line 13
    invoke-virtual {v0}, LbNg$__c$;->e8$mp_s$()LQoXYbY;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    iget-object v0, p0, LiItem7095;->rz__9J_:LWY_einx;

    .line 18
    .line 19
    invoke-interface {v0}, LWY_einx;->POOl()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    move-object v4, v0

    .line 24
    check-cast v4, Landroid/content/pm/PackageInfo;

    .line 25
    .line 26
    iget-object v0, p0, LiItem7095;->POOl:LWY_einx;

    .line 27
    .line 28
    check-cast v0, Lcg_D$7_;

    .line 29
    .line 30
    invoke-virtual {v0}, Lcg_D$7_;->e8$mp_s$()LI1O1;

    .line 31
    .line 32
    .line 33
    move-result-object v5

    .line 34
    new-instance v1, LtmpIndex2079;

    .line 35
    .line 36
    const/4 v6, 0x5

    .line 37
    invoke-direct/range {v1 .. v6}, LtmpIndex2079;-><init>(Ljava/lang/Object;LQoXYbY;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 38
    .line 39
    .line 40
    return-object v1

    .line 41
    :pswitch_0
    iget-object v0, p0, LiItem7095;->rz__9J_:LWY_einx;

    .line 42
    .line 43
    invoke-interface {v0}, LWY_einx;->POOl()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    check-cast v0, Lzv$f_4$;

    .line 48
    .line 49
    iget-object v1, p0, LiItem7095;->waiBKÀ:LbNg$__c$;

    .line 50
    .line 51
    invoke-virtual {v1}, LbNg$__c$;->e8$mp_s$()LQoXYbY;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    iget-object v2, p0, LiItem7095;->POOl:LWY_einx;

    .line 56
    .line 57
    invoke-interface {v2}, LWY_einx;->POOl()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    check-cast v2, Ljava/lang/String;

    .line 62
    .line 63
    new-instance v3, LWmAbID4;

    .line 64
    .line 65
    invoke-direct {v3, v0, v1, v2}, LWmAbID4;-><init>(Lzv$f_4$;LQoXYbY;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    return-object v3

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
