.class public final LiData3805;
.super LmbTtYSOsv;
.source "SourceFile"

# interfaces
.implements LcIIQO;
.implements LnData9003;


# instance fields
.field public final Ialue:LkData5861;

.field public gKey4112:LqxarMJ;

.field public final iOffset934:Ljava/lang/String;

.field public jPos3709:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public kO_6X_:LlDQI;

.field public final kQy:Lell1QQ;

.field public final pCXDYg:LqjA;

.field public final vaIue:Landroid/content/Context;

.field public final valuI:LxED$DU_3A$;

.field public final yON3x:LiKey8287;

.field public yàÒZ:J


# direct methods
.method public constructor <init>(LiKey8287;Landroid/content/Context;Ljava/lang/String;Lell1QQ;LkData5861;LxED$DU_3A$;LqjA;)V
    .locals 2

    .line 1
    invoke-direct {p0}, LmbTtYSOsv;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LiData3805;->jPos3709:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 10
    .line 11
    const-wide/16 v0, -0x1

    .line 12
    .line 13
    iput-wide v0, p0, LiData3805;->yàÒZ:J

    .line 14
    .line 15
    iput-object p1, p0, LiData3805;->yON3x:LiKey8287;

    .line 16
    .line 17
    iput-object p2, p0, LiData3805;->vaIue:Landroid/content/Context;

    .line 18
    .line 19
    iput-object p3, p0, LiData3805;->iOffset934:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p4, p0, LiData3805;->kQy:Lell1QQ;

    .line 22
    .line 23
    iput-object p5, p0, LiData3805;->Ialue:LkData5861;

    .line 24
    .line 25
    iput-object p6, p0, LiData3805;->valuI:LxED$DU_3A$;

    .line 26
    .line 27
    iput-object p7, p0, LiData3805;->pCXDYg:LqjA;

    .line 28
    .line 29
    iget-object p1, p5, LkData5861;->Ialue:Ljava/util/concurrent/atomic/AtomicReference;

    .line 30
    .line 31
    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final Iii()V
    .locals 0

    .line 1
    return-void
.end method

.method public final JKEoÙX()LbK$h_uX$;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final declared-synchronized K0I()Ljava/lang/String;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LiData3805;->iOffset934:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 3
    .line 4
    monitor-exit p0

    .line 5
    return-object v0

    .line 6
    :catchall_0
    move-exception v0

    .line 7
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 8
    throw v0
.end method

.method public final NU$h_7$(LisIndex2213;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final declared-synchronized NYZ_O$oV_(LLpCYzX;)V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-void
.end method

.method public final declared-synchronized Q1_f_()Ljava/lang/String;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    const/4 v0, 0x0

    .line 4
    return-object v0
.end method

.method public final TSYa(Z)V
    .locals 0

    .line 1
    return-void
.end method

.method public final UEYOU()V
    .locals 0

    .line 1
    return-void
.end method

.method public final a0(LsIndex2851;)V
    .locals 1

    .line 1
    iget-object v0, p0, LiData3805;->Ialue:LkData5861;

    .line 2
    .line 3
    iget-object v0, v0, LkData5861;->vaIue:Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final declared-synchronized cEi_G$x5_()Z
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    const/4 v0, 0x0

    .line 4
    return v0
.end method

.method public final cjt_Ue$7M_(LKàaq;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final dnN$d$()V
    .locals 0

    .line 1
    return-void
.end method

.method public final declared-synchronized eQOI(LvItem787;)V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-void
.end method

.method public final gKey1542()V
    .locals 0

    .line 1
    return-void
.end method

.method public final declared-synchronized gOffset7597(Lmh_p$kn_;)V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    const-string p1, "setAdSize must be called on the main UI thread."

    .line 3
    .line 4
    invoke-static {p1}, Lzl1;->yON3x(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    .line 6
    .line 7
    monitor-exit p0

    .line 8
    return-void

    .line 9
    :catchall_0
    move-exception p1

    .line 10
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 11
    throw p1
.end method

.method public final declared-synchronized gc_$M_w2$()V
    .locals 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LiData3805;->kO_6X_:LlDQI;

    .line 3
    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    sget-object v1, LvItem598;->tzKù7Ol1:LvItem598;

    .line 7
    .line 8
    iget-object v1, v1, LvItem598;->vaIue:LkOffset8539;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 14
    .line 15
    .line 16
    move-result-wide v1

    .line 17
    iget-wide v3, p0, LiData3805;->yàÒZ:J

    .line 18
    .line 19
    sub-long/2addr v1, v3

    .line 20
    const/4 v3, 0x1

    .line 21
    invoke-virtual {v0, v3, v1, v2}, LlDQI;->POOl(IJ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    .line 23
    .line 24
    monitor-exit p0

    .line 25
    return-void

    .line 26
    :catchall_0
    move-exception v0

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    monitor-exit p0

    .line 29
    return-void

    .line 30
    :goto_0
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 31
    throw v0
.end method

.method public final hlO(LgwL$$_3p$;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final iCount5302()V
    .locals 0

    .line 1
    return-void
.end method

.method public final iOffset934()LKàaq;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method

.method public final iQ0D()V
    .locals 0

    .line 1
    return-void
.end method

.method public final declared-synchronized iSize9261(I)V
    .locals 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LiData3805;->jPos3709:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    const/4 v2, 0x1

    .line 6
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_3

    .line 11
    .line 12
    iget-object v0, p0, LiData3805;->Ialue:LkData5861;

    .line 13
    .line 14
    invoke-virtual {v0}, LkData5861;->e8$mp_s$()V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, LiData3805;->gKey4112:LqxarMJ;

    .line 18
    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    sget-object v1, LvItem598;->tzKù7Ol1:LvItem598;

    .line 22
    .line 23
    iget-object v1, v1, LvItem598;->tmpData3485:LlO;

    .line 24
    .line 25
    invoke-virtual {v1, v0}, LlO;->valuI(LKbt8odZ;)V

    .line 26
    .line 27
    .line 28
    goto :goto_0

    .line 29
    :catchall_0
    move-exception p1

    .line 30
    goto :goto_2

    .line 31
    :cond_0
    :goto_0
    iget-object v0, p0, LiData3805;->kO_6X_:LlDQI;

    .line 32
    .line 33
    if-eqz v0, :cond_2

    .line 34
    .line 35
    iget-wide v0, p0, LiData3805;->yàÒZ:J

    .line 36
    .line 37
    const-wide/16 v2, -0x1

    .line 38
    .line 39
    cmp-long v4, v0, v2

    .line 40
    .line 41
    if-nez v4, :cond_1

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 45
    .line 46
    iget-object v0, v0, LvItem598;->vaIue:LkOffset8539;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 52
    .line 53
    .line 54
    move-result-wide v0

    .line 55
    iget-wide v2, p0, LiData3805;->yàÒZ:J

    .line 56
    .line 57
    sub-long v2, v0, v2

    .line 58
    .line 59
    :goto_1
    iget-object v0, p0, LiData3805;->kO_6X_:LlDQI;

    .line 60
    .line 61
    invoke-virtual {v0, p1, v2, v3}, LlDQI;->POOl(IJ)V

    .line 62
    .line 63
    .line 64
    :cond_2
    invoke-virtual {p0}, LiData3805;->sKey6064()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 65
    .line 66
    .line 67
    monitor-exit p0

    .line 68
    return-void

    .line 69
    :cond_3
    monitor-exit p0

    .line 70
    return-void

    .line 71
    :goto_2
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 72
    throw p1
.end method

.method public final inlex()V
    .locals 0

    .line 1
    return-void
.end method

.method public final jData2280()V
    .locals 0

    .line 1
    return-void
.end method

.method public final jItem4302(LbK$h_uX$;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final declared-synchronized jPos3709()LOx_cPmt;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    const/4 v0, 0x0

    .line 4
    return-object v0
.end method

.method public final declared-synchronized kCount1402()Ljava/lang/String;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    const/4 v0, 0x0

    .line 4
    return-object v0
.end method

.method public final declared-synchronized kly()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    const-string v0, "pause must be called on the main UI thread."

    .line 3
    .line 4
    invoke-static {v0}, Lzl1;->yON3x(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    .line 6
    .line 7
    monitor-exit p0

    .line 8
    return-void

    .line 9
    :catchall_0
    move-exception v0

    .line 10
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 11
    throw v0
.end method

.method public final declared-synchronized l0$8J$(Z)V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-void
.end method

.method public final lU$X9_r$(I)V
    .locals 2

    .line 1
    if-eqz p1, :cond_3

    .line 2
    .line 3
    add-int/lit8 p1, p1, -0x1

    .line 4
    .line 5
    const/4 v0, 0x2

    .line 6
    if-eqz p1, :cond_2

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    if-eq p1, v1, :cond_1

    .line 10
    .line 11
    if-eq p1, v0, :cond_0

    .line 12
    .line 13
    const/4 p1, 0x6

    .line 14
    invoke-virtual {p0, p1}, LiData3805;->iSize9261(I)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    const/4 p1, 0x3

    .line 19
    invoke-virtual {p0, p1}, LiData3805;->iSize9261(I)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_1
    const/4 p1, 0x4

    .line 24
    invoke-virtual {p0, p1}, LiData3805;->iSize9261(I)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_2
    invoke-virtual {p0, v0}, LiData3805;->iSize9261(I)V

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :cond_3
    const/4 p1, 0x0

    .line 33
    throw p1
.end method

.method public final declared-synchronized leQgth(LmValue1279;)V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-void
.end method

.method public final declared-synchronized mItem9003()Z
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LiData3805;->kQy:Lell1QQ;

    .line 3
    .line 4
    iget-object v0, v0, Lell1QQ;->vaIue:LeO;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-interface {v0}, Ljava/util/concurrent/Future;->isDone()Z

    .line 9
    .line 10
    .line 11
    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    const/4 v0, 0x1

    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const/4 v0, 0x0

    .line 17
    :goto_0
    monitor-exit p0

    .line 18
    return v0

    .line 19
    :catchall_0
    move-exception v0

    .line 20
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 21
    throw v0
.end method

.method public final declared-synchronized mÀ2tA3()V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-void
.end method

.method public final nValue9528(LAmzxB;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final olD1QI(LPlQ;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final declared-synchronized pCXDYg()LyqQ$S_gR$;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    const/4 v0, 0x0

    .line 4
    return-object v0
.end method

.method public final declared-synchronized pQ1Il()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    const-string v0, "resume must be called on the main UI thread."

    .line 3
    .line 4
    invoke-static {v0}, Lzl1;->yON3x(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    .line 6
    .line 7
    monitor-exit p0

    .line 8
    return-void

    .line 9
    :catchall_0
    move-exception v0

    .line 10
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 11
    throw v0
.end method

.method public final pZDcLvd()V
    .locals 0

    .line 1
    return-void
.end method

.method public final po0()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return v0
.end method

.method public final declared-synchronized sKey6064()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    const-string v0, "destroy must be called on the main UI thread."

    .line 3
    .line 4
    invoke-static {v0}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, LiData3805;->kO_6X_:LlDQI;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, LlDQI;->waiBKÀ()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 12
    .line 13
    .line 14
    monitor-exit p0

    .line 15
    return-void

    .line 16
    :catchall_0
    move-exception v0

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    monitor-exit p0

    .line 19
    return-void

    .line 20
    :goto_0
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 21
    throw v0
.end method

.method public final declared-synchronized tmpData3485()Lmh_p$kn_;
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    const/4 v0, 0x0

    .line 4
    return-object v0
.end method

.method public final declared-synchronized tmpKey6288()V
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p0, LiData3805;->kO_6X_:LlDQI;

    .line 3
    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 8
    .line 9
    iget-object v1, v0, LvItem598;->vaIue:LkOffset8539;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 15
    .line 16
    .line 17
    move-result-wide v1

    .line 18
    iput-wide v1, p0, LiData3805;->yàÒZ:J

    .line 19
    .line 20
    iget-object v1, p0, LiData3805;->kO_6X_:LlDQI;

    .line 21
    .line 22
    iget v1, v1, LlDQI;->jPos3709:I

    .line 23
    .line 24
    if-lez v1, :cond_1

    .line 25
    .line 26
    iget-object v2, p0, LiData3805;->yON3x:LiKey8287;

    .line 27
    .line 28
    new-instance v3, LqxarMJ;

    .line 29
    .line 30
    iget-object v2, v2, LiKey8287;->POOl:LjPos3798;

    .line 31
    .line 32
    invoke-virtual {v2}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    check-cast v2, Ljava/util/concurrent/ScheduledExecutorService;

    .line 37
    .line 38
    iget-object v0, v0, LvItem598;->vaIue:LkOffset8539;

    .line 39
    .line 40
    invoke-direct {v3, v2, v0}, LqxarMJ;-><init>(Ljava/util/concurrent/ScheduledExecutorService;LkOffset8539;)V

    .line 41
    .line 42
    .line 43
    iput-object v3, p0, LiData3805;->gKey4112:LqxarMJ;

    .line 44
    .line 45
    new-instance v0, LLXYGKu;

    .line 46
    .line 47
    const/4 v2, 0x1

    .line 48
    invoke-direct {v0, p0, v2}, LLXYGKu;-><init>(LiData3805;I)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v3, v1, v0}, LqxarMJ;->waiBKÀ(ILLXYGKu;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 52
    .line 53
    .line 54
    monitor-exit p0

    .line 55
    return-void

    .line 56
    :catchall_0
    move-exception v0

    .line 57
    goto :goto_1

    .line 58
    :cond_1
    :goto_0
    monitor-exit p0

    .line 59
    return-void

    .line 60
    :goto_1
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 61
    throw v0
.end method

.method public final declared-synchronized tmpOffset3178(LfO0;)Z
    .locals 5

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-object v0, p1, LfO0;->jPos3709:Landroid/os/Bundle;

    .line 3
    .line 4
    const-string v1, "is_sdk_preload"

    .line 5
    .line 6
    const/4 v2, 0x0

    .line 7
    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_0

    .line 12
    .line 13
    goto :goto_1

    .line 14
    :cond_0
    sget-object v0, LcPtla;->POOl:LvSize4545;

    .line 15
    .line 16
    invoke-virtual {v0}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Ljava/lang/Boolean;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1

    .line 27
    .line 28
    sget-object v0, LisIndex2415;->Gl1ID:LSdE$n$;

    .line 29
    .line 30
    sget-object v1, LIl1il;->POOl:LIl1il;

    .line 31
    .line 32
    iget-object v1, v1, LIl1il;->rz__9J_:LnCount1076;

    .line 33
    .line 34
    invoke-virtual {v1, v0}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    check-cast v0, Ljava/lang/Boolean;

    .line 39
    .line 40
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 41
    .line 42
    .line 43
    move-result v0

    .line 44
    if-eqz v0, :cond_1

    .line 45
    .line 46
    const/4 v0, 0x1

    .line 47
    goto :goto_0

    .line 48
    :cond_1
    const/4 v0, 0x0

    .line 49
    goto :goto_0

    .line 50
    :catchall_0
    move-exception p1

    .line 51
    goto :goto_3

    .line 52
    :goto_0
    iget-object v1, p0, LiData3805;->valuI:LxED$DU_3A$;

    .line 53
    .line 54
    iget v1, v1, LxED$DU_3A$;->jPos3709:I

    .line 55
    .line 56
    sget-object v3, LisIndex2415;->Qength:LSdE$n$;

    .line 57
    .line 58
    sget-object v4, LIl1il;->POOl:LIl1il;

    .line 59
    .line 60
    iget-object v4, v4, LIl1il;->rz__9J_:LnCount1076;

    .line 61
    .line 62
    invoke-virtual {v4, v3}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v3

    .line 66
    check-cast v3, Ljava/lang/Integer;

    .line 67
    .line 68
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 69
    .line 70
    .line 71
    move-result v3

    .line 72
    if-lt v1, v3, :cond_2

    .line 73
    .line 74
    if-nez v0, :cond_3

    .line 75
    .line 76
    :cond_2
    const-string v0, "loadAd must be called on the main UI thread."

    .line 77
    .line 78
    invoke-static {v0}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    :cond_3
    :goto_1
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 82
    .line 83
    iget-object v0, v0, LvItem598;->rz__9J_:LQ__wr_;

    .line 84
    .line 85
    iget-object v0, p0, LiData3805;->vaIue:Landroid/content/Context;

    .line 86
    .line 87
    invoke-static {v0}, LQ__wr_;->sKey7917(Landroid/content/Context;)Z

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-eqz v0, :cond_5

    .line 92
    .line 93
    iget-object v0, p1, LfO0;->sKey6064:LNlCjcEùr;

    .line 94
    .line 95
    if-eqz v0, :cond_4

    .line 96
    .line 97
    goto :goto_2

    .line 98
    :cond_4
    const-string p1, "Failed to load the ad because app ID is missing."

    .line 99
    .line 100
    invoke-static {p1}, LPJNypàa;->WoI_9_(Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    iget-object p1, p0, LiData3805;->Ialue:LkData5861;

    .line 104
    .line 105
    const/4 v0, 0x4

    .line 106
    const/4 v1, 0x0

    .line 107
    invoke-static {v0, v1, v1}, LdQta;->iCount5302(ILjava/lang/String;LjData6565;)LjData6565;

    .line 108
    .line 109
    .line 110
    move-result-object v0

    .line 111
    invoke-virtual {p1, v0}, LkData5861;->vSize1911(LjData6565;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 112
    .line 113
    .line 114
    monitor-exit p0

    .line 115
    return v2

    .line 116
    :cond_5
    :goto_2
    :try_start_1
    invoke-virtual {p0}, LiData3805;->mItem9003()Z

    .line 117
    .line 118
    .line 119
    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 120
    if-eqz v0, :cond_6

    .line 121
    .line 122
    monitor-exit p0

    .line 123
    return v2

    .line 124
    :cond_6
    :try_start_2
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 125
    .line 126
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    .line 127
    .line 128
    .line 129
    iput-object v0, p0, LiData3805;->jPos3709:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 130
    .line 131
    new-instance v0, LRSF$f4$;

    .line 132
    .line 133
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 134
    .line 135
    .line 136
    iget-object v1, p0, LiData3805;->kQy:Lell1QQ;

    .line 137
    .line 138
    iget-object v2, p0, LiData3805;->iOffset934:Ljava/lang/String;

    .line 139
    .line 140
    new-instance v3, LvtF_Nd$TJ_;

    .line 141
    .line 142
    const/16 v4, 0x8

    .line 143
    .line 144
    invoke-direct {v3, v4, p0}, LvtF_Nd$TJ_;-><init>(ILjava/lang/Object;)V

    .line 145
    .line 146
    .line 147
    invoke-virtual {v1, p1, v2, v0, v3}, Lell1QQ;->e8$mp_s$(LfO0;Ljava/lang/String;LN11Il1;LGrC_PW$oa_;)Z

    .line 148
    .line 149
    .line 150
    move-result p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 151
    monitor-exit p0

    .line 152
    return p1

    .line 153
    :goto_3
    :try_start_3
    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 154
    throw p1
.end method

.method public final tmpValue4603(LmIndex723;)V
    .locals 1

    .line 1
    iget-object v0, p0, LiData3805;->kQy:Lell1QQ;

    .line 2
    .line 3
    iget-object v0, v0, Lell1QQ;->yON3x:LSQ1OlI;

    .line 4
    .line 5
    iput-object p1, v0, LSQ1OlI;->yON3x:LmIndex723;

    .line 6
    .line 7
    return-void
.end method

.method public final declared-synchronized vData2659()V
    .locals 0

    .line 1
    monitor-enter p0

    .line 2
    monitor-exit p0

    .line 3
    return-void
.end method

.method public final vData9996(Lqw$Z$;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final vIndex5150(LfO0;LjOffset2714;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final vaIue()Landroid/os/Bundle;
    .locals 1

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object v0
.end method

.method public final yON3x()LAmzxB;
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    return-object v0
.end method
