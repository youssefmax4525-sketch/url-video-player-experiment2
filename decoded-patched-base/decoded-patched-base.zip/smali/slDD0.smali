.class public interface abstract LslDD0;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LvOffset4792;
