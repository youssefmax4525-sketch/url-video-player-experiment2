.class public final synthetic LxjeNPnM;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic jPos3709:Lorg/cybergarage/upnp/Device;

.field public final synthetic vaIue:LUBK;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LUBK;Lorg/cybergarage/upnp/Device;I)V
    .locals 0

    .line 1
    iput p3, p0, LxjeNPnM;->yON3x:I

    iput-object p1, p0, LxjeNPnM;->vaIue:LUBK;

    iput-object p2, p0, LxjeNPnM;->jPos3709:Lorg/cybergarage/upnp/Device;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final e8$mp_s$()V
    .locals 9

    .line 1
    iget-object v0, p0, LxjeNPnM;->vaIue:LUBK;

    .line 2
    .line 3
    iget-object v1, p0, LxjeNPnM;->jPos3709:Lorg/cybergarage/upnp/Device;

    .line 4
    .line 5
    iget-object v0, v0, LUBK;->JKEoÙX:LTCyD9È5;

    .line 6
    .line 7
    if-eqz v0, :cond_2

    .line 8
    .line 9
    iget-object v0, v0, LTCyD9È5;->vaIue:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, LsIndex9566;

    .line 12
    .line 13
    iget-object v0, v0, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, LisItem6344;

    .line 16
    .line 17
    check-cast v0, Linfo/t4w/vp/view/MultiCastActivity;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    :try_start_0
    iget-object v2, v0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 23
    .line 24
    monitor-enter v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 25
    :try_start_1
    iget-object v3, v0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 26
    .line 27
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    const/4 v5, 0x0

    .line 32
    const/4 v6, 0x0

    .line 33
    :cond_0
    if-ge v6, v4, :cond_1

    .line 34
    .line 35
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v7

    .line 39
    add-int/lit8 v6, v6, 0x1

    .line 40
    .line 41
    check-cast v7, Lorg/cybergarage/upnp/Device;

    .line 42
    .line 43
    invoke-virtual {v7}, Lorg/cybergarage/upnp/Device;->getUDN()Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v7

    .line 47
    invoke-virtual {v1}, Lorg/cybergarage/upnp/Device;->getUDN()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v8

    .line 51
    invoke-virtual {v7, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v7

    .line 55
    if-eqz v7, :cond_0

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :catchall_0
    move-exception v0

    .line 59
    goto :goto_1

    .line 60
    :cond_1
    iget-object v3, v0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 61
    .line 62
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 63
    .line 64
    .line 65
    const/4 v5, 0x1

    .line 66
    :goto_0
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 67
    if-eqz v5, :cond_2

    .line 68
    .line 69
    :try_start_2
    iget-object v2, v0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 70
    .line 71
    new-instance v3, LsnzSYFYw;

    .line 72
    .line 73
    const/4 v4, 0x1

    .line 74
    invoke-direct {v3, v0, v1, v4}, LsnzSYFYw;-><init>(Linfo/t4w/vp/view/MultiCastActivity;Lorg/cybergarage/upnp/Device;I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 78
    .line 79
    .line 80
    return-void

    .line 81
    :catch_0
    move-exception v0

    .line 82
    goto :goto_2

    .line 83
    :goto_1
    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 84
    :try_start_4
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 85
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    :cond_2
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget v0, p0, LxjeNPnM;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LxjeNPnM;->vaIue:LUBK;

    .line 7
    .line 8
    iget-object v1, p0, LxjeNPnM;->jPos3709:Lorg/cybergarage/upnp/Device;

    .line 9
    .line 10
    iget-object v0, v0, LUBK;->JKEoÙX:LTCyD9È5;

    .line 11
    .line 12
    if-eqz v0, :cond_3

    .line 13
    .line 14
    iget-object v0, v0, LTCyD9È5;->vaIue:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, LsIndex9566;

    .line 17
    .line 18
    iget-object v0, v0, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, LisItem6344;

    .line 21
    .line 22
    check-cast v0, Linfo/t4w/vp/view/MultiCastActivity;

    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    :try_start_0
    iget-object v2, v0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 28
    .line 29
    monitor-enter v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 30
    :try_start_1
    invoke-virtual {v1}, Lorg/cybergarage/upnp/Device;->getUDN()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    iget-object v3, v0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    const/4 v5, 0x0

    .line 41
    :cond_0
    if-ge v5, v4, :cond_1

    .line 42
    .line 43
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    add-int/lit8 v5, v5, 0x1

    .line 48
    .line 49
    check-cast v6, Lorg/cybergarage/upnp/Device;

    .line 50
    .line 51
    invoke-virtual {v6}, Lorg/cybergarage/upnp/Device;->getUDN()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v7

    .line 55
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result v7

    .line 59
    if-eqz v7, :cond_0

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :catchall_0
    move-exception v0

    .line 63
    goto :goto_1

    .line 64
    :cond_1
    const/4 v6, 0x0

    .line 65
    :goto_0
    if-eqz v6, :cond_2

    .line 66
    .line 67
    iget-object v1, v0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 68
    .line 69
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    :cond_2
    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 73
    :try_start_2
    iget-object v1, v0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 74
    .line 75
    new-instance v2, Lcn_v_;

    .line 76
    .line 77
    const/16 v3, 0x11

    .line 78
    .line 79
    invoke-direct {v2, v0, v3}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 83
    .line 84
    .line 85
    goto :goto_3

    .line 86
    :catch_0
    move-exception v0

    .line 87
    goto :goto_2

    .line 88
    :goto_1
    :try_start_3
    monitor-exit v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 89
    :try_start_4
    throw v0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 90
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 94
    .line 95
    .line 96
    :cond_3
    :goto_3
    return-void

    .line 97
    :pswitch_0
    invoke-direct {p0}, LxjeNPnM;->e8$mp_s$()V

    .line 98
    .line 99
    .line 100
    return-void

    .line 101
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
