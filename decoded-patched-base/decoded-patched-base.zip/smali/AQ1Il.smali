.class public final LAQ1Il;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LwI1O;
.implements Lhlg$l_D$;


# instance fields
.field public final vaIue:Lhlg$l_D$;

.field public final yON3x:LwI1O;


# direct methods
.method public synthetic constructor <init>(LwI1O;Lhlg$l_D$;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAQ1Il;->yON3x:LwI1O;

    .line 5
    .line 6
    iput-object p2, p0, LAQ1Il;->vaIue:Lhlg$l_D$;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final POOl(LQNNzV;)V
    .locals 1

    .line 1
    iget-object v0, p0, LAQ1Il;->yON3x:LwI1O;

    .line 2
    .line 3
    invoke-interface {v0, p1}, LwI1O;->POOl(LQNNzV;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final rz__9J_(LIIII;)V
    .locals 1

    .line 1
    iget-object v0, p0, LAQ1Il;->vaIue:Lhlg$l_D$;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Lhlg$l_D$;->rz__9J_(LIIII;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
