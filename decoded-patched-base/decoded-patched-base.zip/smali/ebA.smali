.class public final LebA;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LTSNàm;


# direct methods
.method public constructor <init>(LTSNàm;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LebA;->e8$mp_s$:LTSNàm;

    .line 5
    .line 6
    return-void
.end method

.method public static final e8$mp_s$(Landroid/content/Context;)LebA;
    .locals 8

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, LZkZz;->e8$mp_s$:LZkZz;

    .line 5
    .line 6
    const/16 v3, 0x1e

    .line 7
    .line 8
    if-lt v0, v3, :cond_0

    .line 9
    .line 10
    invoke-virtual {v2}, LZkZz;->e8$mp_s$()I

    .line 11
    .line 12
    .line 13
    move-result v4

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v4, 0x0

    .line 16
    :goto_0
    const/4 v5, 0x5

    .line 17
    const/4 v6, 0x0

    .line 18
    const-string v7, "context.getSystemService\u2026opicsManager::class.java)"

    .line 19
    .line 20
    if-lt v4, v5, :cond_1

    .line 21
    .line 22
    new-instance v0, LtmpValue9533;

    .line 23
    .line 24
    invoke-static {}, LvItem9215;->pCXDYg()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-static {p0, v1}, Ljc4_8W$K_;->pCXDYg(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-static {v7, p0}, LdbÙLJ;->sKey7917(Ljava/lang/String;Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    invoke-static {p0}, LvItem9215;->jPos3709(Ljava/lang/Object;)Landroid/adservices/topics/TopicsManager;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    const/4 v1, 0x1

    .line 40
    invoke-direct {v0, p0, v1}, LtmpValue9533;-><init>(Landroid/adservices/topics/TopicsManager;I)V

    .line 41
    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    if-lt v0, v3, :cond_2

    .line 45
    .line 46
    invoke-virtual {v2}, LZkZz;->e8$mp_s$()I

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    :cond_2
    const/4 v0, 0x4

    .line 51
    if-ne v1, v0, :cond_3

    .line 52
    .line 53
    new-instance v0, LtmpValue9533;

    .line 54
    .line 55
    invoke-static {}, LvItem9215;->pCXDYg()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    invoke-static {p0, v1}, Ljc4_8W$K_;->pCXDYg(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    invoke-static {v7, p0}, LdbÙLJ;->sKey7917(Ljava/lang/String;Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-static {p0}, LvItem9215;->jPos3709(Ljava/lang/Object;)Landroid/adservices/topics/TopicsManager;

    .line 67
    .line 68
    .line 69
    move-result-object p0

    .line 70
    const/4 v1, 0x0

    .line 71
    invoke-direct {v0, p0, v1}, LtmpValue9533;-><init>(Landroid/adservices/topics/TopicsManager;I)V

    .line 72
    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_3
    move-object v0, v6

    .line 76
    :goto_1
    if-eqz v0, :cond_4

    .line 77
    .line 78
    new-instance p0, LebA;

    .line 79
    .line 80
    invoke-direct {p0, v0}, LebA;-><init>(LTSNàm;)V

    .line 81
    .line 82
    .line 83
    return-object p0

    .line 84
    :cond_4
    return-object v6
.end method


# virtual methods
.method public waiBKÀ(LiQJeDCWE;)LeO;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "LiQJeDCWE;",
            ")",
            "LeO;"
        }
    .end annotation

    .line 1
    sget-object v0, LhZ_L$Xs_;->e8$mp_s$:L_1_PB_;

    .line 2
    .line 3
    sget-object v0, LiSize8628;->e8$mp_s$:LWEòg;

    .line 4
    .line 5
    invoke-static {v0}, LdbÙLJ;->e8$mp_s$(LyqÈS;)LtmpKey1882;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    new-instance v1, LqÒSÒxÀQX;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    invoke-direct {v1, p0, p1, v2}, LqÒSÒxÀQX;-><init>(LebA;LiQJeDCWE;LCw$vQ_6V$;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1}, LQEHcu;->waiBKÀ(LtmpKey1882;LnCount8552;)LblDQl;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    invoke-static {p1}, LmKB;->waiBKÀ(LblDQl;)LXI0QI;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    return-object p1
.end method
