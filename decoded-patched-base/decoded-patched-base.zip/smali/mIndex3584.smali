.class public final synthetic LmIndex3584;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic Ialue:LHHH$Qf$;

.field public final synthetic iOffset934:Ljava/util/List;

.field public final synthetic jPos3709:Landroid/os/Bundle;

.field public final synthetic kQy:Ls0l1D;

.field public final synthetic vaIue:LOÀB2s1;

.field public final synthetic yON3x:LXXI_M_;


# direct methods
.method public synthetic constructor <init>(LXXI_M_;LOÀB2s1;Landroid/os/Bundle;Ljava/util/List;Ls0l1D;LHHH$Qf$;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LmIndex3584;->yON3x:LXXI_M_;

    .line 5
    .line 6
    iput-object p2, p0, LmIndex3584;->vaIue:LOÀB2s1;

    .line 7
    .line 8
    iput-object p3, p0, LmIndex3584;->jPos3709:Landroid/os/Bundle;

    .line 9
    .line 10
    iput-object p4, p0, LmIndex3584;->iOffset934:Ljava/util/List;

    .line 11
    .line 12
    iput-object p5, p0, LmIndex3584;->kQy:Ls0l1D;

    .line 13
    .line 14
    iput-object p6, p0, LmIndex3584;->Ialue:LHHH$Qf$;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final run()V
    .locals 8

    .line 1
    iget-object v0, p0, LmIndex3584;->yON3x:LXXI_M_;

    .line 2
    .line 3
    iget-object v1, p0, LmIndex3584;->vaIue:LOÀB2s1;

    .line 4
    .line 5
    iget-object v4, p0, LmIndex3584;->jPos3709:Landroid/os/Bundle;

    .line 6
    .line 7
    iget-object v2, p0, LmIndex3584;->iOffset934:Ljava/util/List;

    .line 8
    .line 9
    iget-object v7, p0, LmIndex3584;->kQy:Ls0l1D;

    .line 10
    .line 11
    :try_start_0
    iget-object v3, v0, LXXI_M_;->POOl:Landroid/content/Context;

    .line 12
    .line 13
    move-object v5, v2

    .line 14
    new-instance v2, Lfdo_n_;

    .line 15
    .line 16
    invoke-direct {v2, v3}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    invoke-interface {v5, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    move-object v5, v3

    .line 25
    check-cast v5, Landroid/os/Bundle;

    .line 26
    .line 27
    iget-object v3, v0, LXXI_M_;->vaIue:Ljava/lang/String;

    .line 28
    .line 29
    iget-object v0, v0, LXXI_M_;->JKEoÙX:LQoXYbY;

    .line 30
    .line 31
    iget-object v6, v0, LQoXYbY;->JKEoÙX:Lmh_p$kn_;

    .line 32
    .line 33
    invoke-interface/range {v1 .. v7}, LOÀB2s1;->Ii1(LKàaq;Ljava/lang/String;Landroid/os/Bundle;Landroid/os/Bundle;Lmh_p$kn_;LgPos9226;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :catch_0
    move-exception v0

    .line 38
    iget-object v1, p0, LmIndex3584;->Ialue:LHHH$Qf$;

    .line 39
    .line 40
    invoke-virtual {v1, v0}, LHHH$Qf$;->rz__9J_(Ljava/lang/Throwable;)Z

    .line 41
    .line 42
    .line 43
    return-void
.end method
