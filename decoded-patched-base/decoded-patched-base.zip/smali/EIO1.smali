.class public final LEIO1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final POOl:LqD11O1;

.field public final e8$mp_s$:Ljava/util/concurrent/Executor;

.field public final rz__9J_:LPX6$F_j$;

.field public final waiBKÀ:LjValue2770;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Executor;LjValue2770;LPX6$F_j$;LqD11O1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LEIO1;->e8$mp_s$:Ljava/util/concurrent/Executor;

    .line 5
    .line 6
    iput-object p2, p0, LEIO1;->waiBKÀ:LjValue2770;

    .line 7
    .line 8
    iput-object p3, p0, LEIO1;->rz__9J_:LPX6$F_j$;

    .line 9
    .line 10
    iput-object p4, p0, LEIO1;->POOl:LqD11O1;

    .line 11
    .line 12
    return-void
.end method
