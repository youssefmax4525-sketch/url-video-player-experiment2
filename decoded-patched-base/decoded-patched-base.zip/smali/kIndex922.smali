.class public final LkIndex922;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final JKEoÙX:LaX9m$Q;

.field public final POOl:LDKbÀD;

.field public final e8$mp_s$:Ljava/lang/String;

.field public final rz__9J_:L$X7x7d0o;

.field public final waiBKÀ:LKÒyÙ;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    sget-object v0, LnW_cN_;->vaIue:Ljk_NI_;

    .line 2
    .line 3
    sget-object v0, LlII1II;->kQy:LlII1II;

    .line 4
    .line 5
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 6
    .line 7
    sget-object v0, Lhf$O4_7H$;->e8$mp_s$:Lhf$O4_7H$;

    .line 8
    .line 9
    new-instance v0, LaX9m$Q;

    .line 10
    .line 11
    invoke-direct {v0}, LsData9614;-><init>()V

    .line 12
    .line 13
    .line 14
    new-instance v0, L$X7x7d0o;

    .line 15
    .line 16
    sget-object v0, LDKbÀD;->tmpSize211:LDKbÀD;

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    const/16 v1, 0x24

    .line 20
    .line 21
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    const/4 v0, 0x1

    .line 25
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    const/4 v0, 0x2

    .line 29
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    const/4 v0, 0x3

    .line 33
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    const/4 v0, 0x4

    .line 37
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    const/4 v0, 0x5

    .line 41
    invoke-static {v0, v1}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;LaX9m$Q;LKÒyÙ;L$X7x7d0o;LDKbÀD;)V
    .locals 1

    .line 1
    sget-object v0, Lhf$O4_7H$;->e8$mp_s$:Lhf$O4_7H$;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, LkIndex922;->e8$mp_s$:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, LkIndex922;->waiBKÀ:LKÒyÙ;

    .line 9
    .line 10
    iput-object p4, p0, LkIndex922;->rz__9J_:L$X7x7d0o;

    .line 11
    .line 12
    iput-object p5, p0, LkIndex922;->POOl:LDKbÀD;

    .line 13
    .line 14
    iput-object p2, p0, LkIndex922;->JKEoÙX:LaX9m$Q;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 2

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    goto :goto_0

    .line 4
    :cond_0
    instance-of v0, p1, LkIndex922;

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    goto :goto_1

    .line 9
    :cond_1
    check-cast p1, LkIndex922;

    .line 10
    .line 11
    iget-object v0, p0, LkIndex922;->e8$mp_s$:Ljava/lang/String;

    .line 12
    .line 13
    iget-object v1, p1, LkIndex922;->e8$mp_s$:Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    iget-object v0, p0, LkIndex922;->JKEoÙX:LaX9m$Q;

    .line 22
    .line 23
    iget-object v1, p1, LkIndex922;->JKEoÙX:LaX9m$Q;

    .line 24
    .line 25
    invoke-virtual {v0, v1}, LsData9614;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    iget-object v0, p0, LkIndex922;->waiBKÀ:LKÒyÙ;

    .line 32
    .line 33
    iget-object v1, p1, LkIndex922;->waiBKÀ:LKÒyÙ;

    .line 34
    .line 35
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_2

    .line 40
    .line 41
    iget-object v0, p0, LkIndex922;->rz__9J_:L$X7x7d0o;

    .line 42
    .line 43
    iget-object v1, p1, LkIndex922;->rz__9J_:L$X7x7d0o;

    .line 44
    .line 45
    invoke-virtual {v0, v1}, L$X7x7d0o;->equals(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result v0

    .line 49
    if-eqz v0, :cond_2

    .line 50
    .line 51
    iget-object v0, p0, LkIndex922;->POOl:LDKbÀD;

    .line 52
    .line 53
    iget-object p1, p1, LkIndex922;->POOl:LDKbÀD;

    .line 54
    .line 55
    invoke-static {v0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 56
    .line 57
    .line 58
    move-result p1

    .line 59
    if-eqz p1, :cond_2

    .line 60
    .line 61
    sget-object p1, Lhf$O4_7H$;->e8$mp_s$:Lhf$O4_7H$;

    .line 62
    .line 63
    invoke-virtual {p1, p1}, Lhf$O4_7H$;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    if-eqz p1, :cond_2

    .line 68
    .line 69
    :goto_0
    const/4 p1, 0x1

    .line 70
    return p1

    .line 71
    :cond_2
    :goto_1
    const/4 p1, 0x0

    .line 72
    return p1
.end method

.method public final hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, LkIndex922;->e8$mp_s$:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget-object v1, p0, LkIndex922;->waiBKÀ:LKÒyÙ;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {v1}, LKÒyÙ;->hashCode()I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    const/4 v1, 0x0

    .line 19
    :goto_0
    add-int/2addr v0, v1

    .line 20
    mul-int/lit8 v0, v0, 0x1f

    .line 21
    .line 22
    iget-object v1, p0, LkIndex922;->rz__9J_:L$X7x7d0o;

    .line 23
    .line 24
    invoke-virtual {v1}, L$X7x7d0o;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    add-int/2addr v1, v0

    .line 29
    mul-int/lit8 v1, v1, 0x1f

    .line 30
    .line 31
    iget-object v0, p0, LkIndex922;->JKEoÙX:LaX9m$Q;

    .line 32
    .line 33
    invoke-virtual {v0}, LsData9614;->hashCode()I

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    add-int/2addr v0, v1

    .line 38
    mul-int/lit8 v0, v0, 0x1f

    .line 39
    .line 40
    iget-object v1, p0, LkIndex922;->POOl:LDKbÀD;

    .line 41
    .line 42
    invoke-virtual {v1}, LDKbÀD;->hashCode()I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    add-int/2addr v1, v0

    .line 47
    mul-int/lit8 v1, v1, 0x1f

    .line 48
    .line 49
    return v1
.end method
