.class public interface abstract LgdN;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LvOffset4792;
