.class public final La9$I_FH$;
.super LADllI1;
.source "SourceFile"

# interfaces
.implements LVB8J;


# instance fields
.field public final DDù8:LWÒò;

.field public Ialue:I

.field public final JKEoÙX:Ljava/net/Socket;

.field public final POOl:LGIQ;

.field public gKey4112:J

.field public iOffset934:Z

.field public jPos3709:Z

.field public kQy:I

.field public pCXDYg:I

.field public final rz__9J_:LkOffset7125;

.field public final sKey7917:Ll00;

.field public final tmpData3485:Ljava/net/Socket;

.field public vaIue:Lgp_T_;

.field public valuI:I

.field public final waiBKÀ:LCÒllàY;

.field public final yON3x:LsIndex9566;

.field public final yàÒZ:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(LCÒllàY;LkOffset7125;LGIQ;Ljava/net/Socket;Ljava/net/Socket;Ll00;LWÒò;LsIndex9566;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, La9$I_FH$;->waiBKÀ:LCÒllàY;

    .line 5
    .line 6
    iput-object p2, p0, La9$I_FH$;->rz__9J_:LkOffset7125;

    .line 7
    .line 8
    iput-object p3, p0, La9$I_FH$;->POOl:LGIQ;

    .line 9
    .line 10
    iput-object p4, p0, La9$I_FH$;->JKEoÙX:Ljava/net/Socket;

    .line 11
    .line 12
    iput-object p5, p0, La9$I_FH$;->tmpData3485:Ljava/net/Socket;

    .line 13
    .line 14
    iput-object p6, p0, La9$I_FH$;->sKey7917:Ll00;

    .line 15
    .line 16
    iput-object p7, p0, La9$I_FH$;->DDù8:LWÒò;

    .line 17
    .line 18
    iput-object p8, p0, La9$I_FH$;->yON3x:LsIndex9566;

    .line 19
    .line 20
    const/4 p1, 0x1

    .line 21
    iput p1, p0, La9$I_FH$;->pCXDYg:I

    .line 22
    .line 23
    new-instance p1, Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 26
    .line 27
    .line 28
    iput-object p1, p0, La9$I_FH$;->yàÒZ:Ljava/util/ArrayList;

    .line 29
    .line 30
    const-wide p1, 0x7fffffffffffffffL

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    iput-wide p1, p0, La9$I_FH$;->gKey4112:J

    .line 36
    .line 37
    return-void
.end method

.method public static rz__9J_(LtmpKey8240;LGIQ;Ljava/io/IOException;)V
    .locals 3

    .line 1
    iget-object v0, p1, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sget-object v1, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    .line 8
    .line 9
    if-eq v0, v1, :cond_0

    .line 10
    .line 11
    iget-object v0, p1, LGIQ;->e8$mp_s$:LnValue2624;

    .line 12
    .line 13
    iget-object v1, v0, LnValue2624;->sKey7917:Ljava/net/ProxySelector;

    .line 14
    .line 15
    iget-object v0, v0, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 16
    .line 17
    invoke-virtual {v0}, LUu_Kn$K_;->sKey7917()Ljava/net/URI;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iget-object v2, p1, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/net/Proxy;->address()Ljava/net/SocketAddress;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-virtual {v1, v0, v2, p2}, Ljava/net/ProxySelector;->connectFailed(Ljava/net/URI;Ljava/net/SocketAddress;Ljava/io/IOException;)V

    .line 28
    .line 29
    .line 30
    :cond_0
    iget-object p0, p0, LtmpKey8240;->sKey6064:L$1Q0O;

    .line 31
    .line 32
    monitor-enter p0

    .line 33
    :try_start_0
    iget-object p2, p0, L$1Q0O;->vaIue:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p2, Ljava/util/LinkedHashSet;

    .line 36
    .line 37
    invoke-interface {p2, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    .line 39
    .line 40
    monitor-exit p0

    .line 41
    return-void

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 44
    throw p1
.end method


# virtual methods
.method public final DDù8(LnValue2624;Ljava/util/List;)Z
    .locals 7

    .line 1
    iget-object v0, p1, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 2
    .line 3
    sget-object v1, LyhM_S9$N_;->e8$mp_s$:Ljava/util/TimeZone;

    .line 4
    .line 5
    iget-object v1, p0, La9$I_FH$;->yàÒZ:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    iget v2, p0, La9$I_FH$;->pCXDYg:I

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    if-ge v1, v2, :cond_a

    .line 15
    .line 16
    iget-boolean v1, p0, La9$I_FH$;->jPos3709:Z

    .line 17
    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    goto/16 :goto_2

    .line 21
    .line 22
    :cond_0
    iget-object v1, p0, La9$I_FH$;->POOl:LGIQ;

    .line 23
    .line 24
    iget-object v2, v1, LGIQ;->e8$mp_s$:LnValue2624;

    .line 25
    .line 26
    iget-object v4, v1, LGIQ;->e8$mp_s$:LnValue2624;

    .line 27
    .line 28
    invoke-virtual {v2, p1}, LnValue2624;->e8$mp_s$(LnValue2624;)Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-nez v2, :cond_1

    .line 33
    .line 34
    goto/16 :goto_2

    .line 35
    .line 36
    :cond_1
    iget-object v2, v0, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 37
    .line 38
    iget-object v5, v4, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 39
    .line 40
    iget-object v5, v5, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 41
    .line 42
    invoke-static {v2, v5}, LdbÙLJ;->rz__9J_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v2, :cond_2

    .line 47
    .line 48
    goto/16 :goto_1

    .line 49
    .line 50
    :cond_2
    iget-object v2, p0, La9$I_FH$;->vaIue:Lgp_T_;

    .line 51
    .line 52
    if-nez v2, :cond_3

    .line 53
    .line 54
    goto/16 :goto_2

    .line 55
    .line 56
    :cond_3
    if-eqz p2, :cond_a

    .line 57
    .line 58
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    .line 59
    .line 60
    .line 61
    move-result v2

    .line 62
    if-eqz v2, :cond_4

    .line 63
    .line 64
    goto/16 :goto_2

    .line 65
    .line 66
    :cond_4
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 67
    .line 68
    .line 69
    move-result-object p2

    .line 70
    :cond_5
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-eqz v2, :cond_a

    .line 75
    .line 76
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v2

    .line 80
    check-cast v2, LGIQ;

    .line 81
    .line 82
    iget-object v5, v2, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 83
    .line 84
    invoke-virtual {v5}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    sget-object v6, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    .line 89
    .line 90
    if-ne v5, v6, :cond_5

    .line 91
    .line 92
    iget-object v5, v1, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 93
    .line 94
    invoke-virtual {v5}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    .line 95
    .line 96
    .line 97
    move-result-object v5

    .line 98
    if-ne v5, v6, :cond_5

    .line 99
    .line 100
    iget-object v5, v1, LGIQ;->rz__9J_:Ljava/net/InetSocketAddress;

    .line 101
    .line 102
    iget-object v2, v2, LGIQ;->rz__9J_:Ljava/net/InetSocketAddress;

    .line 103
    .line 104
    invoke-static {v5, v2}, LdbÙLJ;->rz__9J_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    if-eqz v2, :cond_5

    .line 109
    .line 110
    iget-object p2, p1, LnValue2624;->POOl:Ljavax/net/ssl/HostnameVerifier;

    .line 111
    .line 112
    sget-object v1, Lr0QD0O;->e8$mp_s$:Lr0QD0O;

    .line 113
    .line 114
    if-eq p2, v1, :cond_6

    .line 115
    .line 116
    goto :goto_2

    .line 117
    :cond_6
    sget-object p2, LyhM_S9$N_;->e8$mp_s$:Ljava/util/TimeZone;

    .line 118
    .line 119
    iget-object p2, v4, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 120
    .line 121
    iget v1, v0, LUu_Kn$K_;->JKEoÙX:I

    .line 122
    .line 123
    iget-object v0, v0, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 124
    .line 125
    iget v2, p2, LUu_Kn$K_;->JKEoÙX:I

    .line 126
    .line 127
    if-eq v1, v2, :cond_7

    .line 128
    .line 129
    goto :goto_2

    .line 130
    :cond_7
    iget-object p2, p2, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 131
    .line 132
    invoke-static {v0, p2}, LdbÙLJ;->rz__9J_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result p2

    .line 136
    iget-object v1, p0, La9$I_FH$;->sKey7917:Ll00;

    .line 137
    .line 138
    if-eqz p2, :cond_8

    .line 139
    .line 140
    goto :goto_0

    .line 141
    :cond_8
    iget-boolean p2, p0, La9$I_FH$;->iOffset934:Z

    .line 142
    .line 143
    if-nez p2, :cond_a

    .line 144
    .line 145
    if-eqz v1, :cond_a

    .line 146
    .line 147
    invoke-virtual {v1}, Ll00;->e8$mp_s$()Ljava/util/List;

    .line 148
    .line 149
    .line 150
    move-result-object p2

    .line 151
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    .line 152
    .line 153
    .line 154
    move-result v2

    .line 155
    if-nez v2, :cond_a

    .line 156
    .line 157
    invoke-interface {p2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    check-cast p2, Ljava/security/cert/X509Certificate;

    .line 162
    .line 163
    invoke-static {v0, p2}, Lr0QD0O;->rz__9J_(Ljava/lang/String;Ljava/security/cert/X509Certificate;)Z

    .line 164
    .line 165
    .line 166
    move-result p2

    .line 167
    if-eqz p2, :cond_a

    .line 168
    .line 169
    :goto_0
    :try_start_0
    iget-object p1, p1, LnValue2624;->JKEoÙX:LiOffset4404;

    .line 170
    .line 171
    invoke-virtual {v1}, Ll00;->e8$mp_s$()Ljava/util/List;

    .line 172
    .line 173
    .line 174
    iget-object p1, p1, LiOffset4404;->e8$mp_s$:Ljava/util/Set;

    .line 175
    .line 176
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 181
    .line 182
    .line 183
    move-result p2

    .line 184
    if-nez p2, :cond_9

    .line 185
    .line 186
    :goto_1
    const/4 p1, 0x1

    .line 187
    return p1

    .line 188
    :cond_9
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    invoke-static {p1}, LRQU_K6$Kv_;->Qp_Hp$i_(Ljava/lang/Object;)V

    .line 193
    .line 194
    .line 195
    const/4 p1, 0x0

    .line 196
    throw p1
    :try_end_0
    .catch Ljavax/net/ssl/SSLPeerUnverifiedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 197
    :catch_0
    :cond_a
    :goto_2
    return v3
.end method

.method public final JKEoÙX(LvKey7702;Ljava/io/IOException;)V
    .locals 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    instance-of v0, p2, LiIndex5728;

    .line 3
    .line 4
    const/4 v1, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    move-object v0, p2

    .line 8
    check-cast v0, LiIndex5728;

    .line 9
    .line 10
    iget v0, v0, LiIndex5728;->yON3x:I

    .line 11
    .line 12
    const/16 v2, 0x8

    .line 13
    .line 14
    if-ne v0, v2, :cond_0

    .line 15
    .line 16
    iget p1, p0, La9$I_FH$;->valuI:I

    .line 17
    .line 18
    add-int/2addr p1, v1

    .line 19
    iput p1, p0, La9$I_FH$;->valuI:I

    .line 20
    .line 21
    if-le p1, v1, :cond_6

    .line 22
    .line 23
    iput-boolean v1, p0, La9$I_FH$;->jPos3709:Z

    .line 24
    .line 25
    iget p1, p0, La9$I_FH$;->kQy:I

    .line 26
    .line 27
    add-int/2addr p1, v1

    .line 28
    iput p1, p0, La9$I_FH$;->kQy:I

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :catchall_0
    move-exception p1

    .line 32
    goto :goto_2

    .line 33
    :cond_0
    check-cast p2, LiIndex5728;

    .line 34
    .line 35
    iget p2, p2, LiIndex5728;->yON3x:I

    .line 36
    .line 37
    const/16 v0, 0x9

    .line 38
    .line 39
    if-ne p2, v0, :cond_1

    .line 40
    .line 41
    iget-boolean p1, p1, LvKey7702;->UC_n_:Z

    .line 42
    .line 43
    if-nez p1, :cond_6

    .line 44
    .line 45
    :cond_1
    iput-boolean v1, p0, La9$I_FH$;->jPos3709:Z

    .line 46
    .line 47
    iget p1, p0, La9$I_FH$;->kQy:I

    .line 48
    .line 49
    add-int/2addr p1, v1

    .line 50
    iput p1, p0, La9$I_FH$;->kQy:I

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_2
    iget-object v0, p0, La9$I_FH$;->vaIue:Lgp_T_;

    .line 54
    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    const/4 v0, 0x1

    .line 58
    goto :goto_0

    .line 59
    :cond_3
    const/4 v0, 0x0

    .line 60
    :goto_0
    if-eqz v0, :cond_4

    .line 61
    .line 62
    instance-of v0, p2, LnData4392;

    .line 63
    .line 64
    if-eqz v0, :cond_6

    .line 65
    .line 66
    :cond_4
    iput-boolean v1, p0, La9$I_FH$;->jPos3709:Z

    .line 67
    .line 68
    iget v0, p0, La9$I_FH$;->Ialue:I

    .line 69
    .line 70
    if-nez v0, :cond_6

    .line 71
    .line 72
    if-eqz p2, :cond_5

    .line 73
    .line 74
    iget-object p1, p1, LvKey7702;->yON3x:LtmpKey8240;

    .line 75
    .line 76
    iget-object v0, p0, La9$I_FH$;->POOl:LGIQ;

    .line 77
    .line 78
    invoke-static {p1, v0, p2}, La9$I_FH$;->rz__9J_(LtmpKey8240;LGIQ;Ljava/io/IOException;)V

    .line 79
    .line 80
    .line 81
    :cond_5
    iget p1, p0, La9$I_FH$;->kQy:I

    .line 82
    .line 83
    add-int/2addr p1, v1

    .line 84
    iput p1, p0, La9$I_FH$;->kQy:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 85
    .line 86
    :cond_6
    :goto_1
    monitor-exit p0

    .line 87
    return-void

    .line 88
    :goto_2
    monitor-exit p0

    .line 89
    throw p1
.end method

.method public final POOl()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    const/4 v0, 0x1

    .line 3
    :try_start_0
    iput-boolean v0, p0, La9$I_FH$;->jPos3709:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 4
    .line 5
    monitor-exit p0

    .line 6
    return-void

    .line 7
    :catchall_0
    move-exception v0

    .line 8
    monitor-exit p0

    .line 9
    throw v0
.end method

.method public final cancel()V
    .locals 1

    .line 1
    iget-object v0, p0, La9$I_FH$;->JKEoÙX:Ljava/net/Socket;

    .line 2
    .line 3
    invoke-static {v0}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final e8$mp_s$(LiOffset8639;)V
    .locals 3

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget v0, p0, La9$I_FH$;->pCXDYg:I

    .line 3
    .line 4
    iget v1, p1, LiOffset8639;->e8$mp_s$:I

    .line 5
    .line 6
    and-int/lit8 v1, v1, 0x8

    .line 7
    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    iget-object p1, p1, LiOffset8639;->waiBKÀ:[I

    .line 11
    .line 12
    const/4 v1, 0x3

    .line 13
    aget p1, p1, v1

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    const p1, 0x7fffffff

    .line 17
    .line 18
    .line 19
    :goto_0
    iput p1, p0, La9$I_FH$;->pCXDYg:I

    .line 20
    .line 21
    if-ge p1, v0, :cond_2

    .line 22
    .line 23
    iget-object p1, p0, La9$I_FH$;->rz__9J_:LkOffset7125;

    .line 24
    .line 25
    iget-object v0, p0, La9$I_FH$;->POOl:LGIQ;

    .line 26
    .line 27
    iget-object v0, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 28
    .line 29
    iget-object p1, p1, LkOffset7125;->waiBKÀ:Ljava/util/Map;

    .line 30
    .line 31
    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    if-nez p1, :cond_1

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_1
    new-instance p1, Ljava/lang/ClassCastException;

    .line 39
    .line 40
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 41
    .line 42
    .line 43
    throw p1

    .line 44
    :catchall_0
    move-exception p1

    .line 45
    goto :goto_2

    .line 46
    :cond_2
    if-le p1, v0, :cond_3

    .line 47
    .line 48
    iget-object p1, p0, La9$I_FH$;->rz__9J_:LkOffset7125;

    .line 49
    .line 50
    iget-object v0, p1, LkOffset7125;->rz__9J_:Lco1nt;

    .line 51
    .line 52
    iget-object p1, p1, LkOffset7125;->POOl:LDni_4_;

    .line 53
    .line 54
    const-wide/16 v1, 0x0

    .line 55
    .line 56
    invoke-virtual {v0, p1, v1, v2}, Lco1nt;->POOl(LvaluO;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 57
    .line 58
    .line 59
    :cond_3
    :goto_1
    monitor-exit p0

    .line 60
    return-void

    .line 61
    :goto_2
    monitor-exit p0

    .line 62
    throw p1
.end method

.method public final sKey7917()LGIQ;
    .locals 1

    .line 1
    iget-object v0, p0, La9$I_FH$;->POOl:LGIQ;

    .line 2
    .line 3
    return-object v0
.end method

.method public final tmpData3485()V
    .locals 1

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget v0, p0, La9$I_FH$;->Ialue:I

    .line 3
    .line 4
    add-int/lit8 v0, v0, 0x1

    .line 5
    .line 6
    iput v0, p0, La9$I_FH$;->Ialue:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 7
    .line 8
    monitor-exit p0

    .line 9
    return-void

    .line 10
    :catchall_0
    move-exception v0

    .line 11
    monitor-exit p0

    .line 12
    throw v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Connection{"

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, La9$I_FH$;->POOl:LGIQ;

    .line 9
    .line 10
    iget-object v2, v1, LGIQ;->e8$mp_s$:LnValue2624;

    .line 11
    .line 12
    iget-object v2, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 13
    .line 14
    iget-object v2, v2, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const/16 v2, 0x3a

    .line 20
    .line 21
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    iget-object v2, v1, LGIQ;->e8$mp_s$:LnValue2624;

    .line 25
    .line 26
    iget-object v2, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 27
    .line 28
    iget v2, v2, LUu_Kn$K_;->JKEoÙX:I

    .line 29
    .line 30
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v2, ", proxy="

    .line 34
    .line 35
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    iget-object v2, v1, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 39
    .line 40
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v2, " hostAddress="

    .line 44
    .line 45
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    iget-object v1, v1, LGIQ;->rz__9J_:Ljava/net/InetSocketAddress;

    .line 49
    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    const-string v1, " cipherSuite="

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    iget-object v1, p0, La9$I_FH$;->sKey7917:Ll00;

    .line 59
    .line 60
    if-eqz v1, :cond_0

    .line 61
    .line 62
    iget-object v1, v1, Ll00;->waiBKÀ:LIG_7$a_;

    .line 63
    .line 64
    if-nez v1, :cond_1

    .line 65
    .line 66
    :cond_0
    const-string v1, "none"

    .line 67
    .line 68
    :cond_1
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 69
    .line 70
    .line 71
    const-string v1, " protocol="

    .line 72
    .line 73
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    iget-object v1, p0, La9$I_FH$;->DDù8:LWÒò;

    .line 77
    .line 78
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    const/16 v1, 0x7d

    .line 82
    .line 83
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    return-object v0
.end method

.method public final vaIue()V
    .locals 6

    .line 1
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 2
    .line 3
    .line 4
    move-result-wide v0

    .line 5
    iput-wide v0, p0, La9$I_FH$;->gKey4112:J

    .line 6
    .line 7
    iget-object v0, p0, La9$I_FH$;->DDù8:LWÒò;

    .line 8
    .line 9
    sget-object v1, LWÒò;->kQy:LWÒò;

    .line 10
    .line 11
    if-eq v0, v1, :cond_1

    .line 12
    .line 13
    sget-object v1, LWÒò;->Ialue:LWÒò;

    .line 14
    .line 15
    if-ne v0, v1, :cond_0

    .line 16
    .line 17
    goto :goto_0

    .line 18
    :cond_0
    return-void

    .line 19
    :cond_1
    :goto_0
    iget-object v0, p0, La9$I_FH$;->tmpData3485:Ljava/net/Socket;

    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 23
    .line 24
    .line 25
    sget-object v0, L_nÀ6ÌM;->vaIue:L_nÀ6ÌM;

    .line 26
    .line 27
    sget-object v0, LiP$2j_t$;->e8$mp_s$:LiP$2j_t$;

    .line 28
    .line 29
    new-instance v2, LKkmORP;

    .line 30
    .line 31
    iget-object v3, p0, La9$I_FH$;->waiBKÀ:LCÒllàY;

    .line 32
    .line 33
    invoke-direct {v2, v3}, LKkmORP;-><init>(LCÒllàY;)V

    .line 34
    .line 35
    .line 36
    iget-object v3, p0, La9$I_FH$;->yON3x:LsIndex9566;

    .line 37
    .line 38
    iget-object v4, p0, La9$I_FH$;->POOl:LGIQ;

    .line 39
    .line 40
    iget-object v4, v4, LGIQ;->e8$mp_s$:LnValue2624;

    .line 41
    .line 42
    iget-object v4, v4, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 43
    .line 44
    iget-object v4, v4, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 45
    .line 46
    iput-object v3, v2, LKkmORP;->jPos3709:Ljava/lang/Object;

    .line 47
    .line 48
    new-instance v3, Ljava/lang/StringBuilder;

    .line 49
    .line 50
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 51
    .line 52
    .line 53
    sget-object v5, LyhM_S9$N_;->waiBKÀ:Ljava/lang/String;

    .line 54
    .line 55
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 56
    .line 57
    .line 58
    const/16 v5, 0x20

    .line 59
    .line 60
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 67
    .line 68
    .line 69
    move-result-object v3

    .line 70
    iput-object v3, v2, LKkmORP;->iOffset934:Ljava/lang/Object;

    .line 71
    .line 72
    iput-object p0, v2, LKkmORP;->kQy:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v0, v2, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 75
    .line 76
    new-instance v0, Lgp_T_;

    .line 77
    .line 78
    invoke-direct {v0, v2}, Lgp_T_;-><init>(LKkmORP;)V

    .line 79
    .line 80
    .line 81
    iput-object v0, p0, La9$I_FH$;->vaIue:Lgp_T_;

    .line 82
    .line 83
    sget-object v2, Lgp_T_;->l1:LiOffset8639;

    .line 84
    .line 85
    iget v3, v2, LiOffset8639;->e8$mp_s$:I

    .line 86
    .line 87
    and-int/lit8 v3, v3, 0x8

    .line 88
    .line 89
    if-eqz v3, :cond_2

    .line 90
    .line 91
    iget-object v2, v2, LiOffset8639;->waiBKÀ:[I

    .line 92
    .line 93
    const/4 v3, 0x3

    .line 94
    aget v2, v2, v3

    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_2
    const v2, 0x7fffffff

    .line 98
    .line 99
    .line 100
    :goto_1
    iput v2, p0, La9$I_FH$;->pCXDYg:I

    .line 101
    .line 102
    iget-object v2, v0, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 103
    .line 104
    const-string v3, ">> CONNECTION "

    .line 105
    .line 106
    monitor-enter v2

    .line 107
    :try_start_0
    iget-boolean v4, v2, LoìMB;->iOffset934:Z

    .line 108
    .line 109
    if-nez v4, :cond_5

    .line 110
    .line 111
    sget-object v4, LoìMB;->Ialue:Ljava/util/logging/Logger;

    .line 112
    .line 113
    sget-object v5, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    .line 114
    .line 115
    invoke-virtual {v4, v5}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    .line 116
    .line 117
    .line 118
    move-result v4

    .line 119
    if-eqz v4, :cond_3

    .line 120
    .line 121
    new-instance v4, Ljava/lang/StringBuilder;

    .line 122
    .line 123
    invoke-direct {v4, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    sget-object v3, Lo0O00;->e8$mp_s$:LindeO;

    .line 127
    .line 128
    invoke-virtual {v3}, LindeO;->waiBKÀ()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v3

    .line 139
    new-array v4, v1, [Ljava/lang/Object;

    .line 140
    .line 141
    invoke-static {v3, v4}, LyhM_S9$N_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    goto :goto_2

    .line 145
    :catchall_0
    move-exception v0

    .line 146
    goto :goto_3

    .line 147
    :cond_3
    :goto_2
    iget-object v3, v2, LoìMB;->yON3x:LdatQ;

    .line 148
    .line 149
    sget-object v4, Lo0O00;->e8$mp_s$:LindeO;

    .line 150
    .line 151
    invoke-interface {v3, v4}, LdatQ;->tmpData3485(LindeO;)LdatQ;

    .line 152
    .line 153
    .line 154
    iget-object v3, v2, LoìMB;->yON3x:LdatQ;

    .line 155
    .line 156
    invoke-interface {v3}, LdatQ;->flush()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 157
    .line 158
    .line 159
    monitor-exit v2

    .line 160
    iget-object v2, v0, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 161
    .line 162
    iget-object v3, v0, Lgp_T_;->Q1_f_:LiOffset8639;

    .line 163
    .line 164
    invoke-virtual {v2, v3}, LoìMB;->yàÒZ(LiOffset8639;)V

    .line 165
    .line 166
    .line 167
    iget-object v2, v0, Lgp_T_;->Q1_f_:LiOffset8639;

    .line 168
    .line 169
    invoke-virtual {v2}, LiOffset8639;->e8$mp_s$()I

    .line 170
    .line 171
    .line 172
    move-result v2

    .line 173
    const v3, 0xffff

    .line 174
    .line 175
    .line 176
    if-eq v2, v3, :cond_4

    .line 177
    .line 178
    iget-object v4, v0, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 179
    .line 180
    sub-int/2addr v2, v3

    .line 181
    int-to-long v2, v2

    .line 182
    invoke-virtual {v4, v1, v2, v3}, LoìMB;->gKey4112(IJ)V

    .line 183
    .line 184
    .line 185
    :cond_4
    iget-object v1, v0, Lgp_T_;->valuI:LCÒllàY;

    .line 186
    .line 187
    invoke-virtual {v1}, LCÒllàY;->POOl()Lco1nt;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    iget-object v2, v0, Lgp_T_;->jPos3709:Ljava/lang/String;

    .line 192
    .line 193
    iget-object v0, v0, Lgp_T_;->Oey:LJìì4ÀN;

    .line 194
    .line 195
    invoke-static {v1, v2, v0}, Lco1nt;->rz__9J_(Lco1nt;Ljava/lang/String;LH2h_go_;)V

    .line 196
    .line 197
    .line 198
    return-void

    .line 199
    :cond_5
    :try_start_1
    new-instance v0, Ljava/io/IOException;

    .line 200
    .line 201
    const-string v1, "closed"

    .line 202
    .line 203
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 207
    :goto_3
    monitor-exit v2

    .line 208
    throw v0
.end method

.method public final waiBKÀ(LUNRnRNBiy;)V
    .locals 2

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p1, v1, v0}, LUNRnRNBiy;->rz__9J_(Ljava/io/IOException;I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final yON3x(Z)Z
    .locals 7

    .line 1
    sget-object v0, LyhM_S9$N_;->e8$mp_s$:Ljava/util/TimeZone;

    .line 2
    .line 3
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    iget-object v2, p0, La9$I_FH$;->JKEoÙX:Ljava/net/Socket;

    .line 8
    .line 9
    invoke-virtual {v2}, Ljava/net/Socket;->isClosed()Z

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    const/4 v3, 0x0

    .line 14
    if-nez v2, :cond_3

    .line 15
    .line 16
    iget-object v2, p0, La9$I_FH$;->tmpData3485:Ljava/net/Socket;

    .line 17
    .line 18
    invoke-virtual {v2}, Ljava/net/Socket;->isClosed()Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-nez v2, :cond_3

    .line 23
    .line 24
    iget-object v2, p0, La9$I_FH$;->tmpData3485:Ljava/net/Socket;

    .line 25
    .line 26
    invoke-virtual {v2}, Ljava/net/Socket;->isInputShutdown()Z

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    if-nez v2, :cond_3

    .line 31
    .line 32
    iget-object v2, p0, La9$I_FH$;->tmpData3485:Ljava/net/Socket;

    .line 33
    .line 34
    invoke-virtual {v2}, Ljava/net/Socket;->isOutputShutdown()Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_0

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_0
    iget-object v2, p0, La9$I_FH$;->vaIue:Lgp_T_;

    .line 42
    .line 43
    if-eqz v2, :cond_1

    .line 44
    .line 45
    invoke-virtual {v2, v0, v1}, Lgp_T_;->yON3x(J)Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    return p1

    .line 50
    :cond_1
    monitor-enter p0

    .line 51
    :try_start_0
    iget-wide v4, p0, La9$I_FH$;->gKey4112:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 52
    .line 53
    sub-long/2addr v0, v4

    .line 54
    monitor-exit p0

    .line 55
    const-wide v4, 0x2540be400L

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    const/4 v2, 0x1

    .line 61
    cmp-long v6, v0, v4

    .line 62
    .line 63
    if-ltz v6, :cond_2

    .line 64
    .line 65
    if-eqz p1, :cond_2

    .line 66
    .line 67
    iget-object p1, p0, La9$I_FH$;->tmpData3485:Ljava/net/Socket;

    .line 68
    .line 69
    iget-object v0, p0, La9$I_FH$;->yON3x:LsIndex9566;

    .line 70
    .line 71
    iget-object v0, v0, LsIndex9566;->jPos3709:Ljava/lang/Object;

    .line 72
    .line 73
    check-cast v0, LIi11I;

    .line 74
    .line 75
    :try_start_1
    invoke-virtual {p1}, Ljava/net/Socket;->getSoTimeout()I

    .line 76
    .line 77
    .line 78
    move-result v1
    :try_end_1
    .catch Ljava/net/SocketTimeoutException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1

    .line 79
    :try_start_2
    invoke-virtual {p1, v2}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v0}, LIi11I;->rz__9J_()Z

    .line 83
    .line 84
    .line 85
    move-result v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 86
    xor-int/2addr v0, v2

    .line 87
    :try_start_3
    invoke-virtual {p1, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 88
    .line 89
    .line 90
    return v0

    .line 91
    :catchall_0
    move-exception v0

    .line 92
    invoke-virtual {p1, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 93
    .line 94
    .line 95
    throw v0
    :try_end_3
    .catch Ljava/net/SocketTimeoutException; {:try_start_3 .. :try_end_3} :catch_0
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    .line 96
    :catch_0
    const/4 v3, 0x1

    .line 97
    :catch_1
    return v3

    .line 98
    :cond_2
    return v2

    .line 99
    :catchall_1
    move-exception p1

    .line 100
    monitor-exit p0

    .line 101
    throw p1

    .line 102
    :cond_3
    :goto_0
    return v3
.end method
