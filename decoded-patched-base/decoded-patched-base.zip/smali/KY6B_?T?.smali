.class public final LKY6B_àTì;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LisSize8185;


# instance fields
.field public DDù8:Z

.field public JKEoÙX:LvD9$JN$;

.field public final POOl:LZKy6àp;

.field public final e8$mp_s$:Lzn$r5_AT$;

.field public final rz__9J_:LYizKm;

.field public sKey7917:J

.field public tmpData3485:J

.field public final waiBKÀ:LYizKm;

.field public yON3x:Z


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lzn$r5_AT$;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x1

    .line 9
    invoke-direct {v0, v1, v2, v3}, Lzn$r5_AT$;-><init>(Ljava/lang/String;IZ)V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, LKY6B_àTì;->e8$mp_s$:Lzn$r5_AT$;

    .line 13
    .line 14
    new-instance v0, LYizKm;

    .line 15
    .line 16
    const/16 v1, 0x800

    .line 17
    .line 18
    invoke-direct {v0, v1}, LYizKm;-><init>(I)V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, LKY6B_àTì;->waiBKÀ:LYizKm;

    .line 22
    .line 23
    const-wide/16 v0, -0x1

    .line 24
    .line 25
    iput-wide v0, p0, LKY6B_àTì;->sKey7917:J

    .line 26
    .line 27
    new-instance v0, LYizKm;

    .line 28
    .line 29
    const/16 v1, 0xa

    .line 30
    .line 31
    invoke-direct {v0, v1}, LYizKm;-><init>(I)V

    .line 32
    .line 33
    .line 34
    iput-object v0, p0, LKY6B_àTì;->rz__9J_:LYizKm;

    .line 35
    .line 36
    new-instance v1, LZKy6àp;

    .line 37
    .line 38
    iget-object v0, v0, LYizKm;->e8$mp_s$:[B

    .line 39
    .line 40
    array-length v2, v0

    .line 41
    invoke-direct {v1, v0, v2}, LZKy6àp;-><init>([BI)V

    .line 42
    .line 43
    .line 44
    iput-object v1, p0, LKY6B_àTì;->POOl:LZKy6àp;

    .line 45
    .line 46
    return-void
.end method


# virtual methods
.method public final Ialue(JJ)V
    .locals 0

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-boolean p1, p0, LKY6B_àTì;->DDù8:Z

    .line 3
    .line 4
    iget-object p1, p0, LKY6B_àTì;->e8$mp_s$:Lzn$r5_AT$;

    .line 5
    .line 6
    invoke-virtual {p1}, Lzn$r5_AT$;->rz__9J_()V

    .line 7
    .line 8
    .line 9
    iput-wide p3, p0, LKY6B_àTì;->tmpData3485:J

    .line 10
    .line 11
    return-void
.end method

.method public final iOffset934(LxPsMK;)Z
    .locals 10

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    iget-object v2, p0, LKY6B_àTì;->rz__9J_:LYizKm;

    .line 4
    .line 5
    iget-object v3, v2, LYizKm;->e8$mp_s$:[B

    .line 6
    .line 7
    move-object v4, p1

    .line 8
    check-cast v4, LoYxmSde;

    .line 9
    .line 10
    const/16 v5, 0xa

    .line 11
    .line 12
    invoke-virtual {v4, v3, v0, v5, v0}, LoYxmSde;->pQ1Il([BIIZ)Z

    .line 13
    .line 14
    .line 15
    invoke-virtual {v2, v0}, LYizKm;->vaIue(I)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v2}, LYizKm;->$ÒcdS()I

    .line 19
    .line 20
    .line 21
    move-result v3

    .line 22
    const v5, 0x494433

    .line 23
    .line 24
    .line 25
    if-eq v3, v5, :cond_6

    .line 26
    .line 27
    move-object v3, p1

    .line 28
    check-cast v3, LoYxmSde;

    .line 29
    .line 30
    iput v0, v3, LoYxmSde;->Ialue:I

    .line 31
    .line 32
    invoke-virtual {v4, v1, v0}, LoYxmSde;->tmpData3485(IZ)Z

    .line 33
    .line 34
    .line 35
    iget-wide v5, p0, LKY6B_àTì;->sKey7917:J

    .line 36
    .line 37
    const-wide/16 v7, -0x1

    .line 38
    .line 39
    cmp-long p1, v5, v7

    .line 40
    .line 41
    if-nez p1, :cond_0

    .line 42
    .line 43
    int-to-long v5, v1

    .line 44
    iput-wide v5, p0, LKY6B_àTì;->sKey7917:J

    .line 45
    .line 46
    :cond_0
    move v5, v1

    .line 47
    const/4 p1, 0x0

    .line 48
    const/4 v6, 0x0

    .line 49
    :cond_1
    iget-object v7, v2, LYizKm;->e8$mp_s$:[B

    .line 50
    .line 51
    const/4 v8, 0x2

    .line 52
    invoke-virtual {v4, v7, v0, v8, v0}, LoYxmSde;->pQ1Il([BIIZ)Z

    .line 53
    .line 54
    .line 55
    invoke-virtual {v2, v0}, LYizKm;->vaIue(I)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v2}, LYizKm;->tmpSize211()I

    .line 59
    .line 60
    .line 61
    move-result v7

    .line 62
    const v8, 0xfff6

    .line 63
    .line 64
    .line 65
    and-int/2addr v7, v8

    .line 66
    const v8, 0xfff0

    .line 67
    .line 68
    .line 69
    if-ne v7, v8, :cond_5

    .line 70
    .line 71
    const/4 v7, 0x1

    .line 72
    add-int/2addr p1, v7

    .line 73
    const/4 v8, 0x4

    .line 74
    if-lt p1, v8, :cond_3

    .line 75
    .line 76
    const/16 v9, 0xbc

    .line 77
    .line 78
    if-gt v6, v9, :cond_2

    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_2
    return v7

    .line 82
    :cond_3
    :goto_1
    iget-object v7, v2, LYizKm;->e8$mp_s$:[B

    .line 83
    .line 84
    invoke-virtual {v4, v7, v0, v8, v0}, LoYxmSde;->pQ1Il([BIIZ)Z

    .line 85
    .line 86
    .line 87
    const/16 v7, 0xe

    .line 88
    .line 89
    iget-object v8, p0, LKY6B_àTì;->POOl:LZKy6àp;

    .line 90
    .line 91
    invoke-virtual {v8, v7}, LZKy6àp;->kO_6X_(I)V

    .line 92
    .line 93
    .line 94
    const/16 v7, 0xd

    .line 95
    .line 96
    invoke-virtual {v8, v7}, LZKy6àp;->tmpData3485(I)I

    .line 97
    .line 98
    .line 99
    move-result v7

    .line 100
    const/4 v8, 0x6

    .line 101
    if-gt v7, v8, :cond_4

    .line 102
    .line 103
    add-int/lit8 v5, v5, 0x1

    .line 104
    .line 105
    iput v0, v3, LoYxmSde;->Ialue:I

    .line 106
    .line 107
    invoke-virtual {v4, v5, v0}, LoYxmSde;->tmpData3485(IZ)Z

    .line 108
    .line 109
    .line 110
    :goto_2
    const/4 p1, 0x0

    .line 111
    const/4 v6, 0x0

    .line 112
    goto :goto_3

    .line 113
    :cond_4
    add-int/lit8 v8, v7, -0x6

    .line 114
    .line 115
    invoke-virtual {v4, v8, v0}, LoYxmSde;->tmpData3485(IZ)Z

    .line 116
    .line 117
    .line 118
    add-int/2addr v6, v7

    .line 119
    goto :goto_3

    .line 120
    :cond_5
    add-int/lit8 v5, v5, 0x1

    .line 121
    .line 122
    iput v0, v3, LoYxmSde;->Ialue:I

    .line 123
    .line 124
    invoke-virtual {v4, v5, v0}, LoYxmSde;->tmpData3485(IZ)Z

    .line 125
    .line 126
    .line 127
    goto :goto_2

    .line 128
    :goto_3
    sub-int v7, v5, v1

    .line 129
    .line 130
    const/16 v8, 0x2000

    .line 131
    .line 132
    if-lt v7, v8, :cond_1

    .line 133
    .line 134
    return v0

    .line 135
    :cond_6
    const/4 v3, 0x3

    .line 136
    invoke-virtual {v2, v3}, LYizKm;->jPos3709(I)V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v2}, LYizKm;->Qp_Hp$i_()I

    .line 140
    .line 141
    .line 142
    move-result v2

    .line 143
    add-int/lit8 v3, v2, 0xa

    .line 144
    .line 145
    add-int/2addr v1, v3

    .line 146
    invoke-virtual {v4, v2, v0}, LoYxmSde;->tmpData3485(IZ)Z

    .line 147
    .line 148
    .line 149
    goto/16 :goto_0
.end method

.method public final jPos3709(LxPsMK;LgUx$H8_De$;)I
    .locals 8

    .line 1
    iget-object p2, p0, LKY6B_àTì;->JKEoÙX:LvD9$JN$;

    .line 2
    .line 3
    invoke-static {p2}, LvItem3158;->po0(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object p2, p0, LKY6B_àTì;->waiBKÀ:LYizKm;

    .line 7
    .line 8
    iget-object v0, p2, LYizKm;->e8$mp_s$:[B

    .line 9
    .line 10
    const/16 v1, 0x800

    .line 11
    .line 12
    check-cast p1, LoYxmSde;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {p1, v0, v2, v1}, LoYxmSde;->JKEoÙX([BII)I

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    iget-boolean v0, p0, LKY6B_àTì;->yON3x:Z

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    if-nez v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p0, LKY6B_àTì;->JKEoÙX:LvD9$JN$;

    .line 25
    .line 26
    new-instance v3, LisData7872;

    .line 27
    .line 28
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    const-wide/16 v6, 0x0

    .line 34
    .line 35
    invoke-direct {v3, v4, v5, v6, v7}, LisData7872;-><init>(JJ)V

    .line 36
    .line 37
    .line 38
    invoke-interface {v0, v3}, LvD9$JN$;->Q1_f_(LkQQ;)V

    .line 39
    .line 40
    .line 41
    iput-boolean v1, p0, LKY6B_àTì;->yON3x:Z

    .line 42
    .line 43
    :cond_0
    const/4 v0, -0x1

    .line 44
    if-ne p1, v0, :cond_1

    .line 45
    .line 46
    return v0

    .line 47
    :cond_1
    invoke-virtual {p2, v2}, LYizKm;->vaIue(I)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {p2, p1}, LYizKm;->yON3x(I)V

    .line 51
    .line 52
    .line 53
    iget-boolean p1, p0, LKY6B_àTì;->DDù8:Z

    .line 54
    .line 55
    iget-object v0, p0, LKY6B_àTì;->e8$mp_s$:Lzn$r5_AT$;

    .line 56
    .line 57
    if-nez p1, :cond_2

    .line 58
    .line 59
    iget-wide v3, p0, LKY6B_àTì;->tmpData3485:J

    .line 60
    .line 61
    iput-wide v3, v0, Lzn$r5_AT$;->K0I:J

    .line 62
    .line 63
    iput-boolean v1, p0, LKY6B_àTì;->DDù8:Z

    .line 64
    .line 65
    :cond_2
    invoke-virtual {v0, p2}, Lzn$r5_AT$;->waiBKÀ(LYizKm;)V

    .line 66
    .line 67
    .line 68
    return v2
.end method

.method public final kQy(LvD9$JN$;)V
    .locals 4

    .line 1
    iput-object p1, p0, LKY6B_àTì;->JKEoÙX:LvD9$JN$;

    .line 2
    .line 3
    new-instance v0, LkKey9521;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    const/high16 v3, -0x80000000

    .line 8
    .line 9
    invoke-direct {v0, v3, v1, v2}, LkKey9521;-><init>(III)V

    .line 10
    .line 11
    .line 12
    iget-object v1, p0, LKY6B_àTì;->e8$mp_s$:Lzn$r5_AT$;

    .line 13
    .line 14
    invoke-virtual {v1, p1, v0}, Lzn$r5_AT$;->JKEoÙX(LvD9$JN$;LkKey9521;)V

    .line 15
    .line 16
    .line 17
    invoke-interface {p1}, LvD9$JN$;->Qp_Hp$i_()V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final vaIue()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, LnW_cN_;->vaIue:Ljk_NI_;

    .line 2
    .line 3
    sget-object v0, LlII1II;->kQy:LlII1II;

    .line 4
    .line 5
    return-object v0
.end method
