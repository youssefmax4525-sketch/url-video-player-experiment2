.class public final LJlT$O_a$;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final DDù8:I

.field public final JKEoÙX:I

.field public final POOl:I

.field public final e8$mp_s$:Ljava/lang/String;

.field public final rz__9J_:F

.field public final sKey7917:F

.field public final tmpData3485:F

.field public final vaIue:I

.field public final waiBKÀ:F

.field public final yON3x:F


# direct methods
.method public constructor <init>(Ljava/lang/String;FFIIFFIFI)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LJlT$O_a$;->e8$mp_s$:Ljava/lang/String;

    .line 5
    .line 6
    iput p2, p0, LJlT$O_a$;->waiBKÀ:F

    .line 7
    .line 8
    iput p3, p0, LJlT$O_a$;->rz__9J_:F

    .line 9
    .line 10
    iput p4, p0, LJlT$O_a$;->POOl:I

    .line 11
    .line 12
    iput p5, p0, LJlT$O_a$;->JKEoÙX:I

    .line 13
    .line 14
    iput p6, p0, LJlT$O_a$;->tmpData3485:F

    .line 15
    .line 16
    iput p7, p0, LJlT$O_a$;->sKey7917:F

    .line 17
    .line 18
    iput p8, p0, LJlT$O_a$;->DDù8:I

    .line 19
    .line 20
    iput p9, p0, LJlT$O_a$;->yON3x:F

    .line 21
    .line 22
    iput p10, p0, LJlT$O_a$;->vaIue:I

    .line 23
    .line 24
    return-void
.end method
