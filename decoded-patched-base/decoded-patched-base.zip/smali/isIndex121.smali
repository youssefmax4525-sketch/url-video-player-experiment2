.class public final LisIndex121;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LhasPos5367;


# direct methods
.method public constructor <init>(LhasPos5367;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LisIndex121;->e8$mp_s$:LhasPos5367;

    .line 5
    .line 6
    return-void
.end method
