.class public final LLQD0IQ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LhasValue7753;
.implements LEpDsèPM;


# instance fields
.field public final yON3x:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LLQD0IQ;->yON3x:Ljava/lang/Object;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LLQD0IQ;->yON3x:Ljava/lang/Object;

    .line 2
    .line 3
    return-object v0
.end method
