.class public final LvCount9307;
.super LslD;
.source "SourceFile"


# instance fields
.field public final synthetic JKEoÙX:Ljava/lang/Object;

.field public final synthetic POOl:LyKÙIE;

.field public rz__9J_:LyZxYs2;

.field public final waiBKÀ:LiPos8519;


# direct methods
.method public constructor <init>(LiPos8519;LyKÙIE;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p2, p0, LvCount9307;->POOl:LyKÙIE;

    .line 2
    .line 3
    iput-object p3, p0, LvCount9307;->JKEoÙX:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, LslD;-><init>()V

    .line 6
    .line 7
    .line 8
    iput-object p1, p0, LvCount9307;->waiBKÀ:LiPos8519;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final rz__9J_(Ljava/lang/Object;)LnPos4111;
    .locals 1

    .line 1
    check-cast p1, LUE_O_;

    .line 2
    .line 3
    iget-object p1, p0, LvCount9307;->POOl:LyKÙIE;

    .line 4
    .line 5
    invoke-virtual {p1}, LyKÙIE;->valuI()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    iget-object v0, p0, LvCount9307;->JKEoÙX:Ljava/lang/Object;

    .line 10
    .line 11
    if-ne p1, v0, :cond_0

    .line 12
    .line 13
    const/4 p1, 0x0

    .line 14
    return-object p1

    .line 15
    :cond_0
    sget-object p1, LnItem4702;->waiBKÀ:LnPos4111;

    .line 16
    .line 17
    return-object p1
.end method

.method public final waiBKÀ(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4

    .line 1
    check-cast p1, LUE_O_;

    .line 2
    .line 3
    if-nez p2, :cond_0

    .line 4
    .line 5
    const/4 p2, 0x1

    .line 6
    goto :goto_0

    .line 7
    :cond_0
    const/4 p2, 0x0

    .line 8
    :goto_0
    iget-object v0, p0, LvCount9307;->waiBKÀ:LiPos8519;

    .line 9
    .line 10
    if-eqz p2, :cond_1

    .line 11
    .line 12
    move-object v1, v0

    .line 13
    goto :goto_1

    .line 14
    :cond_1
    iget-object v1, p0, LvCount9307;->rz__9J_:LyZxYs2;

    .line 15
    .line 16
    :goto_1
    if-eqz v1, :cond_4

    .line 17
    .line 18
    sget-object v2, LUE_O_;->yON3x:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 19
    .line 20
    :cond_2
    invoke-virtual {v2, p1, p0, v1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-eqz v3, :cond_3

    .line 25
    .line 26
    if-eqz p2, :cond_4

    .line 27
    .line 28
    iget-object p1, p0, LvCount9307;->rz__9J_:LyZxYs2;

    .line 29
    .line 30
    invoke-virtual {v0, p1}, LUE_O_;->DDù8(LUE_O_;)V

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_3
    invoke-virtual {v2, p1}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    if-eq v3, p0, :cond_2

    .line 39
    .line 40
    :cond_4
    return-void
.end method
