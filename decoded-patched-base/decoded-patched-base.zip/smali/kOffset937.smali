.class public final LkOffset937;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LeZpY_mì;


# instance fields
.field public final e8$mp_s$:LQoXYbY;

.field public final waiBKÀ:J


# direct methods
.method public constructor <init>(LQoXYbY;J)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LkOffset937;->e8$mp_s$:LQoXYbY;

    .line 5
    .line 6
    iput-wide p2, p0, LkOffset937;->waiBKÀ:J

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final kQy(Ljava/lang/Object;)V
    .locals 8

    .line 1
    check-cast p1, LoH_T$M3_;

    .line 2
    .line 3
    iget-object p1, p1, LoH_T$M3_;->waiBKÀ:Landroid/os/Bundle;

    .line 4
    .line 5
    const-string v0, "slotname"

    .line 6
    .line 7
    iget-object v1, p0, LkOffset937;->e8$mp_s$:LQoXYbY;

    .line 8
    .line 9
    iget-object v2, v1, LQoXYbY;->tmpData3485:Ljava/lang/String;

    .line 10
    .line 11
    invoke-virtual {p1, v0, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, v1, LQoXYbY;->POOl:LfO0;

    .line 15
    .line 16
    iget-boolean v1, v0, LfO0;->Ialue:Z

    .line 17
    .line 18
    iget-object v2, v0, LfO0;->jPos3709:Landroid/os/Bundle;

    .line 19
    .line 20
    const/4 v3, 0x1

    .line 21
    if-eqz v1, :cond_0

    .line 22
    .line 23
    const-string v1, "test_request"

    .line 24
    .line 25
    invoke-virtual {p1, v1, v3}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 26
    .line 27
    .line 28
    :cond_0
    iget v1, v0, LfO0;->valuI:I

    .line 29
    .line 30
    const/4 v4, 0x0

    .line 31
    const/4 v5, -0x1

    .line 32
    if-eq v1, v5, :cond_1

    .line 33
    .line 34
    const/4 v6, 0x1

    .line 35
    goto :goto_0

    .line 36
    :cond_1
    const/4 v6, 0x0

    .line 37
    :goto_0
    const-string v7, "tag_for_child_directed_treatment"

    .line 38
    .line 39
    invoke-static {p1, v7, v1, v6}, LdbÙLJ;->po0(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    .line 40
    .line 41
    .line 42
    iget v1, v0, LfO0;->yON3x:I

    .line 43
    .line 44
    const/16 v6, 0x8

    .line 45
    .line 46
    if-lt v1, v6, :cond_3

    .line 47
    .line 48
    iget v1, v0, LfO0;->tzKù7Ol1:I

    .line 49
    .line 50
    if-eq v1, v5, :cond_2

    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_2
    const/4 v3, 0x0

    .line 54
    :goto_1
    const-string v4, "tag_for_under_age_of_consent"

    .line 55
    .line 56
    invoke-static {p1, v4, v1, v3}, LdbÙLJ;->po0(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    .line 57
    .line 58
    .line 59
    :cond_3
    iget-object v1, v0, LfO0;->K0I:Ljava/lang/String;

    .line 60
    .line 61
    const-string v3, "url"

    .line 62
    .line 63
    invoke-static {v3, v1, p1}, LdbÙLJ;->pZDcLvd(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 64
    .line 65
    .line 66
    iget-object v0, v0, LfO0;->oy_R$Xx_:Ljava/util/List;

    .line 67
    .line 68
    const-string v1, "neighboring_content_urls"

    .line 69
    .line 70
    invoke-static {p1, v1, v0}, LdbÙLJ;->s$_D_(Landroid/os/Bundle;Ljava/lang/String;Ljava/util/List;)V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v2}, Landroid/os/Bundle;->clone()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    check-cast v0, Landroid/os/Bundle;

    .line 78
    .line 79
    new-instance v1, Ljava/util/HashSet;

    .line 80
    .line 81
    sget-object v3, LisIndex2415;->po1:LSdE$n$;

    .line 82
    .line 83
    sget-object v4, LIl1il;->POOl:LIl1il;

    .line 84
    .line 85
    iget-object v4, v4, LIl1il;->rz__9J_:LnCount1076;

    .line 86
    .line 87
    invoke-virtual {v4, v3}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    check-cast v3, Ljava/lang/String;

    .line 92
    .line 93
    const-string v4, ","

    .line 94
    .line 95
    invoke-virtual {v3, v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v3

    .line 99
    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 100
    .line 101
    .line 102
    move-result-object v3

    .line 103
    invoke-direct {v1, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 107
    .line 108
    .line 109
    move-result-object v2

    .line 110
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 111
    .line 112
    .line 113
    move-result-object v2

    .line 114
    :cond_4
    :goto_2
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 115
    .line 116
    .line 117
    move-result v3

    .line 118
    if-eqz v3, :cond_5

    .line 119
    .line 120
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    check-cast v3, Ljava/lang/String;

    .line 125
    .line 126
    invoke-virtual {v1, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v4

    .line 130
    if-nez v4, :cond_4

    .line 131
    .line 132
    invoke-virtual {v0, v3}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_5
    if-eqz v0, :cond_6

    .line 137
    .line 138
    const-string v1, "extras"

    .line 139
    .line 140
    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 141
    .line 142
    .line 143
    :cond_6
    return-void
.end method

.method public final yàÒZ(Ljava/lang/Object;)V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, LoH_T$M3_;

    .line 6
    .line 7
    iget-object v1, v1, LoH_T$M3_;->e8$mp_s$:Landroid/os/Bundle;

    .line 8
    .line 9
    iget-object v2, v0, LkOffset937;->e8$mp_s$:LQoXYbY;

    .line 10
    .line 11
    iget-object v3, v2, LQoXYbY;->POOl:LfO0;

    .line 12
    .line 13
    iget v4, v3, LfO0;->yPN$A_n$:I

    .line 14
    .line 15
    iget-object v5, v3, LfO0;->jPos3709:Landroid/os/Bundle;

    .line 16
    .line 17
    iget-wide v6, v3, LfO0;->vaIue:J

    .line 18
    .line 19
    iget v8, v3, LfO0;->yON3x:I

    .line 20
    .line 21
    const-string v9, "http_timeout_millis"

    .line 22
    .line 23
    invoke-virtual {v1, v9, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 24
    .line 25
    .line 26
    const-string v4, "slotname"

    .line 27
    .line 28
    iget-object v9, v2, LQoXYbY;->tmpData3485:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v1, v4, v9}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    iget-object v2, v2, LQoXYbY;->valuI:LZlTMJ;

    .line 34
    .line 35
    iget v2, v2, LZlTMJ;->vaIue:I

    .line 36
    .line 37
    if-eqz v2, :cond_e

    .line 38
    .line 39
    const/4 v4, -0x1

    .line 40
    add-int/2addr v2, v4

    .line 41
    const/4 v9, 0x2

    .line 42
    const/4 v10, 0x1

    .line 43
    if-eq v2, v10, :cond_1

    .line 44
    .line 45
    if-eq v2, v9, :cond_0

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_0
    const-string v2, "is_rewarded_interstitial"

    .line 49
    .line 50
    invoke-virtual {v1, v2, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_1
    const-string v2, "is_new_rewarded"

    .line 55
    .line 56
    invoke-virtual {v1, v2, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 57
    .line 58
    .line 59
    :goto_0
    iget-wide v11, v0, LkOffset937;->waiBKÀ:J

    .line 60
    .line 61
    const-string v2, "start_signals_timestamp"

    .line 62
    .line 63
    invoke-virtual {v1, v2, v11, v12}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 64
    .line 65
    .line 66
    const-string v2, "is_sdk_preload"

    .line 67
    .line 68
    const/4 v11, 0x0

    .line 69
    invoke-virtual {v5, v2, v11}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 70
    .line 71
    .line 72
    move-result v12

    .line 73
    invoke-static {v1, v2, v10, v12}, LdbÙLJ;->CcZMD(Landroid/os/Bundle;Ljava/lang/String;ZZ)V

    .line 74
    .line 75
    .line 76
    new-instance v2, Ljava/text/SimpleDateFormat;

    .line 77
    .line 78
    const-string v12, "yyyyMMdd"

    .line 79
    .line 80
    sget-object v13, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 81
    .line 82
    invoke-direct {v2, v12, v13}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 83
    .line 84
    .line 85
    new-instance v12, Ljava/util/Date;

    .line 86
    .line 87
    invoke-direct {v12, v6, v7}, Ljava/util/Date;-><init>(J)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v2, v12}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v2

    .line 94
    const-wide/16 v12, -0x1

    .line 95
    .line 96
    cmp-long v14, v6, v12

    .line 97
    .line 98
    if-eqz v14, :cond_2

    .line 99
    .line 100
    const/4 v6, 0x1

    .line 101
    goto :goto_1

    .line 102
    :cond_2
    const/4 v6, 0x0

    .line 103
    :goto_1
    const-string v7, "cust_age"

    .line 104
    .line 105
    invoke-static {v1, v7, v2, v6}, LdbÙLJ;->cEi_G$x5_(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 106
    .line 107
    .line 108
    if-eqz v5, :cond_3

    .line 109
    .line 110
    const-string v2, "extras"

    .line 111
    .line 112
    invoke-virtual {v1, v2, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 113
    .line 114
    .line 115
    :cond_3
    iget v2, v3, LfO0;->iOffset934:I

    .line 116
    .line 117
    if-eq v2, v4, :cond_4

    .line 118
    .line 119
    const/4 v5, 0x1

    .line 120
    goto :goto_2

    .line 121
    :cond_4
    const/4 v5, 0x0

    .line 122
    :goto_2
    const-string v6, "cust_gender"

    .line 123
    .line 124
    invoke-static {v1, v6, v2, v5}, LdbÙLJ;->po0(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    .line 125
    .line 126
    .line 127
    iget-object v2, v3, LfO0;->kQy:Ljava/util/List;

    .line 128
    .line 129
    const-string v5, "kw"

    .line 130
    .line 131
    invoke-static {v1, v5, v2}, LdbÙLJ;->s$_D_(Landroid/os/Bundle;Ljava/lang/String;Ljava/util/List;)V

    .line 132
    .line 133
    .line 134
    iget v2, v3, LfO0;->valuI:I

    .line 135
    .line 136
    if-eq v2, v4, :cond_5

    .line 137
    .line 138
    const/4 v5, 0x1

    .line 139
    goto :goto_3

    .line 140
    :cond_5
    const/4 v5, 0x0

    .line 141
    :goto_3
    const-string v6, "tag_for_child_directed_treatment"

    .line 142
    .line 143
    invoke-static {v1, v6, v2, v5}, LdbÙLJ;->po0(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    .line 144
    .line 145
    .line 146
    iget-boolean v2, v3, LfO0;->Ialue:Z

    .line 147
    .line 148
    if-eqz v2, :cond_6

    .line 149
    .line 150
    const-string v2, "test_request"

    .line 151
    .line 152
    invoke-virtual {v1, v2, v10}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 153
    .line 154
    .line 155
    :cond_6
    iget v2, v3, LfO0;->Iii:I

    .line 156
    .line 157
    const-string v5, "ppt_p13n"

    .line 158
    .line 159
    invoke-virtual {v1, v5, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 160
    .line 161
    .line 162
    if-lt v8, v9, :cond_7

    .line 163
    .line 164
    iget-boolean v2, v3, LfO0;->pCXDYg:Z

    .line 165
    .line 166
    if-eqz v2, :cond_7

    .line 167
    .line 168
    const/4 v2, 0x1

    .line 169
    goto :goto_4

    .line 170
    :cond_7
    const/4 v2, 0x0

    .line 171
    :goto_4
    const-string v5, "d_imp_hdr"

    .line 172
    .line 173
    invoke-static {v1, v5, v10, v2}, LdbÙLJ;->po0(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    .line 174
    .line 175
    .line 176
    iget-object v2, v3, LfO0;->yàÒZ:Ljava/lang/String;

    .line 177
    .line 178
    if-lt v8, v9, :cond_8

    .line 179
    .line 180
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 181
    .line 182
    .line 183
    move-result v5

    .line 184
    if-nez v5, :cond_8

    .line 185
    .line 186
    const/4 v5, 0x1

    .line 187
    goto :goto_5

    .line 188
    :cond_8
    const/4 v5, 0x0

    .line 189
    :goto_5
    const-string v6, "ppid"

    .line 190
    .line 191
    invoke-static {v1, v6, v2, v5}, LdbÙLJ;->cEi_G$x5_(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/String;Z)V

    .line 192
    .line 193
    .line 194
    iget-object v2, v3, LfO0;->kO_6X_:Landroid/location/Location;

    .line 195
    .line 196
    if-eqz v2, :cond_9

    .line 197
    .line 198
    invoke-virtual {v2}, Landroid/location/Location;->getAccuracy()F

    .line 199
    .line 200
    .line 201
    move-result v5

    .line 202
    const/high16 v6, 0x447a0000    # 1000.0f

    .line 203
    .line 204
    mul-float v5, v5, v6

    .line 205
    .line 206
    invoke-virtual {v2}, Landroid/location/Location;->getTime()J

    .line 207
    .line 208
    .line 209
    move-result-wide v6

    .line 210
    const-wide/16 v12, 0x3e8

    .line 211
    .line 212
    mul-long v6, v6, v12

    .line 213
    .line 214
    invoke-virtual {v2}, Landroid/location/Location;->getLatitude()D

    .line 215
    .line 216
    .line 217
    move-result-wide v12

    .line 218
    const-wide v14, 0x416312d000000000L    # 1.0E7

    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    mul-double v12, v12, v14

    .line 224
    .line 225
    invoke-virtual {v2}, Landroid/location/Location;->getLongitude()D

    .line 226
    .line 227
    .line 228
    move-result-wide v16

    .line 229
    mul-double v14, v14, v16

    .line 230
    .line 231
    new-instance v2, Landroid/os/Bundle;

    .line 232
    .line 233
    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    .line 234
    .line 235
    .line 236
    const-string v9, "radius"

    .line 237
    .line 238
    invoke-virtual {v2, v9, v5}, Landroid/os/Bundle;->putFloat(Ljava/lang/String;F)V

    .line 239
    .line 240
    .line 241
    const-string v5, "lat"

    .line 242
    .line 243
    double-to-long v12, v12

    .line 244
    invoke-virtual {v2, v5, v12, v13}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 245
    .line 246
    .line 247
    const-string v5, "long"

    .line 248
    .line 249
    double-to-long v12, v14

    .line 250
    invoke-virtual {v2, v5, v12, v13}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 251
    .line 252
    .line 253
    const-string v5, "time"

    .line 254
    .line 255
    invoke-virtual {v2, v5, v6, v7}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 256
    .line 257
    .line 258
    const-string v5, "uule"

    .line 259
    .line 260
    invoke-virtual {v1, v5, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 261
    .line 262
    .line 263
    :cond_9
    iget-object v2, v3, LfO0;->K0I:Ljava/lang/String;

    .line 264
    .line 265
    const-string v5, "url"

    .line 266
    .line 267
    invoke-static {v5, v2, v1}, LdbÙLJ;->pZDcLvd(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 268
    .line 269
    .line 270
    iget-object v2, v3, LfO0;->oy_R$Xx_:Ljava/util/List;

    .line 271
    .line 272
    const-string v5, "neighboring_content_urls"

    .line 273
    .line 274
    invoke-static {v1, v5, v2}, LdbÙLJ;->s$_D_(Landroid/os/Bundle;Ljava/lang/String;Ljava/util/List;)V

    .line 275
    .line 276
    .line 277
    iget-object v2, v3, LfO0;->UC_n_:Landroid/os/Bundle;

    .line 278
    .line 279
    if-eqz v2, :cond_a

    .line 280
    .line 281
    const-string v5, "custom_targeting"

    .line 282
    .line 283
    invoke-virtual {v1, v5, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 284
    .line 285
    .line 286
    :cond_a
    iget-object v2, v3, LfO0;->kCount1402:Ljava/util/List;

    .line 287
    .line 288
    const-string v5, "category_exclusions"

    .line 289
    .line 290
    invoke-static {v1, v5, v2}, LdbÙLJ;->s$_D_(Landroid/os/Bundle;Ljava/lang/String;Ljava/util/List;)V

    .line 291
    .line 292
    .line 293
    iget-object v2, v3, LfO0;->$ÒcdS:Ljava/lang/String;

    .line 294
    .line 295
    const-string v5, "request_agent"

    .line 296
    .line 297
    invoke-static {v5, v2, v1}, LdbÙLJ;->pZDcLvd(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 298
    .line 299
    .line 300
    iget-object v2, v3, LfO0;->Q1_f_:Ljava/lang/String;

    .line 301
    .line 302
    const-string v5, "request_pkg"

    .line 303
    .line 304
    invoke-static {v5, v2, v1}, LdbÙLJ;->pZDcLvd(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 305
    .line 306
    .line 307
    iget-boolean v2, v3, LfO0;->tmpSize211:Z

    .line 308
    .line 309
    const/4 v5, 0x7

    .line 310
    if-lt v8, v5, :cond_b

    .line 311
    .line 312
    const/4 v5, 0x1

    .line 313
    goto :goto_6

    .line 314
    :cond_b
    const/4 v5, 0x0

    .line 315
    :goto_6
    const-string v6, "is_designed_for_families"

    .line 316
    .line 317
    invoke-static {v1, v6, v2, v5}, LdbÙLJ;->CcZMD(Landroid/os/Bundle;Ljava/lang/String;ZZ)V

    .line 318
    .line 319
    .line 320
    const/16 v2, 0x8

    .line 321
    .line 322
    if-lt v8, v2, :cond_d

    .line 323
    .line 324
    iget v2, v3, LfO0;->tzKù7Ol1:I

    .line 325
    .line 326
    if-eq v2, v4, :cond_c

    .line 327
    .line 328
    goto :goto_7

    .line 329
    :cond_c
    const/4 v10, 0x0

    .line 330
    :goto_7
    const-string v4, "tag_for_under_age_of_consent"

    .line 331
    .line 332
    invoke-static {v1, v4, v2, v10}, LdbÙLJ;->po0(Landroid/os/Bundle;Ljava/lang/String;IZ)V

    .line 333
    .line 334
    .line 335
    iget-object v2, v3, LfO0;->ll:Ljava/lang/String;

    .line 336
    .line 337
    const-string v3, "max_ad_content_rating"

    .line 338
    .line 339
    invoke-static {v3, v2, v1}, LdbÙLJ;->pZDcLvd(Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)V

    .line 340
    .line 341
    .line 342
    :cond_d
    return-void

    .line 343
    :cond_e
    const/4 v1, 0x0

    .line 344
    throw v1
.end method
