.class public final Lak$rM_i$;
.super LHU$B$;
.source "SourceFile"


# static fields
.field public static final zza:I = 0x1

.field public static final zzb:I = 0x2

.field private static final zzc:Lak$rM_i$;

.field private static volatile zzd:Lw00OID;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw00OID;"
        }
    .end annotation
.end field


# instance fields
.field private zze:I

.field private zzf:Z

.field private zzg:I


# direct methods
.method public static $ÒcdS()Lak$rM_i$;
    .locals 1

    .line 1
    sget-object v0, Lak$rM_i$;->zzc:Lak$rM_i$;

    .line 2
    .line 3
    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lak$rM_i$;

    .line 2
    .line 3
    invoke-direct {v0}, LHU$B$;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lak$rM_i$;->zzc:Lak$rM_i$;

    .line 7
    .line 8
    const-class v1, Lak$rM_i$;

    .line 9
    .line 10
    invoke-static {v1, v0}, LHU$B$;->jPos3709(Ljava/lang/Class;LHU$B$;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static Q1_f_(Lak$rM_i$;Z)V
    .locals 1

    .line 1
    iget v0, p0, Lak$rM_i$;->zze:I

    .line 2
    .line 3
    or-int/lit8 v0, v0, 0x1

    .line 4
    .line 5
    iput v0, p0, Lak$rM_i$;->zze:I

    .line 6
    .line 7
    iput-boolean p1, p0, Lak$rM_i$;->zzf:Z

    .line 8
    .line 9
    return-void
.end method

.method public static kCount1402()LIl1l;
    .locals 1

    .line 1
    sget-object v0, Lak$rM_i$;->zzc:Lak$rM_i$;

    .line 2
    .line 3
    invoke-virtual {v0}, LHU$B$;->sKey7917()Lw1I;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LIl1l;

    .line 8
    .line 9
    return-object v0
.end method

.method public static tmpSize211(Lak$rM_i$;I)V
    .locals 1

    .line 1
    iget v0, p0, Lak$rM_i$;->zze:I

    .line 2
    .line 3
    or-int/lit8 v0, v0, 0x2

    .line 4
    .line 5
    iput v0, p0, Lak$rM_i$;->zze:I

    .line 6
    .line 7
    iput p1, p0, Lak$rM_i$;->zzg:I

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final kO_6X_(ILHU$B$;)Ljava/lang/Object;
    .locals 3

    .line 1
    invoke-static {p1}, LBRK_m_;->UC_n_(I)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 p2, 0x1

    .line 6
    if-eqz p1, :cond_7

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    const/4 v1, 0x2

    .line 10
    if-eq p1, v1, :cond_6

    .line 11
    .line 12
    if-eq p1, v0, :cond_5

    .line 13
    .line 14
    const/4 p2, 0x4

    .line 15
    if-eq p1, p2, :cond_4

    .line 16
    .line 17
    const/4 p2, 0x5

    .line 18
    if-eq p1, p2, :cond_3

    .line 19
    .line 20
    const/4 p2, 0x6

    .line 21
    if-ne p1, p2, :cond_2

    .line 22
    .line 23
    sget-object p1, Lak$rM_i$;->zzd:Lw00OID;

    .line 24
    .line 25
    if-nez p1, :cond_1

    .line 26
    .line 27
    const-class p2, Lak$rM_i$;

    .line 28
    .line 29
    monitor-enter p2

    .line 30
    :try_start_0
    sget-object p1, Lak$rM_i$;->zzd:Lw00OID;

    .line 31
    .line 32
    if-nez p1, :cond_0

    .line 33
    .line 34
    new-instance p1, LEsp;

    .line 35
    .line 36
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 37
    .line 38
    .line 39
    sput-object p1, Lak$rM_i$;->zzd:Lw00OID;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    goto :goto_1

    .line 44
    :cond_0
    :goto_0
    monitor-exit p2

    .line 45
    return-object p1

    .line 46
    :goto_1
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    throw p1

    .line 48
    :cond_1
    return-object p1

    .line 49
    :cond_2
    const/4 p1, 0x0

    .line 50
    throw p1

    .line 51
    :cond_3
    sget-object p1, Lak$rM_i$;->zzc:Lak$rM_i$;

    .line 52
    .line 53
    return-object p1

    .line 54
    :cond_4
    new-instance p1, LIl1l;

    .line 55
    .line 56
    sget-object p2, Lak$rM_i$;->zzc:Lak$rM_i$;

    .line 57
    .line 58
    invoke-direct {p1, p2}, Lw1I;-><init>(LHU$B$;)V

    .line 59
    .line 60
    .line 61
    return-object p1

    .line 62
    :cond_5
    new-instance p1, Lak$rM_i$;

    .line 63
    .line 64
    invoke-direct {p1}, LHU$B$;-><init>()V

    .line 65
    .line 66
    .line 67
    return-object p1

    .line 68
    :cond_6
    new-array p1, v0, [Ljava/lang/Object;

    .line 69
    .line 70
    const-string v0, "zze"

    .line 71
    .line 72
    const/4 v2, 0x0

    .line 73
    aput-object v0, p1, v2

    .line 74
    .line 75
    const-string v0, "zzf"

    .line 76
    .line 77
    aput-object v0, p1, p2

    .line 78
    .line 79
    const-string p2, "zzg"

    .line 80
    .line 81
    aput-object p2, p1, v1

    .line 82
    .line 83
    sget-object p2, Lak$rM_i$;->zzc:Lak$rM_i$;

    .line 84
    .line 85
    const-string v0, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u1007\u0000\u0002\u100b\u0001"

    .line 86
    .line 87
    new-instance v1, Lk1D;

    .line 88
    .line 89
    invoke-direct {v1, p2, v0, p1}, Lk1D;-><init>(Lp1l;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    return-object v1

    .line 93
    :cond_7
    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    return-object p1
.end method
