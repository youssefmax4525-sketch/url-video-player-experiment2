.class public abstract LGi$EL$;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e8$mp_s$:Lab_w_;

.field public static final waiBKÀ:Ll1i;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Lab_w_;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-direct {v0, v1}, Lab_w_;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LGi$EL$;->e8$mp_s$:Lab_w_;

    .line 8
    .line 9
    new-instance v0, Ll1i;

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    invoke-direct {v0, v1}, Ll1i;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, LGi$EL$;->waiBKÀ:Ll1i;

    .line 16
    .line 17
    return-void
.end method
