.class public final LkIndex504;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public DDù8:F

.field public Ialue:I

.field public JKEoÙX:F

.field public POOl:Landroid/text/Layout$Alignment;

.field public e8$mp_s$:Ljava/lang/CharSequence;

.field public iOffset934:F

.field public jPos3709:F

.field public final kQy:F

.field public rz__9J_:Landroid/text/Layout$Alignment;

.field public sKey7917:I

.field public tmpData3485:I

.field public vaIue:I

.field public valuI:F

.field public final waiBKÀ:Landroid/graphics/Bitmap;

.field public yON3x:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, LkIndex504;->e8$mp_s$:Ljava/lang/CharSequence;

    .line 6
    .line 7
    iput-object v0, p0, LkIndex504;->waiBKÀ:Landroid/graphics/Bitmap;

    .line 8
    .line 9
    iput-object v0, p0, LkIndex504;->rz__9J_:Landroid/text/Layout$Alignment;

    .line 10
    .line 11
    iput-object v0, p0, LkIndex504;->POOl:Landroid/text/Layout$Alignment;

    .line 12
    .line 13
    const v0, -0x800001

    .line 14
    .line 15
    .line 16
    iput v0, p0, LkIndex504;->JKEoÙX:F

    .line 17
    .line 18
    const/high16 v1, -0x80000000

    .line 19
    .line 20
    iput v1, p0, LkIndex504;->tmpData3485:I

    .line 21
    .line 22
    iput v1, p0, LkIndex504;->sKey7917:I

    .line 23
    .line 24
    iput v0, p0, LkIndex504;->DDù8:F

    .line 25
    .line 26
    iput v1, p0, LkIndex504;->yON3x:I

    .line 27
    .line 28
    iput v1, p0, LkIndex504;->vaIue:I

    .line 29
    .line 30
    iput v0, p0, LkIndex504;->jPos3709:F

    .line 31
    .line 32
    iput v0, p0, LkIndex504;->iOffset934:F

    .line 33
    .line 34
    iput v0, p0, LkIndex504;->kQy:F

    .line 35
    .line 36
    iput v1, p0, LkIndex504;->Ialue:I

    .line 37
    .line 38
    return-void
.end method


# virtual methods
.method public final e8$mp_s$()LOS_U_;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, LOS_U_;

    .line 4
    .line 5
    iget-object v2, v0, LkIndex504;->e8$mp_s$:Ljava/lang/CharSequence;

    .line 6
    .line 7
    iget-object v3, v0, LkIndex504;->rz__9J_:Landroid/text/Layout$Alignment;

    .line 8
    .line 9
    iget-object v4, v0, LkIndex504;->POOl:Landroid/text/Layout$Alignment;

    .line 10
    .line 11
    iget v6, v0, LkIndex504;->JKEoÙX:F

    .line 12
    .line 13
    iget v7, v0, LkIndex504;->tmpData3485:I

    .line 14
    .line 15
    iget v8, v0, LkIndex504;->sKey7917:I

    .line 16
    .line 17
    iget v9, v0, LkIndex504;->DDù8:F

    .line 18
    .line 19
    iget v10, v0, LkIndex504;->yON3x:I

    .line 20
    .line 21
    iget v11, v0, LkIndex504;->vaIue:I

    .line 22
    .line 23
    iget v12, v0, LkIndex504;->jPos3709:F

    .line 24
    .line 25
    iget v13, v0, LkIndex504;->iOffset934:F

    .line 26
    .line 27
    iget v15, v0, LkIndex504;->Ialue:I

    .line 28
    .line 29
    iget v5, v0, LkIndex504;->valuI:F

    .line 30
    .line 31
    move/from16 v16, v5

    .line 32
    .line 33
    iget-object v5, v0, LkIndex504;->waiBKÀ:Landroid/graphics/Bitmap;

    .line 34
    .line 35
    iget v14, v0, LkIndex504;->kQy:F

    .line 36
    .line 37
    invoke-direct/range {v1 .. v16}, LOS_U_;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFIF)V

    .line 38
    .line 39
    .line 40
    return-object v1
.end method
