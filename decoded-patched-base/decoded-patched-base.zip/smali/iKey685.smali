.class public abstract LiKey685;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final JKEoÙX:LkKey8355;

.field public static final POOl:LVìmDs;

.field public static final e8$mp_s$:L$òuj;

.field public static final rz__9J_:LUEè;

.field public static final tmpData3485:I

.field public static final waiBKÀ:L$òuj;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LJ11D;

    .line 2
    .line 3
    const/16 v1, 0x18

    .line 4
    .line 5
    invoke-direct {v0, v1}, LJ11D;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, L$òuj;

    .line 9
    .line 10
    const-class v2, LCicqEZY;

    .line 11
    .line 12
    const-class v3, L_00Dl;

    .line 13
    .line 14
    invoke-direct {v1, v2, v3, v0}, L$òuj;-><init>(Ljava/lang/Class;Ljava/lang/Class;LnA$3g_00$;)V

    .line 15
    .line 16
    .line 17
    sput-object v1, LiKey685;->e8$mp_s$:L$òuj;

    .line 18
    .line 19
    new-instance v0, LtmpPos8530;

    .line 20
    .line 21
    const/16 v1, 0x18

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    invoke-direct {v0, v1, v3}, LtmpPos8530;-><init>(IB)V

    .line 25
    .line 26
    .line 27
    new-instance v1, L$òuj;

    .line 28
    .line 29
    const-class v3, LsLt4;

    .line 30
    .line 31
    invoke-direct {v1, v2, v3, v0}, L$òuj;-><init>(Ljava/lang/Class;Ljava/lang/Class;LnA$3g_00$;)V

    .line 32
    .line 33
    .line 34
    sput-object v1, LiKey685;->waiBKÀ:L$òuj;

    .line 35
    .line 36
    invoke-static {}, LOM_o$vs_;->ll()Lw00OID;

    .line 37
    .line 38
    .line 39
    new-instance v0, LUEè;

    .line 40
    .line 41
    const/4 v1, 0x2

    .line 42
    const-string v2, "type.googleapis.com/google.crypto.tink.HmacKey"

    .line 43
    .line 44
    invoke-direct {v0, v1, v3, v2}, LUEè;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    .line 45
    .line 46
    .line 47
    sput-object v0, LiKey685;->rz__9J_:LUEè;

    .line 48
    .line 49
    new-instance v0, LVìmDs;

    .line 50
    .line 51
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 52
    .line 53
    .line 54
    sput-object v0, LiKey685;->POOl:LVìmDs;

    .line 55
    .line 56
    new-instance v0, LkKey8355;

    .line 57
    .line 58
    const/16 v2, 0xb

    .line 59
    .line 60
    invoke-direct {v0, v2}, LkKey8355;-><init>(I)V

    .line 61
    .line 62
    .line 63
    sput-object v0, LiKey685;->JKEoÙX:LkKey8355;

    .line 64
    .line 65
    sput v1, LiKey685;->tmpData3485:I

    .line 66
    .line 67
    return-void
.end method
