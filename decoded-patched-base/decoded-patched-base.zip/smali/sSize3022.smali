.class public final LsSize3022;
.super LIQ;

# interfaces
.implements LOUy_0_;


# instance fields
.field public iOffset934:Z

.field public kQy:J


# virtual methods
.method public final e8$mp_s$()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, LsSize3022;->iOffset934:Z

    .line 2
    .line 3
    return v0
.end method

.method public final start()V
    .locals 11

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, LsSize3022;->iOffset934:Z

    .line 3
    .line 4
    iget-wide v0, p0, LsSize3022;->kQy:J

    .line 5
    .line 6
    const-wide/16 v2, 0x0

    .line 7
    .line 8
    cmp-long v4, v0, v2

    .line 9
    .line 10
    if-lez v4, :cond_2

    .line 11
    .line 12
    iget-object v2, p0, LIQ;->vaIue:LZN$P$;

    .line 13
    .line 14
    if-nez v2, :cond_0

    .line 15
    .line 16
    goto :goto_1

    .line 17
    :cond_0
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 18
    .line 19
    .line 20
    move-result-wide v2

    .line 21
    iget-object v4, p0, LIQ;->vaIue:LZN$P$;

    .line 22
    .line 23
    iget-object v4, v4, LZN$P$;->jPos3709:LZID1;

    .line 24
    .line 25
    invoke-virtual {v4}, LZID1;->jPos3709()Ljava/util/ArrayList;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    const/4 v6, 0x0

    .line 34
    :cond_1
    :goto_0
    if-ge v6, v5, :cond_2

    .line 35
    .line 36
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v7

    .line 40
    add-int/lit8 v6, v6, 0x1

    .line 41
    .line 42
    check-cast v7, LGLQ$hz$;

    .line 43
    .line 44
    move-object v8, v7

    .line 45
    check-cast v8, LNxccOS;

    .line 46
    .line 47
    iget-wide v8, v8, LNxccOS;->JKEoÙX:J

    .line 48
    .line 49
    sub-long v8, v2, v8

    .line 50
    .line 51
    cmp-long v10, v8, v0

    .line 52
    .line 53
    if-gez v10, :cond_1

    .line 54
    .line 55
    new-instance v8, Ljava/lang/StringBuilder;

    .line 56
    .line 57
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 58
    .line 59
    .line 60
    invoke-static {v8, v7}, LAELA3Dm;->e8$mp_s$(Ljava/lang/StringBuilder;LGLQ$hz$;)V

    .line 61
    .line 62
    .line 63
    sget-object v7, Ljava/lang/System;->out:Ljava/io/PrintStream;

    .line 64
    .line 65
    invoke-virtual {v7, v8}, Ljava/io/PrintStream;->print(Ljava/lang/Object;)V

    .line 66
    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_2
    :goto_1
    return-void
.end method

.method public final stop()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, LsSize3022;->iOffset934:Z

    .line 3
    .line 4
    return-void
.end method
