.class public final synthetic LhasOffset664;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LwI1O;


# instance fields
.field public final synthetic yON3x:LjSize1789;


# direct methods
.method public synthetic constructor <init>(LjSize1789;)V
    .locals 0

    .line 1
    iput-object p1, p0, LhasOffset664;->yON3x:LjSize1789;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public POOl(LQNNzV;)V
    .locals 7

    .line 1
    iget-object v0, p0, LhasOffset664;->yON3x:LjSize1789;

    .line 2
    .line 3
    iget-object v1, v0, LjSize1789;->vaIue:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, LsItem5946;

    .line 6
    .line 7
    invoke-virtual {v1}, LsItem5946;->e8$mp_s$()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x2

    .line 12
    if-ne v2, v3, :cond_4

    .line 13
    .line 14
    iget-object v1, v0, LjSize1789;->jPos3709:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v1, Landroid/app/Activity;

    .line 17
    .line 18
    new-instance v2, LbI;

    .line 19
    .line 20
    invoke-direct {v2, v0}, LbI;-><init>(LjSize1789;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    sget-object v0, LI1lIill;->e8$mp_s$:Landroid/os/Handler;

    .line 27
    .line 28
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    if-ne v0, v3, :cond_3

    .line 37
    .line 38
    iget-object v0, p1, LQNNzV;->DDù8:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 39
    .line 40
    const/4 v3, 0x0

    .line 41
    const/4 v4, 0x1

    .line 42
    invoke-virtual {v0, v3, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    const/4 v5, 0x3

    .line 47
    if-nez v0, :cond_1

    .line 48
    .line 49
    new-instance v0, LvCount2714;

    .line 50
    .line 51
    iget-boolean p1, p1, LQNNzV;->iOffset934:Z

    .line 52
    .line 53
    if-eq v4, p1, :cond_0

    .line 54
    .line 55
    const-string p1, "ConsentForm#show can only be invoked once."

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_0
    const-string p1, "Privacy options form is being loading. Please try again later."

    .line 59
    .line 60
    :goto_0
    invoke-direct {v0, v5, p1}, LvCount2714;-><init>(ILjava/lang/String;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0}, LvCount2714;->e8$mp_s$()LIIII;

    .line 64
    .line 65
    .line 66
    return-void

    .line 67
    :cond_1
    iget-object v0, p1, LQNNzV;->sKey7917:LsKey9565;

    .line 68
    .line 69
    iget-object v4, v0, LsKey9565;->vaIue:LRv$0$;

    .line 70
    .line 71
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    new-instance v6, L$TymaTF;

    .line 75
    .line 76
    invoke-direct {v6, v4, v3}, L$TymaTF;-><init>(LRv$0$;I)V

    .line 77
    .line 78
    .line 79
    iget-object v0, v0, LsKey9565;->yON3x:Landroid/os/Handler;

    .line 80
    .line 81
    invoke-virtual {v0, v6}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 82
    .line 83
    .line 84
    new-instance v0, LGmlòNO;

    .line 85
    .line 86
    invoke-direct {v0, p1, v1}, LGmlòNO;-><init>(LQNNzV;Landroid/app/Activity;)V

    .line 87
    .line 88
    .line 89
    iget-object v4, p1, LQNNzV;->e8$mp_s$:Landroid/app/Application;

    .line 90
    .line 91
    invoke-virtual {v4, v0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    .line 92
    .line 93
    .line 94
    iget-object v4, p1, LQNNzV;->jPos3709:Ljava/util/concurrent/atomic/AtomicReference;

    .line 95
    .line 96
    invoke-virtual {v4, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    iget-object v0, p1, LQNNzV;->waiBKÀ:LKQx_U$n9_;

    .line 100
    .line 101
    iput-object v1, v0, LKQx_U$n9_;->e8$mp_s$:Landroid/app/Activity;

    .line 102
    .line 103
    new-instance v0, Landroid/app/Dialog;

    .line 104
    .line 105
    const v4, 0x1030010

    .line 106
    .line 107
    .line 108
    invoke-direct {v0, v1, v4}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    .line 109
    .line 110
    .line 111
    iget-object v1, p1, LQNNzV;->sKey7917:LsKey9565;

    .line 112
    .line 113
    invoke-virtual {v0, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v0, v3}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    if-nez v1, :cond_2

    .line 124
    .line 125
    new-instance p1, LvCount2714;

    .line 126
    .line 127
    const-string v0, "Activity with null windows is passed in."

    .line 128
    .line 129
    invoke-direct {p1, v5, v0}, LvCount2714;-><init>(ILjava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1}, LvCount2714;->e8$mp_s$()LIIII;

    .line 133
    .line 134
    .line 135
    return-void

    .line 136
    :cond_2
    const/4 v4, -0x1

    .line 137
    invoke-virtual {v1, v4, v4}, Landroid/view/Window;->setLayout(II)V

    .line 138
    .line 139
    .line 140
    new-instance v4, Landroid/graphics/drawable/ColorDrawable;

    .line 141
    .line 142
    invoke-direct {v4, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {v1, v4}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 146
    .line 147
    .line 148
    const/high16 v4, 0x1000000

    .line 149
    .line 150
    invoke-virtual {v1, v4, v4}, Landroid/view/Window;->setFlags(II)V

    .line 151
    .line 152
    .line 153
    invoke-static {v1, v3}, LIlIIll;->valuI(Landroid/view/Window;Z)V

    .line 154
    .line 155
    .line 156
    iget-object v1, p1, LQNNzV;->vaIue:Ljava/util/concurrent/atomic/AtomicReference;

    .line 157
    .line 158
    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 159
    .line 160
    .line 161
    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    .line 162
    .line 163
    .line 164
    iput-object v0, p1, LQNNzV;->tmpData3485:Landroid/app/Dialog;

    .line 165
    .line 166
    iget-object p1, p1, LQNNzV;->sKey7917:LsKey9565;

    .line 167
    .line 168
    const-string v0, "UMP_messagePresented"

    .line 169
    .line 170
    const-string v1, ""

    .line 171
    .line 172
    invoke-virtual {p1, v0, v1}, LsKey9565;->e8$mp_s$(Ljava/lang/String;Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    return-void

    .line 176
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 177
    .line 178
    const-string v0, "Method must be call on main thread."

    .line 179
    .line 180
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    throw p1

    .line 184
    :cond_4
    invoke-virtual {v1}, LsItem5946;->e8$mp_s$()I

    .line 185
    .line 186
    .line 187
    return-void
.end method
