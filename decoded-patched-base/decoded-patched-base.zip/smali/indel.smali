.class public final Lindel;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public JKEoÙX:I

.field public POOl:Z

.field public e8$mp_s$:Z

.field public rz__9J_:I

.field public sKey7917:Z

.field public tmpData3485:LXnN_I$Cz_;

.field public waiBKÀ:I


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lindel;->e8$mp_s$:Z

    const/4 v1, -0x1

    iput v1, p0, Lindel;->waiBKÀ:I

    iput v0, p0, Lindel;->rz__9J_:I

    iput-boolean v0, p0, Lindel;->POOl:Z

    const/4 v1, 0x1

    iput v1, p0, Lindel;->JKEoÙX:I

    iput-boolean v0, p0, Lindel;->sKey7917:Z

    return-void
.end method

.method public synthetic constructor <init>(Lindel;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iget-boolean v0, p1, Lindel;->e8$mp_s$:Z

    .line 3
    iput-boolean v0, p0, Lindel;->e8$mp_s$:Z

    .line 4
    iget v0, p1, Lindel;->waiBKÀ:I

    .line 5
    iput v0, p0, Lindel;->waiBKÀ:I

    .line 6
    iget v0, p1, Lindel;->rz__9J_:I

    .line 7
    iput v0, p0, Lindel;->rz__9J_:I

    .line 8
    iget-boolean v0, p1, Lindel;->POOl:Z

    .line 9
    iput-boolean v0, p0, Lindel;->POOl:Z

    .line 10
    iget v0, p1, Lindel;->JKEoÙX:I

    .line 11
    iput v0, p0, Lindel;->JKEoÙX:I

    .line 12
    iget-object v0, p1, Lindel;->tmpData3485:LXnN_I$Cz_;

    .line 13
    iput-object v0, p0, Lindel;->tmpData3485:LXnN_I$Cz_;

    .line 14
    iget-boolean p1, p1, Lindel;->sKey7917:Z

    .line 15
    iput-boolean p1, p0, Lindel;->sKey7917:Z

    return-void
.end method
