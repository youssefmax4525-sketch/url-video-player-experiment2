.class public final LYQ;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final sKey7917:LhiB_7$0y_;


# instance fields
.field public JKEoÙX:Z

.field public final POOl:Lde5_bN_;

.field public final e8$mp_s$:LGtVP;

.field public final rz__9J_:LlI111l;

.field public tmpData3485:LIll1iI;

.field public final waiBKÀ:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LhiB_7$0y_;

    .line 2
    .line 3
    const-string v1, "SessionTransController"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, LhiB_7$0y_;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LYQ;->sKey7917:LhiB_7$0y_;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(LGtVP;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/HashSet;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 7
    .line 8
    .line 9
    invoke-static {v0}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iput-object v0, p0, LYQ;->waiBKÀ:Ljava/util/Set;

    .line 14
    .line 15
    iput-object p1, p0, LYQ;->e8$mp_s$:LGtVP;

    .line 16
    .line 17
    new-instance p1, LlI111l;

    .line 18
    .line 19
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    const/4 v1, 0x3

    .line 24
    invoke-direct {p1, v0, v1}, LlI111l;-><init>(Landroid/os/Looper;I)V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, LYQ;->rz__9J_:LlI111l;

    .line 28
    .line 29
    new-instance p1, Lde5_bN_;

    .line 30
    .line 31
    const/4 v0, 0x0

    .line 32
    invoke-direct {p1, p0, v0}, Lde5_bN_;-><init>(LYQ;I)V

    .line 33
    .line 34
    .line 35
    iput-object p1, p0, LYQ;->POOl:Lde5_bN_;

    .line 36
    .line 37
    return-void
.end method


# virtual methods
.method public final e8$mp_s$()V
    .locals 2

    .line 1
    iget-object v0, p0, LYQ;->rz__9J_:LlI111l;

    .line 2
    .line 3
    invoke-static {v0}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, LYQ;->POOl:Lde5_bN_;

    .line 7
    .line 8
    invoke-static {v1}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 12
    .line 13
    .line 14
    return-void
.end method
