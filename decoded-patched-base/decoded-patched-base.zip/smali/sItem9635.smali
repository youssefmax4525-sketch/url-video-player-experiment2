.class public final LsItem9635;
.super LtmpItem7277;
.source "SourceFile"


# static fields
.field public static final Ialue:Ljava/util/Set;

.field public static final valuI:Ljava/text/DecimalFormat;


# instance fields
.field public iOffset934:Ljava/io/File;

.field public kQy:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {v0}, Ljava/util/Collections;->synchronizedSet(Ljava/util/Set;)Ljava/util/Set;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, LsItem9635;->Ialue:Ljava/util/Set;

    .line 11
    .line 12
    new-instance v0, Ljava/text/DecimalFormat;

    .line 13
    .line 14
    const-string v1, "#,###"

    .line 15
    .line 16
    invoke-direct {v0, v1}, Ljava/text/DecimalFormat;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    sput-object v0, LsItem9635;->valuI:Ljava/text/DecimalFormat;

    .line 20
    .line 21
    return-void
.end method


# virtual methods
.method public final K0I(Ljava/io/File;)Ljava/io/File;
    .locals 3

    .line 1
    new-instance v0, Ljava/io/File;

    .line 2
    .line 3
    iget-object v1, p0, LsItem9635;->iOffset934:Ljava/io/File;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    const-string v2, ".done"

    .line 14
    .line 15
    invoke-virtual {p1, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    new-instance v2, Ljava/io/File;

    .line 20
    .line 21
    invoke-direct {v2, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    return-object v0
.end method

.method public final vaIue()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, LsItem9635;->kQy:Z

    .line 3
    .line 4
    return-void
.end method

.method public final yàÒZ(Ljava/lang/String;)Z
    .locals 25

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    iget-object v0, v1, LsItem9635;->iOffset934:Ljava/io/File;

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    const/4 v7, 0x0

    .line 9
    if-eqz v0, :cond_1b

    .line 10
    .line 11
    :cond_0
    iget-object v0, v1, LsItem9635;->iOffset934:Ljava/io/File;

    .line 12
    .line 13
    if-nez v0, :cond_1

    .line 14
    .line 15
    const/4 v5, 0x0

    .line 16
    goto :goto_1

    .line 17
    :cond_1
    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    array-length v3, v0

    .line 22
    const/4 v4, 0x0

    .line 23
    const/4 v5, 0x0

    .line 24
    :goto_0
    if-ge v4, v3, :cond_3

    .line 25
    .line 26
    aget-object v8, v0, v4

    .line 27
    .line 28
    invoke-virtual {v8}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v8

    .line 32
    const-string v9, ".done"

    .line 33
    .line 34
    invoke-virtual {v8, v9}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 35
    .line 36
    .line 37
    move-result v8

    .line 38
    if-nez v8, :cond_2

    .line 39
    .line 40
    add-int/lit8 v5, v5, 0x1

    .line 41
    .line 42
    :cond_2
    add-int/lit8 v4, v4, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_3
    :goto_1
    sget-object v0, LisIndex2415;->yàÒZ:LSdE$n$;

    .line 46
    .line 47
    sget-object v3, LIl1il;->POOl:LIl1il;

    .line 48
    .line 49
    iget-object v4, v3, LIl1il;->rz__9J_:LnCount1076;

    .line 50
    .line 51
    invoke-virtual {v4, v0}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Ljava/lang/Integer;

    .line 56
    .line 57
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 58
    .line 59
    .line 60
    move-result v0

    .line 61
    if-le v5, v0, :cond_9

    .line 62
    .line 63
    iget-object v0, v1, LsItem9635;->iOffset934:Ljava/io/File;

    .line 64
    .line 65
    if-nez v0, :cond_4

    .line 66
    .line 67
    goto :goto_4

    .line 68
    :cond_4
    invoke-virtual {v0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    array-length v3, v0

    .line 73
    const-wide v4, 0x7fffffffffffffffL

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    move-object v9, v7

    .line 79
    const/4 v8, 0x0

    .line 80
    :goto_2
    if-ge v8, v3, :cond_6

    .line 81
    .line 82
    aget-object v10, v0, v8

    .line 83
    .line 84
    invoke-virtual {v10}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v11

    .line 88
    const-string v12, ".done"

    .line 89
    .line 90
    invoke-virtual {v11, v12}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 91
    .line 92
    .line 93
    move-result v11

    .line 94
    if-nez v11, :cond_5

    .line 95
    .line 96
    invoke-virtual {v10}, Ljava/io/File;->lastModified()J

    .line 97
    .line 98
    .line 99
    move-result-wide v11

    .line 100
    cmp-long v13, v11, v4

    .line 101
    .line 102
    if-gez v13, :cond_5

    .line 103
    .line 104
    move-object v9, v10

    .line 105
    move-wide v4, v11

    .line 106
    :cond_5
    add-int/lit8 v8, v8, 0x1

    .line 107
    .line 108
    goto :goto_2

    .line 109
    :cond_6
    if-eqz v9, :cond_7

    .line 110
    .line 111
    invoke-virtual {v9}, Ljava/io/File;->delete()Z

    .line 112
    .line 113
    .line 114
    move-result v0

    .line 115
    invoke-virtual {v1, v9}, LsItem9635;->K0I(Ljava/io/File;)Ljava/io/File;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    invoke-virtual {v3}, Ljava/io/File;->isFile()Z

    .line 120
    .line 121
    .line 122
    move-result v4

    .line 123
    if-eqz v4, :cond_8

    .line 124
    .line 125
    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    .line 126
    .line 127
    .line 128
    move-result v3

    .line 129
    and-int/2addr v0, v3

    .line 130
    goto :goto_3

    .line 131
    :cond_7
    const/4 v0, 0x0

    .line 132
    :cond_8
    :goto_3
    if-nez v0, :cond_0

    .line 133
    .line 134
    :goto_4
    const-string v0, "Unable to expire stream cache"

    .line 135
    .line 136
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    const-string v0, "expireFailed"

    .line 140
    .line 141
    invoke-virtual {v1, v2, v7, v0, v7}, LtmpItem7277;->jPos3709(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    return v6

    .line 145
    :cond_9
    const-string v0, "MD5"

    .line 146
    .line 147
    invoke-static {v2, v0}, Lhl;->Ialue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v0

    .line 151
    new-instance v8, Ljava/io/File;

    .line 152
    .line 153
    iget-object v4, v1, LsItem9635;->iOffset934:Ljava/io/File;

    .line 154
    .line 155
    new-instance v5, Ljava/io/File;

    .line 156
    .line 157
    invoke-direct {v5, v4, v0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v5}, Ljava/io/File;->getPath()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-direct {v8, v0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {v1, v8}, LsItem9635;->K0I(Ljava/io/File;)Ljava/io/File;

    .line 168
    .line 169
    .line 170
    move-result-object v9

    .line 171
    invoke-virtual {v8}, Ljava/io/File;->isFile()Z

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    const/4 v10, 0x1

    .line 176
    if-eqz v0, :cond_b

    .line 177
    .line 178
    invoke-virtual {v9}, Ljava/io/File;->isFile()Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    if-nez v0, :cond_a

    .line 183
    .line 184
    goto :goto_5

    .line 185
    :cond_a
    invoke-virtual {v8}, Ljava/io/File;->length()J

    .line 186
    .line 187
    .line 188
    move-result-wide v3

    .line 189
    long-to-int v0, v3

    .line 190
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object v3

    .line 194
    const-string v4, "Stream cache hit at "

    .line 195
    .line 196
    invoke-virtual {v4, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v3

    .line 200
    invoke-static {v3}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object v3

    .line 207
    sget-object v4, Lhl;->waiBKÀ:LlI111l;

    .line 208
    .line 209
    new-instance v5, LmSxNdlh;

    .line 210
    .line 211
    invoke-direct {v5, v1, v2, v3, v0}, LmSxNdlh;-><init>(LtmpItem7277;Ljava/lang/String;Ljava/lang/String;I)V

    .line 212
    .line 213
    .line 214
    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 215
    .line 216
    .line 217
    return v10

    .line 218
    :cond_b
    :goto_5
    iget-object v0, v1, LsItem9635;->iOffset934:Ljava/io/File;

    .line 219
    .line 220
    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 229
    .line 230
    .line 231
    move-result-object v4

    .line 232
    sget-object v5, LsItem9635;->Ialue:Ljava/util/Set;

    .line 233
    .line 234
    invoke-virtual {v0, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v11

    .line 238
    monitor-enter v5

    .line 239
    :try_start_0
    invoke-interface {v5, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    move-result v0

    .line 243
    if-eqz v0, :cond_c

    .line 244
    .line 245
    new-instance v0, Ljava/lang/StringBuilder;

    .line 246
    .line 247
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 248
    .line 249
    .line 250
    const-string v3, "Stream cache already in progress at "

    .line 251
    .line 252
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 253
    .line 254
    .line 255
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 256
    .line 257
    .line 258
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 259
    .line 260
    .line 261
    move-result-object v0

    .line 262
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 266
    .line 267
    .line 268
    move-result-object v0

    .line 269
    const-string v3, "inProgress"

    .line 270
    .line 271
    invoke-virtual {v1, v2, v0, v3, v7}, LtmpItem7277;->jPos3709(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 272
    .line 273
    .line 274
    monitor-exit v5

    .line 275
    return v6

    .line 276
    :catchall_0
    move-exception v0

    .line 277
    goto/16 :goto_11

    .line 278
    .line 279
    :cond_c
    invoke-interface {v5, v11}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 280
    .line 281
    .line 282
    monitor-exit v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 283
    const-string v12, "error"

    .line 284
    .line 285
    :try_start_1
    new-instance v0, LhE$h6_Y$;

    .line 286
    .line 287
    new-instance v4, LJ11D;

    .line 288
    .line 289
    const/4 v13, 0x6

    .line 290
    invoke-direct {v4, v13}, LJ11D;-><init>(I)V

    .line 291
    .line 292
    .line 293
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 294
    .line 295
    .line 296
    iput-object v4, v0, LhE$h6_Y$;->yON3x:LkItem6218;

    .line 297
    .line 298
    iput-object v7, v0, LhE$h6_Y$;->vaIue:LnPos4111;

    .line 299
    .line 300
    new-instance v4, LnPos4111;

    .line 301
    .line 302
    const/4 v13, 0x5

    .line 303
    invoke-direct {v4, v2, v13}, LnPos4111;-><init>(Ljava/lang/String;I)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {v0, v4}, LhE$h6_Y$;->rz__9J_(LnPos4111;)Ljava/net/HttpURLConnection;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 311
    .line 312
    .line 313
    move-result v4

    .line 314
    const/16 v13, 0x190

    .line 315
    .line 316
    if-ge v4, v13, :cond_17

    .line 317
    .line 318
    invoke-virtual {v0}, Ljava/net/URLConnection;->getContentLength()I

    .line 319
    .line 320
    .line 321
    move-result v4

    .line 322
    if-gez v4, :cond_d

    .line 323
    .line 324
    new-instance v0, Ljava/lang/StringBuilder;

    .line 325
    .line 326
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 327
    .line 328
    .line 329
    const-string v3, "Stream cache aborted, missing content-length header at "

    .line 330
    .line 331
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 332
    .line 333
    .line 334
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 335
    .line 336
    .line 337
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 338
    .line 339
    .line 340
    move-result-object v0

    .line 341
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v0

    .line 348
    const-string v3, "contentLengthMissing"

    .line 349
    .line 350
    invoke-virtual {v1, v2, v0, v3, v7}, LtmpItem7277;->jPos3709(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 351
    .line 352
    .line 353
    invoke-interface {v5, v11}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 354
    .line 355
    .line 356
    return v6

    .line 357
    :cond_d
    sget-object v13, LsItem9635;->valuI:Ljava/text/DecimalFormat;

    .line 358
    .line 359
    int-to-long v14, v4

    .line 360
    invoke-virtual {v13, v14, v15}, Ljava/text/NumberFormat;->format(J)Ljava/lang/String;

    .line 361
    .line 362
    .line 363
    move-result-object v13

    .line 364
    sget-object v14, LisIndex2415;->gKey4112:LSdE$n$;

    .line 365
    .line 366
    iget-object v15, v3, LIl1il;->rz__9J_:LnCount1076;

    .line 367
    .line 368
    invoke-virtual {v15, v14}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 369
    .line 370
    .line 371
    move-result-object v14

    .line 372
    check-cast v14, Ljava/lang/Integer;

    .line 373
    .line 374
    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    .line 375
    .line 376
    .line 377
    move-result v14

    .line 378
    if-le v4, v14, :cond_e

    .line 379
    .line 380
    new-instance v0, Ljava/lang/StringBuilder;

    .line 381
    .line 382
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 383
    .line 384
    .line 385
    const-string v3, "Content length "

    .line 386
    .line 387
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 388
    .line 389
    .line 390
    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 391
    .line 392
    .line 393
    const-string v3, " exceeds limit at "

    .line 394
    .line 395
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 396
    .line 397
    .line 398
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v0

    .line 405
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    new-instance v0, Ljava/lang/StringBuilder;

    .line 409
    .line 410
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 411
    .line 412
    .line 413
    const-string v3, "File too big for full file cache. Size: "

    .line 414
    .line 415
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 416
    .line 417
    .line 418
    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 419
    .line 420
    .line 421
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object v3

    .line 429
    const-string v4, "sizeExceeded"

    .line 430
    .line 431
    invoke-virtual {v1, v2, v3, v4, v0}, LtmpItem7277;->jPos3709(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 432
    .line 433
    .line 434
    invoke-interface {v5, v11}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 435
    .line 436
    .line 437
    return v6

    .line 438
    :cond_e
    new-instance v5, Ljava/lang/StringBuilder;

    .line 439
    .line 440
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 441
    .line 442
    .line 443
    const-string v15, "Caching "

    .line 444
    .line 445
    invoke-virtual {v5, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 446
    .line 447
    .line 448
    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 449
    .line 450
    .line 451
    const-string v13, " bytes from "

    .line 452
    .line 453
    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 454
    .line 455
    .line 456
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 457
    .line 458
    .line 459
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 460
    .line 461
    .line 462
    move-result-object v5

    .line 463
    invoke-static {v5}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 464
    .line 465
    .line 466
    invoke-virtual {v0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 467
    .line 468
    .line 469
    move-result-object v0

    .line 470
    invoke-static {v0}, Ljava/nio/channels/Channels;->newChannel(Ljava/io/InputStream;)Ljava/nio/channels/ReadableByteChannel;

    .line 471
    .line 472
    .line 473
    move-result-object v13

    .line 474
    new-instance v15, Ljava/io/FileOutputStream;

    .line 475
    .line 476
    invoke-direct {v15, v8}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_8
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_7

    .line 477
    .line 478
    .line 479
    :try_start_2
    invoke-virtual {v15}, Ljava/io/FileOutputStream;->getChannel()Ljava/nio/channels/FileChannel;

    .line 480
    .line 481
    .line 482
    move-result-object v0

    .line 483
    const/high16 v5, 0x100000

    .line 484
    .line 485
    invoke-static {v5}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 486
    .line 487
    .line 488
    move-result-object v5

    .line 489
    sget-object v7, LvItem598;->tzKù7Ol1:LvItem598;

    .line 490
    .line 491
    iget-object v7, v7, LvItem598;->vaIue:LkOffset8539;

    .line 492
    .line 493
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 494
    .line 495
    .line 496
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 497
    .line 498
    .line 499
    move-result-wide v16

    .line 500
    sget-object v7, LisIndex2415;->ll:LSdE$n$;

    .line 501
    .line 502
    iget-object v6, v3, LIl1il;->rz__9J_:LnCount1076;

    .line 503
    .line 504
    invoke-virtual {v6, v7}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 505
    .line 506
    .line 507
    move-result-object v6

    .line 508
    check-cast v6, Ljava/lang/Long;

    .line 509
    .line 510
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 511
    .line 512
    .line 513
    move-result-wide v6

    .line 514
    new-instance v10, LUeQoJÒ;

    .line 515
    .line 516
    invoke-direct {v10, v6, v7}, LUeQoJÒ;-><init>(J)V

    .line 517
    .line 518
    .line 519
    sget-object v6, LisIndex2415;->tzKù7Ol1:LSdE$n$;

    .line 520
    .line 521
    iget-object v3, v3, LIl1il;->rz__9J_:LnCount1076;

    .line 522
    .line 523
    invoke-virtual {v3, v6}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 524
    .line 525
    .line 526
    move-result-object v3

    .line 527
    check-cast v3, Ljava/lang/Long;

    .line 528
    .line 529
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 530
    .line 531
    .line 532
    move-result-wide v6

    .line 533
    const/4 v3, 0x0

    .line 534
    :goto_6
    invoke-interface {v13, v5}, Ljava/nio/channels/ReadableByteChannel;->read(Ljava/nio/ByteBuffer;)I

    .line 535
    .line 536
    .line 537
    move-result v20

    .line 538
    if-ltz v20, :cond_14

    .line 539
    .line 540
    add-int v3, v3, v20

    .line 541
    .line 542
    if-gt v3, v14, :cond_13

    .line 543
    .line 544
    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    .line 545
    .line 546
    .line 547
    :goto_7
    invoke-virtual {v0, v5}, Ljava/nio/channels/FileChannel;->write(Ljava/nio/ByteBuffer;)I

    .line 548
    .line 549
    .line 550
    move-result v20

    .line 551
    if-gtz v20, :cond_12

    .line 552
    .line 553
    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->clear()Ljava/nio/Buffer;

    .line 554
    .line 555
    .line 556
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 557
    .line 558
    .line 559
    move-result-wide v20

    .line 560
    sub-long v20, v20, v16

    .line 561
    .line 562
    const-wide/16 v22, 0x3e8

    .line 563
    .line 564
    mul-long v22, v22, v6

    .line 565
    .line 566
    cmp-long v24, v20, v22

    .line 567
    .line 568
    if-gtz v24, :cond_11

    .line 569
    .line 570
    move-object/from16 v20, v0

    .line 571
    .line 572
    iget-boolean v0, v1, LsItem9635;->kQy:Z

    .line 573
    .line 574
    if-nez v0, :cond_10

    .line 575
    .line 576
    invoke-virtual {v10}, LUeQoJÒ;->POOl()Z

    .line 577
    .line 578
    .line 579
    move-result v0

    .line 580
    if-eqz v0, :cond_f

    .line 581
    .line 582
    move-object v0, v5

    .line 583
    move v5, v4

    .line 584
    move v4, v3

    .line 585
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 586
    .line 587
    .line 588
    move-result-object v3

    .line 589
    move-wide/from16 v21, v6

    .line 590
    .line 591
    sget-object v6, Lhl;->waiBKÀ:LlI111l;

    .line 592
    .line 593
    move-object v7, v0

    .line 594
    new-instance v0, LkPos547;

    .line 595
    .line 596
    invoke-direct/range {v0 .. v5}, LkPos547;-><init>(LsItem9635;Ljava/lang/String;Ljava/lang/String;II)V

    .line 597
    .line 598
    .line 599
    invoke-virtual {v6, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 600
    .line 601
    .line 602
    goto :goto_8

    .line 603
    :cond_f
    move-wide/from16 v21, v6

    .line 604
    .line 605
    move-object v7, v5

    .line 606
    move v5, v4

    .line 607
    move v4, v3

    .line 608
    :goto_8
    move v3, v4

    .line 609
    move v4, v5

    .line 610
    move-object v5, v7

    .line 611
    move-object/from16 v0, v20

    .line 612
    .line 613
    move-wide/from16 v6, v21

    .line 614
    .line 615
    goto :goto_6

    .line 616
    :cond_10
    const-string v12, "externalAbort"

    .line 617
    .line 618
    new-instance v0, Ljava/io/IOException;

    .line 619
    .line 620
    const-string v3, "abort requested"

    .line 621
    .line 622
    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 623
    .line 624
    .line 625
    throw v0

    .line 626
    :catch_0
    move-exception v0

    .line 627
    goto :goto_9

    .line 628
    :catch_1
    move-exception v0

    .line 629
    :goto_9
    move-object v7, v15

    .line 630
    const/4 v3, 0x0

    .line 631
    goto/16 :goto_e

    .line 632
    .line 633
    :cond_11
    move-wide/from16 v21, v6

    .line 634
    .line 635
    const-string v12, "downloadTimeout"

    .line 636
    .line 637
    invoke-static/range {v21 .. v22}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    .line 638
    .line 639
    .line 640
    move-result-object v0

    .line 641
    new-instance v3, Ljava/lang/StringBuilder;

    .line 642
    .line 643
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 644
    .line 645
    .line 646
    const-string v4, "Timeout exceeded. Limit: "

    .line 647
    .line 648
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 649
    .line 650
    .line 651
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 652
    .line 653
    .line 654
    const-string v0, " sec"

    .line 655
    .line 656
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 657
    .line 658
    .line 659
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 660
    .line 661
    .line 662
    move-result-object v7
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_2} :catch_0

    .line 663
    :try_start_3
    new-instance v0, Ljava/io/IOException;

    .line 664
    .line 665
    const-string v3, "stream cache time limit exceeded"

    .line 666
    .line 667
    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 668
    .line 669
    .line 670
    throw v0
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_3} :catch_2

    .line 671
    :catch_2
    move-exception v0

    .line 672
    goto :goto_a

    .line 673
    :catch_3
    move-exception v0

    .line 674
    :goto_a
    move-object v3, v7

    .line 675
    move-object v7, v15

    .line 676
    goto/16 :goto_e

    .line 677
    .line 678
    :cond_12
    move-wide/from16 v21, v6

    .line 679
    .line 680
    goto/16 :goto_7

    .line 681
    .line 682
    :cond_13
    move v4, v3

    .line 683
    :try_start_4
    const-string v12, "sizeExceeded"

    .line 684
    .line 685
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 686
    .line 687
    .line 688
    move-result-object v0

    .line 689
    new-instance v3, Ljava/lang/StringBuilder;

    .line 690
    .line 691
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 692
    .line 693
    .line 694
    const-string v4, "File too big for full file cache. Size: "

    .line 695
    .line 696
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 697
    .line 698
    .line 699
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 700
    .line 701
    .line 702
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 703
    .line 704
    .line 705
    move-result-object v7
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_4 .. :try_end_4} :catch_0

    .line 706
    :try_start_5
    new-instance v0, Ljava/io/IOException;

    .line 707
    .line 708
    const-string v3, "stream cache file size limit exceeded"

    .line 709
    .line 710
    invoke-direct {v0, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 711
    .line 712
    .line 713
    throw v0
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_3
    .catch Ljava/lang/RuntimeException; {:try_start_5 .. :try_end_5} :catch_2

    .line 714
    :cond_14
    :try_start_6
    invoke-virtual {v15}, Ljava/io/FileOutputStream;->close()V

    .line 715
    .line 716
    .line 717
    const/4 v0, 0x3

    .line 718
    invoke-static {v0}, LPJNypàa;->CcZMD(I)Z

    .line 719
    .line 720
    .line 721
    move-result v0

    .line 722
    if-eqz v0, :cond_15

    .line 723
    .line 724
    sget-object v0, LsItem9635;->valuI:Ljava/text/DecimalFormat;

    .line 725
    .line 726
    int-to-long v4, v3

    .line 727
    invoke-virtual {v0, v4, v5}, Ljava/text/NumberFormat;->format(J)Ljava/lang/String;

    .line 728
    .line 729
    .line 730
    move-result-object v0

    .line 731
    new-instance v4, Ljava/lang/StringBuilder;

    .line 732
    .line 733
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 734
    .line 735
    .line 736
    const-string v5, "Preloaded "

    .line 737
    .line 738
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 739
    .line 740
    .line 741
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 742
    .line 743
    .line 744
    const-string v0, " bytes from "

    .line 745
    .line 746
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 747
    .line 748
    .line 749
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 750
    .line 751
    .line 752
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 753
    .line 754
    .line 755
    move-result-object v0

    .line 756
    invoke-static {v0}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 757
    .line 758
    .line 759
    :cond_15
    const/4 v0, 0x1

    .line 760
    const/4 v4, 0x0

    .line 761
    invoke-virtual {v8, v0, v4}, Ljava/io/File;->setReadable(ZZ)Z

    .line 762
    .line 763
    .line 764
    invoke-virtual {v9}, Ljava/io/File;->isFile()Z

    .line 765
    .line 766
    .line 767
    move-result v0

    .line 768
    if-eqz v0, :cond_16

    .line 769
    .line 770
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 771
    .line 772
    .line 773
    move-result-wide v4

    .line 774
    invoke-virtual {v9, v4, v5}, Ljava/io/File;->setLastModified(J)Z
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_6 .. :try_end_6} :catch_0

    .line 775
    .line 776
    .line 777
    goto :goto_b

    .line 778
    :cond_16
    :try_start_7
    invoke-virtual {v9}, Ljava/io/File;->createNewFile()Z
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_4
    .catch Ljava/lang/RuntimeException; {:try_start_7 .. :try_end_7} :catch_0

    .line 779
    .line 780
    .line 781
    :catch_4
    :goto_b
    :try_start_8
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 782
    .line 783
    .line 784
    move-result-object v0

    .line 785
    sget-object v4, Lhl;->waiBKÀ:LlI111l;

    .line 786
    .line 787
    new-instance v5, LmSxNdlh;

    .line 788
    .line 789
    invoke-direct {v5, v1, v2, v0, v3}, LmSxNdlh;-><init>(LtmpItem7277;Ljava/lang/String;Ljava/lang/String;I)V

    .line 790
    .line 791
    .line 792
    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 793
    .line 794
    .line 795
    sget-object v0, LsItem9635;->Ialue:Ljava/util/Set;

    .line 796
    .line 797
    invoke-interface {v0, v11}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_1
    .catch Ljava/lang/RuntimeException; {:try_start_8 .. :try_end_8} :catch_0

    .line 798
    .line 799
    .line 800
    const/16 v19, 0x1

    .line 801
    .line 802
    return v19

    .line 803
    :cond_17
    :try_start_9
    const-string v12, "badUrl"

    .line 804
    .line 805
    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 806
    .line 807
    .line 808
    move-result-object v0

    .line 809
    new-instance v3, Ljava/lang/StringBuilder;

    .line 810
    .line 811
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 812
    .line 813
    .line 814
    const-string v5, "HTTP request failed. Code: "

    .line 815
    .line 816
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 817
    .line 818
    .line 819
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 820
    .line 821
    .line 822
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 823
    .line 824
    .line 825
    move-result-object v3
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_8
    .catch Ljava/lang/RuntimeException; {:try_start_9 .. :try_end_9} :catch_7

    .line 826
    :try_start_a
    new-instance v0, Ljava/io/IOException;

    .line 827
    .line 828
    new-instance v5, Ljava/lang/StringBuilder;

    .line 829
    .line 830
    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    .line 831
    .line 832
    .line 833
    const-string v6, "HTTP status code "

    .line 834
    .line 835
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 836
    .line 837
    .line 838
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 839
    .line 840
    .line 841
    const-string v4, " at "

    .line 842
    .line 843
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 844
    .line 845
    .line 846
    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 847
    .line 848
    .line 849
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 850
    .line 851
    .line 852
    move-result-object v4

    .line 853
    invoke-direct {v0, v4}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 854
    .line 855
    .line 856
    throw v0
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_6
    .catch Ljava/lang/RuntimeException; {:try_start_a .. :try_end_a} :catch_5

    .line 857
    :catch_5
    move-exception v0

    .line 858
    goto :goto_c

    .line 859
    :catch_6
    move-exception v0

    .line 860
    :goto_c
    const/4 v7, 0x0

    .line 861
    goto :goto_e

    .line 862
    :catch_7
    move-exception v0

    .line 863
    goto :goto_d

    .line 864
    :catch_8
    move-exception v0

    .line 865
    :goto_d
    const/4 v3, 0x0

    .line 866
    goto :goto_c

    .line 867
    :goto_e
    instance-of v4, v0, Ljava/lang/RuntimeException;

    .line 868
    .line 869
    if-eqz v4, :cond_18

    .line 870
    .line 871
    const-string v4, "VideoStreamFullFileCache.preload"

    .line 872
    .line 873
    sget-object v5, LvItem598;->tzKù7Ol1:LvItem598;

    .line 874
    .line 875
    iget-object v5, v5, LvItem598;->sKey7917:LNl;

    .line 876
    .line 877
    invoke-virtual {v5, v4, v0}, LNl;->yON3x(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 878
    .line 879
    .line 880
    :cond_18
    :try_start_b
    invoke-virtual {v7}, Ljava/io/FileOutputStream;->close()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_9
    .catch Ljava/lang/NullPointerException; {:try_start_b .. :try_end_b} :catch_9

    .line 881
    .line 882
    .line 883
    goto :goto_f

    .line 884
    :catch_9
    nop

    .line 885
    :goto_f
    iget-boolean v0, v1, LsItem9635;->kQy:Z

    .line 886
    .line 887
    if-eqz v0, :cond_19

    .line 888
    .line 889
    new-instance v0, Ljava/lang/StringBuilder;

    .line 890
    .line 891
    const-string v4, "Preload aborted for URL \""

    .line 892
    .line 893
    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 894
    .line 895
    .line 896
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 897
    .line 898
    .line 899
    const-string v4, "\""

    .line 900
    .line 901
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 902
    .line 903
    .line 904
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 905
    .line 906
    .line 907
    move-result-object v0

    .line 908
    invoke-static {v0}, LPJNypàa;->lIl1(Ljava/lang/String;)V

    .line 909
    .line 910
    .line 911
    :cond_19
    invoke-virtual {v8}, Ljava/io/File;->exists()Z

    .line 912
    .line 913
    .line 914
    move-result v0

    .line 915
    if-eqz v0, :cond_1a

    .line 916
    .line 917
    invoke-virtual {v8}, Ljava/io/File;->delete()Z

    .line 918
    .line 919
    .line 920
    move-result v0

    .line 921
    if-nez v0, :cond_1a

    .line 922
    .line 923
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 924
    .line 925
    .line 926
    move-result-object v0

    .line 927
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 928
    .line 929
    .line 930
    move-result-object v0

    .line 931
    const-string v4, "Could not delete partial cache file at "

    .line 932
    .line 933
    invoke-virtual {v4, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 934
    .line 935
    .line 936
    move-result-object v0

    .line 937
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 938
    .line 939
    .line 940
    :cond_1a
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 941
    .line 942
    .line 943
    move-result-object v0

    .line 944
    invoke-virtual {v1, v2, v0, v12, v3}, LtmpItem7277;->jPos3709(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 945
    .line 946
    .line 947
    sget-object v0, LsItem9635;->Ialue:Ljava/util/Set;

    .line 948
    .line 949
    invoke-interface {v0, v11}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 950
    .line 951
    .line 952
    :goto_10
    const/16 v18, 0x0

    .line 953
    .line 954
    return v18

    .line 955
    :goto_11
    :try_start_c
    monitor-exit v5
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_0

    .line 956
    throw v0

    .line 957
    :cond_1b
    const-string v0, "noCacheDir"

    .line 958
    .line 959
    const/4 v3, 0x0

    .line 960
    invoke-virtual {v1, v2, v3, v0, v3}, LtmpItem7277;->jPos3709(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 961
    .line 962
    .line 963
    goto :goto_10
.end method
