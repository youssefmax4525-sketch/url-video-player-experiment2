.class public abstract Lw1I;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field public vaIue:LHU$B$;

.field public final yON3x:LHU$B$;


# direct methods
.method public constructor <init>(LHU$B$;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lw1I;->yON3x:LHU$B$;

    .line 5
    .line 6
    invoke-virtual {p1}, LHU$B$;->gKey4112()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p1}, LHU$B$;->Ialue()LHU$B$;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Lw1I;->vaIue:LHU$B$;

    .line 17
    .line 18
    return-void

    .line 19
    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 20
    .line 21
    const-string v0, "Default instance must be immutable."

    .line 22
    .line 23
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw p1
.end method

.method public static JKEoÙX(ILjava/util/List;)V
    .locals 3

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    sub-int/2addr v0, p0

    .line 6
    const-string v1, "Element at index "

    .line 7
    .line 8
    const-string v2, " is null."

    .line 9
    .line 10
    invoke-static {v1, v0, v2}, LBRK_m_;->sKey7917(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    :goto_0
    add-int/lit8 v1, v1, -0x1

    .line 19
    .line 20
    if-lt v1, p0, :cond_0

    .line 21
    .line 22
    invoke-interface {p1, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    new-instance p0, Ljava/lang/NullPointerException;

    .line 27
    .line 28
    invoke-direct {p0, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw p0
.end method


# virtual methods
.method public final POOl()V
    .locals 4

    .line 1
    iget-object v0, p0, Lw1I;->vaIue:LHU$B$;

    .line 2
    .line 3
    invoke-virtual {v0}, LHU$B$;->gKey4112()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lw1I;->yON3x:LHU$B$;

    .line 10
    .line 11
    invoke-virtual {v0}, LHU$B$;->Ialue()LHU$B$;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-object v1, p0, Lw1I;->vaIue:LHU$B$;

    .line 16
    .line 17
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    invoke-virtual {v2, v3}, LLKmiA;->e8$mp_s$(Ljava/lang/Class;)LfèkèNDÙy;

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-interface {v2, v0, v1}, LfèkèNDÙy;->yON3x(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iput-object v0, p0, Lw1I;->vaIue:LHU$B$;

    .line 31
    .line 32
    :cond_0
    return-void
.end method

.method public final clone()Ljava/lang/Object;
    .locals 3

    .line 1
    const/4 v0, 0x5

    .line 2
    const/4 v1, 0x0

    .line 3
    iget-object v2, p0, Lw1I;->yON3x:LHU$B$;

    .line 4
    .line 5
    invoke-virtual {v2, v0, v1}, LHU$B$;->kO_6X_(ILHU$B$;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Lw1I;

    .line 10
    .line 11
    invoke-virtual {p0}, Lw1I;->rz__9J_()LHU$B$;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    iput-object v1, v0, Lw1I;->vaIue:LHU$B$;

    .line 16
    .line 17
    return-object v0
.end method

.method public final e8$mp_s$([BLOìJÒ6;)V
    .locals 6

    .line 1
    array-length v4, p1

    .line 2
    invoke-virtual {p0}, Lw1I;->POOl()V

    .line 3
    .line 4
    .line 5
    :try_start_0
    sget-object v0, LLKmiA;->rz__9J_:LLKmiA;

    .line 6
    .line 7
    iget-object v1, p0, Lw1I;->vaIue:LHU$B$;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v0, v1}, LLKmiA;->e8$mp_s$(Ljava/lang/Class;)LfèkèNDÙy;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iget-object v1, p0, Lw1I;->vaIue:LHU$B$;

    .line 18
    .line 19
    new-instance v5, LlKV_Cj$n_;

    .line 20
    .line 21
    invoke-direct {v5, p2}, LlKV_Cj$n_;-><init>(LOìJÒ6;)V

    .line 22
    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    move-object v2, p1

    .line 26
    invoke-interface/range {v0 .. v5}, LfèkèNDÙy;->DDù8(Ljava/lang/Object;[BIILlKV_Cj$n_;)V
    :try_end_0
    .catch LtbdÀ7Ì; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :catch_0
    move-exception v0

    .line 31
    move-object p1, v0

    .line 32
    goto :goto_0

    .line 33
    :catch_1
    move-exception v0

    .line 34
    move-object p1, v0

    .line 35
    goto :goto_1

    .line 36
    :goto_0
    new-instance p2, Ljava/lang/RuntimeException;

    .line 37
    .line 38
    const-string v0, "Reading from byte array should not throw IOException."

    .line 39
    .line 40
    invoke-direct {p2, v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 41
    .line 42
    .line 43
    throw p2

    .line 44
    :catch_2
    new-instance p1, LtbdÀ7Ì;

    .line 45
    .line 46
    const-string p2, "While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length."

    .line 47
    .line 48
    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    throw p1

    .line 52
    :goto_1
    throw p1
.end method

.method public final rz__9J_()LHU$B$;
    .locals 3

    .line 1
    iget-object v0, p0, Lw1I;->vaIue:LHU$B$;

    .line 2
    .line 3
    invoke-virtual {v0}, LHU$B$;->gKey4112()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Lw1I;->vaIue:LHU$B$;

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    iget-object v0, p0, Lw1I;->vaIue:LHU$B$;

    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    sget-object v1, LLKmiA;->rz__9J_:LLKmiA;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    invoke-virtual {v1, v2}, LLKmiA;->e8$mp_s$(Ljava/lang/Class;)LfèkèNDÙy;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    invoke-interface {v1, v0}, LfèkèNDÙy;->e8$mp_s$(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, LHU$B$;->vaIue()V

    .line 31
    .line 32
    .line 33
    iget-object v0, p0, Lw1I;->vaIue:LHU$B$;

    .line 34
    .line 35
    return-object v0
.end method

.method public final waiBKÀ()LHU$B$;
    .locals 2

    .line 1
    invoke-virtual {p0}, Lw1I;->rz__9J_()LHU$B$;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    invoke-static {v0, v1}, LHU$B$;->UC_n_(LHU$B$;Z)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    return-object v0

    .line 16
    :cond_0
    new-instance v0, LcoInt;

    .line 17
    .line 18
    invoke-direct {v0}, LcoInt;-><init>()V

    .line 19
    .line 20
    .line 21
    throw v0
.end method
