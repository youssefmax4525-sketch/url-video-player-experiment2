.class public final LBO;
.super LHU$B$;
.source "SourceFile"


# static fields
.field private static final zza:LBO;

.field private static volatile zzb:Lw00OID;


# instance fields
.field private zzc:I

.field private zzd:LWYÌ;

.field private zze:Ljava/lang/String;

.field private zzf:Ljava/lang/String;

.field private zzg:Ljava/lang/String;


# direct methods
.method public static synthetic $ÒcdS(LBO;Ljava/lang/String;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v0, p0, LBO;->zzc:I

    .line 5
    .line 6
    or-int/lit8 v0, v0, 0x1

    .line 7
    .line 8
    iput v0, p0, LBO;->zzc:I

    .line 9
    .line 10
    iput-object p1, p0, LBO;->zze:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method

.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LBO;

    .line 2
    .line 3
    invoke-direct {v0}, LBO;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LBO;->zza:LBO;

    .line 7
    .line 8
    const-class v1, LBO;

    .line 9
    .line 10
    invoke-static {v1, v0}, LHU$B$;->jPos3709(Ljava/lang/Class;LHU$B$;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LHU$B$;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, LIllil1;->kQy:LIllil1;

    .line 5
    .line 6
    iput-object v0, p0, LBO;->zzd:LWYÌ;

    .line 7
    .line 8
    const-string v0, ""

    .line 9
    .line 10
    iput-object v0, p0, LBO;->zze:Ljava/lang/String;

    .line 11
    .line 12
    iput-object v0, p0, LBO;->zzf:Ljava/lang/String;

    .line 13
    .line 14
    iput-object v0, p0, LBO;->zzg:Ljava/lang/String;

    .line 15
    .line 16
    return-void
.end method

.method public static Q1_f_(LBO;)V
    .locals 2

    .line 1
    iget-object v0, p0, LBO;->zzd:LWYÌ;

    .line 2
    .line 3
    move-object v1, v0

    .line 4
    check-cast v1, LF00;

    .line 5
    .line 6
    iget-boolean v1, v1, LF00;->yON3x:Z

    .line 7
    .line 8
    if-nez v1, :cond_0

    .line 9
    .line 10
    check-cast v0, LIllil1;

    .line 11
    .line 12
    iget v1, v0, LIllil1;->jPos3709:I

    .line 13
    .line 14
    add-int/2addr v1, v1

    .line 15
    invoke-virtual {v0, v1}, LIllil1;->POOl(I)LIllil1;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LBO;->zzd:LWYÌ;

    .line 20
    .line 21
    :cond_0
    iget-object p0, p0, LBO;->zzd:LWYÌ;

    .line 22
    .line 23
    const/4 v0, 0x2

    .line 24
    check-cast p0, LIllil1;

    .line 25
    .line 26
    invoke-virtual {p0, v0}, LIllil1;->JKEoÙX(I)V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public static kCount1402()LPO0I;
    .locals 1

    .line 1
    sget-object v0, LBO;->zza:LBO;

    .line 2
    .line 3
    invoke-virtual {v0}, LHU$B$;->sKey7917()Lw1I;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, LPO0I;

    .line 8
    .line 9
    return-object v0
.end method


# virtual methods
.method public final kO_6X_(ILHU$B$;)Ljava/lang/Object;
    .locals 6

    .line 1
    invoke-static {p1}, LBRK_m_;->UC_n_(I)I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    const/4 p2, 0x1

    .line 6
    if-eqz p1, :cond_7

    .line 7
    .line 8
    const/4 v0, 0x6

    .line 9
    const/4 v1, 0x5

    .line 10
    const/4 v2, 0x4

    .line 11
    const/4 v3, 0x3

    .line 12
    const/4 v4, 0x2

    .line 13
    if-eq p1, v4, :cond_6

    .line 14
    .line 15
    if-eq p1, v3, :cond_5

    .line 16
    .line 17
    if-eq p1, v2, :cond_4

    .line 18
    .line 19
    if-eq p1, v1, :cond_3

    .line 20
    .line 21
    if-ne p1, v0, :cond_2

    .line 22
    .line 23
    sget-object p1, LBO;->zzb:Lw00OID;

    .line 24
    .line 25
    if-nez p1, :cond_1

    .line 26
    .line 27
    const-class p2, LBO;

    .line 28
    .line 29
    monitor-enter p2

    .line 30
    :try_start_0
    sget-object p1, LBO;->zzb:Lw00OID;

    .line 31
    .line 32
    if-nez p1, :cond_0

    .line 33
    .line 34
    new-instance p1, LEsp;

    .line 35
    .line 36
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 37
    .line 38
    .line 39
    sput-object p1, LBO;->zzb:Lw00OID;

    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception p1

    .line 43
    goto :goto_1

    .line 44
    :cond_0
    :goto_0
    monitor-exit p2

    .line 45
    return-object p1

    .line 46
    :goto_1
    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 47
    throw p1

    .line 48
    :cond_1
    return-object p1

    .line 49
    :cond_2
    const/4 p1, 0x0

    .line 50
    throw p1

    .line 51
    :cond_3
    sget-object p1, LBO;->zza:LBO;

    .line 52
    .line 53
    return-object p1

    .line 54
    :cond_4
    new-instance p1, LPO0I;

    .line 55
    .line 56
    sget-object p2, LBO;->zza:LBO;

    .line 57
    .line 58
    invoke-direct {p1, p2}, Lw1I;-><init>(LHU$B$;)V

    .line 59
    .line 60
    .line 61
    return-object p1

    .line 62
    :cond_5
    new-instance p1, LBO;

    .line 63
    .line 64
    invoke-direct {p1}, LBO;-><init>()V

    .line 65
    .line 66
    .line 67
    return-object p1

    .line 68
    :cond_6
    new-array p1, v0, [Ljava/lang/Object;

    .line 69
    .line 70
    const-string v0, "zzc"

    .line 71
    .line 72
    const/4 v5, 0x0

    .line 73
    aput-object v0, p1, v5

    .line 74
    .line 75
    const-string v0, "zzd"

    .line 76
    .line 77
    aput-object v0, p1, p2

    .line 78
    .line 79
    sget-object p2, Lc0;->Qp_Hp$i_:Lc0;

    .line 80
    .line 81
    aput-object p2, p1, v4

    .line 82
    .line 83
    const-string p2, "zze"

    .line 84
    .line 85
    aput-object p2, p1, v3

    .line 86
    .line 87
    const-string p2, "zzf"

    .line 88
    .line 89
    aput-object p2, p1, v2

    .line 90
    .line 91
    const-string p2, "zzg"

    .line 92
    .line 93
    aput-object p2, p1, v1

    .line 94
    .line 95
    sget-object p2, LBO;->zza:LBO;

    .line 96
    .line 97
    const-string v0, "\u0001\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0001\u0000\u0001\u081e\u0002\u1008\u0000\u0003\u1008\u0001\u0004\u1008\u0002"

    .line 98
    .line 99
    new-instance v1, Lk1D;

    .line 100
    .line 101
    invoke-direct {v1, p2, v0, p1}, Lk1D;-><init>(Lp1l;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    return-object v1

    .line 105
    :cond_7
    invoke-static {p2}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    return-object p1
.end method
