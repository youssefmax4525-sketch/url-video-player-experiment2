.class public final LbCd;
.super LqNxòyyn;
.source "SourceFile"


# instance fields
.field public final jPos3709:Ljava/lang/Object;

.field public final synthetic vaIue:I


# direct methods
.method public constructor <init>(LSpyB;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LbCd;->vaIue:I

    .line 7
    iput-object p1, p0, LbCd;->jPos3709:Ljava/lang/Object;

    .line 8
    const-string p1, "com.google.android.gms.cast.framework.ISessionProvider"

    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, LqNxòyyn;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public constructor <init>(LVb$PX_Pk$;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, LbCd;->vaIue:I

    .line 9
    iput-object p1, p0, LbCd;->jPos3709:Ljava/lang/Object;

    .line 10
    const-string p1, "com.google.android.gms.cast.framework.media.internal.IFetchBitmapTaskProgressPublisher"

    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, LqNxòyyn;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public constructor <init>(LZQ;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LbCd;->vaIue:I

    .line 5
    iput-object p1, p0, LbCd;->jPos3709:Ljava/lang/Object;

    .line 6
    const-string p1, "com.google.android.gms.cast.framework.ISessionProxy"

    invoke-direct {p0, p1, v0}, LqNxòyyn;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public constructor <init>(LeU5$iU_h$;)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, LbCd;->vaIue:I

    .line 1
    iput-object p1, p0, LbCd;->jPos3709:Ljava/lang/Object;

    .line 2
    const-string p1, "com.google.android.gms.cast.framework.ICastConnectionController"

    const/4 v0, 0x1

    invoke-direct {p0, p1, v0}, LqNxòyyn;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public constructor <init>(LgIXQù;)V
    .locals 2

    const/4 v0, 0x0

    iput v0, p0, LbCd;->vaIue:I

    .line 3
    const-string v0, "com.google.android.gms.cast.framework.ICastStateListener"

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, LqNxòyyn;-><init>(Ljava/lang/String;I)V

    .line 4
    iput-object p1, p0, LbCd;->jPos3709:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final gKey1542(ILandroid/os/Parcel;Landroid/os/Parcel;)Z
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    move-object/from16 v3, p3

    .line 8
    .line 9
    iget v4, v0, LbCd;->vaIue:I

    .line 10
    .line 11
    const/4 v5, 0x4

    .line 12
    const/4 v6, 0x3

    .line 13
    const v7, 0xbdfcb8

    .line 14
    .line 15
    .line 16
    iget-object v8, v0, LbCd;->jPos3709:Ljava/lang/Object;

    .line 17
    .line 18
    const/4 v9, 0x2

    .line 19
    const/4 v10, 0x0

    .line 20
    const/4 v11, 0x1

    .line 21
    packed-switch v4, :pswitch_data_0

    .line 22
    .line 23
    .line 24
    check-cast v8, LeU5$iU_h$;

    .line 25
    .line 26
    if-eq v1, v11, :cond_6

    .line 27
    .line 28
    if-eq v1, v9, :cond_4

    .line 29
    .line 30
    if-eq v1, v6, :cond_2

    .line 31
    .line 32
    if-eq v1, v5, :cond_1

    .line 33
    .line 34
    const/4 v2, 0x5

    .line 35
    if-eq v1, v2, :cond_0

    .line 36
    .line 37
    goto/16 :goto_1

    .line 38
    .line 39
    :cond_0
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v3, v7}, Landroid/os/Parcel;->writeInt(I)V

    .line 43
    .line 44
    .line 45
    :goto_0
    const/4 v10, 0x1

    .line 46
    goto/16 :goto_1

    .line 47
    .line 48
    :cond_1
    invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 53
    .line 54
    .line 55
    invoke-static {v8, v1}, LeU5$iU_h$;->POOl(LeU5$iU_h$;I)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 59
    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 67
    .line 68
    .line 69
    iget-object v2, v8, LeU5$iU_h$;->yON3x:Lk0l;

    .line 70
    .line 71
    if-eqz v2, :cond_3

    .line 72
    .line 73
    iget v4, v2, Lk0l;->gSy_FG$D_:I

    .line 74
    .line 75
    if-ne v4, v6, :cond_3

    .line 76
    .line 77
    invoke-static {}, LIata;->waiBKÀ()LIata;

    .line 78
    .line 79
    .line 80
    move-result-object v4

    .line 81
    new-instance v5, LjSize1789;

    .line 82
    .line 83
    const/16 v6, 0x12

    .line 84
    .line 85
    invoke-direct {v5, v6, v2, v1}, LjSize1789;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 86
    .line 87
    .line 88
    iput-object v5, v4, LIata;->POOl:Ljava/lang/Object;

    .line 89
    .line 90
    const/16 v1, 0x20d9

    .line 91
    .line 92
    iput v1, v4, LIata;->waiBKÀ:I

    .line 93
    .line 94
    invoke-virtual {v4}, LIata;->e8$mp_s$()LIata;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    invoke-virtual {v2, v11, v1}, LC4t_Zg$W_;->POOl(ILIata;)LGIlO;

    .line 99
    .line 100
    .line 101
    :cond_3
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 102
    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_4
    invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    sget-object v4, LHU$s$;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 110
    .line 111
    invoke-static {v2, v4}, LWoaOàtYj;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 112
    .line 113
    .line 114
    move-result-object v4

    .line 115
    check-cast v4, LHU$s$;

    .line 116
    .line 117
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 118
    .line 119
    .line 120
    iget-object v2, v8, LeU5$iU_h$;->yON3x:Lk0l;

    .line 121
    .line 122
    if-eqz v2, :cond_5

    .line 123
    .line 124
    iget v5, v2, Lk0l;->gSy_FG$D_:I

    .line 125
    .line 126
    if-ne v5, v6, :cond_5

    .line 127
    .line 128
    invoke-static {}, LIata;->waiBKÀ()LIata;

    .line 129
    .line 130
    .line 131
    move-result-object v5

    .line 132
    new-instance v6, LMl;

    .line 133
    .line 134
    const/16 v7, 0xe

    .line 135
    .line 136
    invoke-direct {v6, v2, v1, v4, v7}, LMl;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 137
    .line 138
    .line 139
    iput-object v6, v5, LIata;->POOl:Ljava/lang/Object;

    .line 140
    .line 141
    const/16 v1, 0x20d6

    .line 142
    .line 143
    iput v1, v5, LIata;->waiBKÀ:I

    .line 144
    .line 145
    invoke-virtual {v5}, LIata;->e8$mp_s$()LIata;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    invoke-virtual {v2, v11, v1}, LC4t_Zg$W_;->POOl(ILIata;)LGIlO;

    .line 150
    .line 151
    .line 152
    move-result-object v1

    .line 153
    new-instance v2, LkGd_Gk_;

    .line 154
    .line 155
    const/16 v4, 0x11

    .line 156
    .line 157
    invoke-direct {v2, v4, v0}, LkGd_Gk_;-><init>(ILjava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v1, v2}, LGIlO;->e8$mp_s$(LmOffset752;)V

    .line 161
    .line 162
    .line 163
    :cond_5
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 164
    .line 165
    .line 166
    goto :goto_0

    .line 167
    :cond_6
    invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 168
    .line 169
    .line 170
    move-result-object v1

    .line 171
    invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object v4

    .line 175
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 176
    .line 177
    .line 178
    iget-object v2, v8, LeU5$iU_h$;->yON3x:Lk0l;

    .line 179
    .line 180
    if-eqz v2, :cond_7

    .line 181
    .line 182
    iget v5, v2, Lk0l;->gSy_FG$D_:I

    .line 183
    .line 184
    if-ne v5, v6, :cond_7

    .line 185
    .line 186
    invoke-static {}, LIata;->waiBKÀ()LIata;

    .line 187
    .line 188
    .line 189
    move-result-object v5

    .line 190
    new-instance v6, LsIndex9566;

    .line 191
    .line 192
    const/16 v7, 0xf

    .line 193
    .line 194
    invoke-direct {v6, v2, v1, v4, v7}, LsIndex9566;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 195
    .line 196
    .line 197
    iput-object v6, v5, LIata;->POOl:Ljava/lang/Object;

    .line 198
    .line 199
    const/16 v1, 0x20d7

    .line 200
    .line 201
    iput v1, v5, LIata;->waiBKÀ:I

    .line 202
    .line 203
    invoke-virtual {v5}, LIata;->e8$mp_s$()LIata;

    .line 204
    .line 205
    .line 206
    move-result-object v1

    .line 207
    invoke-virtual {v2, v11, v1}, LC4t_Zg$W_;->POOl(ILIata;)LGIlO;

    .line 208
    .line 209
    .line 210
    move-result-object v1

    .line 211
    new-instance v2, LindQx;

    .line 212
    .line 213
    const/16 v4, 0xb

    .line 214
    .line 215
    invoke-direct {v2, v4, v0}, LindQx;-><init>(ILjava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v1, v2}, LGIlO;->e8$mp_s$(LmOffset752;)V

    .line 219
    .line 220
    .line 221
    :cond_7
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 222
    .line 223
    .line 224
    goto/16 :goto_0

    .line 225
    .line 226
    :goto_1
    return v10

    .line 227
    :pswitch_0
    if-eq v1, v11, :cond_9

    .line 228
    .line 229
    if-eq v1, v9, :cond_8

    .line 230
    .line 231
    goto :goto_3

    .line 232
    :cond_8
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v3, v7}, Landroid/os/Parcel;->writeInt(I)V

    .line 236
    .line 237
    .line 238
    :goto_2
    const/4 v10, 0x1

    .line 239
    goto :goto_3

    .line 240
    :cond_9
    invoke-virtual {v2}, Landroid/os/Parcel;->readLong()J

    .line 241
    .line 242
    .line 243
    move-result-wide v4

    .line 244
    invoke-virtual {v2}, Landroid/os/Parcel;->readLong()J

    .line 245
    .line 246
    .line 247
    move-result-wide v6

    .line 248
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 249
    .line 250
    .line 251
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 252
    .line 253
    .line 254
    move-result-object v1

    .line 255
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 256
    .line 257
    .line 258
    move-result-object v2

    .line 259
    new-array v4, v9, [Ljava/lang/Long;

    .line 260
    .line 261
    aput-object v1, v4, v10

    .line 262
    .line 263
    aput-object v2, v4, v11

    .line 264
    .line 265
    check-cast v8, LVb$PX_Pk$;

    .line 266
    .line 267
    invoke-static {v8, v4}, LVb$PX_Pk$;->e8$mp_s$(LVb$PX_Pk$;[Ljava/lang/Object;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 271
    .line 272
    .line 273
    goto :goto_2

    .line 274
    :goto_3
    return v10

    .line 275
    :pswitch_1
    check-cast v8, LSpyB;

    .line 276
    .line 277
    iget-object v4, v8, LSpyB;->POOl:LGtVP;

    .line 278
    .line 279
    if-eq v1, v11, :cond_d

    .line 280
    .line 281
    if-eq v1, v9, :cond_c

    .line 282
    .line 283
    if-eq v1, v6, :cond_b

    .line 284
    .line 285
    if-eq v1, v5, :cond_a

    .line 286
    .line 287
    goto :goto_5

    .line 288
    :cond_a
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v3, v7}, Landroid/os/Parcel;->writeInt(I)V

    .line 292
    .line 293
    .line 294
    :goto_4
    const/4 v10, 0x1

    .line 295
    goto :goto_5

    .line 296
    :cond_b
    iget-object v1, v8, LSpyB;->waiBKÀ:Ljava/lang/String;

    .line 297
    .line 298
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 299
    .line 300
    .line 301
    invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 302
    .line 303
    .line 304
    goto :goto_4

    .line 305
    :cond_c
    iget-boolean v1, v4, LGtVP;->kQy:Z

    .line 306
    .line 307
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 308
    .line 309
    .line 310
    sget v2, LWoaOàtYj;->e8$mp_s$:I

    .line 311
    .line 312
    invoke-virtual {v3, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 313
    .line 314
    .line 315
    goto :goto_4

    .line 316
    :cond_d
    invoke-virtual {v2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v15

    .line 320
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 321
    .line 322
    .line 323
    new-instance v12, LeU5$iU_h$;

    .line 324
    .line 325
    iget-object v13, v8, LSpyB;->e8$mp_s$:Landroid/content/Context;

    .line 326
    .line 327
    iget-object v14, v8, LSpyB;->waiBKÀ:Ljava/lang/String;

    .line 328
    .line 329
    new-instance v1, LAD_x$n2_;

    .line 330
    .line 331
    iget-object v2, v8, LSpyB;->e8$mp_s$:Landroid/content/Context;

    .line 332
    .line 333
    iget-object v5, v8, LSpyB;->JKEoÙX:LsqùAA;

    .line 334
    .line 335
    invoke-direct {v1, v2, v4, v5}, LAD_x$n2_;-><init>(Landroid/content/Context;LGtVP;LsqùAA;)V

    .line 336
    .line 337
    .line 338
    move-object/from16 v18, v1

    .line 339
    .line 340
    move-object/from16 v16, v4

    .line 341
    .line 342
    move-object/from16 v17, v5

    .line 343
    .line 344
    invoke-direct/range {v12 .. v18}, LeU5$iU_h$;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;LGtVP;LsqùAA;LAD_x$n2_;)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {v12}, LZQ;->rz__9J_()LKàaq;

    .line 348
    .line 349
    .line 350
    move-result-object v1

    .line 351
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 352
    .line 353
    .line 354
    invoke-static {v3, v1}, LWoaOàtYj;->POOl(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 355
    .line 356
    .line 357
    goto :goto_4

    .line 358
    :goto_5
    return v10

    .line 359
    :pswitch_2
    check-cast v8, LZQ;

    .line 360
    .line 361
    packed-switch v1, :pswitch_data_1

    .line 362
    .line 363
    .line 364
    goto/16 :goto_d

    .line 365
    .line 366
    :pswitch_3
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 367
    .line 368
    invoke-static {v2, v1}, LWoaOàtYj;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 369
    .line 370
    .line 371
    move-result-object v1

    .line 372
    check-cast v1, Landroid/os/Bundle;

    .line 373
    .line 374
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 375
    .line 376
    .line 377
    check-cast v8, LeU5$iU_h$;

    .line 378
    .line 379
    invoke-static {v1}, Lcom/google/android/gms/cast/CastDevice;->POOl(Landroid/os/Bundle;)Lcom/google/android/gms/cast/CastDevice;

    .line 380
    .line 381
    .line 382
    move-result-object v1

    .line 383
    if-eqz v1, :cond_13

    .line 384
    .line 385
    iget-object v2, v1, Lcom/google/android/gms/cast/CastDevice;->iOffset934:Ljava/lang/String;

    .line 386
    .line 387
    iget-object v4, v8, LeU5$iU_h$;->jPos3709:Lcom/google/android/gms/cast/CastDevice;

    .line 388
    .line 389
    invoke-virtual {v1, v4}, Lcom/google/android/gms/cast/CastDevice;->equals(Ljava/lang/Object;)Z

    .line 390
    .line 391
    .line 392
    move-result v4

    .line 393
    if-nez v4, :cond_13

    .line 394
    .line 395
    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 396
    .line 397
    .line 398
    move-result v4

    .line 399
    if-nez v4, :cond_f

    .line 400
    .line 401
    iget-object v4, v8, LeU5$iU_h$;->jPos3709:Lcom/google/android/gms/cast/CastDevice;

    .line 402
    .line 403
    if-eqz v4, :cond_e

    .line 404
    .line 405
    iget-object v4, v4, Lcom/google/android/gms/cast/CastDevice;->iOffset934:Ljava/lang/String;

    .line 406
    .line 407
    invoke-static {v4, v2}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 408
    .line 409
    .line 410
    move-result v2

    .line 411
    if-nez v2, :cond_f

    .line 412
    .line 413
    :cond_e
    const/4 v2, 0x1

    .line 414
    goto :goto_6

    .line 415
    :cond_f
    const/4 v2, 0x0

    .line 416
    :goto_6
    iput-object v1, v8, LeU5$iU_h$;->jPos3709:Lcom/google/android/gms/cast/CastDevice;

    .line 417
    .line 418
    sget-object v4, LeU5$iU_h$;->kQy:LhiB_7$0y_;

    .line 419
    .line 420
    if-eq v11, v2, :cond_10

    .line 421
    .line 422
    const-string v5, "unchanged"

    .line 423
    .line 424
    goto :goto_7

    .line 425
    :cond_10
    const-string v5, "changed"

    .line 426
    .line 427
    :goto_7
    new-array v6, v9, [Ljava/lang/Object;

    .line 428
    .line 429
    aput-object v1, v6, v10

    .line 430
    .line 431
    aput-object v5, v6, v11

    .line 432
    .line 433
    const-string v1, "update to device (%s) with name %s"

    .line 434
    .line 435
    invoke-virtual {v4, v1, v6}, LhiB_7$0y_;->e8$mp_s$(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    if-eqz v2, :cond_13

    .line 439
    .line 440
    iget-object v1, v8, LeU5$iU_h$;->jPos3709:Lcom/google/android/gms/cast/CastDevice;

    .line 441
    .line 442
    if-eqz v1, :cond_13

    .line 443
    .line 444
    iget-object v2, v8, LeU5$iU_h$;->DDù8:LAD_x$n2_;

    .line 445
    .line 446
    if-eqz v2, :cond_11

    .line 447
    .line 448
    sget-object v4, LAD_x$n2_;->UC_n_:LhiB_7$0y_;

    .line 449
    .line 450
    new-array v5, v11, [Ljava/lang/Object;

    .line 451
    .line 452
    aput-object v1, v5, v10

    .line 453
    .line 454
    const-string v6, "update Cast device to %s"

    .line 455
    .line 456
    invoke-virtual {v4, v6, v5}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 457
    .line 458
    .line 459
    iput-object v1, v2, LAD_x$n2_;->valuI:Lcom/google/android/gms/cast/CastDevice;

    .line 460
    .line 461
    invoke-virtual {v2}, LAD_x$n2_;->rz__9J_()V

    .line 462
    .line 463
    .line 464
    :cond_11
    iget-object v1, v8, LeU5$iU_h$;->POOl:Ljava/util/HashSet;

    .line 465
    .line 466
    new-instance v2, Ljava/util/HashSet;

    .line 467
    .line 468
    invoke-direct {v2, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v2}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 472
    .line 473
    .line 474
    move-result-object v1

    .line 475
    :goto_8
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 476
    .line 477
    .line 478
    move-result v2

    .line 479
    if-eqz v2, :cond_12

    .line 480
    .line 481
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v2

    .line 485
    check-cast v2, LQG$A_lg$;

    .line 486
    .line 487
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 488
    .line 489
    .line 490
    goto :goto_8

    .line 491
    :cond_12
    iget-object v1, v8, LeU5$iU_h$;->iOffset934:Lah_1k$4v_;

    .line 492
    .line 493
    if-eqz v1, :cond_13

    .line 494
    .line 495
    iget-object v1, v1, Lah_1k$4v_;->vaIue:Ljava/lang/Object;

    .line 496
    .line 497
    check-cast v1, LKkmORP;

    .line 498
    .line 499
    invoke-virtual {v1}, LKkmORP;->yPN$A_n$()Lvòk;

    .line 500
    .line 501
    .line 502
    move-result-object v1

    .line 503
    iget v2, v1, Lvòk;->Qp_Hp$i_:I

    .line 504
    .line 505
    add-int/2addr v2, v11

    .line 506
    iput v2, v1, Lvòk;->Qp_Hp$i_:I

    .line 507
    .line 508
    :cond_13
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 509
    .line 510
    .line 511
    :goto_9
    const/4 v10, 0x1

    .line 512
    goto/16 :goto_d

    .line 513
    .line 514
    :pswitch_4
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 515
    .line 516
    invoke-static {v2, v1}, LWoaOàtYj;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 517
    .line 518
    .line 519
    move-result-object v1

    .line 520
    check-cast v1, Landroid/os/Bundle;

    .line 521
    .line 522
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 523
    .line 524
    .line 525
    check-cast v8, LeU5$iU_h$;

    .line 526
    .line 527
    invoke-static {v1}, Lcom/google/android/gms/cast/CastDevice;->POOl(Landroid/os/Bundle;)Lcom/google/android/gms/cast/CastDevice;

    .line 528
    .line 529
    .line 530
    move-result-object v1

    .line 531
    iput-object v1, v8, LeU5$iU_h$;->jPos3709:Lcom/google/android/gms/cast/CastDevice;

    .line 532
    .line 533
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 534
    .line 535
    .line 536
    goto :goto_9

    .line 537
    :pswitch_5
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 538
    .line 539
    invoke-static {v2, v1}, LWoaOàtYj;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 540
    .line 541
    .line 542
    move-result-object v1

    .line 543
    check-cast v1, Landroid/os/Bundle;

    .line 544
    .line 545
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 546
    .line 547
    .line 548
    check-cast v8, LeU5$iU_h$;

    .line 549
    .line 550
    invoke-static {v1}, Lcom/google/android/gms/cast/CastDevice;->POOl(Landroid/os/Bundle;)Lcom/google/android/gms/cast/CastDevice;

    .line 551
    .line 552
    .line 553
    move-result-object v1

    .line 554
    iput-object v1, v8, LeU5$iU_h$;->jPos3709:Lcom/google/android/gms/cast/CastDevice;

    .line 555
    .line 556
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 557
    .line 558
    .line 559
    goto :goto_9

    .line 560
    :pswitch_6
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 561
    .line 562
    .line 563
    invoke-virtual {v3, v7}, Landroid/os/Parcel;->writeInt(I)V

    .line 564
    .line 565
    .line 566
    goto :goto_9

    .line 567
    :pswitch_7
    check-cast v8, LeU5$iU_h$;

    .line 568
    .line 569
    const-string v1, "Must be called from the main thread."

    .line 570
    .line 571
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 572
    .line 573
    .line 574
    iget-object v1, v8, LeU5$iU_h$;->vaIue:Lol01D;

    .line 575
    .line 576
    if-nez v1, :cond_14

    .line 577
    .line 578
    const-wide/16 v1, 0x0

    .line 579
    .line 580
    goto :goto_a

    .line 581
    :cond_14
    invoke-virtual {v1}, Lol01D;->tmpData3485()J

    .line 582
    .line 583
    .line 584
    move-result-wide v1

    .line 585
    iget-object v4, v8, LeU5$iU_h$;->vaIue:Lol01D;

    .line 586
    .line 587
    invoke-virtual {v4}, Lol01D;->e8$mp_s$()J

    .line 588
    .line 589
    .line 590
    move-result-wide v4

    .line 591
    sub-long/2addr v1, v4

    .line 592
    :goto_a
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 593
    .line 594
    .line 595
    invoke-virtual {v3, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    .line 596
    .line 597
    .line 598
    goto :goto_9

    .line 599
    :pswitch_8
    sget v1, LWoaOàtYj;->e8$mp_s$:I

    .line 600
    .line 601
    invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I

    .line 602
    .line 603
    .line 604
    move-result v1

    .line 605
    if-eqz v1, :cond_15

    .line 606
    .line 607
    const/4 v1, 0x1

    .line 608
    goto :goto_b

    .line 609
    :cond_15
    const/4 v1, 0x0

    .line 610
    :goto_b
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 611
    .line 612
    .line 613
    check-cast v8, LeU5$iU_h$;

    .line 614
    .line 615
    iget-object v2, v8, LeU5$iU_h$;->JKEoÙX:LvValue4114;

    .line 616
    .line 617
    if-eqz v2, :cond_16

    .line 618
    .line 619
    :try_start_0
    check-cast v2, LMÒJ;

    .line 620
    .line 621
    invoke-virtual {v2}, LrEÈQD;->gc_$M_w2$()Landroid/os/Parcel;

    .line 622
    .line 623
    .line 624
    move-result-object v4

    .line 625
    invoke-virtual {v4, v1}, Landroid/os/Parcel;->writeInt(I)V

    .line 626
    .line 627
    .line 628
    invoke-virtual {v4, v10}, Landroid/os/Parcel;->writeInt(I)V

    .line 629
    .line 630
    .line 631
    const/4 v1, 0x6

    .line 632
    invoke-virtual {v2, v4, v1}, LrEÈQD;->gKey1542(Landroid/os/Parcel;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 633
    .line 634
    .line 635
    goto :goto_c

    .line 636
    :catch_0
    sget-object v1, LeU5$iU_h$;->kQy:LhiB_7$0y_;

    .line 637
    .line 638
    const-class v2, LvValue4114;

    .line 639
    .line 640
    invoke-virtual {v2}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 641
    .line 642
    .line 643
    move-result-object v2

    .line 644
    new-array v4, v9, [Ljava/lang/Object;

    .line 645
    .line 646
    const-string v5, "disconnectFromDevice"

    .line 647
    .line 648
    aput-object v5, v4, v10

    .line 649
    .line 650
    aput-object v2, v4, v11

    .line 651
    .line 652
    const-string v2, "Unable to call %s on %s."

    .line 653
    .line 654
    invoke-virtual {v1, v2, v4}, LhiB_7$0y_;->waiBKÀ(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 655
    .line 656
    .line 657
    :goto_c
    invoke-virtual {v8, v10}, LZQ;->e8$mp_s$(I)V

    .line 658
    .line 659
    .line 660
    :cond_16
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 661
    .line 662
    .line 663
    goto/16 :goto_9

    .line 664
    .line 665
    :pswitch_9
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 666
    .line 667
    invoke-static {v2, v1}, LWoaOàtYj;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 668
    .line 669
    .line 670
    move-result-object v1

    .line 671
    check-cast v1, Landroid/os/Bundle;

    .line 672
    .line 673
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 674
    .line 675
    .line 676
    check-cast v8, LeU5$iU_h$;

    .line 677
    .line 678
    invoke-virtual {v8, v1}, LeU5$iU_h$;->tmpData3485(Landroid/os/Bundle;)V

    .line 679
    .line 680
    .line 681
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 682
    .line 683
    .line 684
    goto/16 :goto_9

    .line 685
    .line 686
    :pswitch_a
    sget-object v1, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 687
    .line 688
    invoke-static {v2, v1}, LWoaOàtYj;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 689
    .line 690
    .line 691
    move-result-object v1

    .line 692
    check-cast v1, Landroid/os/Bundle;

    .line 693
    .line 694
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 695
    .line 696
    .line 697
    check-cast v8, LeU5$iU_h$;

    .line 698
    .line 699
    invoke-virtual {v8, v1}, LeU5$iU_h$;->tmpData3485(Landroid/os/Bundle;)V

    .line 700
    .line 701
    .line 702
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 703
    .line 704
    .line 705
    goto/16 :goto_9

    .line 706
    .line 707
    :pswitch_b
    new-instance v1, Lfdo_n_;

    .line 708
    .line 709
    invoke-direct {v1, v8}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 710
    .line 711
    .line 712
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 713
    .line 714
    .line 715
    invoke-static {v3, v1}, LWoaOàtYj;->POOl(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 716
    .line 717
    .line 718
    goto/16 :goto_9

    .line 719
    .line 720
    :goto_d
    return v10

    .line 721
    :pswitch_c
    check-cast v8, LgIXQù;

    .line 722
    .line 723
    if-eq v1, v11, :cond_19

    .line 724
    .line 725
    if-eq v1, v9, :cond_18

    .line 726
    .line 727
    if-eq v1, v6, :cond_17

    .line 728
    .line 729
    goto :goto_f

    .line 730
    :cond_17
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 731
    .line 732
    .line 733
    invoke-virtual {v3, v7}, Landroid/os/Parcel;->writeInt(I)V

    .line 734
    .line 735
    .line 736
    :goto_e
    const/4 v10, 0x1

    .line 737
    goto :goto_f

    .line 738
    :cond_18
    invoke-virtual {v2}, Landroid/os/Parcel;->readInt()I

    .line 739
    .line 740
    .line 741
    move-result v1

    .line 742
    invoke-static {v2}, LWoaOàtYj;->waiBKÀ(Landroid/os/Parcel;)V

    .line 743
    .line 744
    .line 745
    invoke-interface {v8, v1}, LgIXQù;->rz__9J_(I)V

    .line 746
    .line 747
    .line 748
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 749
    .line 750
    .line 751
    goto :goto_e

    .line 752
    :cond_19
    new-instance v1, Lfdo_n_;

    .line 753
    .line 754
    invoke-direct {v1, v8}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 755
    .line 756
    .line 757
    invoke-virtual {v3}, Landroid/os/Parcel;->writeNoException()V

    .line 758
    .line 759
    .line 760
    invoke-static {v3, v1}, LWoaOàtYj;->POOl(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 761
    .line 762
    .line 763
    goto :goto_e

    .line 764
    :goto_f
    return v10

    .line 765
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_c
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 766
    .line 767
    .line 768
    .line 769
    .line 770
    .line 771
    .line 772
    .line 773
    .line 774
    .line 775
    .line 776
    .line 777
    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch
.end method
