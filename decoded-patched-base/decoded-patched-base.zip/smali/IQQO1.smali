.class public interface abstract LIQQO1;
.super Ljava/lang/Object;
.source "SourceFile"
