.class public final Ltd$G_Zs$;
.super LtmpKey7471;
.source "SourceFile"


# instance fields
.field public JKEoÙX:I

.field public tmpData3485:I


# direct methods
.method public constructor <init>(II)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, LtmpKey7471;-><init>(II)V

    .line 2
    .line 3
    .line 4
    const/4 p1, -0x1

    .line 5
    iput p1, p0, Ltd$G_Zs$;->JKEoÙX:I

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    iput p1, p0, Ltd$G_Zs$;->tmpData3485:I

    .line 9
    .line 10
    return-void
.end method
