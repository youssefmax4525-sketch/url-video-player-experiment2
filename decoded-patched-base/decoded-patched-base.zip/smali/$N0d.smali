.class public final L$N0d;
.super LkValue3873;
.source "SourceFile"


# instance fields
.field public final synthetic Ialue:Ljava/lang/Object;

.field public final synthetic kQy:I

.field public final synthetic valuI:LY01l;


# direct methods
.method public synthetic constructor <init>(LY01l;Landroid/os/Bundle;I)V
    .locals 0

    .line 1
    iput p3, p0, L$N0d;->kQy:I

    iput-object p1, p0, L$N0d;->valuI:LY01l;

    iput-object p2, p0, L$N0d;->Ialue:Ljava/lang/Object;

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, LkValue3873;-><init>(LY01l;Z)V

    return-void
.end method

.method public constructor <init>(LY01l;Ljava/lang/Exception;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, L$N0d;->kQy:I

    .line 2
    iput-object p1, p0, L$N0d;->valuI:LY01l;

    iput-object p2, p0, L$N0d;->Ialue:Ljava/lang/Object;

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, LkValue3873;-><init>(LY01l;Z)V

    return-void
.end method


# virtual methods
.method public final e8$mp_s$()V
    .locals 6

    .line 1
    iget v0, p0, L$N0d;->kQy:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, L$N0d;->valuI:LY01l;

    .line 7
    .line 8
    iget-object v0, v0, LY01l;->DDù8:LOIQOll;

    .line 9
    .line 10
    invoke-static {v0}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, L$N0d;->Ialue:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v1, Ljava/lang/Exception;

    .line 16
    .line 17
    new-instance v2, Lfdo_n_;

    .line 18
    .line 19
    invoke-direct {v2, v1}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 20
    .line 21
    .line 22
    new-instance v1, Lfdo_n_;

    .line 23
    .line 24
    const/4 v3, 0x0

    .line 25
    invoke-direct {v1, v3}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    new-instance v4, Lfdo_n_;

    .line 29
    .line 30
    invoke-direct {v4, v3}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    check-cast v0, LjItem6265;

    .line 34
    .line 35
    invoke-virtual {v0}, LjItem6265;->iSize4906()Landroid/os/Parcel;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    const/4 v5, 0x5

    .line 40
    invoke-virtual {v3, v5}, Landroid/os/Parcel;->writeInt(I)V

    .line 41
    .line 42
    .line 43
    const-string v5, "Error with data collection. Data lost."

    .line 44
    .line 45
    invoke-virtual {v3, v5}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-static {v3, v2}, LsOze;->waiBKÀ(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 49
    .line 50
    .line 51
    invoke-static {v3, v1}, LsOze;->waiBKÀ(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 52
    .line 53
    .line 54
    invoke-static {v3, v4}, LsOze;->waiBKÀ(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 55
    .line 56
    .line 57
    const/16 v1, 0x21

    .line 58
    .line 59
    invoke-virtual {v0, v3, v1}, LjItem6265;->gc_$M_w2$(Landroid/os/Parcel;I)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :pswitch_0
    iget-object v0, p0, L$N0d;->valuI:LY01l;

    .line 64
    .line 65
    iget-object v0, v0, LY01l;->DDù8:LOIQOll;

    .line 66
    .line 67
    invoke-static {v0}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iget-object v1, p0, L$N0d;->Ialue:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v1, Landroid/os/Bundle;

    .line 73
    .line 74
    iget-wide v2, p0, LkValue3873;->yON3x:J

    .line 75
    .line 76
    check-cast v0, LjItem6265;

    .line 77
    .line 78
    invoke-virtual {v0}, LjItem6265;->iSize4906()Landroid/os/Parcel;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    invoke-static {v4, v1}, LsOze;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {v4, v2, v3}, Landroid/os/Parcel;->writeLong(J)V

    .line 86
    .line 87
    .line 88
    const/16 v1, 0x2c

    .line 89
    .line 90
    invoke-virtual {v0, v4, v1}, LjItem6265;->gc_$M_w2$(Landroid/os/Parcel;I)V

    .line 91
    .line 92
    .line 93
    return-void

    .line 94
    :pswitch_1
    iget-object v0, p0, L$N0d;->valuI:LY01l;

    .line 95
    .line 96
    iget-object v0, v0, LY01l;->DDù8:LOIQOll;

    .line 97
    .line 98
    invoke-static {v0}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 99
    .line 100
    .line 101
    iget-object v1, p0, L$N0d;->Ialue:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v1, Landroid/os/Bundle;

    .line 104
    .line 105
    iget-wide v2, p0, LkValue3873;->yON3x:J

    .line 106
    .line 107
    check-cast v0, LjItem6265;

    .line 108
    .line 109
    invoke-virtual {v0}, LjItem6265;->iSize4906()Landroid/os/Parcel;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    invoke-static {v4, v1}, LsOze;->e8$mp_s$(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    .line 114
    .line 115
    .line 116
    invoke-virtual {v4, v2, v3}, Landroid/os/Parcel;->writeLong(J)V

    .line 117
    .line 118
    .line 119
    const/16 v1, 0x8

    .line 120
    .line 121
    invoke-virtual {v0, v4, v1}, LjItem6265;->gc_$M_w2$(Landroid/os/Parcel;I)V

    .line 122
    .line 123
    .line 124
    return-void

    .line 125
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
