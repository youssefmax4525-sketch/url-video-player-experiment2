.class public final LsizO;
.super LzPàWiY;
.source "SourceFile"


# static fields
.field public static final synthetic WoI_9_:I


# instance fields
.field public $ÒcdS:Z

.field public BCIm:Landroid/widget/Button;

.field public ChI_KH_:Ljava/lang/String;

.field public final Ialue:LILA_l$V_;

.field public Iii:Z

.field public final K0I:Ljava/util/ArrayList;

.field public K11ID:I

.field public Oey:Ljava/util/HashMap;

.field public Q1_f_:J

.field public final Qp_Hp$i_:Ljava/util/ArrayList;

.field public RD:Landroid/support/v4/media/MediaDescriptionCompat;

.field public Txy$$d_w$:Landroid/widget/TextView;

.field public final UC_n_:Landroid/content/Context;

.field public YOD0:Landroid/net/Uri;

.field public dnN$d$:Landroid/graphics/Bitmap;

.field public gCount1961:LBqOjcA;

.field public final gKey4112:Ljava/util/ArrayList;

.field public gSy_FG$D_:Landroid/view/View;

.field public gc_$M_w2$:Z

.field public iQ0D:Landroid/graphics/Bitmap;

.field public iSize4906:Landroid/widget/ImageView;

.field public final k1y:LIiliIi;

.field public kCount1402:Z

.field public final kO_6X_:Ljava/util/ArrayList;

.field public l1:Z

.field public ll:LIsÒEz;

.field public oaX_6_:Landroid/widget/ImageButton;

.field public oy_R$Xx_:Ljava/util/HashMap;

.field public pCXDYg:LvKey5061;

.field public pQ1Il:Z

.field public final pZDcLvd:Z

.field public sKey6064:Landroidx/recyclerview/widget/RecyclerView;

.field public final tmpSize211:LT3K$G_7$;

.field public tzKù7Ol1:LlllIi;

.field public valu0:LT1QD;

.field public final valuI:LynBMMg;

.field public vz$a$:Landroid/widget/TextView;

.field public yPN$A_n$:LRo_Zk$ML_;

.field public yàÒZ:LRo_Zk$ML_;

.field public zAt$p:Landroid/widget/ImageView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-static {p1, v0}, LQÙcmZà;->e8$mp_s$(Landroid/content/Context;Z)Landroid/view/ContextThemeWrapper;

    .line 3
    .line 4
    .line 5
    move-result-object p1

    .line 6
    sget v0, LOndex;->mediaRouteTheme:I

    .line 7
    .line 8
    invoke-static {p1, v0}, LQÙcmZà;->sKey7917(Landroid/content/Context;I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_0

    .line 13
    .line 14
    invoke-static {p1}, LQÙcmZà;->JKEoÙX(Landroid/content/Context;)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    :cond_0
    invoke-direct {p0, p1, v0}, LzPàWiY;-><init>(Landroid/view/ContextThemeWrapper;I)V

    .line 19
    .line 20
    .line 21
    sget-object p1, LvKey5061;->rz__9J_:LvKey5061;

    .line 22
    .line 23
    iput-object p1, p0, LsizO;->pCXDYg:LvKey5061;

    .line 24
    .line 25
    new-instance p1, Ljava/util/ArrayList;

    .line 26
    .line 27
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 28
    .line 29
    .line 30
    iput-object p1, p0, LsizO;->gKey4112:Ljava/util/ArrayList;

    .line 31
    .line 32
    new-instance p1, Ljava/util/ArrayList;

    .line 33
    .line 34
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, LsizO;->kO_6X_:Ljava/util/ArrayList;

    .line 38
    .line 39
    new-instance p1, Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    iput-object p1, p0, LsizO;->K0I:Ljava/util/ArrayList;

    .line 45
    .line 46
    new-instance p1, Ljava/util/ArrayList;

    .line 47
    .line 48
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 49
    .line 50
    .line 51
    iput-object p1, p0, LsizO;->Qp_Hp$i_:Ljava/util/ArrayList;

    .line 52
    .line 53
    new-instance p1, LT3K$G_7$;

    .line 54
    .line 55
    const/4 v0, 0x3

    .line 56
    invoke-direct {p1, v0, p0}, LT3K$G_7$;-><init>(ILjava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    iput-object p1, p0, LsizO;->tmpSize211:LT3K$G_7$;

    .line 60
    .line 61
    invoke-virtual {p0}, Landroid/app/Dialog;->getContext()Landroid/content/Context;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    iput-object p1, p0, LsizO;->UC_n_:Landroid/content/Context;

    .line 66
    .line 67
    invoke-static {p1}, LILA_l$V_;->POOl(Landroid/content/Context;)LILA_l$V_;

    .line 68
    .line 69
    .line 70
    move-result-object p1

    .line 71
    iput-object p1, p0, LsizO;->Ialue:LILA_l$V_;

    .line 72
    .line 73
    invoke-static {}, LILA_l$V_;->sKey7917()Z

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    iput-boolean p1, p0, LsizO;->pZDcLvd:Z

    .line 78
    .line 79
    new-instance p1, LynBMMg;

    .line 80
    .line 81
    const/4 v0, 0x4

    .line 82
    invoke-direct {p1, p0, v0}, LynBMMg;-><init>(Landroid/view/KeyEvent$Callback;I)V

    .line 83
    .line 84
    .line 85
    iput-object p1, p0, LsizO;->valuI:LynBMMg;

    .line 86
    .line 87
    invoke-static {}, LILA_l$V_;->tmpData3485()LRo_Zk$ML_;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    iput-object p1, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 92
    .line 93
    new-instance p1, LIiliIi;

    .line 94
    .line 95
    const/4 v0, 0x1

    .line 96
    invoke-direct {p1, p0, v0}, LIiliIi;-><init>(LzPàWiY;I)V

    .line 97
    .line 98
    .line 99
    iput-object p1, p0, LsizO;->k1y:LIiliIi;

    .line 100
    .line 101
    invoke-static {}, LILA_l$V_;->JKEoÙX()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-virtual {p0, p1}, LsizO;->yON3x(Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 106
    .line 107
    .line 108
    return-void
.end method


# virtual methods
.method public final Ialue()V
    .locals 7

    .line 1
    iget-boolean v0, p0, LsizO;->$ÒcdS:Z

    .line 2
    .line 3
    if-eqz v0, :cond_6

    .line 4
    .line 5
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    iget-wide v2, p0, LsizO;->Q1_f_:J

    .line 10
    .line 11
    sub-long/2addr v0, v2

    .line 12
    const-wide/16 v2, 0x12c

    .line 13
    .line 14
    const/4 v4, 0x1

    .line 15
    cmp-long v5, v0, v2

    .line 16
    .line 17
    if-ltz v5, :cond_5

    .line 18
    .line 19
    iget-object v0, p0, LsizO;->yPN$A_n$:LRo_Zk$ML_;

    .line 20
    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    iget-boolean v0, p0, LsizO;->Iii:Z

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    iget-boolean v0, p0, LsizO;->kCount1402:Z

    .line 29
    .line 30
    xor-int/2addr v0, v4

    .line 31
    goto :goto_1

    .line 32
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 33
    :goto_1
    if-eqz v0, :cond_2

    .line 34
    .line 35
    iput-boolean v4, p0, LsizO;->l1:Z

    .line 36
    .line 37
    return-void

    .line 38
    :cond_2
    const/4 v0, 0x0

    .line 39
    iput-boolean v0, p0, LsizO;->l1:Z

    .line 40
    .line 41
    iget-object v0, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 42
    .line 43
    invoke-virtual {v0}, LRo_Zk$ML_;->sKey7917()Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_3

    .line 48
    .line 49
    iget-object v0, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 50
    .line 51
    invoke-virtual {v0}, LRo_Zk$ML_;->POOl()Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_4

    .line 56
    .line 57
    :cond_3
    invoke-virtual {p0}, LzPàWiY;->dismiss()V

    .line 58
    .line 59
    .line 60
    :cond_4
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 61
    .line 62
    .line 63
    move-result-wide v0

    .line 64
    iput-wide v0, p0, LsizO;->Q1_f_:J

    .line 65
    .line 66
    iget-object v0, p0, LsizO;->tzKù7Ol1:LlllIi;

    .line 67
    .line 68
    invoke-virtual {v0}, LlllIi;->rz__9J_()V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :cond_5
    iget-object v0, p0, LsizO;->tmpSize211:LT3K$G_7$;

    .line 73
    .line 74
    invoke-virtual {v0, v4}, Landroid/os/Handler;->removeMessages(I)V

    .line 75
    .line 76
    .line 77
    iget-wide v5, p0, LsizO;->Q1_f_:J

    .line 78
    .line 79
    add-long/2addr v5, v2

    .line 80
    invoke-virtual {v0, v4, v5, v6}, Landroid/os/Handler;->sendEmptyMessageAtTime(IJ)Z

    .line 81
    .line 82
    .line 83
    :cond_6
    return-void
.end method

.method public final iOffset934()V
    .locals 10

    .line 1
    iget-object v0, p0, LsizO;->yPN$A_n$:LRo_Zk$ML_;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-nez v0, :cond_1

    .line 5
    .line 6
    iget-boolean v0, p0, LsizO;->Iii:Z

    .line 7
    .line 8
    if-eqz v0, :cond_0

    .line 9
    .line 10
    goto :goto_0

    .line 11
    :cond_0
    iget-boolean v0, p0, LsizO;->kCount1402:Z

    .line 12
    .line 13
    xor-int/2addr v0, v1

    .line 14
    goto :goto_1

    .line 15
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 16
    :goto_1
    if-eqz v0, :cond_2

    .line 17
    .line 18
    iput-boolean v1, p0, LsizO;->pQ1Il:Z

    .line 19
    .line 20
    return-void

    .line 21
    :cond_2
    const/4 v0, 0x0

    .line 22
    iput-boolean v0, p0, LsizO;->pQ1Il:Z

    .line 23
    .line 24
    iget-object v2, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 25
    .line 26
    invoke-virtual {v2}, LRo_Zk$ML_;->sKey7917()Z

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    if-eqz v2, :cond_3

    .line 31
    .line 32
    iget-object v2, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 33
    .line 34
    invoke-virtual {v2}, LRo_Zk$ML_;->POOl()Z

    .line 35
    .line 36
    .line 37
    move-result v2

    .line 38
    if-eqz v2, :cond_4

    .line 39
    .line 40
    :cond_3
    invoke-virtual {p0}, LzPàWiY;->dismiss()V

    .line 41
    .line 42
    .line 43
    :cond_4
    iget-boolean v2, p0, LsizO;->gc_$M_w2$:Z

    .line 44
    .line 45
    const/4 v3, 0x0

    .line 46
    const/16 v4, 0x8

    .line 47
    .line 48
    if-eqz v2, :cond_6

    .line 49
    .line 50
    iget-object v2, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 51
    .line 52
    if-eqz v2, :cond_5

    .line 53
    .line 54
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-eqz v2, :cond_5

    .line 59
    .line 60
    const/4 v2, 0x1

    .line 61
    goto :goto_2

    .line 62
    :cond_5
    const/4 v2, 0x0

    .line 63
    :goto_2
    if-nez v2, :cond_6

    .line 64
    .line 65
    iget-object v2, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 66
    .line 67
    if-eqz v2, :cond_6

    .line 68
    .line 69
    iget-object v2, p0, LsizO;->iSize4906:Landroid/widget/ImageView;

    .line 70
    .line 71
    invoke-virtual {v2, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 72
    .line 73
    .line 74
    iget-object v2, p0, LsizO;->iSize4906:Landroid/widget/ImageView;

    .line 75
    .line 76
    iget-object v5, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 77
    .line 78
    invoke-virtual {v2, v5}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 79
    .line 80
    .line 81
    iget-object v2, p0, LsizO;->iSize4906:Landroid/widget/ImageView;

    .line 82
    .line 83
    iget v5, p0, LsizO;->K11ID:I

    .line 84
    .line 85
    invoke-virtual {v2, v5}, Landroid/view/View;->setBackgroundColor(I)V

    .line 86
    .line 87
    .line 88
    iget-object v2, p0, LsizO;->gSy_FG$D_:Landroid/view/View;

    .line 89
    .line 90
    invoke-virtual {v2, v0}, Landroid/view/View;->setVisibility(I)V

    .line 91
    .line 92
    .line 93
    iget-object v2, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 94
    .line 95
    iget-object v5, p0, LsizO;->UC_n_:Landroid/content/Context;

    .line 96
    .line 97
    invoke-static {v5}, Landroid/renderscript/RenderScript;->create(Landroid/content/Context;)Landroid/renderscript/RenderScript;

    .line 98
    .line 99
    .line 100
    move-result-object v5

    .line 101
    invoke-static {v5, v2}, Landroid/renderscript/Allocation;->createFromBitmap(Landroid/renderscript/RenderScript;Landroid/graphics/Bitmap;)Landroid/renderscript/Allocation;

    .line 102
    .line 103
    .line 104
    move-result-object v6

    .line 105
    invoke-virtual {v6}, Landroid/renderscript/Allocation;->getType()Landroid/renderscript/Type;

    .line 106
    .line 107
    .line 108
    move-result-object v7

    .line 109
    invoke-static {v5, v7}, Landroid/renderscript/Allocation;->createTyped(Landroid/renderscript/RenderScript;Landroid/renderscript/Type;)Landroid/renderscript/Allocation;

    .line 110
    .line 111
    .line 112
    move-result-object v7

    .line 113
    invoke-static {v5}, Landroid/renderscript/Element;->U8_4(Landroid/renderscript/RenderScript;)Landroid/renderscript/Element;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    invoke-static {v5, v8}, Landroid/renderscript/ScriptIntrinsicBlur;->create(Landroid/renderscript/RenderScript;Landroid/renderscript/Element;)Landroid/renderscript/ScriptIntrinsicBlur;

    .line 118
    .line 119
    .line 120
    move-result-object v8

    .line 121
    const/high16 v9, 0x41200000    # 10.0f

    .line 122
    .line 123
    invoke-virtual {v8, v9}, Landroid/renderscript/ScriptIntrinsicBlur;->setRadius(F)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v8, v6}, Landroid/renderscript/ScriptIntrinsicBlur;->setInput(Landroid/renderscript/Allocation;)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v8, v7}, Landroid/renderscript/ScriptIntrinsicBlur;->forEach(Landroid/renderscript/Allocation;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->getConfig()Landroid/graphics/Bitmap$Config;

    .line 133
    .line 134
    .line 135
    move-result-object v9

    .line 136
    invoke-virtual {v2, v9, v1}, Landroid/graphics/Bitmap;->copy(Landroid/graphics/Bitmap$Config;Z)Landroid/graphics/Bitmap;

    .line 137
    .line 138
    .line 139
    move-result-object v1

    .line 140
    invoke-virtual {v7, v1}, Landroid/renderscript/Allocation;->copyTo(Landroid/graphics/Bitmap;)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v6}, Landroid/renderscript/Allocation;->destroy()V

    .line 144
    .line 145
    .line 146
    invoke-virtual {v7}, Landroid/renderscript/Allocation;->destroy()V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v8}, Landroid/renderscript/BaseObj;->destroy()V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v5}, Landroid/renderscript/RenderScript;->destroy()V

    .line 153
    .line 154
    .line 155
    iget-object v2, p0, LsizO;->zAt$p:Landroid/widget/ImageView;

    .line 156
    .line 157
    invoke-virtual {v2, v1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 158
    .line 159
    .line 160
    goto :goto_4

    .line 161
    :cond_6
    iget-object v2, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 162
    .line 163
    if-eqz v2, :cond_7

    .line 164
    .line 165
    invoke-virtual {v2}, Landroid/graphics/Bitmap;->isRecycled()Z

    .line 166
    .line 167
    .line 168
    move-result v2

    .line 169
    if-eqz v2, :cond_7

    .line 170
    .line 171
    goto :goto_3

    .line 172
    :cond_7
    const/4 v1, 0x0

    .line 173
    :goto_3
    if-eqz v1, :cond_8

    .line 174
    .line 175
    iget-object v1, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 176
    .line 177
    invoke-static {v1}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    :cond_8
    iget-object v1, p0, LsizO;->iSize4906:Landroid/widget/ImageView;

    .line 181
    .line 182
    invoke-virtual {v1, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 183
    .line 184
    .line 185
    iget-object v1, p0, LsizO;->gSy_FG$D_:Landroid/view/View;

    .line 186
    .line 187
    invoke-virtual {v1, v4}, Landroid/view/View;->setVisibility(I)V

    .line 188
    .line 189
    .line 190
    iget-object v1, p0, LsizO;->zAt$p:Landroid/widget/ImageView;

    .line 191
    .line 192
    invoke-virtual {v1, v3}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    .line 193
    .line 194
    .line 195
    :goto_4
    iput-boolean v0, p0, LsizO;->gc_$M_w2$:Z

    .line 196
    .line 197
    iput-object v3, p0, LsizO;->iQ0D:Landroid/graphics/Bitmap;

    .line 198
    .line 199
    iput v0, p0, LsizO;->K11ID:I

    .line 200
    .line 201
    iget-object v1, p0, LsizO;->RD:Landroid/support/v4/media/MediaDescriptionCompat;

    .line 202
    .line 203
    if-nez v1, :cond_9

    .line 204
    .line 205
    move-object v1, v3

    .line 206
    goto :goto_5

    .line 207
    :cond_9
    iget-object v1, v1, Landroid/support/v4/media/MediaDescriptionCompat;->vaIue:Ljava/lang/CharSequence;

    .line 208
    .line 209
    :goto_5
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 210
    .line 211
    .line 212
    move-result v2

    .line 213
    iget-object v5, p0, LsizO;->RD:Landroid/support/v4/media/MediaDescriptionCompat;

    .line 214
    .line 215
    if-nez v5, :cond_a

    .line 216
    .line 217
    goto :goto_6

    .line 218
    :cond_a
    iget-object v3, v5, Landroid/support/v4/media/MediaDescriptionCompat;->jPos3709:Ljava/lang/CharSequence;

    .line 219
    .line 220
    :goto_6
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 221
    .line 222
    .line 223
    move-result v5

    .line 224
    if-nez v2, :cond_b

    .line 225
    .line 226
    iget-object v2, p0, LsizO;->Txy$$d_w$:Landroid/widget/TextView;

    .line 227
    .line 228
    invoke-virtual {v2, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 229
    .line 230
    .line 231
    goto :goto_7

    .line 232
    :cond_b
    iget-object v1, p0, LsizO;->Txy$$d_w$:Landroid/widget/TextView;

    .line 233
    .line 234
    iget-object v2, p0, LsizO;->ChI_KH_:Ljava/lang/String;

    .line 235
    .line 236
    invoke-virtual {v1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 237
    .line 238
    .line 239
    :goto_7
    if-nez v5, :cond_c

    .line 240
    .line 241
    iget-object v1, p0, LsizO;->vz$a$:Landroid/widget/TextView;

    .line 242
    .line 243
    invoke-virtual {v1, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 244
    .line 245
    .line 246
    iget-object v1, p0, LsizO;->vz$a$:Landroid/widget/TextView;

    .line 247
    .line 248
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 249
    .line 250
    .line 251
    return-void

    .line 252
    :cond_c
    iget-object v0, p0, LsizO;->vz$a$:Landroid/widget/TextView;

    .line 253
    .line 254
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 255
    .line 256
    .line 257
    return-void
.end method

.method public final jPos3709()V
    .locals 4

    .line 1
    iget-object v0, p0, LsizO;->UC_n_:Landroid/content/Context;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    sget v2, LpK_Ii$tz_;->is_tablet:I

    .line 8
    .line 9
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getBoolean(I)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, -0x1

    .line 14
    if-nez v1, :cond_0

    .line 15
    .line 16
    const/4 v1, -0x1

    .line 17
    goto :goto_0

    .line 18
    :cond_0
    invoke-static {v0}, LdlDIQ;->tmpData3485(Landroid/content/Context;)I

    .line 19
    .line 20
    .line 21
    move-result v1

    .line 22
    :goto_0
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sget v3, LpK_Ii$tz_;->is_tablet:I

    .line 27
    .line 28
    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getBoolean(I)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_1

    .line 33
    .line 34
    goto :goto_1

    .line 35
    :cond_1
    const/4 v2, -0x2

    .line 36
    :goto_1
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-virtual {v0, v1, v2}, Landroid/view/Window;->setLayout(II)V

    .line 41
    .line 42
    .line 43
    const/4 v0, 0x0

    .line 44
    iput-object v0, p0, LsizO;->dnN$d$:Landroid/graphics/Bitmap;

    .line 45
    .line 46
    iput-object v0, p0, LsizO;->YOD0:Landroid/net/Uri;

    .line 47
    .line 48
    invoke-virtual {p0}, LsizO;->sKey7917()V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, LsizO;->iOffset934()V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, LsizO;->Ialue()V

    .line 55
    .line 56
    .line 57
    return-void
.end method

.method public final kQy()V
    .locals 8

    .line 1
    iget-object v0, p0, LsizO;->gKey4112:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, LsizO;->kO_6X_:Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 9
    .line 10
    .line 11
    iget-object v2, p0, LsizO;->K0I:Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 14
    .line 15
    .line 16
    iget-object v3, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 17
    .line 18
    iget-object v3, v3, LRo_Zk$ML_;->UC_n_:Ljava/util/ArrayList;

    .line 19
    .line 20
    invoke-static {v3}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 25
    .line 26
    .line 27
    iget-object v3, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 28
    .line 29
    invoke-virtual {v3}, LRo_Zk$ML_;->e8$mp_s$()LteIp;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    if-eqz v3, :cond_2

    .line 34
    .line 35
    iget-object v4, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 36
    .line 37
    iget-object v4, v4, LRo_Zk$ML_;->e8$mp_s$:Lo9k$Z$;

    .line 38
    .line 39
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    invoke-static {}, LILA_l$V_;->waiBKÀ()V

    .line 43
    .line 44
    .line 45
    iget-object v4, v4, Lo9k$Z$;->waiBKÀ:Ljava/util/ArrayList;

    .line 46
    .line 47
    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    :cond_0
    :goto_0
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    if-eqz v5, :cond_2

    .line 60
    .line 61
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    check-cast v5, LRo_Zk$ML_;

    .line 66
    .line 67
    invoke-virtual {v3, v5}, LteIp;->valuI(LRo_Zk$ML_;)Z

    .line 68
    .line 69
    .line 70
    move-result v6

    .line 71
    if-eqz v6, :cond_1

    .line 72
    .line 73
    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    :cond_1
    iget-object v6, v3, LteIp;->$ÒcdS:LhasSize1398;

    .line 77
    .line 78
    iget-object v7, v5, LRo_Zk$ML_;->rz__9J_:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {v6, v7}, LZdxMjO;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    check-cast v6, LCQI;

    .line 85
    .line 86
    if-eqz v6, :cond_0

    .line 87
    .line 88
    iget-boolean v6, v6, LCQI;->JKEoÙX:Z

    .line 89
    .line 90
    if-eqz v6, :cond_0

    .line 91
    .line 92
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_2
    invoke-virtual {p0, v1}, LsizO;->tmpData3485(Ljava/util/List;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {p0, v2}, LsizO;->tmpData3485(Ljava/util/List;)V

    .line 100
    .line 101
    .line 102
    sget-object v3, LuqQ$G_rc$;->iOffset934:LuqQ$G_rc$;

    .line 103
    .line 104
    invoke-static {v0, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 105
    .line 106
    .line 107
    invoke-static {v1, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 108
    .line 109
    .line 110
    invoke-static {v2, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    .line 111
    .line 112
    .line 113
    iget-object v0, p0, LsizO;->tzKù7Ol1:LlllIi;

    .line 114
    .line 115
    invoke-virtual {v0}, LlllIi;->POOl()V

    .line 116
    .line 117
    .line 118
    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 4

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    iput-boolean v0, p0, LsizO;->$ÒcdS:Z

    .line 6
    .line 7
    iget-object v1, p0, LsizO;->pCXDYg:LvKey5061;

    .line 8
    .line 9
    iget-object v2, p0, LsizO;->valuI:LynBMMg;

    .line 10
    .line 11
    iget-object v3, p0, LsizO;->Ialue:LILA_l$V_;

    .line 12
    .line 13
    invoke-virtual {v3, v1, v2, v0}, LILA_l$V_;->e8$mp_s$(LvKey5061;LrIlI0;I)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, LsizO;->kQy()V

    .line 17
    .line 18
    .line 19
    invoke-static {}, LILA_l$V_;->JKEoÙX()Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    invoke-virtual {p0, v0}, LsizO;->yON3x(Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, LzPàWiY;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, Lbv$n3$;->mr_cast_dialog:I

    .line 5
    .line 6
    invoke-virtual {p0, p1}, LzPàWiY;->setContentView(I)V

    .line 7
    .line 8
    .line 9
    sget p1, LQÙcmZà;->e8$mp_s$:I

    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    iget-object v0, p0, LsizO;->UC_n_:Landroid/content/Context;

    .line 20
    .line 21
    invoke-static {v0}, LQÙcmZà;->DDù8(Landroid/content/Context;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    sget v1, LXeYEÈPs;->mr_dynamic_dialog_background_light:I

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_0
    sget v1, LXeYEÈPs;->mr_dynamic_dialog_background_dark:I

    .line 31
    .line 32
    :goto_0
    invoke-static {v0, v1}, LvData2646;->vaIue(Landroid/content/Context;I)I

    .line 33
    .line 34
    .line 35
    move-result v1

    .line 36
    invoke-virtual {p1, v1}, Landroid/view/View;->setBackgroundColor(I)V

    .line 37
    .line 38
    .line 39
    sget p1, LXa_G_;->mr_cast_close_button:I

    .line 40
    .line 41
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    check-cast p1, Landroid/widget/ImageButton;

    .line 46
    .line 47
    iput-object p1, p0, LsizO;->oaX_6_:Landroid/widget/ImageButton;

    .line 48
    .line 49
    const/4 v1, -0x1

    .line 50
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setColorFilter(I)V

    .line 51
    .line 52
    .line 53
    iget-object p1, p0, LsizO;->oaX_6_:Landroid/widget/ImageButton;

    .line 54
    .line 55
    new-instance v2, LdI;

    .line 56
    .line 57
    const/4 v3, 0x0

    .line 58
    invoke-direct {v2, p0, v3}, LdI;-><init>(LsizO;I)V

    .line 59
    .line 60
    .line 61
    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 62
    .line 63
    .line 64
    sget p1, LXa_G_;->mr_cast_stop_button:I

    .line 65
    .line 66
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    check-cast p1, Landroid/widget/Button;

    .line 71
    .line 72
    iput-object p1, p0, LsizO;->BCIm:Landroid/widget/Button;

    .line 73
    .line 74
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 75
    .line 76
    .line 77
    iget-object p1, p0, LsizO;->BCIm:Landroid/widget/Button;

    .line 78
    .line 79
    new-instance v2, LdI;

    .line 80
    .line 81
    const/4 v3, 0x1

    .line 82
    invoke-direct {v2, p0, v3}, LdI;-><init>(LsizO;I)V

    .line 83
    .line 84
    .line 85
    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 86
    .line 87
    .line 88
    new-instance p1, LlllIi;

    .line 89
    .line 90
    invoke-direct {p1, p0}, LlllIi;-><init>(LsizO;)V

    .line 91
    .line 92
    .line 93
    iput-object p1, p0, LsizO;->tzKù7Ol1:LlllIi;

    .line 94
    .line 95
    sget p1, LXa_G_;->mr_cast_list:I

    .line 96
    .line 97
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 98
    .line 99
    .line 100
    move-result-object p1

    .line 101
    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    .line 102
    .line 103
    iput-object p1, p0, LsizO;->sKey6064:Landroidx/recyclerview/widget/RecyclerView;

    .line 104
    .line 105
    iget-object v2, p0, LsizO;->tzKù7Ol1:LlllIi;

    .line 106
    .line 107
    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/rz__9J_;)V

    .line 108
    .line 109
    .line 110
    iget-object p1, p0, LsizO;->sKey6064:Landroidx/recyclerview/widget/RecyclerView;

    .line 111
    .line 112
    new-instance v2, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 113
    .line 114
    invoke-direct {v2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(I)V

    .line 115
    .line 116
    .line 117
    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/JKEoÙX;)V

    .line 118
    .line 119
    .line 120
    new-instance p1, LIsÒEz;

    .line 121
    .line 122
    const/4 v2, 0x2

    .line 123
    invoke-direct {p1, v2, p0}, LIsÒEz;-><init>(ILjava/lang/Object;)V

    .line 124
    .line 125
    .line 126
    iput-object p1, p0, LsizO;->ll:LIsÒEz;

    .line 127
    .line 128
    new-instance p1, Ljava/util/HashMap;

    .line 129
    .line 130
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 131
    .line 132
    .line 133
    iput-object p1, p0, LsizO;->oy_R$Xx_:Ljava/util/HashMap;

    .line 134
    .line 135
    new-instance p1, Ljava/util/HashMap;

    .line 136
    .line 137
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 138
    .line 139
    .line 140
    iput-object p1, p0, LsizO;->Oey:Ljava/util/HashMap;

    .line 141
    .line 142
    sget p1, LXa_G_;->mr_cast_meta_background:I

    .line 143
    .line 144
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    check-cast p1, Landroid/widget/ImageView;

    .line 149
    .line 150
    iput-object p1, p0, LsizO;->zAt$p:Landroid/widget/ImageView;

    .line 151
    .line 152
    sget p1, LXa_G_;->mr_cast_meta_black_scrim:I

    .line 153
    .line 154
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    iput-object p1, p0, LsizO;->gSy_FG$D_:Landroid/view/View;

    .line 159
    .line 160
    sget p1, LXa_G_;->mr_cast_meta_art:I

    .line 161
    .line 162
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    check-cast p1, Landroid/widget/ImageView;

    .line 167
    .line 168
    iput-object p1, p0, LsizO;->iSize4906:Landroid/widget/ImageView;

    .line 169
    .line 170
    sget p1, LXa_G_;->mr_cast_meta_title:I

    .line 171
    .line 172
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 173
    .line 174
    .line 175
    move-result-object p1

    .line 176
    check-cast p1, Landroid/widget/TextView;

    .line 177
    .line 178
    iput-object p1, p0, LsizO;->Txy$$d_w$:Landroid/widget/TextView;

    .line 179
    .line 180
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 181
    .line 182
    .line 183
    sget p1, LXa_G_;->mr_cast_meta_subtitle:I

    .line 184
    .line 185
    invoke-virtual {p0, p1}, LzPàWiY;->findViewById(I)Landroid/view/View;

    .line 186
    .line 187
    .line 188
    move-result-object p1

    .line 189
    check-cast p1, Landroid/widget/TextView;

    .line 190
    .line 191
    iput-object p1, p0, LsizO;->vz$a$:Landroid/widget/TextView;

    .line 192
    .line 193
    invoke-virtual {p1, v1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 194
    .line 195
    .line 196
    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    sget v0, LFV$Qn_J$;->mr_cast_dialog_title_view_placeholder:I

    .line 201
    .line 202
    invoke-virtual {p1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object p1

    .line 206
    iput-object p1, p0, LsizO;->ChI_KH_:Ljava/lang/String;

    .line 207
    .line 208
    iput-boolean v3, p0, LsizO;->kCount1402:Z

    .line 209
    .line 210
    invoke-virtual {p0}, LsizO;->jPos3709()V

    .line 211
    .line 212
    .line 213
    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/app/Dialog;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, LsizO;->$ÒcdS:Z

    .line 6
    .line 7
    iget-object v0, p0, LsizO;->Ialue:LILA_l$V_;

    .line 8
    .line 9
    iget-object v1, p0, LsizO;->valuI:LynBMMg;

    .line 10
    .line 11
    invoke-virtual {v0, v1}, LILA_l$V_;->DDù8(LrIlI0;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, LsizO;->tmpSize211:LT3K$G_7$;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v1}, LsizO;->yON3x(Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final sKey7917()V
    .locals 4

    .line 1
    iget-object v0, p0, LsizO;->RD:Landroid/support/v4/media/MediaDescriptionCompat;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    move-object v2, v1

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v2, v0, Landroid/support/v4/media/MediaDescriptionCompat;->kQy:Landroid/graphics/Bitmap;

    .line 9
    .line 10
    :goto_0
    if-nez v0, :cond_1

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_1
    iget-object v1, v0, Landroid/support/v4/media/MediaDescriptionCompat;->Ialue:Landroid/net/Uri;

    .line 14
    .line 15
    :goto_1
    iget-object v0, p0, LsizO;->valu0:LT1QD;

    .line 16
    .line 17
    if-nez v0, :cond_2

    .line 18
    .line 19
    iget-object v3, p0, LsizO;->dnN$d$:Landroid/graphics/Bitmap;

    .line 20
    .line 21
    goto :goto_2

    .line 22
    :cond_2
    iget-object v3, v0, LT1QD;->e8$mp_s$:Landroid/graphics/Bitmap;

    .line 23
    .line 24
    :goto_2
    if-nez v0, :cond_3

    .line 25
    .line 26
    iget-object v0, p0, LsizO;->YOD0:Landroid/net/Uri;

    .line 27
    .line 28
    goto :goto_3

    .line 29
    :cond_3
    iget-object v0, v0, LT1QD;->waiBKÀ:Landroid/net/Uri;

    .line 30
    .line 31
    :goto_3
    if-ne v3, v2, :cond_5

    .line 32
    .line 33
    if-nez v3, :cond_4

    .line 34
    .line 35
    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_5

    .line 40
    .line 41
    :cond_4
    return-void

    .line 42
    :cond_5
    iget-object v0, p0, LsizO;->valu0:LT1QD;

    .line 43
    .line 44
    if-eqz v0, :cond_6

    .line 45
    .line 46
    const/4 v1, 0x1

    .line 47
    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->cancel(Z)Z

    .line 48
    .line 49
    .line 50
    :cond_6
    new-instance v0, LT1QD;

    .line 51
    .line 52
    invoke-direct {v0, p0}, LT1QD;-><init>(LsizO;)V

    .line 53
    .line 54
    .line 55
    iput-object v0, p0, LsizO;->valu0:LT1QD;

    .line 56
    .line 57
    const/4 v1, 0x0

    .line 58
    new-array v1, v1, [Ljava/lang/Void;

    .line 59
    .line 60
    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    .line 61
    .line 62
    .line 63
    return-void
.end method

.method public final tmpData3485(Ljava/util/List;)V
    .locals 3

    .line 1
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    add-int/lit8 v0, v0, -0x1

    .line 6
    .line 7
    :goto_0
    if-ltz v0, :cond_1

    .line 8
    .line 9
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    check-cast v1, LRo_Zk$ML_;

    .line 14
    .line 15
    invoke-virtual {v1}, LRo_Zk$ML_;->POOl()Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-nez v2, :cond_0

    .line 20
    .line 21
    iget-boolean v2, v1, LRo_Zk$ML_;->sKey7917:Z

    .line 22
    .line 23
    if-eqz v2, :cond_0

    .line 24
    .line 25
    iget-object v2, p0, LsizO;->pCXDYg:LvKey5061;

    .line 26
    .line 27
    invoke-virtual {v1, v2}, LRo_Zk$ML_;->DDù8(LvKey5061;)Z

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    if-eqz v2, :cond_0

    .line 32
    .line 33
    iget-object v2, p0, LsizO;->yàÒZ:LRo_Zk$ML_;

    .line 34
    .line 35
    if-eq v2, v1, :cond_0

    .line 36
    .line 37
    goto :goto_1

    .line 38
    :cond_0
    invoke-interface {p1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    :goto_1
    add-int/lit8 v0, v0, -0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    return-void
.end method

.method public final vaIue(LvKey5061;)V
    .locals 3

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    iget-object v0, p0, LsizO;->pCXDYg:LvKey5061;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LvKey5061;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    iput-object p1, p0, LsizO;->pCXDYg:LvKey5061;

    .line 12
    .line 13
    iget-boolean v0, p0, LsizO;->$ÒcdS:Z

    .line 14
    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, LsizO;->Ialue:LILA_l$V_;

    .line 18
    .line 19
    iget-object v1, p0, LsizO;->valuI:LynBMMg;

    .line 20
    .line 21
    invoke-virtual {v0, v1}, LILA_l$V_;->DDù8(LrIlI0;)V

    .line 22
    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    invoke-virtual {v0, p1, v1, v2}, LILA_l$V_;->e8$mp_s$(LvKey5061;LrIlI0;I)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, LsizO;->kQy()V

    .line 29
    .line 30
    .line 31
    :cond_0
    return-void

    .line 32
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 33
    .line 34
    const-string v0, "selector must not be null"

    .line 35
    .line 36
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    throw p1
.end method

.method public final valuI()V
    .locals 1

    .line 1
    iget-boolean v0, p0, LsizO;->l1:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, LsizO;->Ialue()V

    .line 6
    .line 7
    .line 8
    :cond_0
    iget-boolean v0, p0, LsizO;->pQ1Il:Z

    .line 9
    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-virtual {p0}, LsizO;->iOffset934()V

    .line 13
    .line 14
    .line 15
    :cond_1
    return-void
.end method

.method public final yON3x(Landroid/support/v4/media/session/MediaSessionCompat$Token;)V
    .locals 4

    .line 1
    iget-object v0, p0, LsizO;->gCount1961:LBqOjcA;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, LsizO;->k1y:LIiliIi;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0, v2}, LBqOjcA;->YOD0(LIiliIi;)V

    .line 9
    .line 10
    .line 11
    iput-object v1, p0, LsizO;->gCount1961:LBqOjcA;

    .line 12
    .line 13
    :cond_0
    if-nez p1, :cond_1

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_1
    iget-boolean v0, p0, LsizO;->$ÒcdS:Z

    .line 17
    .line 18
    if-nez v0, :cond_2

    .line 19
    .line 20
    :goto_0
    return-void

    .line 21
    :cond_2
    new-instance v0, LBqOjcA;

    .line 22
    .line 23
    iget-object v3, p0, LsizO;->UC_n_:Landroid/content/Context;

    .line 24
    .line 25
    invoke-direct {v0, v3, p1}, LBqOjcA;-><init>(Landroid/content/Context;Landroid/support/v4/media/session/MediaSessionCompat$Token;)V

    .line 26
    .line 27
    .line 28
    iput-object v0, p0, LsizO;->gCount1961:LBqOjcA;

    .line 29
    .line 30
    invoke-virtual {v0, v2}, LBqOjcA;->gCount1961(LIiliIi;)V

    .line 31
    .line 32
    .line 33
    iget-object p1, p0, LsizO;->gCount1961:LBqOjcA;

    .line 34
    .line 35
    iget-object p1, p1, LBqOjcA;->vaIue:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p1, Landroid/support/v4/media/session/waiBKÀ;

    .line 38
    .line 39
    iget-object p1, p1, Landroid/support/v4/media/session/waiBKÀ;->e8$mp_s$:Landroid/media/session/MediaController;

    .line 40
    .line 41
    invoke-virtual {p1}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    if-eqz p1, :cond_3

    .line 46
    .line 47
    sget-object v0, Landroid/support/v4/media/MediaMetadataCompat;->iOffset934:LhasSize1398;

    .line 48
    .line 49
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    const/4 v2, 0x0

    .line 54
    invoke-virtual {p1, v0, v2}, Landroid/media/MediaMetadata;->writeToParcel(Landroid/os/Parcel;I)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v0, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 58
    .line 59
    .line 60
    sget-object v2, Landroid/support/v4/media/MediaMetadataCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 61
    .line 62
    invoke-interface {v2, v0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    check-cast v2, Landroid/support/v4/media/MediaMetadataCompat;

    .line 67
    .line 68
    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    .line 69
    .line 70
    .line 71
    iput-object p1, v2, Landroid/support/v4/media/MediaMetadataCompat;->vaIue:Landroid/media/MediaMetadata;

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_3
    move-object v2, v1

    .line 75
    :goto_1
    if-nez v2, :cond_4

    .line 76
    .line 77
    goto :goto_2

    .line 78
    :cond_4
    invoke-virtual {v2}, Landroid/support/v4/media/MediaMetadataCompat;->waiBKÀ()Landroid/support/v4/media/MediaDescriptionCompat;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    :goto_2
    iput-object v1, p0, LsizO;->RD:Landroid/support/v4/media/MediaDescriptionCompat;

    .line 83
    .line 84
    invoke-virtual {p0}, LsizO;->sKey7917()V

    .line 85
    .line 86
    .line 87
    invoke-virtual {p0}, LsizO;->iOffset934()V

    .line 88
    .line 89
    .line 90
    return-void
.end method
