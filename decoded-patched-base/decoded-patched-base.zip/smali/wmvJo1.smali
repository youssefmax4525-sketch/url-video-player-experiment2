.class public interface abstract LwmvJo1;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract JKEoÙX(Ljava/lang/Class;)Z
.end method

.method public abstract POOl(Ljava/lang/Class;)LBQ7Qx;
.end method
