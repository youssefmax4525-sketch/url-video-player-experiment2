.class public abstract Lxr$t$;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static e8$mp_s$(Landroid/view/View;IIII)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2, p3, p4}, LnIndex9072;->yàÒZ(Landroid/view/View;IIII)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
