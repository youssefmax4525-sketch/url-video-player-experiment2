.class public abstract LtDQ;
.super Ljava/lang/Object;


# static fields
.field public static call_notification_answer_action:I = 0x7f14002c

.field public static call_notification_answer_video_action:I = 0x7f14002d

.field public static call_notification_decline_action:I = 0x7f14002e

.field public static call_notification_hang_up_action:I = 0x7f14002f

.field public static call_notification_incoming_text:I = 0x7f140030

.field public static call_notification_ongoing_text:I = 0x7f140031

.field public static call_notification_screening_text:I = 0x7f140032

.field public static status_bar_notification_info_overflow:I = 0x7f1401ae
