.class public final LPX6$F_j$;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:Landroid/content/Context;

.field public final rz__9J_:LmC8$L_yP$;

.field public final waiBKÀ:LjValue2770;


# direct methods
.method public constructor <init>(Landroid/content/Context;LjValue2770;LmC8$L_yP$;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LPX6$F_j$;->e8$mp_s$:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p2, p0, LPX6$F_j$;->waiBKÀ:LjValue2770;

    .line 7
    .line 8
    iput-object p3, p0, LPX6$F_j$;->rz__9J_:LmC8$L_yP$;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(LrìAqae;IZ)V
    .locals 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    move/from16 v2, p2

    .line 6
    .line 7
    new-instance v3, Landroid/content/ComponentName;

    .line 8
    .line 9
    const-class v4, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/JobInfoSchedulerService;

    .line 10
    .line 11
    iget-object v5, v1, LPX6$F_j$;->e8$mp_s$:Landroid/content/Context;

    .line 12
    .line 13
    invoke-direct {v3, v5, v4}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 14
    .line 15
    .line 16
    const-string v4, "jobscheduler"

    .line 17
    .line 18
    invoke-virtual {v5, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Landroid/app/job/JobScheduler;

    .line 23
    .line 24
    new-instance v6, Ljava/util/zip/Adler32;

    .line 25
    .line 26
    invoke-direct {v6}, Ljava/util/zip/Adler32;-><init>()V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v5

    .line 33
    const-string v7, "UTF-8"

    .line 34
    .line 35
    invoke-static {v7}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 36
    .line 37
    .line 38
    move-result-object v8

    .line 39
    invoke-virtual {v5, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    invoke-virtual {v6, v5}, Ljava/util/zip/Adler32;->update([B)V

    .line 44
    .line 45
    .line 46
    iget-object v5, v0, LrìAqae;->e8$mp_s$:Ljava/lang/String;

    .line 47
    .line 48
    iget-object v8, v0, LrìAqae;->e8$mp_s$:Ljava/lang/String;

    .line 49
    .line 50
    invoke-static {v7}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    .line 51
    .line 52
    .line 53
    move-result-object v7

    .line 54
    invoke-virtual {v5, v7}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 55
    .line 56
    .line 57
    move-result-object v5

    .line 58
    invoke-virtual {v6, v5}, Ljava/util/zip/Adler32;->update([B)V

    .line 59
    .line 60
    .line 61
    const/4 v5, 0x4

    .line 62
    invoke-static {v5}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    iget-object v9, v0, LrìAqae;->rz__9J_:LcQÈè;

    .line 67
    .line 68
    invoke-static {v9}, LkData3876;->e8$mp_s$(LcQÈè;)I

    .line 69
    .line 70
    .line 71
    move-result v10

    .line 72
    invoke-virtual {v7, v10}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    .line 73
    .line 74
    .line 75
    move-result-object v7

    .line 76
    invoke-virtual {v7}, Ljava/nio/ByteBuffer;->array()[B

    .line 77
    .line 78
    .line 79
    move-result-object v7

    .line 80
    invoke-virtual {v6, v7}, Ljava/util/zip/Adler32;->update([B)V

    .line 81
    .line 82
    .line 83
    iget-object v7, v0, LrìAqae;->waiBKÀ:[B

    .line 84
    .line 85
    if-eqz v7, :cond_0

    .line 86
    .line 87
    invoke-virtual {v6, v7}, Ljava/util/zip/Adler32;->update([B)V

    .line 88
    .line 89
    .line 90
    :cond_0
    invoke-virtual {v6}, Ljava/util/zip/Adler32;->getValue()J

    .line 91
    .line 92
    .line 93
    move-result-wide v10

    .line 94
    long-to-int v6, v10

    .line 95
    const-string v10, "attemptNumber"

    .line 96
    .line 97
    if-nez p3, :cond_2

    .line 98
    .line 99
    invoke-virtual {v4}, Landroid/app/job/JobScheduler;->getAllPendingJobs()Ljava/util/List;

    .line 100
    .line 101
    .line 102
    move-result-object v11

    .line 103
    invoke-interface {v11}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 104
    .line 105
    .line 106
    move-result-object v11

    .line 107
    :cond_1
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    .line 109
    .line 110
    move-result v12

    .line 111
    if-eqz v12, :cond_2

    .line 112
    .line 113
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v12

    .line 117
    check-cast v12, Landroid/app/job/JobInfo;

    .line 118
    .line 119
    invoke-virtual {v12}, Landroid/app/job/JobInfo;->getExtras()Landroid/os/PersistableBundle;

    .line 120
    .line 121
    .line 122
    move-result-object v13

    .line 123
    invoke-virtual {v13, v10}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    .line 124
    .line 125
    .line 126
    move-result v13

    .line 127
    invoke-virtual {v12}, Landroid/app/job/JobInfo;->getId()I

    .line 128
    .line 129
    .line 130
    move-result v12

    .line 131
    if-ne v12, v6, :cond_1

    .line 132
    .line 133
    if-lt v13, v2, :cond_2

    .line 134
    .line 135
    new-instance v2, Ljava/lang/StringBuilder;

    .line 136
    .line 137
    const-string v3, "Upload for context "

    .line 138
    .line 139
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    return-void

    .line 146
    :cond_2
    iget-object v11, v1, LPX6$F_j$;->waiBKÀ:LjValue2770;

    .line 147
    .line 148
    check-cast v11, LiValue939;

    .line 149
    .line 150
    invoke-virtual {v11}, LiValue939;->rz__9J_()Landroid/database/sqlite/SQLiteDatabase;

    .line 151
    .line 152
    .line 153
    move-result-object v11

    .line 154
    invoke-static {v9}, LkData3876;->e8$mp_s$(LcQÈè;)I

    .line 155
    .line 156
    .line 157
    move-result v12

    .line 158
    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 159
    .line 160
    .line 161
    move-result-object v12

    .line 162
    filled-new-array {v8, v12}, [Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v12

    .line 166
    const-string v13, "SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?"

    .line 167
    .line 168
    invoke-virtual {v11, v13, v12}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    .line 169
    .line 170
    .line 171
    move-result-object v11

    .line 172
    :try_start_0
    invoke-interface {v11}, Landroid/database/Cursor;->moveToNext()Z

    .line 173
    .line 174
    .line 175
    move-result v12

    .line 176
    const/4 v13, 0x0

    .line 177
    if-eqz v12, :cond_3

    .line 178
    .line 179
    invoke-interface {v11, v13}, Landroid/database/Cursor;->getLong(I)J

    .line 180
    .line 181
    .line 182
    move-result-wide v14

    .line 183
    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 184
    .line 185
    .line 186
    move-result-object v12

    .line 187
    goto :goto_0

    .line 188
    :cond_3
    const-wide/16 v14, 0x0

    .line 189
    .line 190
    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 191
    .line 192
    .line 193
    move-result-object v12
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 194
    :goto_0
    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    .line 195
    .line 196
    .line 197
    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    .line 198
    .line 199
    .line 200
    move-result-wide v14

    .line 201
    new-instance v11, Landroid/app/job/JobInfo$Builder;

    .line 202
    .line 203
    invoke-direct {v11, v6, v3}, Landroid/app/job/JobInfo$Builder;-><init>(ILandroid/content/ComponentName;)V

    .line 204
    .line 205
    .line 206
    iget-object v3, v1, LPX6$F_j$;->rz__9J_:LmC8$L_yP$;

    .line 207
    .line 208
    move/from16 v17, v6

    .line 209
    .line 210
    const/16 v16, 0x4

    .line 211
    .line 212
    invoke-virtual {v3, v9, v14, v15, v2}, LmC8$L_yP$;->e8$mp_s$(LcQÈè;JI)J

    .line 213
    .line 214
    .line 215
    move-result-wide v5

    .line 216
    invoke-virtual {v11, v5, v6}, Landroid/app/job/JobInfo$Builder;->setMinimumLatency(J)Landroid/app/job/JobInfo$Builder;

    .line 217
    .line 218
    .line 219
    iget-object v5, v3, LmC8$L_yP$;->waiBKÀ:Ljava/util/HashMap;

    .line 220
    .line 221
    invoke-virtual {v5, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 222
    .line 223
    .line 224
    move-result-object v5

    .line 225
    check-cast v5, LgValue6090;

    .line 226
    .line 227
    iget-object v5, v5, LgValue6090;->rz__9J_:Ljava/util/Set;

    .line 228
    .line 229
    sget-object v6, Ll1i1;->yON3x:Ll1i1;

    .line 230
    .line 231
    invoke-interface {v5, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v6

    .line 235
    const/4 v13, 0x2

    .line 236
    const/4 v0, 0x1

    .line 237
    if-eqz v6, :cond_4

    .line 238
    .line 239
    invoke-virtual {v11, v13}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    .line 240
    .line 241
    .line 242
    goto :goto_1

    .line 243
    :cond_4
    invoke-virtual {v11, v0}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    .line 244
    .line 245
    .line 246
    :goto_1
    sget-object v6, Ll1i1;->jPos3709:Ll1i1;

    .line 247
    .line 248
    invoke-interface {v5, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    move-result v6

    .line 252
    if-eqz v6, :cond_5

    .line 253
    .line 254
    invoke-virtual {v11, v0}, Landroid/app/job/JobInfo$Builder;->setRequiresCharging(Z)Landroid/app/job/JobInfo$Builder;

    .line 255
    .line 256
    .line 257
    :cond_5
    sget-object v6, Ll1i1;->vaIue:Ll1i1;

    .line 258
    .line 259
    invoke-interface {v5, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 260
    .line 261
    .line 262
    move-result v5

    .line 263
    if-eqz v5, :cond_6

    .line 264
    .line 265
    invoke-virtual {v11, v0}, Landroid/app/job/JobInfo$Builder;->setRequiresDeviceIdle(Z)Landroid/app/job/JobInfo$Builder;

    .line 266
    .line 267
    .line 268
    :cond_6
    new-instance v5, Landroid/os/PersistableBundle;

    .line 269
    .line 270
    invoke-direct {v5}, Landroid/os/PersistableBundle;-><init>()V

    .line 271
    .line 272
    .line 273
    invoke-virtual {v5, v10, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 274
    .line 275
    .line 276
    const-string v6, "backendName"

    .line 277
    .line 278
    invoke-virtual {v5, v6, v8}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    const-string v6, "priority"

    .line 282
    .line 283
    invoke-static {v9}, LkData3876;->e8$mp_s$(LcQÈè;)I

    .line 284
    .line 285
    .line 286
    move-result v8

    .line 287
    invoke-virtual {v5, v6, v8}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 288
    .line 289
    .line 290
    if-eqz v7, :cond_7

    .line 291
    .line 292
    const-string v6, "extras"

    .line 293
    .line 294
    const/4 v8, 0x0

    .line 295
    invoke-static {v7, v8}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 296
    .line 297
    .line 298
    move-result-object v7

    .line 299
    invoke-virtual {v5, v6, v7}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    goto :goto_2

    .line 303
    :cond_7
    const/4 v8, 0x0

    .line 304
    :goto_2
    invoke-virtual {v11, v5}, Landroid/app/job/JobInfo$Builder;->setExtras(Landroid/os/PersistableBundle;)Landroid/app/job/JobInfo$Builder;

    .line 305
    .line 306
    .line 307
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 308
    .line 309
    .line 310
    move-result-object v5

    .line 311
    invoke-virtual {v3, v9, v14, v15, v2}, LmC8$L_yP$;->e8$mp_s$(LcQÈè;JI)J

    .line 312
    .line 313
    .line 314
    move-result-wide v6

    .line 315
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 316
    .line 317
    .line 318
    move-result-object v3

    .line 319
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 320
    .line 321
    .line 322
    move-result-object v2

    .line 323
    const/4 v6, 0x5

    .line 324
    new-array v6, v6, [Ljava/lang/Object;

    .line 325
    .line 326
    aput-object p1, v6, v8

    .line 327
    .line 328
    aput-object v5, v6, v0

    .line 329
    .line 330
    aput-object v3, v6, v13

    .line 331
    .line 332
    const/4 v0, 0x3

    .line 333
    aput-object v12, v6, v0

    .line 334
    .line 335
    aput-object v2, v6, v16

    .line 336
    .line 337
    const-string v0, "Scheduling upload for context %s with jobId=%d in %dms(Backend next call timestamp %d). Attempt %d"

    .line 338
    .line 339
    invoke-static {v0, v6}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    invoke-virtual {v11}, Landroid/app/job/JobInfo$Builder;->build()Landroid/app/job/JobInfo;

    .line 343
    .line 344
    .line 345
    move-result-object v0

    .line 346
    invoke-virtual {v4, v0}, Landroid/app/job/JobScheduler;->schedule(Landroid/app/job/JobInfo;)I

    .line 347
    .line 348
    .line 349
    return-void

    .line 350
    :catchall_0
    move-exception v0

    .line 351
    invoke-interface {v11}, Landroid/database/Cursor;->close()V

    .line 352
    .line 353
    .line 354
    throw v0
.end method
