.class public final L_Bj2ÀE;
.super LnSize9765;
.source "SourceFile"


# instance fields
.field public Ialue:LliiI1li;

.field public gKey4112:LzO;

.field public pCXDYg:Z

.field public valuI:I

.field public yàÒZ:LvO;


# virtual methods
.method public final POOl(J)V
    .locals 4

    .line 1
    iput-wide p1, p0, LnSize9765;->sKey7917:J

    .line 2
    .line 3
    const-wide/16 v0, 0x0

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    cmp-long v3, p1, v0

    .line 7
    .line 8
    if-eqz v3, :cond_0

    .line 9
    .line 10
    const/4 p1, 0x1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 p1, 0x0

    .line 13
    :goto_0
    iput-boolean p1, p0, L_Bj2ÀE;->pCXDYg:Z

    .line 14
    .line 15
    iget-object p1, p0, L_Bj2ÀE;->yàÒZ:LvO;

    .line 16
    .line 17
    if-eqz p1, :cond_1

    .line 18
    .line 19
    iget v2, p1, LvO;->JKEoÙX:I

    .line 20
    .line 21
    :cond_1
    iput v2, p0, L_Bj2ÀE;->valuI:I

    .line 22
    .line 23
    return-void
.end method

.method public final e8$mp_s$(LYizKm;)J
    .locals 12

    .line 1
    iget-object v0, p1, LYizKm;->e8$mp_s$:[B

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    aget-byte v0, v0, v1

    .line 5
    .line 6
    and-int/lit8 v2, v0, 0x1

    .line 7
    .line 8
    const/4 v3, 0x1

    .line 9
    if-ne v2, v3, :cond_0

    .line 10
    .line 11
    const-wide/16 v0, -0x1

    .line 12
    .line 13
    return-wide v0

    .line 14
    :cond_0
    iget-object v2, p0, L_Bj2ÀE;->Ialue:LliiI1li;

    .line 15
    .line 16
    invoke-static {v2}, LvItem3158;->po0(Ljava/lang/Object;)V

    .line 17
    .line 18
    .line 19
    iget-object v4, v2, LliiI1li;->jPos3709:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v4, LvO;

    .line 22
    .line 23
    iget v5, v2, LliiI1li;->vaIue:I

    .line 24
    .line 25
    shr-int/2addr v0, v3

    .line 26
    iget-object v2, v2, LliiI1li;->Ialue:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v2, [LmSize5576;

    .line 29
    .line 30
    const/16 v6, 0xff

    .line 31
    .line 32
    const/16 v7, 0x8

    .line 33
    .line 34
    rsub-int/lit8 v5, v5, 0x8

    .line 35
    .line 36
    ushr-int v5, v6, v5

    .line 37
    .line 38
    and-int/2addr v0, v5

    .line 39
    aget-object v0, v2, v0

    .line 40
    .line 41
    iget-boolean v0, v0, LmSize5576;->vaIue:Z

    .line 42
    .line 43
    if-nez v0, :cond_1

    .line 44
    .line 45
    iget v0, v4, LvO;->JKEoÙX:I

    .line 46
    .line 47
    goto :goto_0

    .line 48
    :cond_1
    iget v0, v4, LvO;->tmpData3485:I

    .line 49
    .line 50
    :goto_0
    iget-boolean v2, p0, L_Bj2ÀE;->pCXDYg:Z

    .line 51
    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    iget v1, p0, L_Bj2ÀE;->valuI:I

    .line 55
    .line 56
    add-int/2addr v1, v0

    .line 57
    div-int/lit8 v1, v1, 0x4

    .line 58
    .line 59
    :cond_2
    iget-object v2, p1, LYizKm;->e8$mp_s$:[B

    .line 60
    .line 61
    array-length v4, v2

    .line 62
    iget v5, p1, LYizKm;->rz__9J_:I

    .line 63
    .line 64
    add-int/lit8 v5, v5, 0x4

    .line 65
    .line 66
    if-ge v4, v5, :cond_3

    .line 67
    .line 68
    invoke-static {v2, v5}, Ljava/util/Arrays;->copyOf([BI)[B

    .line 69
    .line 70
    .line 71
    move-result-object v2

    .line 72
    array-length v4, v2

    .line 73
    invoke-virtual {p1, v4, v2}, LYizKm;->DDù8(I[B)V

    .line 74
    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_3
    invoke-virtual {p1, v5}, LYizKm;->yON3x(I)V

    .line 78
    .line 79
    .line 80
    :goto_1
    int-to-long v1, v1

    .line 81
    iget-object v4, p1, LYizKm;->e8$mp_s$:[B

    .line 82
    .line 83
    iget p1, p1, LYizKm;->rz__9J_:I

    .line 84
    .line 85
    add-int/lit8 v5, p1, -0x4

    .line 86
    .line 87
    const-wide/16 v8, 0xff

    .line 88
    .line 89
    and-long v10, v1, v8

    .line 90
    .line 91
    long-to-int v6, v10

    .line 92
    int-to-byte v6, v6

    .line 93
    aput-byte v6, v4, v5

    .line 94
    .line 95
    add-int/lit8 v5, p1, -0x3

    .line 96
    .line 97
    ushr-long v6, v1, v7

    .line 98
    .line 99
    and-long/2addr v6, v8

    .line 100
    long-to-int v7, v6

    .line 101
    int-to-byte v6, v7

    .line 102
    aput-byte v6, v4, v5

    .line 103
    .line 104
    add-int/lit8 v5, p1, -0x2

    .line 105
    .line 106
    const/16 v6, 0x10

    .line 107
    .line 108
    ushr-long v6, v1, v6

    .line 109
    .line 110
    and-long/2addr v6, v8

    .line 111
    long-to-int v7, v6

    .line 112
    int-to-byte v6, v7

    .line 113
    aput-byte v6, v4, v5

    .line 114
    .line 115
    add-int/lit8 p1, p1, -0x1

    .line 116
    .line 117
    const/16 v5, 0x18

    .line 118
    .line 119
    ushr-long v5, v1, v5

    .line 120
    .line 121
    and-long/2addr v5, v8

    .line 122
    long-to-int v6, v5

    .line 123
    int-to-byte v5, v6

    .line 124
    aput-byte v5, v4, p1

    .line 125
    .line 126
    iput-boolean v3, p0, L_Bj2ÀE;->pCXDYg:Z

    .line 127
    .line 128
    iput v0, p0, L_Bj2ÀE;->valuI:I

    .line 129
    .line 130
    return-wide v1
.end method

.method public final rz__9J_(LYizKm;JLHqc_J$T_;)Z
    .locals 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    iget-object v3, v0, L_Bj2ÀE;->Ialue:LliiI1li;

    .line 8
    .line 9
    const/4 v4, 0x0

    .line 10
    if-eqz v3, :cond_0

    .line 11
    .line 12
    iget-object v1, v2, LHqc_J$T_;->vaIue:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, LgItem9321;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    return v4

    .line 20
    :cond_0
    iget-object v6, v0, L_Bj2ÀE;->yàÒZ:LvO;

    .line 21
    .line 22
    const/4 v5, 0x4

    .line 23
    const/4 v11, 0x1

    .line 24
    if-nez v6, :cond_3

    .line 25
    .line 26
    invoke-static {v11, v1, v4}, LPJNypàa;->dnN$d$(ILYizKm;Z)Z

    .line 27
    .line 28
    .line 29
    invoke-virtual {v1}, LYizKm;->kO_6X_()I

    .line 30
    .line 31
    .line 32
    invoke-virtual {v1}, LYizKm;->UC_n_()I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    invoke-virtual {v1}, LYizKm;->kO_6X_()I

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    invoke-virtual {v1}, LYizKm;->gKey4112()I

    .line 41
    .line 42
    .line 43
    move-result v8

    .line 44
    if-gtz v8, :cond_1

    .line 45
    .line 46
    const/4 v8, -0x1

    .line 47
    :cond_1
    invoke-virtual {v1}, LYizKm;->gKey4112()I

    .line 48
    .line 49
    .line 50
    move-result v9

    .line 51
    if-gtz v9, :cond_2

    .line 52
    .line 53
    const/4 v3, -0x1

    .line 54
    goto :goto_0

    .line 55
    :cond_2
    move v3, v9

    .line 56
    :goto_0
    invoke-virtual {v1}, LYizKm;->gKey4112()I

    .line 57
    .line 58
    .line 59
    invoke-virtual {v1}, LYizKm;->UC_n_()I

    .line 60
    .line 61
    .line 62
    move-result v9

    .line 63
    and-int/lit8 v10, v9, 0xf

    .line 64
    .line 65
    int-to-double v12, v10

    .line 66
    const-wide/high16 v14, 0x4000000000000000L    # 2.0

    .line 67
    .line 68
    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->pow(DD)D

    .line 69
    .line 70
    .line 71
    move-result-wide v12

    .line 72
    double-to-int v10, v12

    .line 73
    and-int/lit16 v9, v9, 0xf0

    .line 74
    .line 75
    shr-int/lit8 v5, v9, 0x4

    .line 76
    .line 77
    int-to-double v12, v5

    .line 78
    invoke-static {v14, v15, v12, v13}, Ljava/lang/Math;->pow(DD)D

    .line 79
    .line 80
    .line 81
    move-result-wide v12

    .line 82
    double-to-int v5, v12

    .line 83
    invoke-virtual {v1}, LYizKm;->UC_n_()I

    .line 84
    .line 85
    .line 86
    iget-object v9, v1, LYizKm;->e8$mp_s$:[B

    .line 87
    .line 88
    iget v1, v1, LYizKm;->rz__9J_:I

    .line 89
    .line 90
    invoke-static {v9, v1}, Ljava/util/Arrays;->copyOf([BI)[B

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    new-instance v9, LvO;

    .line 95
    .line 96
    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    .line 97
    .line 98
    .line 99
    iput v4, v9, LvO;->e8$mp_s$:I

    .line 100
    .line 101
    iput v6, v9, LvO;->waiBKÀ:I

    .line 102
    .line 103
    iput v8, v9, LvO;->rz__9J_:I

    .line 104
    .line 105
    iput v3, v9, LvO;->POOl:I

    .line 106
    .line 107
    iput v10, v9, LvO;->JKEoÙX:I

    .line 108
    .line 109
    iput v5, v9, LvO;->tmpData3485:I

    .line 110
    .line 111
    iput-object v1, v9, LvO;->sKey7917:Ljava/io/Serializable;

    .line 112
    .line 113
    iput-object v9, v0, L_Bj2ÀE;->yàÒZ:LvO;

    .line 114
    .line 115
    :goto_1
    const/4 v7, 0x0

    .line 116
    goto/16 :goto_22

    .line 117
    .line 118
    :cond_3
    iget-object v8, v0, L_Bj2ÀE;->gKey4112:LzO;

    .line 119
    .line 120
    if-nez v8, :cond_4

    .line 121
    .line 122
    invoke-static {v1, v11, v11}, LPJNypàa;->gCount1961(LYizKm;ZZ)LzO;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    iput-object v1, v0, L_Bj2ÀE;->gKey4112:LzO;

    .line 127
    .line 128
    goto :goto_1

    .line 129
    :cond_4
    iget v9, v1, LYizKm;->rz__9J_:I

    .line 130
    .line 131
    move-object v10, v8

    .line 132
    new-array v8, v9, [B

    .line 133
    .line 134
    iget-object v12, v1, LYizKm;->e8$mp_s$:[B

    .line 135
    .line 136
    invoke-static {v12, v4, v8, v4, v9}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 137
    .line 138
    .line 139
    iget v9, v6, LvO;->e8$mp_s$:I

    .line 140
    .line 141
    const/4 v12, 0x5

    .line 142
    invoke-static {v12, v1, v4}, LPJNypàa;->dnN$d$(ILYizKm;Z)Z

    .line 143
    .line 144
    .line 145
    invoke-virtual {v1}, LYizKm;->UC_n_()I

    .line 146
    .line 147
    .line 148
    move-result v13

    .line 149
    add-int/2addr v13, v11

    .line 150
    new-instance v14, LZKy6àp;

    .line 151
    .line 152
    iget-object v15, v1, LYizKm;->e8$mp_s$:[B

    .line 153
    .line 154
    invoke-direct {v14, v15}, LZKy6àp;-><init>([B)V

    .line 155
    .line 156
    .line 157
    iget v1, v1, LYizKm;->waiBKÀ:I

    .line 158
    .line 159
    const/16 v15, 0x8

    .line 160
    .line 161
    mul-int/lit8 v1, v1, 0x8

    .line 162
    .line 163
    invoke-virtual {v14, v1}, LZKy6àp;->JKEoÙX(I)V

    .line 164
    .line 165
    .line 166
    const/4 v1, 0x0

    .line 167
    :goto_2
    const/16 v3, 0x18

    .line 168
    .line 169
    const/4 v4, 0x2

    .line 170
    const/16 p1, 0x8

    .line 171
    .line 172
    const/16 v15, 0x10

    .line 173
    .line 174
    if-ge v1, v13, :cond_10

    .line 175
    .line 176
    invoke-virtual {v14, v3}, LZKy6àp;->POOl(I)I

    .line 177
    .line 178
    .line 179
    move-result v7

    .line 180
    const v11, 0x564342

    .line 181
    .line 182
    .line 183
    if-ne v7, v11, :cond_f

    .line 184
    .line 185
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 186
    .line 187
    .line 188
    move-result v7

    .line 189
    invoke-virtual {v14, v3}, LZKy6àp;->POOl(I)I

    .line 190
    .line 191
    .line 192
    move-result v3

    .line 193
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 194
    .line 195
    .line 196
    move-result v11

    .line 197
    if-nez v11, :cond_7

    .line 198
    .line 199
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 200
    .line 201
    .line 202
    move-result v11

    .line 203
    const/4 v15, 0x0

    .line 204
    :goto_3
    if-ge v15, v3, :cond_9

    .line 205
    .line 206
    if-eqz v11, :cond_5

    .line 207
    .line 208
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 209
    .line 210
    .line 211
    move-result v17

    .line 212
    if-eqz v17, :cond_6

    .line 213
    .line 214
    invoke-virtual {v14, v12}, LZKy6àp;->JKEoÙX(I)V

    .line 215
    .line 216
    .line 217
    goto :goto_4

    .line 218
    :cond_5
    invoke-virtual {v14, v12}, LZKy6àp;->JKEoÙX(I)V

    .line 219
    .line 220
    .line 221
    :cond_6
    :goto_4
    add-int/lit8 v15, v15, 0x1

    .line 222
    .line 223
    goto :goto_3

    .line 224
    :cond_7
    invoke-virtual {v14, v12}, LZKy6àp;->JKEoÙX(I)V

    .line 225
    .line 226
    .line 227
    const/4 v11, 0x0

    .line 228
    :goto_5
    if-ge v11, v3, :cond_9

    .line 229
    .line 230
    sub-int v15, v3, v11

    .line 231
    .line 232
    const/4 v12, 0x0

    .line 233
    :goto_6
    if-lez v15, :cond_8

    .line 234
    .line 235
    ushr-int/lit8 v15, v15, 0x1

    .line 236
    .line 237
    add-int/lit8 v12, v12, 0x1

    .line 238
    .line 239
    goto :goto_6

    .line 240
    :cond_8
    invoke-virtual {v14, v12}, LZKy6àp;->POOl(I)I

    .line 241
    .line 242
    .line 243
    move-result v12

    .line 244
    add-int/2addr v11, v12

    .line 245
    const/4 v12, 0x5

    .line 246
    goto :goto_5

    .line 247
    :cond_9
    invoke-virtual {v14, v5}, LZKy6àp;->POOl(I)I

    .line 248
    .line 249
    .line 250
    move-result v11

    .line 251
    if-gt v11, v4, :cond_e

    .line 252
    .line 253
    const/4 v12, 0x1

    .line 254
    if-eq v11, v12, :cond_b

    .line 255
    .line 256
    if-ne v11, v4, :cond_a

    .line 257
    .line 258
    goto :goto_7

    .line 259
    :cond_a
    move-object v12, v6

    .line 260
    goto :goto_9

    .line 261
    :cond_b
    move v4, v11

    .line 262
    :goto_7
    const/16 v11, 0x20

    .line 263
    .line 264
    invoke-virtual {v14, v11}, LZKy6àp;->JKEoÙX(I)V

    .line 265
    .line 266
    .line 267
    invoke-virtual {v14, v11}, LZKy6àp;->JKEoÙX(I)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v14, v5}, LZKy6àp;->POOl(I)I

    .line 271
    .line 272
    .line 273
    move-result v11

    .line 274
    add-int/2addr v11, v12

    .line 275
    invoke-virtual {v14, v12}, LZKy6àp;->JKEoÙX(I)V

    .line 276
    .line 277
    .line 278
    if-ne v4, v12, :cond_d

    .line 279
    .line 280
    if-eqz v7, :cond_c

    .line 281
    .line 282
    int-to-long v3, v3

    .line 283
    move-object v12, v6

    .line 284
    int-to-long v5, v7

    .line 285
    long-to-double v5, v5

    .line 286
    long-to-double v3, v3

    .line 287
    const-wide/high16 v18, 0x3ff0000000000000L    # 1.0

    .line 288
    .line 289
    div-double v5, v18, v5

    .line 290
    .line 291
    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->pow(DD)D

    .line 292
    .line 293
    .line 294
    move-result-wide v3

    .line 295
    invoke-static {v3, v4}, Ljava/lang/Math;->floor(D)D

    .line 296
    .line 297
    .line 298
    move-result-wide v3

    .line 299
    double-to-long v3, v3

    .line 300
    goto :goto_8

    .line 301
    :cond_c
    move-object v12, v6

    .line 302
    const-wide/16 v3, 0x0

    .line 303
    .line 304
    goto :goto_8

    .line 305
    :cond_d
    move-object v12, v6

    .line 306
    int-to-long v4, v7

    .line 307
    int-to-long v6, v3

    .line 308
    mul-long v3, v6, v4

    .line 309
    .line 310
    :goto_8
    int-to-long v5, v11

    .line 311
    mul-long v3, v3, v5

    .line 312
    .line 313
    long-to-int v4, v3

    .line 314
    invoke-virtual {v14, v4}, LZKy6àp;->JKEoÙX(I)V

    .line 315
    .line 316
    .line 317
    :goto_9
    add-int/lit8 v1, v1, 0x1

    .line 318
    .line 319
    move-object v6, v12

    .line 320
    const/4 v4, 0x0

    .line 321
    const/4 v5, 0x4

    .line 322
    const/4 v11, 0x1

    .line 323
    const/4 v12, 0x5

    .line 324
    const/16 v15, 0x8

    .line 325
    .line 326
    goto/16 :goto_2

    .line 327
    .line 328
    :cond_e
    new-instance v1, Ljava/lang/StringBuilder;

    .line 329
    .line 330
    const-string v2, "lookup type greater than 2 not decodable: "

    .line 331
    .line 332
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v1, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 336
    .line 337
    .line 338
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v1

    .line 342
    const/4 v2, 0x0

    .line 343
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 344
    .line 345
    .line 346
    move-result-object v1

    .line 347
    throw v1

    .line 348
    :cond_f
    const/4 v2, 0x0

    .line 349
    iget v1, v14, LZKy6àp;->POOl:I

    .line 350
    .line 351
    mul-int/lit8 v1, v1, 0x8

    .line 352
    .line 353
    iget v3, v14, LZKy6àp;->JKEoÙX:I

    .line 354
    .line 355
    add-int/2addr v1, v3

    .line 356
    new-instance v3, Ljava/lang/StringBuilder;

    .line 357
    .line 358
    const-string v4, "expected code book to start with [0x56, 0x43, 0x42] at "

    .line 359
    .line 360
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 364
    .line 365
    .line 366
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 367
    .line 368
    .line 369
    move-result-object v1

    .line 370
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 371
    .line 372
    .line 373
    move-result-object v1

    .line 374
    throw v1

    .line 375
    :cond_10
    move-object v12, v6

    .line 376
    const/4 v1, 0x6

    .line 377
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 378
    .line 379
    .line 380
    move-result v5

    .line 381
    const/16 v16, 0x1

    .line 382
    .line 383
    add-int/lit8 v5, v5, 0x1

    .line 384
    .line 385
    const/4 v6, 0x0

    .line 386
    :goto_a
    if-ge v6, v5, :cond_12

    .line 387
    .line 388
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 389
    .line 390
    .line 391
    move-result v7

    .line 392
    if-nez v7, :cond_11

    .line 393
    .line 394
    add-int/lit8 v6, v6, 0x1

    .line 395
    .line 396
    goto :goto_a

    .line 397
    :cond_11
    const-string v1, "placeholder of time domain transforms not zeroed out"

    .line 398
    .line 399
    const/4 v2, 0x0

    .line 400
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 401
    .line 402
    .line 403
    move-result-object v1

    .line 404
    throw v1

    .line 405
    :cond_12
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 406
    .line 407
    .line 408
    move-result v5

    .line 409
    const/4 v6, 0x1

    .line 410
    add-int/2addr v5, v6

    .line 411
    const/4 v7, 0x0

    .line 412
    :goto_b
    const/4 v11, 0x3

    .line 413
    if-ge v7, v5, :cond_1c

    .line 414
    .line 415
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 416
    .line 417
    .line 418
    move-result v13

    .line 419
    if-eqz v13, :cond_1a

    .line 420
    .line 421
    if-ne v13, v6, :cond_19

    .line 422
    .line 423
    const/4 v6, 0x5

    .line 424
    invoke-virtual {v14, v6}, LZKy6àp;->POOl(I)I

    .line 425
    .line 426
    .line 427
    move-result v13

    .line 428
    new-array v6, v13, [I

    .line 429
    .line 430
    const/4 v1, -0x1

    .line 431
    const/4 v3, 0x0

    .line 432
    :goto_c
    if-ge v3, v13, :cond_14

    .line 433
    .line 434
    const/4 v15, 0x4

    .line 435
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 436
    .line 437
    .line 438
    move-result v4

    .line 439
    aput v4, v6, v3

    .line 440
    .line 441
    if-le v4, v1, :cond_13

    .line 442
    .line 443
    move v1, v4

    .line 444
    :cond_13
    add-int/lit8 v3, v3, 0x1

    .line 445
    .line 446
    const/4 v4, 0x2

    .line 447
    const/16 v15, 0x10

    .line 448
    .line 449
    goto :goto_c

    .line 450
    :cond_14
    add-int/lit8 v1, v1, 0x1

    .line 451
    .line 452
    new-array v3, v1, [I

    .line 453
    .line 454
    const/4 v4, 0x0

    .line 455
    :goto_d
    if-ge v4, v1, :cond_17

    .line 456
    .line 457
    invoke-virtual {v14, v11}, LZKy6àp;->POOl(I)I

    .line 458
    .line 459
    .line 460
    move-result v15

    .line 461
    const/16 v16, 0x1

    .line 462
    .line 463
    add-int/lit8 v15, v15, 0x1

    .line 464
    .line 465
    aput v15, v3, v4

    .line 466
    .line 467
    const/4 v15, 0x2

    .line 468
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 469
    .line 470
    .line 471
    move-result v20

    .line 472
    if-lez v20, :cond_15

    .line 473
    .line 474
    const/16 v15, 0x8

    .line 475
    .line 476
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 477
    .line 478
    .line 479
    :goto_e
    move/from16 v21, v1

    .line 480
    .line 481
    const/4 v11, 0x0

    .line 482
    goto :goto_f

    .line 483
    :cond_15
    const/16 v15, 0x8

    .line 484
    .line 485
    goto :goto_e

    .line 486
    :goto_f
    shl-int v1, v16, v20

    .line 487
    .line 488
    if-ge v11, v1, :cond_16

    .line 489
    .line 490
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 491
    .line 492
    .line 493
    add-int/lit8 v11, v11, 0x1

    .line 494
    .line 495
    const/16 v15, 0x8

    .line 496
    .line 497
    const/16 v16, 0x1

    .line 498
    .line 499
    goto :goto_f

    .line 500
    :cond_16
    add-int/lit8 v4, v4, 0x1

    .line 501
    .line 502
    move/from16 v1, v21

    .line 503
    .line 504
    const/16 p1, 0x8

    .line 505
    .line 506
    const/4 v11, 0x3

    .line 507
    goto :goto_d

    .line 508
    :cond_17
    const/4 v15, 0x2

    .line 509
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 510
    .line 511
    .line 512
    const/4 v15, 0x4

    .line 513
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 514
    .line 515
    .line 516
    move-result v1

    .line 517
    const/4 v4, 0x0

    .line 518
    const/4 v11, 0x0

    .line 519
    const/4 v15, 0x0

    .line 520
    :goto_10
    if-ge v4, v13, :cond_1b

    .line 521
    .line 522
    aget v20, v6, v4

    .line 523
    .line 524
    aget v20, v3, v20

    .line 525
    .line 526
    add-int v11, v11, v20

    .line 527
    .line 528
    :goto_11
    if-ge v15, v11, :cond_18

    .line 529
    .line 530
    invoke-virtual {v14, v1}, LZKy6àp;->JKEoÙX(I)V

    .line 531
    .line 532
    .line 533
    add-int/lit8 v15, v15, 0x1

    .line 534
    .line 535
    goto :goto_11

    .line 536
    :cond_18
    add-int/lit8 v4, v4, 0x1

    .line 537
    .line 538
    goto :goto_10

    .line 539
    :cond_19
    new-instance v1, Ljava/lang/StringBuilder;

    .line 540
    .line 541
    const-string v2, "floor type greater than 1 not decodable: "

    .line 542
    .line 543
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 547
    .line 548
    .line 549
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 550
    .line 551
    .line 552
    move-result-object v1

    .line 553
    const/4 v2, 0x0

    .line 554
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 555
    .line 556
    .line 557
    move-result-object v1

    .line 558
    throw v1

    .line 559
    :cond_1a
    const/16 v15, 0x8

    .line 560
    .line 561
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 562
    .line 563
    .line 564
    const/16 v1, 0x10

    .line 565
    .line 566
    invoke-virtual {v14, v1}, LZKy6àp;->JKEoÙX(I)V

    .line 567
    .line 568
    .line 569
    invoke-virtual {v14, v1}, LZKy6àp;->JKEoÙX(I)V

    .line 570
    .line 571
    .line 572
    const/4 v1, 0x6

    .line 573
    invoke-virtual {v14, v1}, LZKy6àp;->JKEoÙX(I)V

    .line 574
    .line 575
    .line 576
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 577
    .line 578
    .line 579
    const/4 v1, 0x4

    .line 580
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 581
    .line 582
    .line 583
    move-result v3

    .line 584
    const/16 v16, 0x1

    .line 585
    .line 586
    add-int/lit8 v3, v3, 0x1

    .line 587
    .line 588
    const/4 v1, 0x0

    .line 589
    :goto_12
    if-ge v1, v3, :cond_1b

    .line 590
    .line 591
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 592
    .line 593
    .line 594
    add-int/lit8 v1, v1, 0x1

    .line 595
    .line 596
    const/16 v15, 0x8

    .line 597
    .line 598
    goto :goto_12

    .line 599
    :cond_1b
    add-int/lit8 v7, v7, 0x1

    .line 600
    .line 601
    const/16 p1, 0x8

    .line 602
    .line 603
    const/4 v1, 0x6

    .line 604
    const/16 v3, 0x18

    .line 605
    .line 606
    const/4 v4, 0x2

    .line 607
    const/4 v6, 0x1

    .line 608
    const/16 v15, 0x10

    .line 609
    .line 610
    goto/16 :goto_b

    .line 611
    .line 612
    :cond_1c
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 613
    .line 614
    .line 615
    move-result v3

    .line 616
    const/16 v16, 0x1

    .line 617
    .line 618
    add-int/lit8 v3, v3, 0x1

    .line 619
    .line 620
    const/4 v4, 0x0

    .line 621
    :goto_13
    if-ge v4, v3, :cond_23

    .line 622
    .line 623
    const/16 v5, 0x10

    .line 624
    .line 625
    invoke-virtual {v14, v5}, LZKy6àp;->POOl(I)I

    .line 626
    .line 627
    .line 628
    move-result v6

    .line 629
    const/4 v15, 0x2

    .line 630
    if-gt v6, v15, :cond_22

    .line 631
    .line 632
    const/16 v5, 0x18

    .line 633
    .line 634
    invoke-virtual {v14, v5}, LZKy6àp;->JKEoÙX(I)V

    .line 635
    .line 636
    .line 637
    invoke-virtual {v14, v5}, LZKy6àp;->JKEoÙX(I)V

    .line 638
    .line 639
    .line 640
    invoke-virtual {v14, v5}, LZKy6àp;->JKEoÙX(I)V

    .line 641
    .line 642
    .line 643
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 644
    .line 645
    .line 646
    move-result v6

    .line 647
    add-int/lit8 v6, v6, 0x1

    .line 648
    .line 649
    const/16 v15, 0x8

    .line 650
    .line 651
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 652
    .line 653
    .line 654
    new-array v1, v6, [I

    .line 655
    .line 656
    const/4 v7, 0x0

    .line 657
    :goto_14
    if-ge v7, v6, :cond_1e

    .line 658
    .line 659
    const/4 v11, 0x3

    .line 660
    invoke-virtual {v14, v11}, LZKy6àp;->POOl(I)I

    .line 661
    .line 662
    .line 663
    move-result v13

    .line 664
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 665
    .line 666
    .line 667
    move-result v18

    .line 668
    if-eqz v18, :cond_1d

    .line 669
    .line 670
    const/4 v5, 0x5

    .line 671
    invoke-virtual {v14, v5}, LZKy6àp;->POOl(I)I

    .line 672
    .line 673
    .line 674
    move-result v17

    .line 675
    goto :goto_15

    .line 676
    :cond_1d
    const/4 v5, 0x5

    .line 677
    const/16 v17, 0x0

    .line 678
    .line 679
    :goto_15
    mul-int/lit8 v17, v17, 0x8

    .line 680
    .line 681
    add-int v17, v17, v13

    .line 682
    .line 683
    aput v17, v1, v7

    .line 684
    .line 685
    add-int/lit8 v7, v7, 0x1

    .line 686
    .line 687
    const/16 v5, 0x18

    .line 688
    .line 689
    goto :goto_14

    .line 690
    :cond_1e
    const/4 v5, 0x5

    .line 691
    const/4 v11, 0x3

    .line 692
    const/4 v7, 0x0

    .line 693
    :goto_16
    if-ge v7, v6, :cond_21

    .line 694
    .line 695
    const/4 v13, 0x0

    .line 696
    :goto_17
    if-ge v13, v15, :cond_20

    .line 697
    .line 698
    aget v17, v1, v7

    .line 699
    .line 700
    const/16 v16, 0x1

    .line 701
    .line 702
    shl-int v20, v16, v13

    .line 703
    .line 704
    and-int v17, v17, v20

    .line 705
    .line 706
    if-eqz v17, :cond_1f

    .line 707
    .line 708
    invoke-virtual {v14, v15}, LZKy6àp;->JKEoÙX(I)V

    .line 709
    .line 710
    .line 711
    :cond_1f
    add-int/lit8 v13, v13, 0x1

    .line 712
    .line 713
    const/16 v15, 0x8

    .line 714
    .line 715
    goto :goto_17

    .line 716
    :cond_20
    add-int/lit8 v7, v7, 0x1

    .line 717
    .line 718
    const/16 v15, 0x8

    .line 719
    .line 720
    goto :goto_16

    .line 721
    :cond_21
    add-int/lit8 v4, v4, 0x1

    .line 722
    .line 723
    const/4 v1, 0x6

    .line 724
    const/16 v16, 0x1

    .line 725
    .line 726
    goto :goto_13

    .line 727
    :cond_22
    const-string v1, "residueType greater than 2 is not decodable"

    .line 728
    .line 729
    const/4 v2, 0x0

    .line 730
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 731
    .line 732
    .line 733
    move-result-object v1

    .line 734
    throw v1

    .line 735
    :cond_23
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 736
    .line 737
    .line 738
    move-result v3

    .line 739
    const/16 v16, 0x1

    .line 740
    .line 741
    add-int/lit8 v3, v3, 0x1

    .line 742
    .line 743
    const/4 v1, 0x0

    .line 744
    :goto_18
    if-ge v1, v3, :cond_2c

    .line 745
    .line 746
    const/16 v5, 0x10

    .line 747
    .line 748
    invoke-virtual {v14, v5}, LZKy6àp;->POOl(I)I

    .line 749
    .line 750
    .line 751
    move-result v4

    .line 752
    if-eqz v4, :cond_24

    .line 753
    .line 754
    new-instance v5, Ljava/lang/StringBuilder;

    .line 755
    .line 756
    const-string v6, "mapping type other than 0 not supported: "

    .line 757
    .line 758
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 759
    .line 760
    .line 761
    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 762
    .line 763
    .line 764
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 765
    .line 766
    .line 767
    move-result-object v4

    .line 768
    invoke-static {v4}, Lzl1;->vz$a$(Ljava/lang/String;)V

    .line 769
    .line 770
    .line 771
    const/4 v6, 0x4

    .line 772
    const/4 v15, 0x2

    .line 773
    goto/16 :goto_1f

    .line 774
    .line 775
    :cond_24
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 776
    .line 777
    .line 778
    move-result v4

    .line 779
    if-eqz v4, :cond_25

    .line 780
    .line 781
    const/4 v15, 0x4

    .line 782
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 783
    .line 784
    .line 785
    move-result v4

    .line 786
    const/16 v16, 0x1

    .line 787
    .line 788
    add-int/lit8 v4, v4, 0x1

    .line 789
    .line 790
    goto :goto_19

    .line 791
    :cond_25
    const/16 v16, 0x1

    .line 792
    .line 793
    const/4 v4, 0x1

    .line 794
    :goto_19
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 795
    .line 796
    .line 797
    move-result v5

    .line 798
    if-eqz v5, :cond_28

    .line 799
    .line 800
    const/16 v15, 0x8

    .line 801
    .line 802
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 803
    .line 804
    .line 805
    move-result v5

    .line 806
    add-int/lit8 v5, v5, 0x1

    .line 807
    .line 808
    const/4 v6, 0x0

    .line 809
    :goto_1a
    if-ge v6, v5, :cond_28

    .line 810
    .line 811
    add-int/lit8 v7, v9, -0x1

    .line 812
    .line 813
    move v11, v7

    .line 814
    const/4 v13, 0x0

    .line 815
    :goto_1b
    if-lez v11, :cond_26

    .line 816
    .line 817
    ushr-int/lit8 v11, v11, 0x1

    .line 818
    .line 819
    add-int/lit8 v13, v13, 0x1

    .line 820
    .line 821
    goto :goto_1b

    .line 822
    :cond_26
    invoke-virtual {v14, v13}, LZKy6àp;->JKEoÙX(I)V

    .line 823
    .line 824
    .line 825
    const/4 v11, 0x0

    .line 826
    :goto_1c
    if-lez v7, :cond_27

    .line 827
    .line 828
    ushr-int/lit8 v7, v7, 0x1

    .line 829
    .line 830
    add-int/lit8 v11, v11, 0x1

    .line 831
    .line 832
    goto :goto_1c

    .line 833
    :cond_27
    invoke-virtual {v14, v11}, LZKy6àp;->JKEoÙX(I)V

    .line 834
    .line 835
    .line 836
    add-int/lit8 v6, v6, 0x1

    .line 837
    .line 838
    goto :goto_1a

    .line 839
    :cond_28
    const/4 v15, 0x2

    .line 840
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 841
    .line 842
    .line 843
    move-result v5

    .line 844
    if-nez v5, :cond_2b

    .line 845
    .line 846
    const/4 v6, 0x1

    .line 847
    if-le v4, v6, :cond_29

    .line 848
    .line 849
    const/4 v5, 0x0

    .line 850
    :goto_1d
    if-ge v5, v9, :cond_29

    .line 851
    .line 852
    const/4 v6, 0x4

    .line 853
    invoke-virtual {v14, v6}, LZKy6àp;->JKEoÙX(I)V

    .line 854
    .line 855
    .line 856
    add-int/lit8 v5, v5, 0x1

    .line 857
    .line 858
    goto :goto_1d

    .line 859
    :cond_29
    const/4 v6, 0x4

    .line 860
    const/4 v5, 0x0

    .line 861
    :goto_1e
    if-ge v5, v4, :cond_2a

    .line 862
    .line 863
    const/16 v7, 0x8

    .line 864
    .line 865
    invoke-virtual {v14, v7}, LZKy6àp;->JKEoÙX(I)V

    .line 866
    .line 867
    .line 868
    invoke-virtual {v14, v7}, LZKy6àp;->JKEoÙX(I)V

    .line 869
    .line 870
    .line 871
    invoke-virtual {v14, v7}, LZKy6àp;->JKEoÙX(I)V

    .line 872
    .line 873
    .line 874
    add-int/lit8 v5, v5, 0x1

    .line 875
    .line 876
    goto :goto_1e

    .line 877
    :cond_2a
    :goto_1f
    add-int/lit8 v1, v1, 0x1

    .line 878
    .line 879
    goto/16 :goto_18

    .line 880
    .line 881
    :cond_2b
    const-string v1, "to reserved bits must be zero after mapping coupling steps"

    .line 882
    .line 883
    const/4 v2, 0x0

    .line 884
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 885
    .line 886
    .line 887
    move-result-object v1

    .line 888
    throw v1

    .line 889
    :cond_2c
    const/4 v1, 0x6

    .line 890
    invoke-virtual {v14, v1}, LZKy6àp;->POOl(I)I

    .line 891
    .line 892
    .line 893
    move-result v1

    .line 894
    add-int/lit8 v3, v1, 0x1

    .line 895
    .line 896
    new-array v9, v3, [LmSize5576;

    .line 897
    .line 898
    const/4 v4, 0x0

    .line 899
    :goto_20
    if-ge v4, v3, :cond_2d

    .line 900
    .line 901
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 902
    .line 903
    .line 904
    move-result v5

    .line 905
    const/16 v6, 0x10

    .line 906
    .line 907
    invoke-virtual {v14, v6}, LZKy6àp;->POOl(I)I

    .line 908
    .line 909
    .line 910
    invoke-virtual {v14, v6}, LZKy6àp;->POOl(I)I

    .line 911
    .line 912
    .line 913
    const/16 v15, 0x8

    .line 914
    .line 915
    invoke-virtual {v14, v15}, LZKy6àp;->POOl(I)I

    .line 916
    .line 917
    .line 918
    new-instance v7, LmSize5576;

    .line 919
    .line 920
    const/4 v11, 0x0

    .line 921
    invoke-direct {v7, v5, v11}, LmSize5576;-><init>(ZI)V

    .line 922
    .line 923
    .line 924
    aput-object v7, v9, v4

    .line 925
    .line 926
    add-int/lit8 v4, v4, 0x1

    .line 927
    .line 928
    goto :goto_20

    .line 929
    :cond_2d
    invoke-virtual {v14}, LZKy6àp;->sKey7917()Z

    .line 930
    .line 931
    .line 932
    move-result v3

    .line 933
    if-eqz v3, :cond_30

    .line 934
    .line 935
    new-instance v5, LliiI1li;

    .line 936
    .line 937
    const/4 v4, 0x0

    .line 938
    :goto_21
    if-lez v1, :cond_2e

    .line 939
    .line 940
    ushr-int/lit8 v1, v1, 0x1

    .line 941
    .line 942
    add-int/lit8 v4, v4, 0x1

    .line 943
    .line 944
    goto :goto_21

    .line 945
    :cond_2e
    move-object v7, v10

    .line 946
    move-object v6, v12

    .line 947
    move v10, v4

    .line 948
    invoke-direct/range {v5 .. v10}, LliiI1li;-><init>(LvO;LzO;[B[LmSize5576;I)V

    .line 949
    .line 950
    .line 951
    move-object v7, v5

    .line 952
    :goto_22
    iput-object v7, v0, L_Bj2ÀE;->Ialue:LliiI1li;

    .line 953
    .line 954
    if-nez v7, :cond_2f

    .line 955
    .line 956
    const/16 v16, 0x1

    .line 957
    .line 958
    return v16

    .line 959
    :cond_2f
    new-instance v1, Ljava/util/ArrayList;

    .line 960
    .line 961
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 962
    .line 963
    .line 964
    iget-object v3, v7, LliiI1li;->jPos3709:Ljava/lang/Object;

    .line 965
    .line 966
    check-cast v3, LvO;

    .line 967
    .line 968
    iget-object v4, v3, LvO;->sKey7917:Ljava/io/Serializable;

    .line 969
    .line 970
    check-cast v4, [B

    .line 971
    .line 972
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 973
    .line 974
    .line 975
    iget-object v4, v7, LliiI1li;->kQy:Ljava/lang/Object;

    .line 976
    .line 977
    check-cast v4, [B

    .line 978
    .line 979
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 980
    .line 981
    .line 982
    iget-object v4, v7, LliiI1li;->iOffset934:Ljava/lang/Object;

    .line 983
    .line 984
    check-cast v4, LzO;

    .line 985
    .line 986
    iget-object v4, v4, LzO;->yON3x:[Ljava/lang/String;

    .line 987
    .line 988
    invoke-static {v4}, LnW_cN_;->iOffset934([Ljava/lang/Object;)LlII1II;

    .line 989
    .line 990
    .line 991
    move-result-object v4

    .line 992
    invoke-static {v4}, LPJNypàa;->Txy$$d_w$(Ljava/util/List;)LDL_90$g_;

    .line 993
    .line 994
    .line 995
    move-result-object v4

    .line 996
    new-instance v5, LtmpOffset9868;

    .line 997
    .line 998
    invoke-direct {v5}, LtmpOffset9868;-><init>()V

    .line 999
    .line 1000
    .line 1001
    const-string v6, "audio/vorbis"

    .line 1002
    .line 1003
    invoke-virtual {v5, v6}, LtmpOffset9868;->rz__9J_(Ljava/lang/String;)V

    .line 1004
    .line 1005
    .line 1006
    iget v6, v3, LvO;->POOl:I

    .line 1007
    .line 1008
    iput v6, v5, LtmpOffset9868;->sKey7917:I

    .line 1009
    .line 1010
    iget v6, v3, LvO;->rz__9J_:I

    .line 1011
    .line 1012
    iput v6, v5, LtmpOffset9868;->DDù8:I

    .line 1013
    .line 1014
    iget v6, v3, LvO;->e8$mp_s$:I

    .line 1015
    .line 1016
    iput v6, v5, LtmpOffset9868;->sKey6064:I

    .line 1017
    .line 1018
    iget v3, v3, LvO;->waiBKÀ:I

    .line 1019
    .line 1020
    iput v3, v5, LtmpOffset9868;->tzKù7Ol1:I

    .line 1021
    .line 1022
    iput-object v1, v5, LtmpOffset9868;->valuI:Ljava/util/List;

    .line 1023
    .line 1024
    iput-object v4, v5, LtmpOffset9868;->vaIue:LDL_90$g_;

    .line 1025
    .line 1026
    new-instance v1, LgItem9321;

    .line 1027
    .line 1028
    invoke-direct {v1, v5}, LgItem9321;-><init>(LtmpOffset9868;)V

    .line 1029
    .line 1030
    .line 1031
    iput-object v1, v2, LHqc_J$T_;->vaIue:Ljava/lang/Object;

    .line 1032
    .line 1033
    const/16 v16, 0x1

    .line 1034
    .line 1035
    return v16

    .line 1036
    :cond_30
    const-string v1, "framing bit after modes not set as expected"

    .line 1037
    .line 1038
    const/4 v2, 0x0

    .line 1039
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 1040
    .line 1041
    .line 1042
    move-result-object v1

    .line 1043
    throw v1
.end method

.method public final waiBKÀ(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, LnSize9765;->waiBKÀ(Z)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_0

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, L_Bj2ÀE;->Ialue:LliiI1li;

    .line 8
    .line 9
    iput-object p1, p0, L_Bj2ÀE;->yàÒZ:LvO;

    .line 10
    .line 11
    iput-object p1, p0, L_Bj2ÀE;->gKey4112:LzO;

    .line 12
    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    iput p1, p0, L_Bj2ÀE;->valuI:I

    .line 15
    .line 16
    iput-boolean p1, p0, L_Bj2ÀE;->pCXDYg:Z

    .line 17
    .line 18
    return-void
.end method
