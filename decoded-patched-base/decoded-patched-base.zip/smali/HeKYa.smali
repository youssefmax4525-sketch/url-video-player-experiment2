.class public abstract LHeKYa;
.super Ljava/lang/Object;
.source "SourceFile"
