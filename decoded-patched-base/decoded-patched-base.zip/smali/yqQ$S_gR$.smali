.class public interface abstract LyqQ$S_gR$;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract ChI_KH_(Z)V
.end method

.method public abstract Ialue()Z
.end method

.method public abstract JKEoÙX()LvSize2258;
.end method

.method public abstract gKey4112()Z
.end method

.method public abstract iOffset934()V
.end method

.method public abstract jPos3709()V
.end method

.method public abstract kO_6X_()Z
.end method

.method public abstract pCXDYg()V
.end method

.method public abstract rz__9J_()F
.end method

.method public abstract sKey7917()I
.end method

.method public abstract tmpData3485()F
.end method

.method public abstract val0e(LvSize2258;)V
.end method

.method public abstract waiBKÀ()F
.end method
