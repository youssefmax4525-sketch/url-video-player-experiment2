.class public final LmKey9057;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LiValue784;


# instance fields
.field public DDù8:I

.field public Ialue:I

.field public JKEoÙX:LwÒJK;

.field public K0I:J

.field public final POOl:LZKy6àp;

.field public Qp_Hp$i_:I

.field public UC_n_:Ljava/lang/String;

.field public final e8$mp_s$:Ljava/lang/String;

.field public gKey4112:J

.field public iOffset934:J

.field public jPos3709:I

.field public kO_6X_:I

.field public kQy:Z

.field public pCXDYg:I

.field public final rz__9J_:LYizKm;

.field public sKey7917:LgItem9321;

.field public tmpData3485:Ljava/lang/String;

.field public vaIue:I

.field public valuI:I

.field public final waiBKÀ:I

.field public yON3x:I

.field public yàÒZ:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LmKey9057;->e8$mp_s$:Ljava/lang/String;

    .line 5
    .line 6
    iput p2, p0, LmKey9057;->waiBKÀ:I

    .line 7
    .line 8
    new-instance p1, LYizKm;

    .line 9
    .line 10
    const/16 p2, 0x400

    .line 11
    .line 12
    invoke-direct {p1, p2}, LYizKm;-><init>(I)V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, LmKey9057;->rz__9J_:LYizKm;

    .line 16
    .line 17
    new-instance p2, LZKy6àp;

    .line 18
    .line 19
    iget-object p1, p1, LYizKm;->e8$mp_s$:[B

    .line 20
    .line 21
    array-length v0, p1

    .line 22
    invoke-direct {p2, p1, v0}, LZKy6àp;-><init>([BI)V

    .line 23
    .line 24
    .line 25
    iput-object p2, p0, LmKey9057;->POOl:LZKy6àp;

    .line 26
    .line 27
    const-wide p1, -0x7fffffffffffffffL    # -4.9E-324

    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    iput-wide p1, p0, LmKey9057;->iOffset934:J

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final JKEoÙX(LvD9$JN$;LkKey9521;)V
    .locals 2

    .line 1
    invoke-virtual {p2}, LkKey9521;->e8$mp_s$()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, LkKey9521;->waiBKÀ()V

    .line 5
    .line 6
    .line 7
    iget v0, p2, LkKey9521;->POOl:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    invoke-interface {p1, v0, v1}, LvD9$JN$;->kCount1402(II)LwÒJK;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iput-object p1, p0, LmKey9057;->JKEoÙX:LwÒJK;

    .line 15
    .line 16
    invoke-virtual {p2}, LkKey9521;->waiBKÀ()V

    .line 17
    .line 18
    .line 19
    iget-object p1, p2, LkKey9521;->JKEoÙX:Ljava/lang/String;

    .line 20
    .line 21
    iput-object p1, p0, LmKey9057;->tmpData3485:Ljava/lang/String;

    .line 22
    .line 23
    return-void
.end method

.method public final POOl(Z)V
    .locals 0

    .line 1
    return-void
.end method

.method public final rz__9J_()V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, LmKey9057;->DDù8:I

    .line 3
    .line 4
    const-wide v1, -0x7fffffffffffffffL    # -4.9E-324

    .line 5
    .line 6
    .line 7
    .line 8
    .line 9
    iput-wide v1, p0, LmKey9057;->iOffset934:J

    .line 10
    .line 11
    iput-boolean v0, p0, LmKey9057;->kQy:Z

    .line 12
    .line 13
    return-void
.end method

.method public final tmpData3485(IJ)V
    .locals 0

    .line 1
    iput-wide p2, p0, LmKey9057;->iOffset934:J

    .line 2
    .line 3
    return-void
.end method

.method public final waiBKÀ(LYizKm;)V
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LmKey9057;->JKEoÙX:LwÒJK;

    .line 4
    .line 5
    invoke-static {v1}, LvItem3158;->po0(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    :cond_0
    :goto_0
    invoke-virtual/range {p1 .. p1}, LYizKm;->valuI()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-lez v1, :cond_1e

    .line 13
    .line 14
    iget v1, v0, LmKey9057;->DDù8:I

    .line 15
    .line 16
    const/16 v2, 0x56

    .line 17
    .line 18
    const/4 v3, 0x1

    .line 19
    if-eqz v1, :cond_1d

    .line 20
    .line 21
    const/4 v4, 0x2

    .line 22
    const/4 v5, 0x0

    .line 23
    if-eq v1, v3, :cond_1b

    .line 24
    .line 25
    iget-object v2, v0, LmKey9057;->POOl:LZKy6àp;

    .line 26
    .line 27
    const/4 v6, 0x3

    .line 28
    iget-object v7, v0, LmKey9057;->rz__9J_:LYizKm;

    .line 29
    .line 30
    const/16 v8, 0x8

    .line 31
    .line 32
    if-eq v1, v4, :cond_19

    .line 33
    .line 34
    invoke-virtual/range {p1 .. p1}, LYizKm;->valuI()I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    iget v9, v0, LmKey9057;->vaIue:I

    .line 39
    .line 40
    iget v10, v0, LmKey9057;->yON3x:I

    .line 41
    .line 42
    sub-int/2addr v9, v10

    .line 43
    invoke-static {v1, v9}, Ljava/lang/Math;->min(II)I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    iget-object v9, v2, LZKy6àp;->waiBKÀ:[B

    .line 48
    .line 49
    iget v10, v0, LmKey9057;->yON3x:I

    .line 50
    .line 51
    move-object/from16 v11, p1

    .line 52
    .line 53
    invoke-virtual {v11, v9, v10, v1}, LYizKm;->tmpData3485([BII)V

    .line 54
    .line 55
    .line 56
    iget v9, v0, LmKey9057;->yON3x:I

    .line 57
    .line 58
    add-int/2addr v9, v1

    .line 59
    iput v9, v0, LmKey9057;->yON3x:I

    .line 60
    .line 61
    iget v1, v0, LmKey9057;->vaIue:I

    .line 62
    .line 63
    if-ne v9, v1, :cond_0

    .line 64
    .line 65
    invoke-virtual {v2, v5}, LZKy6àp;->kO_6X_(I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v2}, LZKy6àp;->kCount1402()Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    const/4 v9, 0x0

    .line 73
    if-nez v1, :cond_10

    .line 74
    .line 75
    iput-boolean v3, v0, LmKey9057;->kQy:Z

    .line 76
    .line 77
    invoke-virtual {v2, v3}, LZKy6àp;->tmpData3485(I)I

    .line 78
    .line 79
    .line 80
    move-result v1

    .line 81
    if-ne v1, v3, :cond_1

    .line 82
    .line 83
    invoke-virtual {v2, v3}, LZKy6àp;->tmpData3485(I)I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    const/4 v10, 0x1

    .line 88
    goto :goto_1

    .line 89
    :cond_1
    move v10, v1

    .line 90
    const/4 v1, 0x0

    .line 91
    :goto_1
    iput v1, v0, LmKey9057;->Ialue:I

    .line 92
    .line 93
    if-nez v1, :cond_f

    .line 94
    .line 95
    if-ne v10, v3, :cond_2

    .line 96
    .line 97
    invoke-virtual {v2, v4}, LZKy6àp;->tmpData3485(I)I

    .line 98
    .line 99
    .line 100
    move-result v1

    .line 101
    add-int/2addr v1, v3

    .line 102
    mul-int/lit8 v1, v1, 0x8

    .line 103
    .line 104
    invoke-virtual {v2, v1}, LZKy6àp;->tmpData3485(I)I

    .line 105
    .line 106
    .line 107
    const/4 v10, 0x1

    .line 108
    :cond_2
    invoke-virtual {v2}, LZKy6àp;->kCount1402()Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_e

    .line 113
    .line 114
    const/4 v1, 0x6

    .line 115
    invoke-virtual {v2, v1}, LZKy6àp;->tmpData3485(I)I

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    iput v12, v0, LmKey9057;->valuI:I

    .line 120
    .line 121
    const/4 v12, 0x4

    .line 122
    invoke-virtual {v2, v12}, LZKy6àp;->tmpData3485(I)I

    .line 123
    .line 124
    .line 125
    move-result v13

    .line 126
    invoke-virtual {v2, v6}, LZKy6àp;->tmpData3485(I)I

    .line 127
    .line 128
    .line 129
    move-result v14

    .line 130
    if-nez v13, :cond_d

    .line 131
    .line 132
    if-nez v14, :cond_d

    .line 133
    .line 134
    if-nez v10, :cond_3

    .line 135
    .line 136
    iget v13, v2, LZKy6àp;->rz__9J_:I

    .line 137
    .line 138
    mul-int/lit8 v13, v13, 0x8

    .line 139
    .line 140
    iget v14, v2, LZKy6àp;->POOl:I

    .line 141
    .line 142
    add-int/2addr v13, v14

    .line 143
    invoke-virtual {v2}, LZKy6àp;->e8$mp_s$()I

    .line 144
    .line 145
    .line 146
    move-result v14

    .line 147
    invoke-static {v2, v3}, LtmpData593;->Oey(LZKy6àp;Z)Ll1Ill;

    .line 148
    .line 149
    .line 150
    move-result-object v15

    .line 151
    iget-object v5, v15, Ll1Ill;->e8$mp_s$:Ljava/lang/String;

    .line 152
    .line 153
    iput-object v5, v0, LmKey9057;->UC_n_:Ljava/lang/String;

    .line 154
    .line 155
    iget v5, v15, Ll1Ill;->waiBKÀ:I

    .line 156
    .line 157
    iput v5, v0, LmKey9057;->kO_6X_:I

    .line 158
    .line 159
    iget v5, v15, Ll1Ill;->rz__9J_:I

    .line 160
    .line 161
    iput v5, v0, LmKey9057;->Qp_Hp$i_:I

    .line 162
    .line 163
    invoke-virtual {v2}, LZKy6àp;->e8$mp_s$()I

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    sub-int/2addr v14, v5

    .line 168
    invoke-virtual {v2, v13}, LZKy6àp;->kO_6X_(I)V

    .line 169
    .line 170
    .line 171
    add-int/lit8 v5, v14, 0x7

    .line 172
    .line 173
    div-int/2addr v5, v8

    .line 174
    new-array v5, v5, [B

    .line 175
    .line 176
    invoke-virtual {v2, v14, v5}, LZKy6àp;->kQy(I[B)V

    .line 177
    .line 178
    .line 179
    new-instance v13, LtmpOffset9868;

    .line 180
    .line 181
    invoke-direct {v13}, LtmpOffset9868;-><init>()V

    .line 182
    .line 183
    .line 184
    iget-object v14, v0, LmKey9057;->tmpData3485:Ljava/lang/String;

    .line 185
    .line 186
    iput-object v14, v13, LtmpOffset9868;->e8$mp_s$:Ljava/lang/String;

    .line 187
    .line 188
    const-string v14, "audio/mp4a-latm"

    .line 189
    .line 190
    invoke-virtual {v13, v14}, LtmpOffset9868;->rz__9J_(Ljava/lang/String;)V

    .line 191
    .line 192
    .line 193
    iget-object v14, v0, LmKey9057;->UC_n_:Ljava/lang/String;

    .line 194
    .line 195
    iput-object v14, v13, LtmpOffset9868;->yON3x:Ljava/lang/String;

    .line 196
    .line 197
    iget v14, v0, LmKey9057;->Qp_Hp$i_:I

    .line 198
    .line 199
    iput v14, v13, LtmpOffset9868;->sKey6064:I

    .line 200
    .line 201
    iget v14, v0, LmKey9057;->kO_6X_:I

    .line 202
    .line 203
    iput v14, v13, LtmpOffset9868;->tzKù7Ol1:I

    .line 204
    .line 205
    invoke-static {v5}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 206
    .line 207
    .line 208
    move-result-object v5

    .line 209
    iput-object v5, v13, LtmpOffset9868;->valuI:Ljava/util/List;

    .line 210
    .line 211
    iget-object v5, v0, LmKey9057;->e8$mp_s$:Ljava/lang/String;

    .line 212
    .line 213
    iput-object v5, v13, LtmpOffset9868;->POOl:Ljava/lang/String;

    .line 214
    .line 215
    iget v5, v0, LmKey9057;->waiBKÀ:I

    .line 216
    .line 217
    iput v5, v13, LtmpOffset9868;->tmpData3485:I

    .line 218
    .line 219
    new-instance v5, LgItem9321;

    .line 220
    .line 221
    invoke-direct {v5, v13}, LgItem9321;-><init>(LtmpOffset9868;)V

    .line 222
    .line 223
    .line 224
    iget-object v13, v0, LmKey9057;->sKey7917:LgItem9321;

    .line 225
    .line 226
    invoke-virtual {v5, v13}, LgItem9321;->equals(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    move-result v13

    .line 230
    if-nez v13, :cond_4

    .line 231
    .line 232
    iput-object v5, v0, LmKey9057;->sKey7917:LgItem9321;

    .line 233
    .line 234
    iget v13, v5, LgItem9321;->ll:I

    .line 235
    .line 236
    int-to-long v13, v13

    .line 237
    const-wide/32 v16, 0x3d090000

    .line 238
    .line 239
    .line 240
    div-long v13, v16, v13

    .line 241
    .line 242
    iput-wide v13, v0, LmKey9057;->K0I:J

    .line 243
    .line 244
    iget-object v13, v0, LmKey9057;->JKEoÙX:LwÒJK;

    .line 245
    .line 246
    invoke-interface {v13, v5}, LwÒJK;->e8$mp_s$(LgItem9321;)V

    .line 247
    .line 248
    .line 249
    goto :goto_2

    .line 250
    :cond_3
    invoke-virtual {v2, v4}, LZKy6àp;->tmpData3485(I)I

    .line 251
    .line 252
    .line 253
    move-result v5

    .line 254
    add-int/2addr v5, v3

    .line 255
    mul-int/lit8 v5, v5, 0x8

    .line 256
    .line 257
    invoke-virtual {v2, v5}, LZKy6àp;->tmpData3485(I)I

    .line 258
    .line 259
    .line 260
    move-result v5

    .line 261
    int-to-long v13, v5

    .line 262
    long-to-int v5, v13

    .line 263
    invoke-virtual {v2}, LZKy6àp;->e8$mp_s$()I

    .line 264
    .line 265
    .line 266
    move-result v13

    .line 267
    invoke-static {v2, v3}, LtmpData593;->Oey(LZKy6àp;Z)Ll1Ill;

    .line 268
    .line 269
    .line 270
    move-result-object v14

    .line 271
    iget-object v15, v14, Ll1Ill;->e8$mp_s$:Ljava/lang/String;

    .line 272
    .line 273
    iput-object v15, v0, LmKey9057;->UC_n_:Ljava/lang/String;

    .line 274
    .line 275
    iget v15, v14, Ll1Ill;->waiBKÀ:I

    .line 276
    .line 277
    iput v15, v0, LmKey9057;->kO_6X_:I

    .line 278
    .line 279
    iget v14, v14, Ll1Ill;->rz__9J_:I

    .line 280
    .line 281
    iput v14, v0, LmKey9057;->Qp_Hp$i_:I

    .line 282
    .line 283
    invoke-virtual {v2}, LZKy6àp;->e8$mp_s$()I

    .line 284
    .line 285
    .line 286
    move-result v14

    .line 287
    sub-int/2addr v13, v14

    .line 288
    sub-int/2addr v5, v13

    .line 289
    invoke-virtual {v2, v5}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 290
    .line 291
    .line 292
    :cond_4
    :goto_2
    invoke-virtual {v2, v6}, LZKy6àp;->tmpData3485(I)I

    .line 293
    .line 294
    .line 295
    move-result v5

    .line 296
    iput v5, v0, LmKey9057;->pCXDYg:I

    .line 297
    .line 298
    if-eqz v5, :cond_9

    .line 299
    .line 300
    if-eq v5, v3, :cond_8

    .line 301
    .line 302
    if-eq v5, v6, :cond_7

    .line 303
    .line 304
    if-eq v5, v12, :cond_7

    .line 305
    .line 306
    const/4 v6, 0x5

    .line 307
    if-eq v5, v6, :cond_7

    .line 308
    .line 309
    if-eq v5, v1, :cond_6

    .line 310
    .line 311
    const/4 v1, 0x7

    .line 312
    if-ne v5, v1, :cond_5

    .line 313
    .line 314
    goto :goto_3

    .line 315
    :cond_5
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 316
    .line 317
    invoke-direct {v1}, Ljava/lang/IllegalStateException;-><init>()V

    .line 318
    .line 319
    .line 320
    throw v1

    .line 321
    :cond_6
    :goto_3
    invoke-virtual {v2, v3}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 322
    .line 323
    .line 324
    goto :goto_4

    .line 325
    :cond_7
    invoke-virtual {v2, v1}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 326
    .line 327
    .line 328
    goto :goto_4

    .line 329
    :cond_8
    const/16 v1, 0x9

    .line 330
    .line 331
    invoke-virtual {v2, v1}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 332
    .line 333
    .line 334
    goto :goto_4

    .line 335
    :cond_9
    invoke-virtual {v2, v8}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 336
    .line 337
    .line 338
    :goto_4
    invoke-virtual {v2}, LZKy6àp;->kCount1402()Z

    .line 339
    .line 340
    .line 341
    move-result v1

    .line 342
    iput-boolean v1, v0, LmKey9057;->yàÒZ:Z

    .line 343
    .line 344
    const-wide/16 v5, 0x0

    .line 345
    .line 346
    iput-wide v5, v0, LmKey9057;->gKey4112:J

    .line 347
    .line 348
    if-eqz v1, :cond_c

    .line 349
    .line 350
    if-eq v10, v3, :cond_b

    .line 351
    .line 352
    :cond_a
    invoke-virtual {v2}, LZKy6àp;->kCount1402()Z

    .line 353
    .line 354
    .line 355
    move-result v1

    .line 356
    iget-wide v4, v0, LmKey9057;->gKey4112:J

    .line 357
    .line 358
    shl-long/2addr v4, v8

    .line 359
    invoke-virtual {v2, v8}, LZKy6àp;->tmpData3485(I)I

    .line 360
    .line 361
    .line 362
    move-result v6

    .line 363
    int-to-long v12, v6

    .line 364
    add-long/2addr v4, v12

    .line 365
    iput-wide v4, v0, LmKey9057;->gKey4112:J

    .line 366
    .line 367
    if-nez v1, :cond_a

    .line 368
    .line 369
    goto :goto_5

    .line 370
    :cond_b
    invoke-virtual {v2, v4}, LZKy6àp;->tmpData3485(I)I

    .line 371
    .line 372
    .line 373
    move-result v1

    .line 374
    add-int/2addr v1, v3

    .line 375
    mul-int/lit8 v1, v1, 0x8

    .line 376
    .line 377
    invoke-virtual {v2, v1}, LZKy6àp;->tmpData3485(I)I

    .line 378
    .line 379
    .line 380
    move-result v1

    .line 381
    int-to-long v4, v1

    .line 382
    iput-wide v4, v0, LmKey9057;->gKey4112:J

    .line 383
    .line 384
    :cond_c
    :goto_5
    invoke-virtual {v2}, LZKy6àp;->kCount1402()Z

    .line 385
    .line 386
    .line 387
    move-result v1

    .line 388
    if-eqz v1, :cond_12

    .line 389
    .line 390
    invoke-virtual {v2, v8}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 391
    .line 392
    .line 393
    goto :goto_7

    .line 394
    :cond_d
    invoke-static {v9, v9}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 395
    .line 396
    .line 397
    move-result-object v1

    .line 398
    throw v1

    .line 399
    :cond_e
    invoke-static {v9, v9}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 400
    .line 401
    .line 402
    move-result-object v1

    .line 403
    throw v1

    .line 404
    :cond_f
    invoke-static {v9, v9}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    throw v1

    .line 409
    :cond_10
    iget-boolean v1, v0, LmKey9057;->kQy:Z

    .line 410
    .line 411
    if-nez v1, :cond_12

    .line 412
    .line 413
    :cond_11
    :goto_6
    const/4 v4, 0x0

    .line 414
    goto :goto_b

    .line 415
    :cond_12
    :goto_7
    iget v1, v0, LmKey9057;->Ialue:I

    .line 416
    .line 417
    if-nez v1, :cond_18

    .line 418
    .line 419
    iget v1, v0, LmKey9057;->valuI:I

    .line 420
    .line 421
    if-nez v1, :cond_17

    .line 422
    .line 423
    iget v1, v0, LmKey9057;->pCXDYg:I

    .line 424
    .line 425
    if-nez v1, :cond_16

    .line 426
    .line 427
    const/4 v1, 0x0

    .line 428
    :goto_8
    invoke-virtual {v2, v8}, LZKy6àp;->tmpData3485(I)I

    .line 429
    .line 430
    .line 431
    move-result v4

    .line 432
    add-int/2addr v1, v4

    .line 433
    const/16 v5, 0xff

    .line 434
    .line 435
    if-eq v4, v5, :cond_15

    .line 436
    .line 437
    iget v4, v2, LZKy6àp;->rz__9J_:I

    .line 438
    .line 439
    mul-int/lit8 v4, v4, 0x8

    .line 440
    .line 441
    iget v5, v2, LZKy6àp;->POOl:I

    .line 442
    .line 443
    add-int/2addr v4, v5

    .line 444
    and-int/lit8 v5, v4, 0x7

    .line 445
    .line 446
    if-nez v5, :cond_13

    .line 447
    .line 448
    shr-int/lit8 v4, v4, 0x3

    .line 449
    .line 450
    invoke-virtual {v7, v4}, LYizKm;->vaIue(I)V

    .line 451
    .line 452
    .line 453
    goto :goto_9

    .line 454
    :cond_13
    mul-int/lit8 v4, v1, 0x8

    .line 455
    .line 456
    iget-object v5, v7, LYizKm;->e8$mp_s$:[B

    .line 457
    .line 458
    invoke-virtual {v2, v4, v5}, LZKy6àp;->kQy(I[B)V

    .line 459
    .line 460
    .line 461
    const/4 v4, 0x0

    .line 462
    invoke-virtual {v7, v4}, LYizKm;->vaIue(I)V

    .line 463
    .line 464
    .line 465
    :goto_9
    iget-object v4, v0, LmKey9057;->JKEoÙX:LwÒJK;

    .line 466
    .line 467
    invoke-interface {v4, v1, v7}, LwÒJK;->JKEoÙX(ILYizKm;)V

    .line 468
    .line 469
    .line 470
    iget-wide v4, v0, LmKey9057;->iOffset934:J

    .line 471
    .line 472
    const-wide v6, -0x7fffffffffffffffL    # -4.9E-324

    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    cmp-long v8, v4, v6

    .line 478
    .line 479
    if-eqz v8, :cond_14

    .line 480
    .line 481
    goto :goto_a

    .line 482
    :cond_14
    const/4 v3, 0x0

    .line 483
    :goto_a
    invoke-static {v3}, LvItem3158;->xlOI(Z)V

    .line 484
    .line 485
    .line 486
    iget-object v3, v0, LmKey9057;->JKEoÙX:LwÒJK;

    .line 487
    .line 488
    iget-wide v4, v0, LmKey9057;->iOffset934:J

    .line 489
    .line 490
    const/16 v21, 0x0

    .line 491
    .line 492
    const/16 v22, 0x0

    .line 493
    .line 494
    const/16 v19, 0x1

    .line 495
    .line 496
    move/from16 v20, v1

    .line 497
    .line 498
    move-object/from16 v16, v3

    .line 499
    .line 500
    move-wide/from16 v17, v4

    .line 501
    .line 502
    invoke-interface/range {v16 .. v22}, LwÒJK;->waiBKÀ(JIIILlF_um_;)V

    .line 503
    .line 504
    .line 505
    iget-wide v3, v0, LmKey9057;->iOffset934:J

    .line 506
    .line 507
    iget-wide v5, v0, LmKey9057;->K0I:J

    .line 508
    .line 509
    add-long/2addr v3, v5

    .line 510
    iput-wide v3, v0, LmKey9057;->iOffset934:J

    .line 511
    .line 512
    iget-boolean v1, v0, LmKey9057;->yàÒZ:Z

    .line 513
    .line 514
    if-eqz v1, :cond_11

    .line 515
    .line 516
    iget-wide v3, v0, LmKey9057;->gKey4112:J

    .line 517
    .line 518
    long-to-int v1, v3

    .line 519
    invoke-virtual {v2, v1}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 520
    .line 521
    .line 522
    goto :goto_6

    .line 523
    :goto_b
    iput v4, v0, LmKey9057;->DDù8:I

    .line 524
    .line 525
    goto/16 :goto_0

    .line 526
    .line 527
    :cond_15
    move/from16 v20, v1

    .line 528
    .line 529
    goto :goto_8

    .line 530
    :cond_16
    invoke-static {v9, v9}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 531
    .line 532
    .line 533
    move-result-object v1

    .line 534
    throw v1

    .line 535
    :cond_17
    invoke-static {v9, v9}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 536
    .line 537
    .line 538
    move-result-object v1

    .line 539
    throw v1

    .line 540
    :cond_18
    invoke-static {v9, v9}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 541
    .line 542
    .line 543
    move-result-object v1

    .line 544
    throw v1

    .line 545
    :cond_19
    move-object/from16 v11, p1

    .line 546
    .line 547
    iget v1, v0, LmKey9057;->jPos3709:I

    .line 548
    .line 549
    and-int/lit16 v1, v1, -0xe1

    .line 550
    .line 551
    shl-int/2addr v1, v8

    .line 552
    invoke-virtual {v11}, LYizKm;->UC_n_()I

    .line 553
    .line 554
    .line 555
    move-result v3

    .line 556
    or-int/2addr v1, v3

    .line 557
    iput v1, v0, LmKey9057;->vaIue:I

    .line 558
    .line 559
    iget-object v3, v7, LYizKm;->e8$mp_s$:[B

    .line 560
    .line 561
    array-length v3, v3

    .line 562
    if-le v1, v3, :cond_1a

    .line 563
    .line 564
    invoke-virtual {v7, v1}, LYizKm;->sKey7917(I)V

    .line 565
    .line 566
    .line 567
    iget-object v1, v7, LYizKm;->e8$mp_s$:[B

    .line 568
    .line 569
    array-length v3, v1

    .line 570
    iput-object v1, v2, LZKy6àp;->waiBKÀ:[B

    .line 571
    .line 572
    const/4 v4, 0x0

    .line 573
    iput v4, v2, LZKy6àp;->rz__9J_:I

    .line 574
    .line 575
    iput v4, v2, LZKy6àp;->POOl:I

    .line 576
    .line 577
    iput v3, v2, LZKy6àp;->JKEoÙX:I

    .line 578
    .line 579
    goto :goto_c

    .line 580
    :cond_1a
    const/4 v4, 0x0

    .line 581
    :goto_c
    iput v4, v0, LmKey9057;->yON3x:I

    .line 582
    .line 583
    iput v6, v0, LmKey9057;->DDù8:I

    .line 584
    .line 585
    goto/16 :goto_0

    .line 586
    .line 587
    :cond_1b
    move-object/from16 v11, p1

    .line 588
    .line 589
    invoke-virtual {v11}, LYizKm;->UC_n_()I

    .line 590
    .line 591
    .line 592
    move-result v1

    .line 593
    and-int/lit16 v3, v1, 0xe0

    .line 594
    .line 595
    const/16 v5, 0xe0

    .line 596
    .line 597
    if-ne v3, v5, :cond_1c

    .line 598
    .line 599
    iput v1, v0, LmKey9057;->jPos3709:I

    .line 600
    .line 601
    :goto_d
    iput v4, v0, LmKey9057;->DDù8:I

    .line 602
    .line 603
    goto/16 :goto_0

    .line 604
    .line 605
    :cond_1c
    if-eq v1, v2, :cond_0

    .line 606
    .line 607
    const/4 v4, 0x0

    .line 608
    goto :goto_d

    .line 609
    :cond_1d
    move-object/from16 v11, p1

    .line 610
    .line 611
    invoke-virtual {v11}, LYizKm;->UC_n_()I

    .line 612
    .line 613
    .line 614
    move-result v1

    .line 615
    if-ne v1, v2, :cond_0

    .line 616
    .line 617
    iput v3, v0, LmKey9057;->DDù8:I

    .line 618
    .line 619
    goto/16 :goto_0

    .line 620
    .line 621
    :cond_1e
    return-void
.end method
