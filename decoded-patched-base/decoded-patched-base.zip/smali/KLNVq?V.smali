.class public final LKLNVqÌV;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LkSize886;


# static fields
.field public static final tmpData3485:Ljava/util/logging/Logger;


# instance fields
.field public final JKEoÙX:LqD11O1;

.field public final POOl:LjValue2770;

.field public final e8$mp_s$:LPX6$F_j$;

.field public final rz__9J_:LxI0;

.field public final waiBKÀ:Ljava/util/concurrent/Executor;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-class v0, LEjù;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, LKLNVqÌV;->tmpData3485:Ljava/util/logging/Logger;

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/Executor;LxI0;LPX6$F_j$;LjValue2770;LqD11O1;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LKLNVqÌV;->waiBKÀ:Ljava/util/concurrent/Executor;

    .line 5
    .line 6
    iput-object p2, p0, LKLNVqÌV;->rz__9J_:LxI0;

    .line 7
    .line 8
    iput-object p3, p0, LKLNVqÌV;->e8$mp_s$:LPX6$F_j$;

    .line 9
    .line 10
    iput-object p4, p0, LKLNVqÌV;->POOl:LjValue2770;

    .line 11
    .line 12
    iput-object p5, p0, LKLNVqÌV;->JKEoÙX:LqD11O1;

    .line 13
    .line 14
    return-void
.end method
