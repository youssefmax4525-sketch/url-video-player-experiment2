.class public interface abstract Lfòei;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract rz__9J_([B[B)[B
.end method
