.class public final LnO;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public JKEoÙX:F

.field public POOl:I

.field public final e8$mp_s$:LkItem6218;

.field public rz__9J_:LpXj$A$;

.field public final waiBKÀ:LSM$p_8$;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/os/Handler;LpXj$A$;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/high16 v0, 0x3f800000    # 1.0f

    .line 5
    .line 6
    iput v0, p0, LnO;->JKEoÙX:F

    .line 7
    .line 8
    new-instance v0, LwZ$3_f$;

    .line 9
    .line 10
    invoke-direct {v0, p1}, LwZ$3_f$;-><init>(Landroid/content/Context;)V

    .line 11
    .line 12
    .line 13
    invoke-static {v0}, LPJNypàa;->BCIm(LkItem6218;)LkItem6218;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    iput-object p1, p0, LnO;->e8$mp_s$:LkItem6218;

    .line 18
    .line 19
    iput-object p3, p0, LnO;->rz__9J_:LpXj$A$;

    .line 20
    .line 21
    new-instance p1, LSM$p_8$;

    .line 22
    .line 23
    invoke-direct {p1, p0, p2}, LSM$p_8$;-><init>(LnO;Landroid/os/Handler;)V

    .line 24
    .line 25
    .line 26
    iput-object p1, p0, LnO;->waiBKÀ:LSM$p_8$;

    .line 27
    .line 28
    const/4 p1, 0x0

    .line 29
    iput p1, p0, LnO;->POOl:I

    .line 30
    .line 31
    return-void
.end method


# virtual methods
.method public final e8$mp_s$()V
    .locals 2

    .line 1
    iget v0, p0, LnO;->POOl:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eq v0, v1, :cond_1

    .line 5
    .line 6
    if-nez v0, :cond_0

    .line 7
    .line 8
    goto :goto_0

    .line 9
    :cond_0
    sget v0, LnPos2706;->e8$mp_s$:I

    .line 10
    .line 11
    const/16 v1, 0x1a

    .line 12
    .line 13
    if-ge v0, v1, :cond_1

    .line 14
    .line 15
    iget-object v0, p0, LnO;->e8$mp_s$:LkItem6218;

    .line 16
    .line 17
    invoke-interface {v0}, LkItem6218;->e8$mp_s$()Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    check-cast v0, Landroid/media/AudioManager;

    .line 22
    .line 23
    iget-object v1, p0, LnO;->waiBKÀ:LSM$p_8$;

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->abandonAudioFocus(Landroid/media/AudioManager$OnAudioFocusChangeListener;)I

    .line 26
    .line 27
    .line 28
    :cond_1
    :goto_0
    return-void
.end method

.method public final waiBKÀ(I)V
    .locals 3

    .line 1
    iget v0, p0, LnO;->POOl:I

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    goto :goto_1

    .line 6
    :cond_0
    iput p1, p0, LnO;->POOl:I

    .line 7
    .line 8
    const/4 v0, 0x4

    .line 9
    if-ne p1, v0, :cond_1

    .line 10
    .line 11
    const p1, 0x3e4ccccd    # 0.2f

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_1
    const/high16 p1, 0x3f800000    # 1.0f

    .line 16
    .line 17
    :goto_0
    iget v0, p0, LnO;->JKEoÙX:F

    .line 18
    .line 19
    cmpl-float v0, v0, p1

    .line 20
    .line 21
    if-eqz v0, :cond_2

    .line 22
    .line 23
    iput p1, p0, LnO;->JKEoÙX:F

    .line 24
    .line 25
    iget-object p1, p0, LnO;->rz__9J_:LpXj$A$;

    .line 26
    .line 27
    if-eqz p1, :cond_2

    .line 28
    .line 29
    iget-object p1, p1, LpXj$A$;->yON3x:LmÀDjRmG;

    .line 30
    .line 31
    iget-object v0, p1, LmÀDjRmG;->yPN$A_n$:LnO;

    .line 32
    .line 33
    iget v1, p1, LmÀDjRmG;->k1y:F

    .line 34
    .line 35
    iget v0, v0, LnO;->JKEoÙX:F

    .line 36
    .line 37
    mul-float v1, v1, v0

    .line 38
    .line 39
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    const/4 v1, 0x1

    .line 44
    const/4 v2, 0x2

    .line 45
    invoke-virtual {p1, v1, v2, v0}, LmÀDjRmG;->mItem4829(IILjava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    :cond_2
    :goto_1
    return-void
.end method
