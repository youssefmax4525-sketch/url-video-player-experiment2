.class public abstract LD6_x$B__;
.super Ljava/lang/Object;


# static fields
.field public static admob_close_button_black_circle_white_cross:I = 0x7f080077

.field public static admob_close_button_white_circle_black_cross:I = 0x7f080078

.field public static admob_close_button_white_cross:I = 0x7f080079

.field public static offline_dialog_background:I = 0x7f0802bd

.field public static offline_dialog_default_icon_42dp:I = 0x7f0802be
