.class public final LIiil1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements L_IDl;


# instance fields
.field public final vaIue:LnW_cN_;

.field public final yON3x:L_IDl;


# direct methods
.method public constructor <init>(L_IDl;Ljava/util/List;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LIiil1;->yON3x:L_IDl;

    .line 5
    .line 6
    invoke-static {p2}, LnW_cN_;->jPos3709(Ljava/util/Collection;)LnW_cN_;

    .line 7
    .line 8
    .line 9
    move-result-object p1

    .line 10
    iput-object p1, p0, LIiil1;->vaIue:LnW_cN_;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final DDù8()J
    .locals 2

    .line 1
    iget-object v0, p0, LIiil1;->yON3x:L_IDl;

    .line 2
    .line 3
    invoke-interface {v0}, L_IDl;->DDù8()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final JKEoÙX(Ly5t$3t$;)Z
    .locals 1

    .line 1
    iget-object v0, p0, LIiil1;->yON3x:L_IDl;

    .line 2
    .line 3
    invoke-interface {v0, p1}, L_IDl;->JKEoÙX(Ly5t$3t$;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final POOl()J
    .locals 2

    .line 1
    iget-object v0, p0, LIiil1;->yON3x:L_IDl;

    .line 2
    .line 3
    invoke-interface {v0}, L_IDl;->POOl()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    return-wide v0
.end method

.method public final e8$mp_s$(J)V
    .locals 1

    .line 1
    iget-object v0, p0, LIiil1;->yON3x:L_IDl;

    .line 2
    .line 3
    invoke-interface {v0, p1, p2}, L_IDl;->e8$mp_s$(J)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final gKey4112()Z
    .locals 1

    .line 1
    iget-object v0, p0, LIiil1;->yON3x:L_IDl;

    .line 2
    .line 3
    invoke-interface {v0}, L_IDl;->gKey4112()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method
