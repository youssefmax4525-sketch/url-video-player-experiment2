.class public final LvÀ8YwZà;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements L_3m$y_B8$;


# instance fields
.field public final JKEoÙX:L$d7KXù;

.field public final POOl:Ljava/net/URL;

.field public final e8$mp_s$:Lyv$5_5$;

.field public final rz__9J_:Landroid/content/Context;

.field public final sKey7917:I

.field public final tmpData3485:L$d7KXù;

.field public final waiBKÀ:Landroid/net/ConnectivityManager;


# direct methods
.method public constructor <init>(Landroid/content/Context;L$d7KXù;L$d7KXù;)V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LjValue9146;

    .line 5
    .line 6
    invoke-direct {v0}, LjValue9146;-><init>()V

    .line 7
    .line 8
    .line 9
    sget-object v1, LOQO_DC$jD_;->e8$mp_s$:LOQO_DC$jD_;

    .line 10
    .line 11
    const-class v2, LpnÒeSA;

    .line 12
    .line 13
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 14
    .line 15
    .line 16
    const-class v2, LjKey1517;

    .line 17
    .line 18
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 19
    .line 20
    .line 21
    sget-object v1, LAl;->e8$mp_s$:LAl;

    .line 22
    .line 23
    const-class v2, LiDIODl;

    .line 24
    .line 25
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 26
    .line 27
    .line 28
    const-class v2, LUbv$S_f$;

    .line 29
    .line 30
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 31
    .line 32
    .line 33
    sget-object v1, L$TÙwzbPq;->e8$mp_s$:L$TÙwzbPq;

    .line 34
    .line 35
    const-class v2, LHeKYa;

    .line 36
    .line 37
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 38
    .line 39
    .line 40
    const-class v2, L$fM$uG$;

    .line 41
    .line 42
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 43
    .line 44
    .line 45
    sget-object v1, LinQex;->e8$mp_s$:LinQex;

    .line 46
    .line 47
    const-class v2, LkeI;

    .line 48
    .line 49
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 50
    .line 51
    .line 52
    const-class v2, LasQA3;

    .line 53
    .line 54
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 55
    .line 56
    .line 57
    sget-object v1, L_lOUK0;->e8$mp_s$:L_lOUK0;

    .line 58
    .line 59
    const-class v2, LvIO;

    .line 60
    .line 61
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 62
    .line 63
    .line 64
    const-class v2, LOemp;

    .line 65
    .line 66
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 67
    .line 68
    .line 69
    sget-object v1, LleIgth;->e8$mp_s$:LleIgth;

    .line 70
    .line 71
    const-class v2, LOSjerB;

    .line 72
    .line 73
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 74
    .line 75
    .line 76
    const-class v2, LQO;

    .line 77
    .line 78
    invoke-virtual {v0, v2, v1}, LjValue9146;->e8$mp_s$(Ljava/lang/Class;LaaXI;)LG8$1P_A$;

    .line 79
    .line 80
    .line 81
    const/4 v1, 0x1

    .line 82
    iput-boolean v1, v0, LjValue9146;->POOl:Z

    .line 83
    .line 84
    new-instance v1, Lyv$5_5$;

    .line 85
    .line 86
    const/4 v2, 0x6

    .line 87
    invoke-direct {v1, v2, v0}, Lyv$5_5$;-><init>(ILjava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    iput-object v1, p0, LvÀ8YwZà;->e8$mp_s$:Lyv$5_5$;

    .line 91
    .line 92
    iput-object p1, p0, LvÀ8YwZà;->rz__9J_:Landroid/content/Context;

    .line 93
    .line 94
    const-string v0, "connectivity"

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    check-cast p1, Landroid/net/ConnectivityManager;

    .line 101
    .line 102
    iput-object p1, p0, LvÀ8YwZà;->waiBKÀ:Landroid/net/ConnectivityManager;

    .line 103
    .line 104
    sget-object p1, LtNK_skB;->rz__9J_:Ljava/lang/String;

    .line 105
    .line 106
    invoke-static {p1}, LvÀ8YwZà;->waiBKÀ(Ljava/lang/String;)Ljava/net/URL;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    iput-object p1, p0, LvÀ8YwZà;->POOl:Ljava/net/URL;

    .line 111
    .line 112
    iput-object p3, p0, LvÀ8YwZà;->JKEoÙX:L$d7KXù;

    .line 113
    .line 114
    iput-object p2, p0, LvÀ8YwZà;->tmpData3485:L$d7KXù;

    .line 115
    .line 116
    const p1, 0x9c40

    .line 117
    .line 118
    .line 119
    iput p1, p0, LvÀ8YwZà;->sKey7917:I

    .line 120
    .line 121
    return-void
.end method

.method public static waiBKÀ(Ljava/lang/String;)Ljava/net/URL;
    .locals 3

    .line 1
    :try_start_0
    new-instance v0, Ljava/net/URL;

    .line 2
    .line 3
    invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_0

    .line 4
    .line 5
    .line 6
    return-object v0

    .line 7
    :catch_0
    move-exception v0

    .line 8
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 9
    .line 10
    const-string v2, "Invalid url: "

    .line 11
    .line 12
    invoke-static {v2, p0}, LBRK_m_;->kO_6X_(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-direct {v1, p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 17
    .line 18
    .line 19
    throw v1
.end method


# virtual methods
.method public final e8$mp_s$(Ld1ta;)Ld1ta;
    .locals 6

    .line 1
    iget-object v0, p0, LvÀ8YwZà;->waiBKÀ:Landroid/net/ConnectivityManager;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {p1}, Ld1ta;->rz__9J_()LIiII11I;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 12
    .line 13
    iget-object v2, p1, LIiII11I;->valuI:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v2, Ljava/util/HashMap;

    .line 16
    .line 17
    const-string v3, "Property \"autoMetadata\" has not been set"

    .line 18
    .line 19
    if-eqz v2, :cond_7

    .line 20
    .line 21
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    const-string v4, "sdk-version"

    .line 26
    .line 27
    invoke-virtual {v2, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    const-string v1, "model"

    .line 31
    .line 32
    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 33
    .line 34
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    const-string v1, "hardware"

    .line 38
    .line 39
    sget-object v2, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    const-string v1, "device"

    .line 45
    .line 46
    sget-object v2, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 47
    .line 48
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    const-string v1, "product"

    .line 52
    .line 53
    sget-object v2, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    .line 54
    .line 55
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    const-string v1, "os-uild"

    .line 59
    .line 60
    sget-object v2, Landroid/os/Build;->ID:Ljava/lang/String;

    .line 61
    .line 62
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    const-string v1, "manufacturer"

    .line 66
    .line 67
    sget-object v2, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 68
    .line 69
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    const-string v1, "fingerprint"

    .line 73
    .line 74
    sget-object v2, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    .line 75
    .line 76
    invoke-virtual {p1, v1, v2}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 80
    .line 81
    .line 82
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    .line 83
    .line 84
    .line 85
    move-result-object v1

    .line 86
    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    invoke-virtual {v2}, Ljava/util/Calendar;->getTimeInMillis()J

    .line 91
    .line 92
    .line 93
    move-result-wide v4

    .line 94
    invoke-virtual {v1, v4, v5}, Ljava/util/TimeZone;->getOffset(J)I

    .line 95
    .line 96
    .line 97
    move-result v1

    .line 98
    div-int/lit16 v1, v1, 0x3e8

    .line 99
    .line 100
    int-to-long v1, v1

    .line 101
    iget-object v4, p1, LIiII11I;->valuI:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast v4, Ljava/util/HashMap;

    .line 104
    .line 105
    if-eqz v4, :cond_6

    .line 106
    .line 107
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    const-string v2, "tz-offset"

    .line 112
    .line 113
    invoke-virtual {v4, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    const/4 v1, -0x1

    .line 117
    if-nez v0, :cond_0

    .line 118
    .line 119
    sget-object v2, Lfb_9$8Z_;->yON3x:Landroid/util/SparseArray;

    .line 120
    .line 121
    const/4 v2, -0x1

    .line 122
    goto :goto_0

    .line 123
    :cond_0
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getType()I

    .line 124
    .line 125
    .line 126
    move-result v2

    .line 127
    :goto_0
    iget-object v4, p1, LIiII11I;->valuI:Ljava/lang/Object;

    .line 128
    .line 129
    check-cast v4, Ljava/util/HashMap;

    .line 130
    .line 131
    if-eqz v4, :cond_5

    .line 132
    .line 133
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v2

    .line 137
    const-string v5, "net-type"

    .line 138
    .line 139
    invoke-virtual {v4, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    const/4 v2, 0x0

    .line 143
    if-nez v0, :cond_2

    .line 144
    .line 145
    sget-object v0, LyS9sc;->yON3x:Landroid/util/SparseArray;

    .line 146
    .line 147
    :cond_1
    const/4 v0, 0x0

    .line 148
    goto :goto_1

    .line 149
    :cond_2
    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getSubtype()I

    .line 150
    .line 151
    .line 152
    move-result v0

    .line 153
    if-ne v0, v1, :cond_3

    .line 154
    .line 155
    sget-object v0, LyS9sc;->yON3x:Landroid/util/SparseArray;

    .line 156
    .line 157
    const/16 v0, 0x64

    .line 158
    .line 159
    goto :goto_1

    .line 160
    :cond_3
    sget-object v4, LyS9sc;->yON3x:Landroid/util/SparseArray;

    .line 161
    .line 162
    invoke-virtual {v4, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    check-cast v4, LyS9sc;

    .line 167
    .line 168
    if-eqz v4, :cond_1

    .line 169
    .line 170
    :goto_1
    iget-object v4, p1, LIiII11I;->valuI:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast v4, Ljava/util/HashMap;

    .line 173
    .line 174
    if-eqz v4, :cond_4

    .line 175
    .line 176
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    const-string v3, "mobile-subtype"

    .line 181
    .line 182
    invoke-virtual {v4, v3, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    invoke-virtual {v0}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    const-string v3, "country"

    .line 194
    .line 195
    invoke-virtual {p1, v3, v0}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 199
    .line 200
    .line 201
    move-result-object v0

    .line 202
    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v0

    .line 206
    const-string v3, "locale"

    .line 207
    .line 208
    invoke-virtual {p1, v3, v0}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    const-string v0, "phone"

    .line 212
    .line 213
    iget-object v3, p0, LvÀ8YwZà;->rz__9J_:Landroid/content/Context;

    .line 214
    .line 215
    invoke-virtual {v3, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v0

    .line 219
    check-cast v0, Landroid/telephony/TelephonyManager;

    .line 220
    .line 221
    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getSimOperator()Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object v0

    .line 225
    const-string v4, "mcc_mnc"

    .line 226
    .line 227
    invoke-virtual {p1, v4, v0}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 228
    .line 229
    .line 230
    :try_start_0
    invoke-virtual {v3}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 231
    .line 232
    .line 233
    move-result-object v0

    .line 234
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v3

    .line 238
    invoke-virtual {v0, v3, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    .line 239
    .line 240
    .line 241
    move-result-object v0

    .line 242
    iget v1, v0, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 243
    .line 244
    :catch_0
    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    const-string v1, "application_build"

    .line 249
    .line 250
    invoke-virtual {p1, v1, v0}, LIiII11I;->rz__9J_(Ljava/lang/String;Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {p1}, LIiII11I;->tmpData3485()Ld1ta;

    .line 254
    .line 255
    .line 256
    move-result-object p1

    .line 257
    return-object p1

    .line 258
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 259
    .line 260
    invoke-direct {p1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    throw p1

    .line 264
    :cond_5
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 265
    .line 266
    invoke-direct {p1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 267
    .line 268
    .line 269
    throw p1

    .line 270
    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 271
    .line 272
    invoke-direct {p1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    throw p1

    .line 276
    :cond_7
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 277
    .line 278
    invoke-direct {p1, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    throw p1
.end method
