.class public abstract synthetic LSX$MK__4$;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static JKEoÙX(Landroidx/media3/common/OverlaySettings;)F
    .locals 0

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public static POOl(Landroidx/media3/common/OverlaySettings;)Landroid/util/Pair;
    .locals 0

    .line 1
    sget-object p0, Landroidx/media3/common/OverlaySettings;->DEFAULT_OVERLAY_FRAME_ANCHOR:Landroid/util/Pair;

    .line 2
    .line 3
    return-object p0
.end method

.method public static e8$mp_s$(Landroidx/media3/common/OverlaySettings;)F
    .locals 0

    .line 1
    const/high16 p0, 0x3f800000    # 1.0f

    .line 2
    .line 3
    return p0
.end method

.method public static rz__9J_(Landroidx/media3/common/OverlaySettings;)F
    .locals 0

    .line 1
    const/high16 p0, 0x3f800000    # 1.0f

    .line 2
    .line 3
    return p0
.end method

.method public static tmpData3485(Landroidx/media3/common/OverlaySettings;)Landroid/util/Pair;
    .locals 0

    .line 1
    sget-object p0, Landroidx/media3/common/OverlaySettings;->DEFAULT_SCALE:Landroid/util/Pair;

    .line 2
    .line 3
    return-object p0
.end method

.method public static waiBKÀ(Landroidx/media3/common/OverlaySettings;)Landroid/util/Pair;
    .locals 0

    .line 1
    sget-object p0, Landroidx/media3/common/OverlaySettings;->DEFAULT_BACKGROUND_FRAME_ANCHOR:Landroid/util/Pair;

    .line 2
    .line 3
    return-object p0
.end method
