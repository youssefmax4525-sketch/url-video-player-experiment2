.class public final LSZòyiGùS;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/common/Player$Listener;


# instance fields
.field public final synthetic vaIue:Linfo/t4w/vp/view/MainActivity;

.field public final synthetic yON3x:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linfo/t4w/vp/view/MainActivity;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LSZòyiGùS;->vaIue:Linfo/t4w/vp/view/MainActivity;

    .line 5
    .line 6
    iput-object p2, p0, LSZòyiGùS;->yON3x:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final synthetic onAudioAttributesChanged(Landroidx/media3/common/AudioAttributes;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->e8$mp_s$(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/AudioAttributes;)V

    return-void
.end method

.method public final synthetic onAudioSessionIdChanged(I)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->waiBKÀ(Landroidx/media3/common/Player$Listener;I)V

    return-void
.end method

.method public final synthetic onAvailableCommandsChanged(Landroidx/media3/common/Player$Commands;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->rz__9J_(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/Player$Commands;)V

    return-void
.end method

.method public final synthetic onCues(Landroidx/media3/common/text/CueGroup;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->POOl(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/text/CueGroup;)V

    return-void
.end method

.method public final synthetic onCues(Ljava/util/List;)V
    .locals 0

    .line 2
    invoke-static {p0, p1}, LcU$A_o7$;->JKEoÙX(Landroidx/media3/common/Player$Listener;Ljava/util/List;)V

    return-void
.end method

.method public final synthetic onDeviceInfoChanged(Landroidx/media3/common/DeviceInfo;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->tmpData3485(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/DeviceInfo;)V

    return-void
.end method

.method public final synthetic onDeviceVolumeChanged(IZ)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->sKey7917(Landroidx/media3/common/Player$Listener;IZ)V

    return-void
.end method

.method public final synthetic onEvents(Landroidx/media3/common/Player;Landroidx/media3/common/Player$Events;)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->DDù8(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/Player;Landroidx/media3/common/Player$Events;)V

    return-void
.end method

.method public final synthetic onIsLoadingChanged(Z)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->yON3x(Landroidx/media3/common/Player$Listener;Z)V

    return-void
.end method

.method public final onIsPlayingChanged(Z)V
    .locals 3

    .line 1
    iget-object v0, p0, LSZòyiGùS;->vaIue:Linfo/t4w/vp/view/MainActivity;

    .line 2
    .line 3
    iget-object v1, v0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 4
    .line 5
    invoke-interface {v1}, Landroidx/media3/common/Player;->getPlaybackState()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x3

    .line 10
    if-ne v1, v2, :cond_1

    .line 11
    .line 12
    if-eqz p1, :cond_0

    .line 13
    .line 14
    sget p1, LcJLÌfz;->status_playing:I

    .line 15
    .line 16
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    invoke-virtual {v0, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    :cond_0
    sget p1, LcJLÌfz;->status_paused:I

    .line 25
    .line 26
    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-virtual {v0, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    :cond_1
    return-void
.end method

.method public final synthetic onLoadingChanged(Z)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->jPos3709(Landroidx/media3/common/Player$Listener;Z)V

    return-void
.end method

.method public final synthetic onMaxSeekToPreviousPositionChanged(J)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->iOffset934(Landroidx/media3/common/Player$Listener;J)V

    return-void
.end method

.method public final synthetic onMediaItemTransition(Landroidx/media3/common/MediaItem;I)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->kQy(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/MediaItem;I)V

    return-void
.end method

.method public final synthetic onMediaMetadataChanged(Landroidx/media3/common/MediaMetadata;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->Ialue(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/MediaMetadata;)V

    return-void
.end method

.method public final synthetic onMetadata(Landroidx/media3/common/Metadata;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->valuI(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/Metadata;)V

    return-void
.end method

.method public final synthetic onPlayWhenReadyChanged(ZI)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->pCXDYg(Landroidx/media3/common/Player$Listener;ZI)V

    return-void
.end method

.method public final synthetic onPlaybackParametersChanged(Landroidx/media3/common/PlaybackParameters;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->yàÒZ(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/PlaybackParameters;)V

    return-void
.end method

.method public final onPlaybackStateChanged(I)V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iget-object v1, p0, LSZòyiGùS;->vaIue:Linfo/t4w/vp/view/MainActivity;

    .line 3
    .line 4
    if-eq p1, v0, :cond_4

    .line 5
    .line 6
    const/4 v0, 0x2

    .line 7
    if-eq p1, v0, :cond_3

    .line 8
    .line 9
    const/4 v0, 0x3

    .line 10
    if-eq p1, v0, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x4

    .line 13
    if-eq p1, v0, :cond_0

    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    sget p1, LcJLÌfz;->status_ended:I

    .line 17
    .line 18
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    sget v0, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 23
    .line 24
    invoke-virtual {v1, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_1
    iget-object p1, v1, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 29
    .line 30
    invoke-interface {p1}, Landroidx/media3/common/Player;->isPlaying()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    if-eqz p1, :cond_2

    .line 35
    .line 36
    sget p1, LcJLÌfz;->status_playing:I

    .line 37
    .line 38
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    invoke-virtual {v1, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :cond_2
    sget p1, LcJLÌfz;->status_ready:I

    .line 47
    .line 48
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    invoke-virtual {v1, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_3
    sget p1, LcJLÌfz;->status_buffering:I

    .line 57
    .line 58
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    sget v0, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 63
    .line 64
    invoke-virtual {v1, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :cond_4
    sget p1, LcJLÌfz;->status_idle:I

    .line 69
    .line 70
    invoke-virtual {v1, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    sget v0, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 75
    .line 76
    invoke-virtual {v1, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-void
.end method

.method public final synthetic onPlaybackSuppressionReasonChanged(I)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->kO_6X_(Landroidx/media3/common/Player$Listener;I)V

    return-void
.end method

.method public final onPlayerError(Landroidx/media3/common/PlaybackException;)V
    .locals 10

    .line 1
    instance-of v0, p1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 2
    .line 3
    if-eqz v0, :cond_4

    .line 4
    .line 5
    check-cast p1, Landroidx/media3/exoplayer/ExoPlaybackException;

    .line 6
    .line 7
    iget p1, p1, Landroidx/media3/exoplayer/ExoPlaybackException;->type:I

    .line 8
    .line 9
    const/4 v1, 0x1

    .line 10
    iget-object v2, p0, LSZòyiGùS;->vaIue:Linfo/t4w/vp/view/MainActivity;

    .line 11
    .line 12
    if-nez p1, :cond_3

    .line 13
    .line 14
    iget-object p1, v2, Linfo/t4w/vp/view/MainActivity;->CcZMD:Ljava/lang/String;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const-string v8, "video/mp2t"

    .line 20
    .line 21
    const/4 v9, 0x0

    .line 22
    const-string v3, "application/x-mpegURL"

    .line 23
    .line 24
    const-string v4, "application/dash+xml"

    .line 25
    .line 26
    const-string v5, "video/mp4"

    .line 27
    .line 28
    const-string v6, "video/webm"

    .line 29
    .line 30
    const-string v7, "video/x-matroska"

    .line 31
    .line 32
    filled-new-array/range {v3 .. v9}, [Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    const/4 v0, 0x0

    .line 37
    const/4 v4, 0x0

    .line 38
    :goto_0
    const/4 v0, 0x7

    .line 39
    if-ge v4, v0, :cond_2

    .line 40
    .line 41
    aget-object v0, v3, v4

    .line 42
    .line 43
    new-instance v5, Landroidx/media3/common/MediaItem$Builder;

    .line 44
    .line 45
    invoke-direct {v5}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 46
    .line 47
    .line 48
    iget-object v6, p0, LSZòyiGùS;->yON3x:Ljava/lang/String;

    .line 49
    .line 50
    invoke-virtual {v5, v6}, Landroidx/media3/common/MediaItem$Builder;->setUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    if-eqz v0, :cond_0

    .line 55
    .line 56
    invoke-virtual {v5, v0}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 57
    .line 58
    .line 59
    :cond_0
    invoke-virtual {v5}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    new-instance v5, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 64
    .line 65
    invoke-direct {v5, v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    .line 66
    .line 67
    .line 68
    new-instance v6, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 69
    .line 70
    invoke-direct {v6}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    .line 71
    .line 72
    .line 73
    invoke-virtual {v6, p1}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 74
    .line 75
    .line 76
    move-result-object v6

    .line 77
    invoke-virtual {v6, v1}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setAllowCrossProtocolRedirects(Z)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 78
    .line 79
    .line 80
    move-result-object v6

    .line 81
    new-instance v7, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 82
    .line 83
    invoke-direct {v7, v2}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;-><init>(Landroid/content/Context;)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {v7, v6}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->setDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 87
    .line 88
    .line 89
    move-result-object v6

    .line 90
    invoke-virtual {v5, v6}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setMediaSourceFactory(Landroidx/media3/exoplayer/source/MediaSource$Factory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 91
    .line 92
    .line 93
    iget-object v6, v2, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 94
    .line 95
    if-eqz v6, :cond_1

    .line 96
    .line 97
    invoke-interface {v6}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    .line 98
    .line 99
    .line 100
    :cond_1
    invoke-virtual {v5}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    iput-object v5, v2, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 105
    .line 106
    iget-object v6, v2, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 107
    .line 108
    invoke-virtual {v6, v5}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 109
    .line 110
    .line 111
    iget-object v5, v2, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 112
    .line 113
    iput-object v5, v2, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 114
    .line 115
    :try_start_0
    invoke-interface {v5, v0}, Landroidx/media3/common/Player;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 116
    .line 117
    .line 118
    iget-object v5, v2, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 119
    .line 120
    invoke-interface {v5}, Landroidx/media3/common/Player;->prepare()V

    .line 121
    .line 122
    .line 123
    iget-object v5, v2, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 124
    .line 125
    invoke-interface {v5}, Landroidx/media3/common/Player;->play()V

    .line 126
    .line 127
    .line 128
    iput-object v0, v2, Linfo/t4w/vp/view/MainActivity;->YOD0:Landroidx/media3/common/MediaItem;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 129
    .line 130
    goto :goto_1

    .line 131
    :catch_0
    move-exception v0

    .line 132
    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 133
    .line 134
    .line 135
    add-int/lit8 v4, v4, 0x1

    .line 136
    .line 137
    goto :goto_0

    .line 138
    :cond_2
    const-string p1, "Failed to play video with all available formats. Please check the URL."

    .line 139
    .line 140
    invoke-static {v2, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 145
    .line 146
    .line 147
    goto :goto_1

    .line 148
    :cond_3
    const-string p1, "Playback error "

    .line 149
    .line 150
    invoke-static {v2, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 155
    .line 156
    .line 157
    :cond_4
    :goto_1
    return-void
.end method

.method public final synthetic onPlayerErrorChanged(Landroidx/media3/common/PlaybackException;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->Qp_Hp$i_(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/PlaybackException;)V

    return-void
.end method

.method public final synthetic onPlayerStateChanged(ZI)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->UC_n_(Landroidx/media3/common/Player$Listener;ZI)V

    return-void
.end method

.method public final synthetic onPlaylistMetadataChanged(Landroidx/media3/common/MediaMetadata;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->kCount1402(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/MediaMetadata;)V

    return-void
.end method

.method public final synthetic onPositionDiscontinuity(I)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->$ÒcdS(Landroidx/media3/common/Player$Listener;I)V

    return-void
.end method

.method public final synthetic onPositionDiscontinuity(Landroidx/media3/common/Player$PositionInfo;Landroidx/media3/common/Player$PositionInfo;I)V
    .locals 0

    .line 2
    invoke-static {p0, p1, p2, p3}, LcU$A_o7$;->Q1_f_(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/Player$PositionInfo;Landroidx/media3/common/Player$PositionInfo;I)V

    return-void
.end method

.method public final synthetic onRenderedFirstFrame()V
    .locals 0

    .line 1
    invoke-static {p0}, LcU$A_o7$;->tmpSize211(Landroidx/media3/common/Player$Listener;)V

    return-void
.end method

.method public final synthetic onRepeatModeChanged(I)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->sKey6064(Landroidx/media3/common/Player$Listener;I)V

    return-void
.end method

.method public final synthetic onSeekBackIncrementChanged(J)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->tzKù7Ol1(Landroidx/media3/common/Player$Listener;J)V

    return-void
.end method

.method public final synthetic onSeekForwardIncrementChanged(J)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->ll(Landroidx/media3/common/Player$Listener;J)V

    return-void
.end method

.method public final synthetic onShuffleModeEnabledChanged(Z)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->oy_R$Xx_(Landroidx/media3/common/Player$Listener;Z)V

    return-void
.end method

.method public final synthetic onSkipSilenceEnabledChanged(Z)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->yPN$A_n$(Landroidx/media3/common/Player$Listener;Z)V

    return-void
.end method

.method public final synthetic onSurfaceSizeChanged(II)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->Oey(Landroidx/media3/common/Player$Listener;II)V

    return-void
.end method

.method public final synthetic onTimelineChanged(Landroidx/media3/common/Timeline;I)V
    .locals 0

    .line 1
    invoke-static {p0, p1, p2}, LcU$A_o7$;->Iii(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/Timeline;I)V

    return-void
.end method

.method public final synthetic onTrackSelectionParametersChanged(Landroidx/media3/common/TrackSelectionParameters;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->l1(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/TrackSelectionParameters;)V

    return-void
.end method

.method public final synthetic onTracksChanged(Landroidx/media3/common/Tracks;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->pQ1Il(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/Tracks;)V

    return-void
.end method

.method public final synthetic onVideoSizeChanged(Landroidx/media3/common/VideoSize;)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->oaX_6_(Landroidx/media3/common/Player$Listener;Landroidx/media3/common/VideoSize;)V

    return-void
.end method

.method public final synthetic onVolumeChanged(F)V
    .locals 0

    .line 1
    invoke-static {p0, p1}, LcU$A_o7$;->BCIm(Landroidx/media3/common/Player$Listener;F)V

    return-void
.end method
