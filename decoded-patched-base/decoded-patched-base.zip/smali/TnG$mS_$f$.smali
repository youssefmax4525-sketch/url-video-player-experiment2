.class public final synthetic LTnG$mS_$f$;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljma$E_vf$;


# instance fields
.field public final synthetic vaIue:LzO1D1D;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LzO1D1D;I)V
    .locals 0

    .line 1
    iput p2, p0, LTnG$mS_$f$;->yON3x:I

    iput-object p1, p0, LTnG$mS_$f$;->vaIue:LzO1D1D;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final kQy(Ljava/lang/Object;)V
    .locals 3

    .line 1
    iget v0, p0, LTnG$mS_$f$;->yON3x:I

    .line 2
    .line 3
    const/16 v1, 0xb

    .line 4
    .line 5
    iget-object v2, p0, LTnG$mS_$f$;->vaIue:LzO1D1D;

    .line 6
    .line 7
    check-cast p1, LtOeky;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    sget v0, LmÀDjRmG;->lIl1:I

    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1}, LtOeky;->sKey7917()LjPRÒÒI;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    new-instance v2, Lll1Iil;

    .line 22
    .line 23
    invoke-direct {v2, v1}, Lll1Iil;-><init>(I)V

    .line 24
    .line 25
    .line 26
    const/4 v1, 0x7

    .line 27
    invoke-virtual {p1, v0, v1, v2}, LtOeky;->yON3x(LjPRÒÒI;ILjma$E_vf$;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_0
    sget v0, LmÀDjRmG;->lIl1:I

    .line 32
    .line 33
    iget-boolean v0, v2, LzO1D1D;->iOffset934:Z

    .line 34
    .line 35
    invoke-virtual {p1}, LtOeky;->sKey7917()LjPRÒÒI;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    new-instance v2, LFJ_p_;

    .line 40
    .line 41
    invoke-direct {v2, v1}, LFJ_p_;-><init>(I)V

    .line 42
    .line 43
    .line 44
    const/4 v1, -0x1

    .line 45
    invoke-virtual {p1, v0, v1, v2}, LtOeky;->yON3x(LjPRÒÒI;ILjma$E_vf$;)V

    .line 46
    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
