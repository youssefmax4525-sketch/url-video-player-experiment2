.class public final synthetic Ll0ngth;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LiOQ10I;


# instance fields
.field public final synthetic e8$mp_s$:I

.field public final synthetic waiBKÀ:LH9_RW$4g_;


# direct methods
.method public synthetic constructor <init>(LH9_RW$4g_;I)V
    .locals 0

    .line 1
    iput p2, p0, Ll0ngth;->e8$mp_s$:I

    iput-object p1, p0, Ll0ngth;->waiBKÀ:LH9_RW$4g_;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final rz__9J_(Ljava/lang/Object;Ljava/util/Map;)V
    .locals 0

    .line 1
    iget p2, p0, Ll0ngth;->e8$mp_s$:I

    .line 2
    .line 3
    check-cast p1, L_ìdp;

    .line 4
    .line 5
    packed-switch p2, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, Ll0ngth;->waiBKÀ:LH9_RW$4g_;

    .line 9
    .line 10
    iget-object p1, p1, LH9_RW$4g_;->waiBKÀ:LfùOtS;

    .line 11
    .line 12
    const/4 p2, 0x0

    .line 13
    iput-boolean p2, p1, LfùOtS;->kQy:Z

    .line 14
    .line 15
    return-void

    .line 16
    :pswitch_0
    iget-object p1, p0, Ll0ngth;->waiBKÀ:LH9_RW$4g_;

    .line 17
    .line 18
    iget-object p1, p1, LH9_RW$4g_;->waiBKÀ:LfùOtS;

    .line 19
    .line 20
    const/4 p2, 0x1

    .line 21
    iput-boolean p2, p1, LfùOtS;->kQy:Z

    .line 22
    .line 23
    invoke-virtual {p1}, LfùOtS;->e8$mp_s$()V

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
