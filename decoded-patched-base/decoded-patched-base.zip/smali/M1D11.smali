.class public final LM1D11;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public DDù8:I

.field public JKEoÙX:[I

.field public POOl:[I

.field public e8$mp_s$:[B

.field public rz__9J_:I

.field public sKey7917:I

.field public tmpData3485:I

.field public final vaIue:Lll1lliI;

.field public waiBKÀ:[B

.field public final yON3x:Landroid/media/MediaCodec$CryptoInfo;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/media/MediaCodec$CryptoInfo;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/media/MediaCodec$CryptoInfo;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LM1D11;->yON3x:Landroid/media/MediaCodec$CryptoInfo;

    .line 10
    .line 11
    sget v1, LnPos2706;->e8$mp_s$:I

    .line 12
    .line 13
    const/16 v2, 0x18

    .line 14
    .line 15
    if-lt v1, v2, :cond_0

    .line 16
    .line 17
    new-instance v1, Lll1lliI;

    .line 18
    .line 19
    invoke-direct {v1, v0}, Lll1lliI;-><init>(Landroid/media/MediaCodec$CryptoInfo;)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v1, 0x0

    .line 24
    :goto_0
    iput-object v1, p0, LM1D11;->vaIue:Lll1lliI;

    .line 25
    .line 26
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(I)V
    .locals 3

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    iget-object v0, p0, LM1D11;->POOl:[I

    .line 5
    .line 6
    if-nez v0, :cond_1

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    new-array v0, v0, [I

    .line 10
    .line 11
    iput-object v0, p0, LM1D11;->POOl:[I

    .line 12
    .line 13
    iget-object v1, p0, LM1D11;->yON3x:Landroid/media/MediaCodec$CryptoInfo;

    .line 14
    .line 15
    iput-object v0, v1, Landroid/media/MediaCodec$CryptoInfo;->numBytesOfClearData:[I

    .line 16
    .line 17
    :cond_1
    iget-object v0, p0, LM1D11;->POOl:[I

    .line 18
    .line 19
    const/4 v1, 0x0

    .line 20
    aget v2, v0, v1

    .line 21
    .line 22
    add-int/2addr v2, p1

    .line 23
    aput v2, v0, v1

    .line 24
    .line 25
    return-void
.end method
