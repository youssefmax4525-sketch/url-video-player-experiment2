.class public final LJBd_VF_;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LisData1637;

.field public final waiBKÀ:LdQta;


# direct methods
.method public constructor <init>(LisData1637;LdQta;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LJBd_VF_;->e8$mp_s$:LisData1637;

    .line 5
    .line 6
    iput-object p2, p0, LJBd_VF_;->waiBKÀ:LdQta;

    .line 7
    .line 8
    return-void
.end method
