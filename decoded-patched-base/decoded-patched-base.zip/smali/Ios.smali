.class public final synthetic LIos;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic iOffset934:J

.field public final synthetic jPos3709:J

.field public final synthetic kQy:Ljava/lang/Object;

.field public final synthetic vaIue:Ljava/lang/String;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/String;JJI)V
    .locals 0

    .line 1
    iput p7, p0, LIos;->yON3x:I

    iput-object p1, p0, LIos;->kQy:Ljava/lang/Object;

    iput-object p2, p0, LIos;->vaIue:Ljava/lang/String;

    iput-wide p3, p0, LIos;->jPos3709:J

    iput-wide p5, p0, LIos;->iOffset934:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 7

    .line 1
    iget v0, p0, LIos;->yON3x:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LIos;->kQy:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Landroidx/media3/exoplayer/video/VideoRendererEventListener$EventDispatcher;

    iget-wide v3, p0, LIos;->jPos3709:J

    iget-wide v5, p0, LIos;->iOffset934:J

    iget-object v2, p0, LIos;->vaIue:Ljava/lang/String;

    invoke-static/range {v1 .. v6}, Landroidx/media3/exoplayer/video/VideoRendererEventListener$EventDispatcher;->e8$mp_s$(Landroidx/media3/exoplayer/video/VideoRendererEventListener$EventDispatcher;Ljava/lang/String;JJ)V

    return-void

    :pswitch_0
    iget-object v0, p0, LIos;->kQy:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;

    iget-wide v3, p0, LIos;->jPos3709:J

    iget-wide v5, p0, LIos;->iOffset934:J

    iget-object v2, p0, LIos;->vaIue:Ljava/lang/String;

    invoke-static/range {v1 .. v6}, Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;->jPos3709(Landroidx/media3/exoplayer/audio/AudioRendererEventListener$EventDispatcher;Ljava/lang/String;JJ)V

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
