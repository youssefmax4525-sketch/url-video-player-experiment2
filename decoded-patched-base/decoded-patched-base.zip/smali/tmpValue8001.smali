.class public final LtmpValue8001;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LvDri;


# instance fields
.field public final jPos3709:Ljava/lang/Object;

.field public final vaIue:Ljava/lang/Object;

.field public final yON3x:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    iput-object p1, p0, LtmpValue8001;->yON3x:Ljava/lang/Object;

    iput-object p2, p0, LtmpValue8001;->vaIue:Ljava/lang/Object;

    iput-object p3, p0, LtmpValue8001;->jPos3709:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(LvData2439;)V
    .locals 1

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LtmpValue8001;->jPos3709:Ljava/lang/Object;

    new-instance p1, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object p1, p0, LtmpValue8001;->yON3x:Ljava/lang/Object;

    .line 3
    new-instance p1, LqlLqT;

    invoke-direct {p1, p0}, LqlLqT;-><init>(LtmpValue8001;)V

    iput-object p1, p0, LtmpValue8001;->vaIue:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public kQy(Ljava/lang/Object;)V
    .locals 4

    .line 1
    iget-object v0, p0, LtmpValue8001;->yON3x:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lavt$p$;

    .line 4
    .line 5
    iget-object v0, v0, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Laa2l;

    .line 8
    .line 9
    iget-object v1, p0, LtmpValue8001;->vaIue:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v1, LHbsOBAl;

    .line 12
    .line 13
    iget-object v2, p0, LtmpValue8001;->jPos3709:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v2, Ldl1OI;

    .line 16
    .line 17
    check-cast p1, LzyuèV;

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    invoke-interface {p1, v3, v0, v1, v2}, LzyuèV;->POOl(ILaa2l;LHbsOBAl;Ldl1OI;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method
