.class public final LlenQth;
.super LIii11;
.source "SourceFile"


# instance fields
.field public final synthetic e8$mp_s$:LjData2280;


# direct methods
.method public constructor <init>(LjData2280;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LlenQth;->e8$mp_s$:LjData2280;

    .line 5
    .line 6
    return-void
.end method
