.class public final synthetic LTeOàùgQ2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic vaIue:LjData4941;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LjData4941;I)V
    .locals 0

    .line 1
    iput p2, p0, LTeOàùgQ2;->yON3x:I

    iput-object p1, p0, LTeOàùgQ2;->vaIue:LjData4941;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 1
    iget v0, p0, LTeOàùgQ2;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LTeOàùgQ2;->vaIue:LjData4941;

    .line 7
    .line 8
    iget-object v0, v0, LjData4941;->JKEoÙX:LIli;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, v0, LIli;->vaIue:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, LsIndex9566;

    .line 15
    .line 16
    iget-object v0, v0, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, LisItem6344;

    .line 19
    .line 20
    check-cast v0, Linfo/t4w/vp/view/MultiCastActivity;

    .line 21
    .line 22
    iget-object v1, v0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 23
    .line 24
    new-instance v2, Lcn_v_;

    .line 25
    .line 26
    const/16 v3, 0x12

    .line 27
    .line 28
    invoke-direct {v2, v0, v3}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 32
    .line 33
    .line 34
    :cond_0
    return-void

    .line 35
    :pswitch_0
    iget-object v0, p0, LTeOàùgQ2;->vaIue:LjData4941;

    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 38
    .line 39
    .line 40
    :try_start_0
    iget-object v1, v0, LjData4941;->rz__9J_:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;

    .line 41
    .line 42
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->startDiscovery()V

    .line 43
    .line 44
    .line 45
    iget-object v1, v0, LjData4941;->waiBKÀ:Landroid/os/Handler;

    .line 46
    .line 47
    new-instance v2, LTeOàùgQ2;

    .line 48
    .line 49
    const/4 v3, 0x1

    .line 50
    invoke-direct {v2, v0, v3}, LTeOàùgQ2;-><init>(LjData4941;I)V

    .line 51
    .line 52
    .line 53
    const-wide/16 v3, 0xbb8

    .line 54
    .line 55
    invoke-virtual {v1, v2, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    .line 57
    .line 58
    goto :goto_0

    .line 59
    :catch_0
    move-exception v1

    .line 60
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    iget-object v0, v0, LjData4941;->JKEoÙX:LIli;

    .line 64
    .line 65
    if-eqz v0, :cond_1

    .line 66
    .line 67
    new-instance v2, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    const-string v3, "Error starting AirPlay discovery: "

    .line 70
    .line 71
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    iget-object v0, v0, LIli;->vaIue:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v0, LsIndex9566;

    .line 88
    .line 89
    iget-object v0, v0, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast v0, LisItem6344;

    .line 92
    .line 93
    check-cast v0, Linfo/t4w/vp/view/MultiCastActivity;

    .line 94
    .line 95
    iget-object v2, v0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 96
    .line 97
    new-instance v3, LIl;

    .line 98
    .line 99
    const/16 v4, 0x13

    .line 100
    .line 101
    invoke-direct {v3, v4, v0, v1}, LIl;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 105
    .line 106
    .line 107
    :cond_1
    :goto_0
    return-void

    .line 108
    nop

    .line 109
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
