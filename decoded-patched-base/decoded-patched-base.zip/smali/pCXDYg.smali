.class public final LpCXDYg;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final waiBKÀ:LpCXDYg;


# instance fields
.field public final e8$mp_s$:Ljava/lang/Throwable;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LpCXDYg;

    .line 2
    .line 3
    new-instance v1, LIalue;

    .line 4
    .line 5
    const-string v2, "Failure occurred while trying to finish a future."

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    invoke-direct {v1, v2, v3}, LIalue;-><init>(Ljava/lang/String;I)V

    .line 9
    .line 10
    .line 11
    invoke-direct {v0, v1}, LpCXDYg;-><init>(Ljava/lang/Throwable;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, LpCXDYg;->waiBKÀ:LpCXDYg;

    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-boolean v0, LpQ1Il;->iOffset934:Z

    .line 5
    .line 6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, LpCXDYg;->e8$mp_s$:Ljava/lang/Throwable;

    .line 10
    .line 11
    return-void
.end method
