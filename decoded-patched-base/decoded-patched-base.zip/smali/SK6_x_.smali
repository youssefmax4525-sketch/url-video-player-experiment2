.class public abstract LSK6_x_;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e8$mp_s$:LvSize4545;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "gads:signals_collection_on_service:enabled"

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, LvSize4545;->kCount1402(Ljava/lang/String;Z)LvSize4545;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sput-object v0, LSK6_x_;->e8$mp_s$:LvSize4545;

    .line 9
    .line 10
    return-void
.end method
