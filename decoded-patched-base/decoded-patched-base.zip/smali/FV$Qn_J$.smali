.class public abstract LFV$Qn_J$;
.super Ljava/lang/Object;


# static fields
.field public static ic_media_route_learn_more_accessibility:I = 0x7f1400c3

.field public static mr_button_content_description:I = 0x7f140116

.field public static mr_cast_button_connected:I = 0x7f140117

.field public static mr_cast_button_connecting:I = 0x7f140118

.field public static mr_cast_button_disconnected:I = 0x7f140119

.field public static mr_cast_dialog_title_view_placeholder:I = 0x7f14011a

.field public static mr_chooser_looking_for_devices:I = 0x7f14011b

.field public static mr_chooser_searching:I = 0x7f14011c

.field public static mr_chooser_title:I = 0x7f14011d

.field public static mr_chooser_wifi_learn_more:I = 0x7f14011e

.field public static mr_chooser_wifi_warning_description_car:I = 0x7f14011f

.field public static mr_chooser_wifi_warning_description_phone:I = 0x7f140120

.field public static mr_chooser_wifi_warning_description_tablet:I = 0x7f140121

.field public static mr_chooser_wifi_warning_description_tv:I = 0x7f140122

.field public static mr_chooser_wifi_warning_description_unknown:I = 0x7f140123

.field public static mr_chooser_wifi_warning_description_watch:I = 0x7f140124

.field public static mr_chooser_zero_routes_found_title:I = 0x7f140125

.field public static mr_controller_album_art:I = 0x7f140126

.field public static mr_controller_casting_screen:I = 0x7f140127

.field public static mr_controller_close_description:I = 0x7f140128

.field public static mr_controller_collapse_group:I = 0x7f140129

.field public static mr_controller_disconnect:I = 0x7f14012a

.field public static mr_controller_expand_group:I = 0x7f14012b

.field public static mr_controller_no_info_available:I = 0x7f14012c

.field public static mr_controller_no_media_selected:I = 0x7f14012d

.field public static mr_controller_pause:I = 0x7f14012e

.field public static mr_controller_play:I = 0x7f14012f

.field public static mr_controller_stop:I = 0x7f140130

.field public static mr_controller_stop_casting:I = 0x7f140131

.field public static mr_controller_volume_slider:I = 0x7f140132

.field public static mr_dialog_default_group_name:I = 0x7f140133

.field public static mr_dialog_groupable_header:I = 0x7f140134

.field public static mr_dialog_transferable_header:I = 0x7f140135

.field public static mr_route_name_bluetooth:I = 0x7f140136

.field public static mr_route_name_speaker:I = 0x7f140137

.field public static mr_route_name_tv:I = 0x7f140138

.field public static mr_route_name_unknown:I = 0x7f140139

.field public static mr_system_route_name:I = 0x7f14013a

.field public static mr_user_route_category_name:I = 0x7f14013b
