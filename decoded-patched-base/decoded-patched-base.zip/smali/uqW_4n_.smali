.class public final LuqW_4n_;
.super LsData6135;
.source "SourceFile"


# instance fields
.field public final synthetic yON3x:LnSize5276;


# direct methods
.method public constructor <init>(LnSize5276;)V
    .locals 0

    .line 1
    iput-object p1, p0, LuqW_4n_;->yON3x:LnSize5276;

    .line 2
    .line 3
    invoke-direct {p0}, LsData6135;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final Qp_Hp$i_(I)V
    .locals 5

    .line 1
    iget-object v0, p0, LuqW_4n_;->yON3x:LnSize5276;

    .line 2
    .line 3
    iget-object v1, v0, LnSize5276;->waiBKÀ:Lah_1k$4v_;

    .line 4
    .line 5
    iget-wide v2, v0, LnSize5276;->e8$mp_s$:J

    .line 6
    .line 7
    new-instance v0, LIiII11I;

    .line 8
    .line 9
    const-string v4, "rewarded"

    .line 10
    .line 11
    invoke-direct {v0, v4}, LIiII11I;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iput-object v2, v0, LIiII11I;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    const-string v2, "onRewardedAdFailedToLoad"

    .line 21
    .line 22
    iput-object v2, v0, LIiII11I;->iOffset934:Ljava/lang/Object;

    .line 23
    .line 24
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iput-object p1, v0, LIiII11I;->kQy:Ljava/lang/Object;

    .line 29
    .line 30
    invoke-virtual {v1, v0}, Lah_1k$4v_;->JKEoÙX(LIiII11I;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final tmpData3485()V
    .locals 5

    .line 1
    iget-object v0, p0, LuqW_4n_;->yON3x:LnSize5276;

    .line 2
    .line 3
    iget-object v1, v0, LnSize5276;->waiBKÀ:Lah_1k$4v_;

    .line 4
    .line 5
    iget-wide v2, v0, LnSize5276;->e8$mp_s$:J

    .line 6
    .line 7
    new-instance v0, LIiII11I;

    .line 8
    .line 9
    const-string v4, "rewarded"

    .line 10
    .line 11
    invoke-direct {v0, v4}, LIiII11I;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    iput-object v2, v0, LIiII11I;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    const-string v2, "onRewardedAdLoaded"

    .line 21
    .line 22
    iput-object v2, v0, LIiII11I;->iOffset934:Ljava/lang/Object;

    .line 23
    .line 24
    invoke-virtual {v1, v0}, Lah_1k$4v_;->JKEoÙX(LIiII11I;)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public final yàÒZ(LjData6565;)V
    .locals 5

    .line 1
    iget-object v0, p0, LuqW_4n_;->yON3x:LnSize5276;

    .line 2
    .line 3
    iget-object v1, v0, LnSize5276;->waiBKÀ:Lah_1k$4v_;

    .line 4
    .line 5
    iget-wide v2, v0, LnSize5276;->e8$mp_s$:J

    .line 6
    .line 7
    iget p1, p1, LjData6565;->yON3x:I

    .line 8
    .line 9
    new-instance v0, LIiII11I;

    .line 10
    .line 11
    const-string v4, "rewarded"

    .line 12
    .line 13
    invoke-direct {v0, v4}, LIiII11I;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    iput-object v2, v0, LIiII11I;->vaIue:Ljava/lang/Object;

    .line 21
    .line 22
    const-string v2, "onRewardedAdFailedToLoad"

    .line 23
    .line 24
    iput-object v2, v0, LIiII11I;->iOffset934:Ljava/lang/Object;

    .line 25
    .line 26
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    iput-object p1, v0, LIiII11I;->kQy:Ljava/lang/Object;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Lah_1k$4v_;->JKEoÙX(LIiII11I;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method
