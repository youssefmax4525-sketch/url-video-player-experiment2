.class public final Lp0$pt$;
.super L_zoTo3l;
.source "SourceFile"

# interfaces
.implements LKqXQÒK;


# static fields
.field public static final ll:Ljava/util/concurrent/atomic/AtomicReference;

.field public static final tzKù7Ol1:Ljava/util/regex/Pattern;


# instance fields
.field public $ÒcdS:J

.field public final Ialue:I

.field public K0I:Z

.field public Q1_f_:J

.field public Qp_Hp$i_:I

.field public UC_n_:J

.field public gKey4112:Ljava/net/HttpURLConnection;

.field public kCount1402:J

.field public kO_6X_:Ljava/io/InputStream;

.field public final kQy:LhasKey9751;

.field public final pCXDYg:Ljava/lang/String;

.field public final sKey6064:Ljava/util/HashSet;

.field public tmpSize211:I

.field public final valuI:I

.field public final yàÒZ:Lavt$p$;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "^bytes (\\d+)-(\\d+)/(\\d+)$"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lp0$pt$;->tzKù7Ol1:Ljava/util/regex/Pattern;

    .line 8
    .line 9
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lp0$pt$;->ll:Ljava/util/concurrent/atomic/AtomicReference;

    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;LTeòRiiz;III)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-direct {p0, v0}, L_zoTo3l;-><init>(Z)V

    .line 3
    .line 4
    .line 5
    new-instance v0, LhasKey9751;

    .line 6
    .line 7
    invoke-direct {v0, p0}, LhasKey9751;-><init>(Lp0$pt$;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lp0$pt$;->kQy:LhasKey9751;

    .line 11
    .line 12
    new-instance v0, Ljava/util/HashSet;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Lp0$pt$;->sKey6064:Ljava/util/HashSet;

    .line 18
    .line 19
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_1

    .line 24
    .line 25
    iput-object p1, p0, Lp0$pt$;->pCXDYg:Ljava/lang/String;

    .line 26
    .line 27
    new-instance p1, Lavt$p$;

    .line 28
    .line 29
    const/4 v0, 0x2

    .line 30
    invoke-direct {p1, v0}, Lavt$p$;-><init>(I)V

    .line 31
    .line 32
    .line 33
    iput-object p1, p0, Lp0$pt$;->yàÒZ:Lavt$p$;

    .line 34
    .line 35
    iput p3, p0, Lp0$pt$;->Ialue:I

    .line 36
    .line 37
    iput p4, p0, Lp0$pt$;->valuI:I

    .line 38
    .line 39
    iput p5, p0, Lp0$pt$;->tmpSize211:I

    .line 40
    .line 41
    if-eqz p2, :cond_0

    .line 42
    .line 43
    invoke-virtual {p0, p2}, L_zoTo3l;->POOl(LhasValue4608;)V

    .line 44
    .line 45
    .line 46
    :cond_0
    return-void

    .line 47
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 48
    .line 49
    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 50
    .line 51
    .line 52
    throw p1
.end method


# virtual methods
.method public final DDù8()Landroid/net/Uri;
    .locals 1

    .line 1
    iget-object v0, p0, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    return-object v0

    .line 7
    :cond_0
    invoke-virtual {v0}, Ljava/net/URLConnection;->getURL()Ljava/net/URL;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Ljava/net/URL;->toString()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    return-object v0
.end method

.method public final JKEoÙX([BII)I
    .locals 9

    .line 1
    sget-object v0, Lp0$pt$;->ll:Ljava/util/concurrent/atomic/AtomicReference;

    .line 2
    .line 3
    :try_start_0
    iget-wide v1, p0, Lp0$pt$;->$ÒcdS:J

    .line 4
    .line 5
    iget-wide v3, p0, Lp0$pt$;->UC_n_:J

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, -0x1

    .line 9
    cmp-long v7, v1, v3

    .line 10
    .line 11
    if-nez v7, :cond_0

    .line 12
    .line 13
    goto :goto_1

    .line 14
    :cond_0
    const/4 v1, 0x0

    .line 15
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, [B

    .line 20
    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    const/16 v1, 0x1000

    .line 24
    .line 25
    new-array v1, v1, [B

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :catch_0
    move-exception p1

    .line 29
    goto/16 :goto_3

    .line 30
    .line 31
    :cond_1
    :goto_0
    iget-wide v2, p0, Lp0$pt$;->$ÒcdS:J

    .line 32
    .line 33
    iget-wide v7, p0, Lp0$pt$;->UC_n_:J

    .line 34
    .line 35
    cmp-long v4, v2, v7

    .line 36
    .line 37
    if-eqz v4, :cond_4

    .line 38
    .line 39
    array-length v4, v1

    .line 40
    sub-long/2addr v7, v2

    .line 41
    int-to-long v2, v4

    .line 42
    invoke-static {v7, v8, v2, v3}, Ljava/lang/Math;->min(JJ)J

    .line 43
    .line 44
    .line 45
    move-result-wide v2

    .line 46
    long-to-int v3, v2

    .line 47
    iget-object v2, p0, Lp0$pt$;->kO_6X_:Ljava/io/InputStream;

    .line 48
    .line 49
    invoke-virtual {v2, v1, v5, v3}, Ljava/io/InputStream;->read([BII)I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    invoke-static {}, Ljava/lang/Thread;->interrupted()Z

    .line 54
    .line 55
    .line 56
    move-result v3

    .line 57
    if-nez v3, :cond_3

    .line 58
    .line 59
    if-eq v2, v6, :cond_2

    .line 60
    .line 61
    iget-wide v3, p0, Lp0$pt$;->$ÒcdS:J

    .line 62
    .line 63
    int-to-long v7, v2

    .line 64
    add-long/2addr v3, v7

    .line 65
    iput-wide v3, p0, Lp0$pt$;->$ÒcdS:J

    .line 66
    .line 67
    invoke-virtual {p0, v2}, L_zoTo3l;->$ÒcdS(I)V

    .line 68
    .line 69
    .line 70
    goto :goto_0

    .line 71
    :cond_2
    new-instance p1, Ljava/io/EOFException;

    .line 72
    .line 73
    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    .line 74
    .line 75
    .line 76
    throw p1

    .line 77
    :cond_3
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 78
    .line 79
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 80
    .line 81
    .line 82
    throw p1

    .line 83
    :cond_4
    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    :goto_1
    if-nez p3, :cond_5

    .line 87
    .line 88
    return v5

    .line 89
    :cond_5
    iget-wide v0, p0, Lp0$pt$;->kCount1402:J

    .line 90
    .line 91
    const-wide/16 v2, -0x1

    .line 92
    .line 93
    cmp-long v4, v0, v2

    .line 94
    .line 95
    if-eqz v4, :cond_7

    .line 96
    .line 97
    iget-wide v4, p0, Lp0$pt$;->Q1_f_:J

    .line 98
    .line 99
    sub-long/2addr v0, v4

    .line 100
    const-wide/16 v4, 0x0

    .line 101
    .line 102
    cmp-long v7, v0, v4

    .line 103
    .line 104
    if-nez v7, :cond_6

    .line 105
    .line 106
    goto :goto_2

    .line 107
    :cond_6
    int-to-long v4, p3

    .line 108
    invoke-static {v4, v5, v0, v1}, Ljava/lang/Math;->min(JJ)J

    .line 109
    .line 110
    .line 111
    move-result-wide v0

    .line 112
    long-to-int p3, v0

    .line 113
    :cond_7
    iget-object v0, p0, Lp0$pt$;->kO_6X_:Ljava/io/InputStream;

    .line 114
    .line 115
    invoke-virtual {v0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    .line 116
    .line 117
    .line 118
    move-result p1

    .line 119
    if-ne p1, v6, :cond_9

    .line 120
    .line 121
    iget-wide p1, p0, Lp0$pt$;->kCount1402:J

    .line 122
    .line 123
    cmp-long p3, p1, v2

    .line 124
    .line 125
    if-nez p3, :cond_8

    .line 126
    .line 127
    :goto_2
    return v6

    .line 128
    :cond_8
    new-instance p1, Ljava/io/EOFException;

    .line 129
    .line 130
    invoke-direct {p1}, Ljava/io/EOFException;-><init>()V

    .line 131
    .line 132
    .line 133
    throw p1

    .line 134
    :cond_9
    iget-wide p2, p0, Lp0$pt$;->Q1_f_:J

    .line 135
    .line 136
    int-to-long v0, p1

    .line 137
    add-long/2addr p2, v0

    .line 138
    iput-wide p2, p0, Lp0$pt$;->Q1_f_:J

    .line 139
    .line 140
    invoke-virtual {p0, p1}, L_zoTo3l;->$ÒcdS(I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 141
    .line 142
    .line 143
    return p1

    .line 144
    :goto_3
    new-instance p2, LvQs_w$S_;

    .line 145
    .line 146
    const/16 p3, 0x7d0

    .line 147
    .line 148
    const/4 v0, 0x2

    .line 149
    invoke-direct {p2, p3, v0, p1}, LvQs_w$S_;-><init>(IILjava/io/IOException;)V

    .line 150
    .line 151
    .line 152
    throw p2
.end method

.method public final e8$mp_s$(Lr8_9_;)J
    .locals 20

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    const-string v3, "Unable to connect to "

    .line 6
    .line 7
    const-wide/16 v4, 0x0

    .line 8
    .line 9
    iput-wide v4, v1, Lp0$pt$;->Q1_f_:J

    .line 10
    .line 11
    iput-wide v4, v1, Lp0$pt$;->$ÒcdS:J

    .line 12
    .line 13
    :try_start_0
    new-instance v0, Ljava/net/URL;

    .line 14
    .line 15
    iget-object v8, v2, Lr8_9_;->e8$mp_s$:Landroid/net/Uri;

    .line 16
    .line 17
    iget-wide v9, v2, Lr8_9_;->rz__9J_:J

    .line 18
    .line 19
    iget-wide v11, v2, Lr8_9_;->POOl:J

    .line 20
    .line 21
    invoke-virtual {v8}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v8

    .line 25
    invoke-direct {v0, v8}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 26
    .line 27
    .line 28
    const/4 v8, 0x0

    .line 29
    const/4 v13, 0x0

    .line 30
    :goto_0
    add-int/lit8 v14, v13, 0x1

    .line 31
    .line 32
    const/16 v15, 0x14

    .line 33
    .line 34
    if-gt v13, v15, :cond_14

    .line 35
    .line 36
    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 37
    .line 38
    .line 39
    move-result-object v13

    .line 40
    check-cast v13, Ljava/net/HttpURLConnection;

    .line 41
    .line 42
    instance-of v15, v13, Ljavax/net/ssl/HttpsURLConnection;

    .line 43
    .line 44
    if-eqz v15, :cond_0

    .line 45
    .line 46
    move-object v15, v13

    .line 47
    check-cast v15, Ljavax/net/ssl/HttpsURLConnection;

    .line 48
    .line 49
    move-wide/from16 v16, v4

    .line 50
    .line 51
    iget-object v4, v1, Lp0$pt$;->kQy:LhasKey9751;

    .line 52
    .line 53
    invoke-virtual {v15, v4}, Ljavax/net/ssl/HttpsURLConnection;->setSSLSocketFactory(Ljavax/net/ssl/SSLSocketFactory;)V

    .line 54
    .line 55
    .line 56
    goto :goto_1

    .line 57
    :catch_0
    move-exception v0

    .line 58
    goto/16 :goto_c

    .line 59
    .line 60
    :cond_0
    move-wide/from16 v16, v4

    .line 61
    .line 62
    :goto_1
    iget v4, v1, Lp0$pt$;->Ialue:I

    .line 63
    .line 64
    invoke-virtual {v13, v4}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 65
    .line 66
    .line 67
    iget v4, v1, Lp0$pt$;->valuI:I

    .line 68
    .line 69
    invoke-virtual {v13, v4}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 70
    .line 71
    .line 72
    iget-object v4, v1, Lp0$pt$;->yàÒZ:Lavt$p$;

    .line 73
    .line 74
    invoke-virtual {v4}, Lavt$p$;->e8$mp_s$()Ljava/util/Map;

    .line 75
    .line 76
    .line 77
    move-result-object v4

    .line 78
    invoke-interface {v4}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 83
    .line 84
    .line 85
    move-result-object v4

    .line 86
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 87
    .line 88
    .line 89
    move-result v5

    .line 90
    if-eqz v5, :cond_1

    .line 91
    .line 92
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v5

    .line 96
    check-cast v5, Ljava/util/Map$Entry;

    .line 97
    .line 98
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 99
    .line 100
    .line 101
    move-result-object v15

    .line 102
    check-cast v15, Ljava/lang/String;

    .line 103
    .line 104
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 105
    .line 106
    .line 107
    move-result-object v5

    .line 108
    check-cast v5, Ljava/lang/String;

    .line 109
    .line 110
    invoke-virtual {v13, v15, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_1
    const-wide/16 v4, -0x1

    .line 115
    .line 116
    cmp-long v15, v9, v16

    .line 117
    .line 118
    if-nez v15, :cond_3

    .line 119
    .line 120
    cmp-long v18, v11, v4

    .line 121
    .line 122
    if-eqz v18, :cond_2

    .line 123
    .line 124
    move-wide/from16 v18, v4

    .line 125
    .line 126
    move-wide/from16 v4, v16

    .line 127
    .line 128
    goto :goto_3

    .line 129
    :cond_2
    move-wide/from16 v18, v4

    .line 130
    .line 131
    goto :goto_4

    .line 132
    :cond_3
    move-wide/from16 v18, v4

    .line 133
    .line 134
    move-wide v4, v9

    .line 135
    :goto_3
    new-instance v6, Ljava/lang/StringBuilder;

    .line 136
    .line 137
    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    .line 138
    .line 139
    .line 140
    const-string v7, "bytes="

    .line 141
    .line 142
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v6, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    const-string v7, "-"

    .line 149
    .line 150
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 151
    .line 152
    .line 153
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 154
    .line 155
    .line 156
    move-result-object v6

    .line 157
    cmp-long v7, v11, v18

    .line 158
    .line 159
    if-eqz v7, :cond_4

    .line 160
    .line 161
    add-long/2addr v4, v11

    .line 162
    add-long v4, v4, v18

    .line 163
    .line 164
    new-instance v7, Ljava/lang/StringBuilder;

    .line 165
    .line 166
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 167
    .line 168
    .line 169
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 170
    .line 171
    .line 172
    invoke-virtual {v7, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 173
    .line 174
    .line 175
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    :cond_4
    const-string v4, "Range"

    .line 180
    .line 181
    invoke-virtual {v13, v4, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 182
    .line 183
    .line 184
    :goto_4
    const-string v4, "User-Agent"

    .line 185
    .line 186
    iget-object v5, v1, Lp0$pt$;->pCXDYg:Ljava/lang/String;

    .line 187
    .line 188
    invoke-virtual {v13, v4, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    const-string v4, "Accept-Encoding"

    .line 192
    .line 193
    const-string v5, "identity"

    .line 194
    .line 195
    invoke-virtual {v13, v4, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v13, v8}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    .line 199
    .line 200
    .line 201
    invoke-virtual {v13, v8}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v13}, Ljava/net/URLConnection;->connect()V

    .line 205
    .line 206
    .line 207
    invoke-virtual {v13}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 208
    .line 209
    .line 210
    move-result v4

    .line 211
    const/16 v5, 0x12c

    .line 212
    .line 213
    if-eq v4, v5, :cond_10

    .line 214
    .line 215
    const/16 v5, 0x12d

    .line 216
    .line 217
    if-eq v4, v5, :cond_10

    .line 218
    .line 219
    const/16 v5, 0x12e

    .line 220
    .line 221
    if-eq v4, v5, :cond_10

    .line 222
    .line 223
    const/16 v5, 0x12f

    .line 224
    .line 225
    if-eq v4, v5, :cond_10

    .line 226
    .line 227
    const/16 v5, 0x133

    .line 228
    .line 229
    if-eq v4, v5, :cond_10

    .line 230
    .line 231
    const/16 v5, 0x134

    .line 232
    .line 233
    if-ne v4, v5, :cond_5

    .line 234
    .line 235
    goto/16 :goto_a

    .line 236
    .line 237
    :cond_5
    iput-object v13, v1, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 238
    .line 239
    :try_start_1
    invoke-virtual {v13}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 240
    .line 241
    .line 242
    move-result v0

    .line 243
    iput v0, v1, Lp0$pt$;->Qp_Hp$i_:I
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_4

    .line 244
    .line 245
    const/16 v3, 0xc8

    .line 246
    .line 247
    if-lt v0, v3, :cond_e

    .line 248
    .line 249
    const/16 v4, 0x12b

    .line 250
    .line 251
    if-le v0, v4, :cond_6

    .line 252
    .line 253
    goto/16 :goto_9

    .line 254
    .line 255
    :cond_6
    if-ne v0, v3, :cond_7

    .line 256
    .line 257
    if-nez v15, :cond_8

    .line 258
    .line 259
    :cond_7
    move-wide/from16 v9, v16

    .line 260
    .line 261
    :cond_8
    iput-wide v9, v1, Lp0$pt$;->UC_n_:J

    .line 262
    .line 263
    cmp-long v0, v11, v18

    .line 264
    .line 265
    if-eqz v0, :cond_9

    .line 266
    .line 267
    iput-wide v11, v1, Lp0$pt$;->kCount1402:J

    .line 268
    .line 269
    goto/16 :goto_8

    .line 270
    .line 271
    :cond_9
    iget-object v0, v1, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 272
    .line 273
    const-string v3, "Content-Length"

    .line 274
    .line 275
    invoke-virtual {v0, v3}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    .line 276
    .line 277
    .line 278
    move-result-object v3

    .line 279
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 280
    .line 281
    .line 282
    move-result v4

    .line 283
    const-string v5, "]"

    .line 284
    .line 285
    if-nez v4, :cond_a

    .line 286
    .line 287
    :try_start_2
    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 288
    .line 289
    .line 290
    move-result-wide v6
    :try_end_2
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    .line 291
    goto :goto_5

    .line 292
    :catch_1
    new-instance v4, Ljava/lang/StringBuilder;

    .line 293
    .line 294
    const-string v6, "Unexpected Content-Length ["

    .line 295
    .line 296
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 300
    .line 301
    .line 302
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 303
    .line 304
    .line 305
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 306
    .line 307
    .line 308
    move-result-object v4

    .line 309
    invoke-static {v4}, LPJNypàa;->WoI_9_(Ljava/lang/String;)V

    .line 310
    .line 311
    .line 312
    :cond_a
    move-wide/from16 v6, v18

    .line 313
    .line 314
    :goto_5
    const-string v4, "Content-Range"

    .line 315
    .line 316
    invoke-virtual {v0, v4}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    .line 317
    .line 318
    .line 319
    move-result-object v0

    .line 320
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 321
    .line 322
    .line 323
    move-result v4

    .line 324
    if-nez v4, :cond_c

    .line 325
    .line 326
    sget-object v4, Lp0$pt$;->tzKù7Ol1:Ljava/util/regex/Pattern;

    .line 327
    .line 328
    invoke-virtual {v4, v0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 329
    .line 330
    .line 331
    move-result-object v4

    .line 332
    invoke-virtual {v4}, Ljava/util/regex/Matcher;->find()Z

    .line 333
    .line 334
    .line 335
    move-result v8

    .line 336
    if-eqz v8, :cond_c

    .line 337
    .line 338
    const/4 v8, 0x2

    .line 339
    :try_start_3
    invoke-virtual {v4, v8}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 340
    .line 341
    .line 342
    move-result-object v8

    .line 343
    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 344
    .line 345
    .line 346
    move-result-wide v8

    .line 347
    const/4 v10, 0x1

    .line 348
    invoke-virtual {v4, v10}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object v4

    .line 352
    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 353
    .line 354
    .line 355
    move-result-wide v10

    .line 356
    sub-long/2addr v8, v10

    .line 357
    cmp-long v4, v6, v16

    .line 358
    .line 359
    const-wide/16 v10, 0x1

    .line 360
    .line 361
    add-long/2addr v8, v10

    .line 362
    if-gez v4, :cond_b

    .line 363
    .line 364
    move-wide v6, v8

    .line 365
    goto :goto_6

    .line 366
    :cond_b
    cmp-long v4, v6, v8

    .line 367
    .line 368
    if-eqz v4, :cond_c

    .line 369
    .line 370
    new-instance v4, Ljava/lang/StringBuilder;

    .line 371
    .line 372
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 373
    .line 374
    .line 375
    const-string v10, "Inconsistent headers ["

    .line 376
    .line 377
    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 378
    .line 379
    .line 380
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 381
    .line 382
    .line 383
    const-string v3, "] ["

    .line 384
    .line 385
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 386
    .line 387
    .line 388
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 389
    .line 390
    .line 391
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 392
    .line 393
    .line 394
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object v3

    .line 398
    invoke-static {v3}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 399
    .line 400
    .line 401
    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->max(JJ)J

    .line 402
    .line 403
    .line 404
    move-result-wide v6
    :try_end_3
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_3} :catch_2

    .line 405
    goto :goto_6

    .line 406
    :catch_2
    new-instance v3, Ljava/lang/StringBuilder;

    .line 407
    .line 408
    const-string v4, "Unexpected Content-Range ["

    .line 409
    .line 410
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 411
    .line 412
    .line 413
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 414
    .line 415
    .line 416
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 417
    .line 418
    .line 419
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 420
    .line 421
    .line 422
    move-result-object v0

    .line 423
    invoke-static {v0}, LPJNypàa;->WoI_9_(Ljava/lang/String;)V

    .line 424
    .line 425
    .line 426
    :cond_c
    :goto_6
    cmp-long v0, v6, v18

    .line 427
    .line 428
    if-eqz v0, :cond_d

    .line 429
    .line 430
    iget-wide v3, v1, Lp0$pt$;->UC_n_:J

    .line 431
    .line 432
    sub-long v3, v6, v3

    .line 433
    .line 434
    move-wide v4, v3

    .line 435
    goto :goto_7

    .line 436
    :cond_d
    move-wide/from16 v4, v18

    .line 437
    .line 438
    :goto_7
    iput-wide v4, v1, Lp0$pt$;->kCount1402:J

    .line 439
    .line 440
    :goto_8
    :try_start_4
    iget-object v0, v1, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 441
    .line 442
    invoke-virtual {v0}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 443
    .line 444
    .line 445
    move-result-object v0

    .line 446
    iput-object v0, v1, Lp0$pt$;->kO_6X_:Ljava/io/InputStream;
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3

    .line 447
    .line 448
    const/4 v10, 0x1

    .line 449
    iput-boolean v10, v1, Lp0$pt$;->K0I:Z

    .line 450
    .line 451
    invoke-virtual/range {p0 .. p1}, L_zoTo3l;->jPos3709(Lr8_9_;)V

    .line 452
    .line 453
    .line 454
    iget-wide v2, v1, Lp0$pt$;->kCount1402:J

    .line 455
    .line 456
    return-wide v2

    .line 457
    :catch_3
    move-exception v0

    .line 458
    invoke-virtual {v1}, Lp0$pt$;->iOffset934()V

    .line 459
    .line 460
    .line 461
    new-instance v2, LvQs_w$S_;

    .line 462
    .line 463
    const/16 v3, 0x7d0

    .line 464
    .line 465
    const/4 v10, 0x1

    .line 466
    invoke-direct {v2, v3, v10, v0}, LvQs_w$S_;-><init>(IILjava/io/IOException;)V

    .line 467
    .line 468
    .line 469
    throw v2

    .line 470
    :cond_e
    :goto_9
    iget-object v0, v1, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 471
    .line 472
    invoke-virtual {v0}, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;

    .line 473
    .line 474
    .line 475
    invoke-virtual {v1}, Lp0$pt$;->iOffset934()V

    .line 476
    .line 477
    .line 478
    new-instance v0, LPÙDYx;

    .line 479
    .line 480
    iget v2, v1, Lp0$pt$;->Qp_Hp$i_:I

    .line 481
    .line 482
    sget v3, LnPos2706;->e8$mp_s$:I

    .line 483
    .line 484
    const/4 v3, 0x0

    .line 485
    invoke-direct {v0, v2, v3}, LPÙDYx;-><init>(ILiSize5679;)V

    .line 486
    .line 487
    .line 488
    iget v2, v1, Lp0$pt$;->Qp_Hp$i_:I

    .line 489
    .line 490
    const/16 v3, 0x1a0

    .line 491
    .line 492
    if-ne v2, v3, :cond_f

    .line 493
    .line 494
    new-instance v2, LiSize5679;

    .line 495
    .line 496
    invoke-direct {v2}, LiSize5679;-><init>()V

    .line 497
    .line 498
    .line 499
    invoke-virtual {v0, v2}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 500
    .line 501
    .line 502
    :cond_f
    throw v0

    .line 503
    :catch_4
    move-exception v0

    .line 504
    invoke-virtual {v1}, Lp0$pt$;->iOffset934()V

    .line 505
    .line 506
    .line 507
    new-instance v4, LvQs_w$S_;

    .line 508
    .line 509
    iget-object v2, v2, Lr8_9_;->e8$mp_s$:Landroid/net/Uri;

    .line 510
    .line 511
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object v2

    .line 515
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 516
    .line 517
    .line 518
    move-result-object v2

    .line 519
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 520
    .line 521
    .line 522
    move-result-object v2

    .line 523
    const/16 v3, 0x7d0

    .line 524
    .line 525
    const/4 v10, 0x1

    .line 526
    invoke-direct {v4, v2, v0, v3, v10}, LvQs_w$S_;-><init>(Ljava/lang/String;Ljava/io/IOException;II)V

    .line 527
    .line 528
    .line 529
    throw v4

    .line 530
    :cond_10
    :goto_a
    :try_start_5
    const-string v4, "Location"

    .line 531
    .line 532
    invoke-virtual {v13, v4}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    .line 533
    .line 534
    .line 535
    move-result-object v4

    .line 536
    invoke-virtual {v13}, Ljava/net/HttpURLConnection;->disconnect()V

    .line 537
    .line 538
    .line 539
    if-eqz v4, :cond_13

    .line 540
    .line 541
    new-instance v5, Ljava/net/URL;

    .line 542
    .line 543
    invoke-direct {v5, v0, v4}, Ljava/net/URL;-><init>(Ljava/net/URL;Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    invoke-virtual {v5}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    .line 547
    .line 548
    .line 549
    move-result-object v0

    .line 550
    const-string v4, "https"

    .line 551
    .line 552
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 553
    .line 554
    .line 555
    move-result v4

    .line 556
    if-nez v4, :cond_12

    .line 557
    .line 558
    const-string v4, "http"

    .line 559
    .line 560
    invoke-virtual {v4, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 561
    .line 562
    .line 563
    move-result v4

    .line 564
    if-eqz v4, :cond_11

    .line 565
    .line 566
    goto :goto_b

    .line 567
    :cond_11
    new-instance v4, Ljava/net/ProtocolException;

    .line 568
    .line 569
    const-string v5, "Unsupported protocol redirect: "

    .line 570
    .line 571
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 572
    .line 573
    .line 574
    move-result-object v0

    .line 575
    invoke-virtual {v5, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 576
    .line 577
    .line 578
    move-result-object v0

    .line 579
    invoke-direct {v4, v0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 580
    .line 581
    .line 582
    throw v4

    .line 583
    :cond_12
    :goto_b
    move-object v0, v5

    .line 584
    move v13, v14

    .line 585
    move-wide/from16 v4, v16

    .line 586
    .line 587
    goto/16 :goto_0

    .line 588
    .line 589
    :cond_13
    new-instance v0, Ljava/net/ProtocolException;

    .line 590
    .line 591
    const-string v4, "Null location redirect"

    .line 592
    .line 593
    invoke-direct {v0, v4}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 594
    .line 595
    .line 596
    throw v0

    .line 597
    :cond_14
    new-instance v0, Ljava/net/NoRouteToHostException;

    .line 598
    .line 599
    new-instance v4, Ljava/lang/StringBuilder;

    .line 600
    .line 601
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 602
    .line 603
    .line 604
    const-string v5, "Too many redirects: "

    .line 605
    .line 606
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 607
    .line 608
    .line 609
    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 610
    .line 611
    .line 612
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 613
    .line 614
    .line 615
    move-result-object v4

    .line 616
    invoke-direct {v0, v4}, Ljava/net/NoRouteToHostException;-><init>(Ljava/lang/String;)V

    .line 617
    .line 618
    .line 619
    throw v0
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_0

    .line 620
    :goto_c
    new-instance v4, LvQs_w$S_;

    .line 621
    .line 622
    iget-object v2, v2, Lr8_9_;->e8$mp_s$:Landroid/net/Uri;

    .line 623
    .line 624
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 625
    .line 626
    .line 627
    move-result-object v2

    .line 628
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 629
    .line 630
    .line 631
    move-result-object v2

    .line 632
    invoke-virtual {v3, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 633
    .line 634
    .line 635
    move-result-object v2

    .line 636
    const/16 v3, 0x7d0

    .line 637
    .line 638
    const/4 v10, 0x1

    .line 639
    invoke-direct {v4, v2, v0, v3, v10}, LvQs_w$S_;-><init>(Ljava/lang/String;Ljava/io/IOException;II)V

    .line 640
    .line 641
    .line 642
    throw v4
.end method

.method public final iOffset934()V
    .locals 1

    .line 1
    iget-object v0, p0, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    :try_start_0
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 6
    .line 7
    .line 8
    :catch_0
    const/4 v0, 0x0

    .line 9
    iput-object v0, p0, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final rz__9J_()Ljava/util/Map;
    .locals 1

    .line 1
    iget-object v0, p0, Lp0$pt$;->gKey4112:Ljava/net/HttpURLConnection;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    return-object v0

    .line 7
    :cond_0
    invoke-virtual {v0}, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0
.end method

.method public final vaIue()V
    .locals 7

    .line 1
    iget-object v0, p0, Lp0$pt$;->sKey6064:Ljava/util/HashSet;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    :try_start_0
    iget-object v3, p0, Lp0$pt$;->kO_6X_:Ljava/io/InputStream;

    .line 6
    .line 7
    if-eqz v3, :cond_0

    .line 8
    .line 9
    sget v4, LnPos2706;->e8$mp_s$:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 10
    .line 11
    :try_start_1
    invoke-virtual {v3}, Ljava/io/InputStream;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 12
    .line 13
    .line 14
    goto :goto_0

    .line 15
    :catchall_0
    move-exception v3

    .line 16
    goto :goto_1

    .line 17
    :catch_0
    move-exception v3

    .line 18
    :try_start_2
    new-instance v4, LvQs_w$S_;

    .line 19
    .line 20
    const/16 v5, 0x7d0

    .line 21
    .line 22
    const/4 v6, 0x3

    .line 23
    invoke-direct {v4, v5, v6, v3}, LvQs_w$S_;-><init>(IILjava/io/IOException;)V

    .line 24
    .line 25
    .line 26
    throw v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 27
    :cond_0
    :goto_0
    iput-object v2, p0, Lp0$pt$;->kO_6X_:Ljava/io/InputStream;

    .line 28
    .line 29
    invoke-virtual {p0}, Lp0$pt$;->iOffset934()V

    .line 30
    .line 31
    .line 32
    iget-boolean v2, p0, Lp0$pt$;->K0I:Z

    .line 33
    .line 34
    if-eqz v2, :cond_1

    .line 35
    .line 36
    iput-boolean v1, p0, Lp0$pt$;->K0I:Z

    .line 37
    .line 38
    invoke-virtual {p0}, L_zoTo3l;->tmpData3485()V

    .line 39
    .line 40
    .line 41
    :cond_1
    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :goto_1
    iput-object v2, p0, Lp0$pt$;->kO_6X_:Ljava/io/InputStream;

    .line 46
    .line 47
    invoke-virtual {p0}, Lp0$pt$;->iOffset934()V

    .line 48
    .line 49
    .line 50
    iget-boolean v2, p0, Lp0$pt$;->K0I:Z

    .line 51
    .line 52
    if-eqz v2, :cond_2

    .line 53
    .line 54
    iput-boolean v1, p0, Lp0$pt$;->K0I:Z

    .line 55
    .line 56
    invoke-virtual {p0}, L_zoTo3l;->tmpData3485()V

    .line 57
    .line 58
    .line 59
    :cond_2
    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    .line 60
    .line 61
    .line 62
    throw v3
.end method
