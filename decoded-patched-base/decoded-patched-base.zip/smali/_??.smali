.class public final synthetic L_òÀ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic jPos3709:Ljava/util/ArrayList;

.field public final synthetic vaIue:LUBK;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LUBK;Ljava/util/ArrayList;I)V
    .locals 0

    .line 1
    iput p3, p0, L_òÀ;->yON3x:I

    iput-object p1, p0, L_òÀ;->vaIue:LUBK;

    iput-object p2, p0, L_òÀ;->jPos3709:Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 10

    .line 1
    iget v0, p0, L_òÀ;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, L_òÀ;->jPos3709:Ljava/util/ArrayList;

    .line 7
    .line 8
    iget-object v1, p0, L_òÀ;->vaIue:LUBK;

    .line 9
    .line 10
    iget-object v2, v1, LUBK;->waiBKÀ:Landroid/os/Handler;

    .line 11
    .line 12
    :try_start_0
    iget-object v3, v1, LUBK;->rz__9J_:Lorg/cybergarage/upnp/ControlPoint;

    .line 13
    .line 14
    invoke-virtual {v3}, Lorg/cybergarage/upnp/ControlPoint;->stop()Z

    .line 15
    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    iput-boolean v3, v1, LUBK;->tmpData3485:Z

    .line 19
    .line 20
    const-wide/16 v3, 0x1f4

    .line 21
    .line 22
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V

    .line 23
    .line 24
    .line 25
    iget-object v3, v1, LUBK;->rz__9J_:Lorg/cybergarage/upnp/ControlPoint;

    .line 26
    .line 27
    invoke-virtual {v3}, Lorg/cybergarage/upnp/ControlPoint;->start()Z

    .line 28
    .line 29
    .line 30
    const/4 v3, 0x1

    .line 31
    iput-boolean v3, v1, LUBK;->tmpData3485:Z

    .line 32
    .line 33
    new-instance v3, L_òÀ;

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    invoke-direct {v3, v1, v0, v4}, L_òÀ;-><init>(LUBK;Ljava/util/ArrayList;I)V

    .line 37
    .line 38
    .line 39
    const-wide/16 v4, 0xbb8

    .line 40
    .line 41
    invoke-virtual {v2, v3, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 42
    .line 43
    .line 44
    new-instance v0, LisSize6478;

    .line 45
    .line 46
    const/4 v3, 0x0

    .line 47
    invoke-direct {v0, v1, v3}, LisSize6478;-><init>(LUBK;I)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v2, v0, v4, v5}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :catch_0
    move-exception v0

    .line 55
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    iget-object v1, v1, LUBK;->JKEoÙX:LTCyD9È5;

    .line 59
    .line 60
    if-eqz v1, :cond_0

    .line 61
    .line 62
    new-instance v2, Ljava/lang/StringBuilder;

    .line 63
    .line 64
    const-string v3, "Error refreshing DLNA devices: "

    .line 65
    .line 66
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    iget-object v1, v1, LTCyD9È5;->vaIue:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v1, LsIndex9566;

    .line 83
    .line 84
    iget-object v1, v1, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v1, LisItem6344;

    .line 87
    .line 88
    check-cast v1, Linfo/t4w/vp/view/MultiCastActivity;

    .line 89
    .line 90
    iget-object v2, v1, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 91
    .line 92
    new-instance v3, LIl;

    .line 93
    .line 94
    const/16 v4, 0x13

    .line 95
    .line 96
    invoke-direct {v3, v4, v1, v0}, LIl;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 100
    .line 101
    .line 102
    :cond_0
    :goto_0
    return-void

    .line 103
    :pswitch_0
    iget-object v0, p0, L_òÀ;->vaIue:LUBK;

    .line 104
    .line 105
    iget-object v0, v0, LUBK;->POOl:Ljava/util/ArrayList;

    .line 106
    .line 107
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    if-eqz v1, :cond_3

    .line 112
    .line 113
    iget-object v1, p0, L_òÀ;->jPos3709:Ljava/util/ArrayList;

    .line 114
    .line 115
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    if-nez v2, :cond_3

    .line 120
    .line 121
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 122
    .line 123
    .line 124
    move-result v2

    .line 125
    const/4 v3, 0x0

    .line 126
    const/4 v4, 0x0

    .line 127
    :goto_1
    if-ge v4, v2, :cond_3

    .line 128
    .line 129
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v5

    .line 133
    add-int/lit8 v4, v4, 0x1

    .line 134
    .line 135
    check-cast v5, Lorg/cybergarage/upnp/Device;

    .line 136
    .line 137
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 138
    .line 139
    .line 140
    move-result v6

    .line 141
    const/4 v7, 0x0

    .line 142
    :cond_1
    if-ge v7, v6, :cond_2

    .line 143
    .line 144
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v8

    .line 148
    add-int/lit8 v7, v7, 0x1

    .line 149
    .line 150
    check-cast v8, Lorg/cybergarage/upnp/Device;

    .line 151
    .line 152
    invoke-virtual {v8}, Lorg/cybergarage/upnp/Device;->getUDN()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v8

    .line 156
    invoke-virtual {v5}, Lorg/cybergarage/upnp/Device;->getUDN()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v9

    .line 160
    invoke-virtual {v8, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 161
    .line 162
    .line 163
    move-result v8

    .line 164
    if-eqz v8, :cond_1

    .line 165
    .line 166
    goto :goto_1

    .line 167
    :cond_2
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    goto :goto_1

    .line 171
    :cond_3
    return-void

    .line 172
    nop

    .line 173
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
