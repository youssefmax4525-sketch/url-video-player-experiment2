.class public interface abstract LjData2185;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract waiBKÀ(LzgQ_WZ$2_;)V
.end method
