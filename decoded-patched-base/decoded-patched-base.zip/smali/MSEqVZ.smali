.class public abstract LMSEqVZ;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final POOl:LgIndex153;

.field public static final e8$mp_s$:LiIndex1200;

.field public static final rz__9J_:Lyll0O0;

.field public static final waiBKÀ:LIIiIlIl;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    const-string v0, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    .line 2
    .line 3
    invoke-static {v0}, LLM$ly_a$;->waiBKÀ(Ljava/lang/String;)LrlI;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, LtmpPos8530;

    .line 8
    .line 9
    const/16 v2, 0xa

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    invoke-direct {v1, v2, v3}, LtmpPos8530;-><init>(IB)V

    .line 13
    .line 14
    .line 15
    new-instance v2, LiIndex1200;

    .line 16
    .line 17
    const-class v3, LjValue555;

    .line 18
    .line 19
    invoke-direct {v2, v3, v1}, LiIndex1200;-><init>(Ljava/lang/Class;LsData8261;)V

    .line 20
    .line 21
    .line 22
    sput-object v2, LMSEqVZ;->e8$mp_s$:LiIndex1200;

    .line 23
    .line 24
    new-instance v1, LuXVÌJÒ;

    .line 25
    .line 26
    const/16 v2, 0xb

    .line 27
    .line 28
    invoke-direct {v1, v2}, LuXVÌJÒ;-><init>(I)V

    .line 29
    .line 30
    .line 31
    new-instance v2, LIIiIlIl;

    .line 32
    .line 33
    invoke-direct {v2, v0, v1}, LIIiIlIl;-><init>(LrlI;LhasKey5903;)V

    .line 34
    .line 35
    .line 36
    sput-object v2, LMSEqVZ;->waiBKÀ:LIIiIlIl;

    .line 37
    .line 38
    new-instance v1, LJ11D;

    .line 39
    .line 40
    const/16 v2, 0xb

    .line 41
    .line 42
    invoke-direct {v1, v2}, LJ11D;-><init>(I)V

    .line 43
    .line 44
    .line 45
    new-instance v2, Lyll0O0;

    .line 46
    .line 47
    const-class v3, LlO_q_;

    .line 48
    .line 49
    invoke-direct {v2, v3, v1}, Lyll0O0;-><init>(Ljava/lang/Class;LbesqìA;)V

    .line 50
    .line 51
    .line 52
    sput-object v2, LMSEqVZ;->rz__9J_:Lyll0O0;

    .line 53
    .line 54
    new-instance v1, LtmpPos8530;

    .line 55
    .line 56
    const/16 v2, 0xb

    .line 57
    .line 58
    const/4 v3, 0x0

    .line 59
    invoke-direct {v1, v2, v3}, LtmpPos8530;-><init>(IB)V

    .line 60
    .line 61
    .line 62
    new-instance v2, LgIndex153;

    .line 63
    .line 64
    invoke-direct {v2, v0, v1}, LgIndex153;-><init>(LrlI;LtmpOffset2707;)V

    .line 65
    .line 66
    .line 67
    sput-object v2, LMSEqVZ;->POOl:LgIndex153;

    .line 68
    .line 69
    return-void
.end method

.method public static e8$mp_s$(Lkòè;)LwYm_BE$mL_;
    .locals 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-eq v0, v1, :cond_1

    .line 7
    .line 8
    const/4 v1, 0x3

    .line 9
    if-ne v0, v1, :cond_0

    .line 10
    .line 11
    sget-object p0, LwYm_BE$mL_;->valuI:LwYm_BE$mL_;

    .line 12
    .line 13
    return-object p0

    .line 14
    :cond_0
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 15
    .line 16
    invoke-virtual {p0}, Lkòè;->e8$mp_s$()I

    .line 17
    .line 18
    .line 19
    move-result p0

    .line 20
    const-string v1, "Unable to parse OutputPrefixType: "

    .line 21
    .line 22
    invoke-static {p0, v1}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw v0

    .line 30
    :cond_1
    sget-object p0, LwYm_BE$mL_;->Ialue:LwYm_BE$mL_;

    .line 31
    .line 32
    return-object p0
.end method

.method public static waiBKÀ(LwYm_BE$mL_;)Lkòè;
    .locals 2

    .line 1
    sget-object v0, LwYm_BE$mL_;->Ialue:LwYm_BE$mL_;

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    sget-object p0, Lkòè;->jPos3709:Lkòè;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_0
    sget-object v0, LwYm_BE$mL_;->valuI:LwYm_BE$mL_;

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    sget-object p0, Lkòè;->kQy:Lkòè;

    .line 21
    .line 22
    return-object p0

    .line 23
    :cond_1
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 24
    .line 25
    iget-object p0, p0, LwYm_BE$mL_;->vaIue:Ljava/lang/String;

    .line 26
    .line 27
    const-string v1, "Unable to serialize variant: "

    .line 28
    .line 29
    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v0
.end method
