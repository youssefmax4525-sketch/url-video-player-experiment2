.class public final LcmNMJ;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LiaZùZ6M;


# instance fields
.field public final e8$mp_s$:LGD;

.field public final waiBKÀ:Lll1Iil;


# direct methods
.method public constructor <init>(Lll1Iil;LGD;)V
    .locals 1

    .line 1
    sget-object v0, LxS_dw_;->e8$mp_s$:LFJ_p_;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, p0, LcmNMJ;->waiBKÀ:Lll1Iil;

    .line 7
    .line 8
    iput-object p2, p0, LcmNMJ;->e8$mp_s$:LGD;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final DDù8()LGk0AIpje;
    .locals 3

    .line 1
    iget-object v0, p0, LcmNMJ;->e8$mp_s$:LGD;

    .line 2
    .line 3
    instance-of v1, v0, LGk0AIpje;

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    check-cast v0, LGk0AIpje;

    .line 9
    .line 10
    const/4 v1, 0x4

    .line 11
    invoke-virtual {v0, v1, v2}, LGk0AIpje;->DDù8(ILGk0AIpje;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, LGk0AIpje;

    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_0
    check-cast v0, LGk0AIpje;

    .line 19
    .line 20
    const/4 v1, 0x5

    .line 21
    invoke-virtual {v0, v1, v2}, LGk0AIpje;->DDù8(ILGk0AIpje;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, LVnKH;

    .line 26
    .line 27
    invoke-virtual {v0}, LVnKH;->waiBKÀ()LGk0AIpje;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    return-object v0
.end method

.method public final JKEoÙX(Ljava/lang/Object;)Z
    .locals 0

    .line 1
    invoke-static {p1}, LBRK_m_;->POOl(Ljava/lang/Object;)Ljava/lang/ClassCastException;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    throw p1
.end method

.method public final POOl(LGD;)I
    .locals 2

    .line 1
    check-cast p1, LGk0AIpje;

    .line 2
    .line 3
    iget-object p1, p1, LGk0AIpje;->zzc:LXB_Ch_;

    .line 4
    .line 5
    iget v0, p1, LXB_Ch_;->rz__9J_:I

    .line 6
    .line 7
    const/4 v1, -0x1

    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    iput v0, p1, LXB_Ch_;->rz__9J_:I

    .line 12
    .line 13
    :cond_0
    return v0
.end method

.method public final e8$mp_s$(LGk0AIpje;LGk0AIpje;)Z
    .locals 0

    .line 1
    iget-object p1, p1, LGk0AIpje;->zzc:LXB_Ch_;

    .line 2
    .line 3
    iget-object p2, p2, LGk0AIpje;->zzc:LXB_Ch_;

    .line 4
    .line 5
    invoke-virtual {p1, p2}, LXB_Ch_;->equals(Ljava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    return p1

    .line 13
    :cond_0
    const/4 p1, 0x1

    .line 14
    return p1
.end method

.method public final rz__9J_(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-static {p1, p2}, LolkÀBy;->Ialue(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public final sKey7917(LGk0AIpje;)I
    .locals 0

    .line 1
    iget-object p1, p1, LGk0AIpje;->zzc:LXB_Ch_;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    const p1, 0x7bc6f

    .line 7
    .line 8
    .line 9
    return p1
.end method

.method public final tmpData3485(Ljava/lang/Object;LQl1;)V
    .locals 0

    .line 1
    invoke-static {p1}, LBRK_m_;->POOl(Ljava/lang/Object;)Ljava/lang/ClassCastException;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    throw p1
.end method

.method public final waiBKÀ(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, LcmNMJ;->waiBKÀ:Lll1Iil;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    move-object v0, p1

    .line 7
    check-cast v0, LGk0AIpje;

    .line 8
    .line 9
    iget-object v0, v0, LGk0AIpje;->zzc:LXB_Ch_;

    .line 10
    .line 11
    iget-boolean v1, v0, LXB_Ch_;->POOl:Z

    .line 12
    .line 13
    if-eqz v1, :cond_0

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    iput-boolean v1, v0, LXB_Ch_;->POOl:Z

    .line 17
    .line 18
    :cond_0
    sget-object v0, LxS_dw_;->e8$mp_s$:LFJ_p_;

    .line 19
    .line 20
    invoke-static {p1}, LBRK_m_;->POOl(Ljava/lang/Object;)Ljava/lang/ClassCastException;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    throw p1
.end method
