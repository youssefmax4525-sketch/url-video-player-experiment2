.class public abstract LliII;
.super Ljava/lang/Object;


# static fields
.field public static activatedAnimationDuration:I = 0x7f040026

.field public static arrowBgColor:I = 0x7f040040

.field public static arrowColor:I = 0x7f040041

.field public static arrowRadius:I = 0x7f040043

.field public static baseCardViewStyle:I = 0x7f040075

.field public static browsePaddingBottom:I = 0x7f040099

.field public static browsePaddingEnd:I = 0x7f04009a

.field public static browsePaddingStart:I = 0x7f04009b

.field public static browsePaddingTop:I = 0x7f04009c

.field public static browseRowsFadingEdgeLength:I = 0x7f04009d

.field public static browseRowsMarginStart:I = 0x7f04009e

.field public static browseRowsMarginTop:I = 0x7f04009f

.field public static browseTitleIconStyle:I = 0x7f0400a0

.field public static browseTitleTextStyle:I = 0x7f0400a1

.field public static browseTitleViewLayout:I = 0x7f0400a2

.field public static browseTitleViewStyle:I = 0x7f0400a3

.field public static cardBackground:I = 0x7f0400b6

.field public static cardForeground:I = 0x7f0400ba

.field public static cardType:I = 0x7f0400be

.field public static closed_captioning:I = 0x7f040134

.field public static columnCount:I = 0x7f04017e

.field public static datePickerFormat:I = 0x7f0401be

.field public static datePickerStyle:I = 0x7f0401bf

.field public static defaultBrandColor:I = 0x7f0401c4

.field public static defaultBrandColorDark:I = 0x7f0401c5

.field public static defaultSearchBrightColor:I = 0x7f0401ca

.field public static defaultSearchColor:I = 0x7f0401cb

.field public static defaultSearchIcon:I = 0x7f0401cc

.field public static defaultSearchIconColor:I = 0x7f0401cd

.field public static defaultSectionHeaderColor:I = 0x7f0401ce

.field public static detailsActionButtonStyle:I = 0x7f0401d4

.field public static detailsDescriptionBodyStyle:I = 0x7f0401d5

.field public static detailsDescriptionSubtitleStyle:I = 0x7f0401d6

.field public static detailsDescriptionTitleStyle:I = 0x7f0401d7

.field public static dotBgColor:I = 0x7f0401e4

.field public static dotToArrowGap:I = 0x7f0401e5

.field public static dotToDotGap:I = 0x7f0401e6

.field public static errorMessageStyle:I = 0x7f040217

.field public static extraVisibility:I = 0x7f040230

.field public static fast_forward:I = 0x7f04023f

.field public static guidanceBreadcrumbStyle:I = 0x7f040289

.field public static guidanceContainerStyle:I = 0x7f04028a

.field public static guidanceDescriptionStyle:I = 0x7f04028b

.field public static guidanceEntryAnimation:I = 0x7f04028c

.field public static guidanceIconStyle:I = 0x7f04028d

.field public static guidanceTitleStyle:I = 0x7f04028e

.field public static guidedActionCheckedAnimation:I = 0x7f04028f

.field public static guidedActionContentWidth:I = 0x7f040290

.field public static guidedActionContentWidthNoIcon:I = 0x7f040291

.field public static guidedActionContentWidthWeight:I = 0x7f040292

.field public static guidedActionContentWidthWeightTwoPanels:I = 0x7f040293

.field public static guidedActionDescriptionMinLines:I = 0x7f040294

.field public static guidedActionDisabledChevronAlpha:I = 0x7f040295

.field public static guidedActionEnabledChevronAlpha:I = 0x7f040296

.field public static guidedActionItemCheckmarkStyle:I = 0x7f040297

.field public static guidedActionItemChevronStyle:I = 0x7f040298

.field public static guidedActionItemContainerStyle:I = 0x7f040299

.field public static guidedActionItemContentStyle:I = 0x7f04029a

.field public static guidedActionItemDescriptionStyle:I = 0x7f04029b

.field public static guidedActionItemIconStyle:I = 0x7f04029c

.field public static guidedActionItemTitleStyle:I = 0x7f04029d

.field public static guidedActionPressedAnimation:I = 0x7f04029e

.field public static guidedActionTitleMaxLines:I = 0x7f04029f

.field public static guidedActionTitleMinLines:I = 0x7f0402a0

.field public static guidedActionUncheckedAnimation:I = 0x7f0402a1

.field public static guidedActionUnpressedAnimation:I = 0x7f0402a2

.field public static guidedActionVerticalPadding:I = 0x7f0402a3

.field public static guidedActionsBackground:I = 0x7f0402a4

.field public static guidedActionsBackgroundDark:I = 0x7f0402a5

.field public static guidedActionsContainerStyle:I = 0x7f0402a6

.field public static guidedActionsElevation:I = 0x7f0402a7

.field public static guidedActionsEntryAnimation:I = 0x7f0402a8

.field public static guidedActionsListStyle:I = 0x7f0402a9

.field public static guidedActionsSelectorDrawable:I = 0x7f0402aa

.field public static guidedActionsSelectorHideAnimation:I = 0x7f0402ab

.field public static guidedActionsSelectorShowAnimation:I = 0x7f0402ac

.field public static guidedActionsSelectorStyle:I = 0x7f0402ad

.field public static guidedActionsShadowWidth:I = 0x7f0402ae

.field public static guidedButtonActionsListStyle:I = 0x7f0402af

.field public static guidedButtonActionsWidthWeight:I = 0x7f0402b0

.field public static guidedStepBackground:I = 0x7f0402b1

.field public static guidedStepEntryAnimation:I = 0x7f0402b2

.field public static guidedStepExitAnimation:I = 0x7f0402b3

.field public static guidedStepHeightWeight:I = 0x7f0402b4

.field public static guidedStepImeAppearingAnimation:I = 0x7f0402b5

.field public static guidedStepImeDisappearingAnimation:I = 0x7f0402b6

.field public static guidedStepKeyline:I = 0x7f0402b7

.field public static guidedStepReentryAnimation:I = 0x7f0402b8

.field public static guidedStepReturnAnimation:I = 0x7f0402b9

.field public static guidedStepTheme:I = 0x7f0402ba

.field public static guidedStepThemeFlag:I = 0x7f0402bb

.field public static guidedSubActionsListStyle:I = 0x7f0402bc

.field public static headerStyle:I = 0x7f0402c1

.field public static headersVerticalGridStyle:I = 0x7f0402c2

.field public static high_quality:I = 0x7f0402cf

.field public static imageCardViewBadgeStyle:I = 0x7f0402e8

.field public static imageCardViewContentStyle:I = 0x7f0402e9

.field public static imageCardViewImageStyle:I = 0x7f0402ea

.field public static imageCardViewInfoAreaStyle:I = 0x7f0402eb

.field public static imageCardViewStyle:I = 0x7f0402ec

.field public static imageCardViewTitleStyle:I = 0x7f0402ed

.field public static infoAreaBackground:I = 0x7f0402fb

.field public static infoVisibility:I = 0x7f0402fc

.field public static is24HourFormat:I = 0x7f0402ff

.field public static itemsVerticalGridStyle:I = 0x7f040322

.field public static layout_viewType:I = 0x7f040376

.field public static lbDotRadius:I = 0x7f040378

.field public static lbImageCardViewType:I = 0x7f040379

.field public static lb_slideEdge:I = 0x7f04037a

.field public static maintainLineSpacing:I = 0x7f040395

.field public static onboardingDescriptionStyle:I = 0x7f040439

.field public static onboardingHeaderStyle:I = 0x7f04043a

.field public static onboardingLogoStyle:I = 0x7f04043b

.field public static onboardingMainIconStyle:I = 0x7f04043c

.field public static onboardingNavigatorContainerStyle:I = 0x7f04043d

.field public static onboardingPageIndicatorStyle:I = 0x7f04043e

.field public static onboardingStartButtonStyle:I = 0x7f04043f

.field public static onboardingTheme:I = 0x7f040440

.field public static onboardingTitleStyle:I = 0x7f040441

.field public static overlayDimActiveLevel:I = 0x7f040444

.field public static overlayDimDimmedLevel:I = 0x7f040445

.field public static overlayDimMaskColor:I = 0x7f040446

.field public static pause:I = 0x7f04045a

.field public static pickerItemLayout:I = 0x7f040461

.field public static pickerItemTextViewId:I = 0x7f040462

.field public static pickerStyle:I = 0x7f040463

.field public static picture_in_picture:I = 0x7f040464

.field public static pinPickerStyle:I = 0x7f040465

.field public static play:I = 0x7f04046b

.field public static playbackControlButtonLabelStyle:I = 0x7f04046d

.field public static playbackControlsActionIcons:I = 0x7f04046e

.field public static playbackControlsAutoHideTickleTimeout:I = 0x7f04046f

.field public static playbackControlsAutoHideTimeout:I = 0x7f040470

.field public static playbackControlsButtonStyle:I = 0x7f040471

.field public static playbackControlsIconHighlightColor:I = 0x7f040472

.field public static playbackControlsTimeStyle:I = 0x7f040473

.field public static playbackMediaItemDetailsStyle:I = 0x7f040474

.field public static playbackMediaItemDurationStyle:I = 0x7f040475

.field public static playbackMediaItemNameStyle:I = 0x7f040476

.field public static playbackMediaItemNumberStyle:I = 0x7f040477

.field public static playbackMediaItemNumberViewFlipperLayout:I = 0x7f040478

.field public static playbackMediaItemNumberViewFlipperStyle:I = 0x7f040479

.field public static playbackMediaItemPaddingStart:I = 0x7f04047a

.field public static playbackMediaItemRowStyle:I = 0x7f04047b

.field public static playbackMediaItemSeparatorStyle:I = 0x7f04047c

.field public static playbackMediaListHeaderStyle:I = 0x7f04047d

.field public static playbackMediaListHeaderTitleStyle:I = 0x7f04047e

.field public static playbackPaddingEnd:I = 0x7f04047f

.field public static playbackPaddingStart:I = 0x7f040480

.field public static playbackProgressPrimaryColor:I = 0x7f040481

.field public static playbackProgressSecondaryColor:I = 0x7f040482

.field public static repeat:I = 0x7f0404a8

.field public static repeat_one:I = 0x7f0404ab

.field public static resizeTrigger:I = 0x7f0404ae

.field public static resizedPaddingAdjustmentBottom:I = 0x7f0404b0

.field public static resizedPaddingAdjustmentTop:I = 0x7f0404b1

.field public static resizedTextSize:I = 0x7f0404b2

.field public static rewind:I = 0x7f0404b4

.field public static rowHeaderDescriptionStyle:I = 0x7f0404ba

.field public static rowHeaderDockStyle:I = 0x7f0404bb

.field public static rowHeaderStyle:I = 0x7f0404bc

.field public static rowHorizontalGridStyle:I = 0x7f0404be

.field public static rowHoverCardDescriptionStyle:I = 0x7f0404bf

.field public static rowHoverCardTitleStyle:I = 0x7f0404c0

.field public static rowsVerticalGridStyle:I = 0x7f0404c1

.field public static searchOrbBrightColor:I = 0x7f0404cf

.field public static searchOrbColor:I = 0x7f0404d0

.field public static searchOrbIcon:I = 0x7f0404d1

.field public static searchOrbIconColor:I = 0x7f0404d2

.field public static searchOrbViewStyle:I = 0x7f0404d3

.field public static sectionHeaderStyle:I = 0x7f0404d6

.field public static selectedAnimationDelay:I = 0x7f0404da

.field public static selectedAnimationDuration:I = 0x7f0404db

.field public static shuffle:I = 0x7f0404ff

.field public static skip_next:I = 0x7f04050d

.field public static skip_previous:I = 0x7f04050e

.field public static thumb_down:I = 0x7f0405bf

.field public static thumb_down_outline:I = 0x7f0405c0

.field public static thumb_up:I = 0x7f0405c1

.field public static thumb_up_outline:I = 0x7f0405c2

.field public static timePickerStyle:I = 0x7f0405cc

.field public static useCurrentTime:I = 0x7f040609
