.class public final synthetic Lrx$t$;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic vaIue:LisKey7282;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LisKey7282;I)V
    .locals 0

    .line 1
    iput p2, p0, Lrx$t$;->yON3x:I

    iput-object p1, p0, Lrx$t$;->vaIue:LisKey7282;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    .line 1
    iget v0, p0, Lrx$t$;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "/result"

    .line 7
    .line 8
    sget-object v1, LsSize5309;->valuI:LkData8785;

    .line 9
    .line 10
    iget-object v2, p0, Lrx$t$;->vaIue:LisKey7282;

    .line 11
    .line 12
    invoke-virtual {v2, v0, v1}, LisKey7282;->e8$mp_s$(Ljava/lang/String;LiOQ10I;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {v2}, LisKey7282;->vaIue()V

    .line 16
    .line 17
    .line 18
    return-void

    .line 19
    :pswitch_0
    iget-object v0, p0, Lrx$t$;->vaIue:LisKey7282;

    .line 20
    .line 21
    invoke-virtual {v0}, LisKey7282;->vaIue()V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :pswitch_1
    iget-object v0, p0, Lrx$t$;->vaIue:LisKey7282;

    .line 26
    .line 27
    invoke-virtual {v0}, LisKey7282;->vaIue()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
