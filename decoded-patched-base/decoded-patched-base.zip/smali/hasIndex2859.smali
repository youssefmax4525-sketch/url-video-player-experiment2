.class public final LhasIndex2859;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LXXìMLÙe;


# instance fields
.field public final synthetic e8$mp_s$:I

.field public final waiBKÀ:LlACD;


# direct methods
.method public synthetic constructor <init>(LlACD;I)V
    .locals 0

    .line 1
    iput p2, p0, LhasIndex2859;->e8$mp_s$:I

    iput-object p1, p0, LhasIndex2859;->waiBKÀ:LlACD;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final POOl()Ljava/lang/Object;
    .locals 5

    .line 1
    iget v0, p0, LhasIndex2859;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LhasIndex2859;->waiBKÀ:LlACD;

    .line 7
    .line 8
    iget-object v0, v0, LlACD;->iOffset934:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LQ1o$jL_AB$;

    .line 11
    .line 12
    return-object v0

    .line 13
    :pswitch_0
    iget-object v0, p0, LhasIndex2859;->waiBKÀ:LlACD;

    .line 14
    .line 15
    iget-object v0, v0, LlACD;->jPos3709:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Ljava/lang/String;

    .line 18
    .line 19
    return-object v0

    .line 20
    :pswitch_1
    iget-object v0, p0, LhasIndex2859;->waiBKÀ:LlACD;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    new-instance v1, Ljava/util/HashSet;

    .line 26
    .line 27
    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 28
    .line 29
    .line 30
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v0, Ljava/lang/String;

    .line 33
    .line 34
    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 35
    .line 36
    invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-virtual {v1, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    return-object v1

    .line 44
    :pswitch_2
    iget-object v0, p0, LhasIndex2859;->waiBKÀ:LlACD;

    .line 45
    .line 46
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 47
    .line 48
    check-cast v0, Ljava/lang/String;

    .line 49
    .line 50
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-static {v0}, LnItem4702;->ll(Ljava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    return-object v0

    .line 60
    :pswitch_3
    iget-object v0, p0, LhasIndex2859;->waiBKÀ:LlACD;

    .line 61
    .line 62
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 63
    .line 64
    check-cast v0, Ljava/lang/String;

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    const/4 v2, 0x2

    .line 71
    const/4 v3, 0x1

    .line 72
    const/4 v4, 0x3

    .line 73
    sparse-switch v1, :sswitch_data_0

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :sswitch_0
    const-string v1, "BANNER"

    .line 78
    .line 79
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result v0

    .line 83
    if-eqz v0, :cond_0

    .line 84
    .line 85
    const/4 v0, 0x0

    .line 86
    goto :goto_1

    .line 87
    :sswitch_1
    const-string v1, "REWARDED"

    .line 88
    .line 89
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-eqz v0, :cond_0

    .line 94
    .line 95
    const/4 v0, 0x3

    .line 96
    goto :goto_1

    .line 97
    :sswitch_2
    const-string v1, "INTERSTITIAL"

    .line 98
    .line 99
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_0

    .line 104
    .line 105
    const/4 v0, 0x1

    .line 106
    goto :goto_1

    .line 107
    :sswitch_3
    const-string v1, "NATIVE"

    .line 108
    .line 109
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    if-eqz v0, :cond_0

    .line 114
    .line 115
    const/4 v0, 0x2

    .line 116
    goto :goto_1

    .line 117
    :cond_0
    :goto_0
    const/4 v0, -0x1

    .line 118
    :goto_1
    if-eqz v0, :cond_4

    .line 119
    .line 120
    if-eq v0, v3, :cond_3

    .line 121
    .line 122
    if-eq v0, v2, :cond_2

    .line 123
    .line 124
    if-eq v0, v4, :cond_1

    .line 125
    .line 126
    sget-object v0, LX6Z_v_;->vaIue:LX6Z_v_;

    .line 127
    .line 128
    goto :goto_2

    .line 129
    :cond_1
    sget-object v0, LX6Z_v_;->yàÒZ:LX6Z_v_;

    .line 130
    .line 131
    goto :goto_2

    .line 132
    :cond_2
    sget-object v0, LX6Z_v_;->pCXDYg:LX6Z_v_;

    .line 133
    .line 134
    goto :goto_2

    .line 135
    :cond_3
    sget-object v0, LX6Z_v_;->kQy:LX6Z_v_;

    .line 136
    .line 137
    goto :goto_2

    .line 138
    :cond_4
    sget-object v0, LX6Z_v_;->jPos3709:LX6Z_v_;

    .line 139
    .line 140
    :goto_2
    return-object v0

    .line 141
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
    .line 152
    .line 153
    :sswitch_data_0
    .sparse-switch
        -0x772abbe9 -> :sswitch_3
        -0x51d5b0d4 -> :sswitch_2
        0x205e3c0e -> :sswitch_1
        0x7458732c -> :sswitch_0
    .end sparse-switch
.end method
