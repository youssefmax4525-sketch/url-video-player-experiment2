.class public Linfo/t4w/vp/airplay/AirPlayDiscoveryService;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;
    }
.end annotation


# static fields
.field private static final AIRPLAY_SERVICE_TYPE:Ljava/lang/String; = "_airplay._tcp.local."

.field private static final AIRPLAY_SERVICE_TYPE_ALT:Ljava/lang/String; = "_raop._tcp.local."

.field private static final AIRPLAY_SERVICE_TYPE_OLD:Ljava/lang/String; = "_appletv._tcp.local."

.field private static final TAG:Ljava/lang/String; = "AirPlayDiscovery"


# instance fields
.field private context:Landroid/content/Context;

.field private final discoveredDevices:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Linfo/t4w/vp/airplay/AirPlayDevice;",
            ">;"
        }
    .end annotation
.end field

.field private hasFoundDevices:Z

.field private isDiscoveryRunning:Z

.field private jmDNS:Ljavax/jmdns/JmDNS;

.field private final listeners:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;",
            ">;"
        }
    .end annotation
.end field

.field private multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

.field private serviceListener:Ljavax/jmdns/ServiceListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->isDiscoveryRunning:Z

    .line 6
    .line 7
    iput-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->hasFoundDevices:Z

    .line 8
    .line 9
    new-instance v0, Ljava/util/ArrayList;

    .line 10
    .line 11
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 15
    .line 16
    new-instance v0, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->listeners:Ljava/util/List;

    .line 22
    .line 23
    if-eqz p1, :cond_1

    .line 24
    .line 25
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->context:Landroid/content/Context;

    .line 30
    .line 31
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 32
    .line 33
    const/16 v1, 0x17

    .line 34
    .line 35
    if-lt v0, v1, :cond_0

    .line 36
    .line 37
    invoke-static {p1}, Ldatl;->vaIue(Landroid/content/Context;)V

    .line 38
    .line 39
    .line 40
    :cond_0
    return-void

    .line 41
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 42
    .line 43
    const-string v0, "Context cannot be null"

    .line 44
    .line 45
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    throw p1
.end method

.method public static bridge synthetic JKEoÙX(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;Ljavax/jmdns/ServiceEvent;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->handleDeviceResolved(Ljavax/jmdns/ServiceEvent;)V

    return-void
.end method

.method public static bridge synthetic POOl(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->handleDeviceRemoved(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic e8$mp_s$(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->lambda$startDiscovery$0()V

    return-void
.end method

.method private findUsableNetworkInterface()Ljava/net/InetAddress;
    .locals 8

    .line 1
    :try_start_0
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v3, 0x0

    .line 15
    :cond_0
    :goto_0
    if-ge v3, v1, :cond_3

    .line 16
    .line 17
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v4

    .line 21
    add-int/lit8 v3, v3, 0x1

    .line 22
    .line 23
    check-cast v4, Ljava/net/NetworkInterface;

    .line 24
    .line 25
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->isUp()Z

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    if-eqz v5, :cond_0

    .line 30
    .line 31
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->isLoopback()Z

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    if-nez v5, :cond_0

    .line 36
    .line 37
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->isVirtual()Z

    .line 38
    .line 39
    .line 40
    move-result v5

    .line 41
    if-eqz v5, :cond_1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->getDisplayName()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    :cond_2
    invoke-interface {v5}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_0

    .line 56
    .line 57
    invoke-interface {v5}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    check-cast v6, Ljava/net/InetAddress;

    .line 62
    .line 63
    instance-of v7, v6, Ljava/net/Inet4Address;

    .line 64
    .line 65
    if-eqz v7, :cond_2

    .line 66
    .line 67
    invoke-virtual {v6}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    .line 68
    .line 69
    .line 70
    move-result v7

    .line 71
    if-nez v7, :cond_2

    .line 72
    .line 73
    invoke-virtual {v6}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    invoke-virtual {v4}, Ljava/net/NetworkInterface;->getDisplayName()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    return-object v6

    .line 80
    :catch_0
    move-exception v0

    .line 81
    goto :goto_2

    .line 82
    :cond_3
    invoke-static {}, Ljava/net/NetworkInterface;->getNetworkInterfaces()Ljava/util/Enumeration;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-static {v0}, Ljava/util/Collections;->list(Ljava/util/Enumeration;)Ljava/util/ArrayList;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    :cond_4
    :goto_1
    if-ge v2, v1, :cond_7

    .line 95
    .line 96
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    add-int/lit8 v2, v2, 0x1

    .line 101
    .line 102
    check-cast v3, Ljava/net/NetworkInterface;

    .line 103
    .line 104
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->isUp()Z

    .line 105
    .line 106
    .line 107
    move-result v4

    .line 108
    if-eqz v4, :cond_4

    .line 109
    .line 110
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->isLoopback()Z

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    if-nez v4, :cond_4

    .line 115
    .line 116
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->isVirtual()Z

    .line 117
    .line 118
    .line 119
    move-result v4

    .line 120
    if-eqz v4, :cond_5

    .line 121
    .line 122
    goto :goto_1

    .line 123
    :cond_5
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->getInetAddresses()Ljava/util/Enumeration;

    .line 124
    .line 125
    .line 126
    move-result-object v4

    .line 127
    :cond_6
    invoke-interface {v4}, Ljava/util/Enumeration;->hasMoreElements()Z

    .line 128
    .line 129
    .line 130
    move-result v5

    .line 131
    if-eqz v5, :cond_4

    .line 132
    .line 133
    invoke-interface {v4}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v5

    .line 137
    check-cast v5, Ljava/net/InetAddress;

    .line 138
    .line 139
    instance-of v6, v5, Ljava/net/Inet6Address;

    .line 140
    .line 141
    if-eqz v6, :cond_6

    .line 142
    .line 143
    invoke-virtual {v5}, Ljava/net/InetAddress;->isLoopbackAddress()Z

    .line 144
    .line 145
    .line 146
    move-result v6

    .line 147
    if-nez v6, :cond_6

    .line 148
    .line 149
    invoke-virtual {v5}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    invoke-virtual {v3}, Ljava/net/NetworkInterface;->getDisplayName()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    return-object v5

    .line 156
    :cond_7
    invoke-static {}, Ljava/net/InetAddress;->getLocalHost()Ljava/net/InetAddress;

    .line 157
    .line 158
    .line 159
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 160
    return-object v0

    .line 161
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    const/4 v0, 0x0

    .line 165
    return-object v0
.end method

.method private getActiveNetworkAddress()Ljava/net/InetAddress;
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->context:Landroid/content/Context;

    .line 3
    .line 4
    const-string v2, "connectivity"

    .line 5
    .line 6
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    check-cast v1, Landroid/net/ConnectivityManager;

    .line 11
    .line 12
    if-nez v1, :cond_0

    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_0
    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    if-eqz v1, :cond_2

    .line 20
    .line 21
    invoke-virtual {v1}, Landroid/net/NetworkInfo;->isConnected()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-nez v1, :cond_1

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_1
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->findUsableNetworkInterface()Ljava/net/InetAddress;

    .line 29
    .line 30
    .line 31
    move-result-object v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 32
    return-object v0

    .line 33
    :catch_0
    move-exception v1

    .line 34
    goto :goto_1

    .line 35
    :cond_2
    :goto_0
    return-object v0

    .line 36
    :goto_1
    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    return-object v0
.end method

.method private handleDeviceRemoved(Ljava/lang/String;)V
    .locals 3

    .line 1
    const/4 v0, 0x0

    .line 2
    :goto_0
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 3
    .line 4
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-ge v0, v1, :cond_1

    .line 9
    .line 10
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 11
    .line 12
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    check-cast v1, Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 17
    .line 18
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getName()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-eqz v2, :cond_0

    .line 27
    .line 28
    iget-object p1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 29
    .line 30
    invoke-interface {p1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    invoke-direct {p0, v1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->notifyDeviceRemoved(Linfo/t4w/vp/airplay/AirPlayDevice;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_0
    add-int/lit8 v0, v0, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    return-void
.end method

.method private handleDeviceResolved(Ljavax/jmdns/ServiceEvent;)V
    .locals 7

    .line 1
    const-string v0, "."

    .line 2
    .line 3
    :try_start_0
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getInfo()Ljavax/jmdns/ServiceInfo;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :catch_0
    move-exception p1

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    invoke-virtual {v1}, Ljavax/jmdns/ServiceInfo;->getInetAddresses()[Ljava/net/InetAddress;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    array-length v3, v2

    .line 20
    if-nez v3, :cond_1

    .line 21
    .line 22
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_1
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    const/4 v4, 0x0

    .line 35
    if-eqz v3, :cond_2

    .line 36
    .line 37
    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    invoke-virtual {p1, v4, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    :cond_2
    const-string v0, "model"

    .line 46
    .line 47
    invoke-virtual {v1, v0}, Ljavax/jmdns/ServiceInfo;->getPropertyString(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    if-nez v0, :cond_3

    .line 52
    .line 53
    const-string v0, "am"

    .line 54
    .line 55
    invoke-virtual {v1, v0}, Ljavax/jmdns/ServiceInfo;->getPropertyString(Ljava/lang/String;)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    :cond_3
    if-nez v0, :cond_4

    .line 60
    .line 61
    const-string v0, "deviceid"

    .line 62
    .line 63
    invoke-virtual {v1, v0}, Ljavax/jmdns/ServiceInfo;->getPropertyString(Ljava/lang/String;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    :cond_4
    if-nez v0, :cond_5

    .line 68
    .line 69
    const-string v0, "AirPlay Device"

    .line 70
    .line 71
    :cond_5
    new-instance v3, Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 72
    .line 73
    aget-object v5, v2, v4

    .line 74
    .line 75
    invoke-virtual {v1}, Ljavax/jmdns/ServiceInfo;->getPort()I

    .line 76
    .line 77
    .line 78
    move-result v6

    .line 79
    invoke-direct {v3, p1, v0, v5, v6}, Linfo/t4w/vp/airplay/AirPlayDevice;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/net/InetAddress;I)V

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 83
    .line 84
    invoke-interface {p1, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 85
    .line 86
    .line 87
    move-result p1

    .line 88
    if-nez p1, :cond_6

    .line 89
    .line 90
    iget-object p1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 91
    .line 92
    invoke-interface {p1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    invoke-direct {p0, v3}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->notifyDeviceAdded(Linfo/t4w/vp/airplay/AirPlayDevice;)V

    .line 96
    .line 97
    .line 98
    invoke-virtual {v3}, Linfo/t4w/vp/airplay/AirPlayDevice;->getName()Ljava/lang/String;

    .line 99
    .line 100
    .line 101
    aget-object p1, v2, v4

    .line 102
    .line 103
    invoke-virtual {p1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    invoke-virtual {v1}, Ljavax/jmdns/ServiceInfo;->getPort()I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 107
    .line 108
    .line 109
    :cond_6
    return-void

    .line 110
    :goto_0
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    return-void
.end method

.method private synthetic lambda$startDiscovery$0()V
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    :try_start_0
    iput-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->isDiscoveryRunning:Z

    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    iput-boolean v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->hasFoundDevices:Z

    .line 6
    .line 7
    iget-object v2, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->context:Landroid/content/Context;

    .line 8
    .line 9
    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    const-string v3, "wifi"

    .line 14
    .line 15
    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    check-cast v2, Landroid/net/wifi/WifiManager;

    .line 20
    .line 21
    if-eqz v2, :cond_4

    .line 22
    .line 23
    const-string v3, "AirPlayDiscovery"

    .line 24
    .line 25
    invoke-virtual {v2, v3}, Landroid/net/wifi/WifiManager;->createMulticastLock(Ljava/lang/String;)Landroid/net/wifi/WifiManager$MulticastLock;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    iput-object v3, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 30
    .line 31
    invoke-virtual {v3, v0}, Landroid/net/wifi/WifiManager$MulticastLock;->setReferenceCounted(Z)V

    .line 32
    .line 33
    .line 34
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 35
    .line 36
    invoke-virtual {v3}, Landroid/net/wifi/WifiManager$MulticastLock;->acquire()V

    .line 37
    .line 38
    .line 39
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->getActiveNetworkAddress()Ljava/net/InetAddress;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    if-nez v3, :cond_3

    .line 44
    .line 45
    invoke-virtual {v2}, Landroid/net/wifi/WifiManager;->getConnectionInfo()Landroid/net/wifi/WifiInfo;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    if-eqz v2, :cond_2

    .line 50
    .line 51
    invoke-virtual {v2}, Landroid/net/wifi/WifiInfo;->getIpAddress()I

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    if-nez v2, :cond_1

    .line 56
    .line 57
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->findUsableNetworkInterface()Ljava/net/InetAddress;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    if-eqz v3, :cond_0

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_0
    new-instance v0, Ljava/io/IOException;

    .line 65
    .line 66
    const-string v1, "Could not find a usable network interface"

    .line 67
    .line 68
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    throw v0

    .line 72
    :catch_0
    move-exception v0

    .line 73
    goto/16 :goto_1

    .line 74
    .line 75
    :catch_1
    move-exception v0

    .line 76
    goto/16 :goto_2

    .line 77
    .line 78
    :catch_2
    move-exception v0

    .line 79
    goto/16 :goto_3

    .line 80
    .line 81
    :cond_1
    and-int/lit16 v3, v2, 0xff

    .line 82
    .line 83
    int-to-byte v3, v3

    .line 84
    shr-int/lit8 v4, v2, 0x8

    .line 85
    .line 86
    and-int/lit16 v4, v4, 0xff

    .line 87
    .line 88
    int-to-byte v4, v4

    .line 89
    shr-int/lit8 v5, v2, 0x10

    .line 90
    .line 91
    and-int/lit16 v5, v5, 0xff

    .line 92
    .line 93
    int-to-byte v5, v5

    .line 94
    shr-int/lit8 v2, v2, 0x18

    .line 95
    .line 96
    and-int/lit16 v2, v2, 0xff

    .line 97
    .line 98
    int-to-byte v2, v2

    .line 99
    const/4 v6, 0x4

    .line 100
    new-array v6, v6, [B

    .line 101
    .line 102
    aput-byte v3, v6, v1

    .line 103
    .line 104
    aput-byte v4, v6, v0

    .line 105
    .line 106
    const/4 v0, 0x2

    .line 107
    aput-byte v5, v6, v0

    .line 108
    .line 109
    const/4 v0, 0x3

    .line 110
    aput-byte v2, v6, v0

    .line 111
    .line 112
    invoke-static {v6}, Ljava/net/InetAddress;->getByAddress([B)Ljava/net/InetAddress;

    .line 113
    .line 114
    .line 115
    move-result-object v3

    .line 116
    goto :goto_0

    .line 117
    :cond_2
    new-instance v0, Ljava/io/IOException;

    .line 118
    .line 119
    const-string v1, "Could not get Wi-Fi connection info"

    .line 120
    .line 121
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    throw v0

    .line 125
    :cond_3
    :goto_0
    invoke-virtual {v3}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    invoke-virtual {v3}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    invoke-static {v3, v0}, Ljavax/jmdns/JmDNS;->create(Ljava/net/InetAddress;Ljava/lang/String;)Ljavax/jmdns/JmDNS;

    .line 133
    .line 134
    .line 135
    move-result-object v0

    .line 136
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 137
    .line 138
    new-instance v0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;

    .line 139
    .line 140
    invoke-direct {v0, p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;-><init>(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)V

    .line 141
    .line 142
    .line 143
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 144
    .line 145
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 146
    .line 147
    const-string v2, "_airplay._tcp.local."

    .line 148
    .line 149
    invoke-virtual {v1, v2, v0}, Ljavax/jmdns/JmDNS;->addServiceListener(Ljava/lang/String;Ljavax/jmdns/ServiceListener;)V

    .line 150
    .line 151
    .line 152
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 153
    .line 154
    const-string v1, "_raop._tcp.local."

    .line 155
    .line 156
    iget-object v2, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 157
    .line 158
    invoke-virtual {v0, v1, v2}, Ljavax/jmdns/JmDNS;->addServiceListener(Ljava/lang/String;Ljavax/jmdns/ServiceListener;)V

    .line 159
    .line 160
    .line 161
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 162
    .line 163
    const-string v1, "_appletv._tcp.local."

    .line 164
    .line 165
    iget-object v2, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 166
    .line 167
    invoke-virtual {v0, v1, v2}, Ljavax/jmdns/JmDNS;->addServiceListener(Ljava/lang/String;Ljavax/jmdns/ServiceListener;)V

    .line 168
    .line 169
    .line 170
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 171
    .line 172
    const-string v1, "_http._tcp.local."

    .line 173
    .line 174
    const-string v2, "AndroidSender"

    .line 175
    .line 176
    const-string v3, "Service for triggering mDNS scan"

    .line 177
    .line 178
    const/16 v4, 0x50

    .line 179
    .line 180
    invoke-static {v1, v2, v4, v3}, Ljavax/jmdns/ServiceInfo;->create(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Ljavax/jmdns/ServiceInfo;

    .line 181
    .line 182
    .line 183
    move-result-object v1

    .line 184
    invoke-virtual {v0, v1}, Ljavax/jmdns/JmDNS;->registerService(Ljavax/jmdns/ServiceInfo;)V

    .line 185
    .line 186
    .line 187
    return-void

    .line 188
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 189
    .line 190
    const-string v1, "Failed to get WifiManager service"

    .line 191
    .line 192
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    throw v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 196
    :goto_1
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->stopDiscovery()V

    .line 200
    .line 201
    .line 202
    goto :goto_5

    .line 203
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->stopDiscovery()V

    .line 207
    .line 208
    .line 209
    goto :goto_5

    .line 210
    :goto_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 211
    .line 212
    .line 213
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->stopDiscovery()V

    .line 214
    .line 215
    .line 216
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 217
    .line 218
    if-eqz v0, :cond_5

    .line 219
    .line 220
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->isHeld()Z

    .line 221
    .line 222
    .line 223
    move-result v0

    .line 224
    if-eqz v0, :cond_5

    .line 225
    .line 226
    :try_start_1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 227
    .line 228
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->release()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_3

    .line 229
    .line 230
    .line 231
    goto :goto_4

    .line 232
    :catch_3
    move-exception v0

    .line 233
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    :goto_4
    const/4 v0, 0x0

    .line 237
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 238
    .line 239
    :cond_5
    :goto_5
    return-void
.end method

.method private notifyDeviceAdded(Linfo/t4w/vp/airplay/AirPlayDevice;)V
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->listeners:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;

    .line 18
    .line 19
    invoke-interface {v1, p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;->onDeviceAdded(Linfo/t4w/vp/airplay/AirPlayDevice;)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    return-void
.end method

.method private notifyDeviceRemoved(Linfo/t4w/vp/airplay/AirPlayDevice;)V
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->listeners:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    check-cast v1, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;

    .line 18
    .line 19
    invoke-interface {v1, p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;->onDeviceRemoved(Linfo/t4w/vp/airplay/AirPlayDevice;)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    return-void
.end method

.method public static bridge synthetic rz__9J_(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->hasFoundDevices:Z

    return-void
.end method

.method public static bridge synthetic waiBKÀ(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)Ljavax/jmdns/JmDNS;
    .locals 0

    .line 1
    iget-object p0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    return-object p0
.end method


# virtual methods
.method public addDiscoveryListener(Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;)V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->listeners:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->listeners:Ljava/util/List;

    .line 10
    .line 11
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 12
    .line 13
    .line 14
    :cond_0
    return-void
.end method

.method public getDiscoveredDevices()Ljava/util/List;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Linfo/t4w/vp/airplay/AirPlayDevice;",
            ">;"
        }
    .end annotation

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public hasFoundDevices()Z
    .locals 1

    .line 1
    iget-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->hasFoundDevices:Z

    .line 2
    .line 3
    return v0
.end method

.method public removeDiscoveryListener(Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;)V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->listeners:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public resetDiscovery()V
    .locals 1

    .line 1
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->stopDiscovery()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->discoveredDevices:Ljava/util/List;

    .line 5
    .line 6
    invoke-interface {v0}, Ljava/util/List;->clear()V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->hasFoundDevices:Z

    .line 11
    .line 12
    return-void
.end method

.method public startDiscovery()V
    .locals 3

    .line 1
    iget-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->isDiscoveryRunning:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->stopDiscovery()V

    .line 6
    .line 7
    .line 8
    :cond_0
    new-instance v0, Ljava/lang/Thread;

    .line 9
    .line 10
    new-instance v1, LvIndex5686;

    .line 11
    .line 12
    const/4 v2, 0x1

    .line 13
    invoke-direct {v1, v2, p0}, LvIndex5686;-><init>(ILjava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public stopDiscovery()V
    .locals 4

    .line 1
    iget-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->isDiscoveryRunning:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    :try_start_0
    iput-boolean v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->isDiscoveryRunning:Z

    .line 8
    .line 9
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    if-eqz v0, :cond_2

    .line 13
    .line 14
    :try_start_1
    iget-object v2, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 15
    .line 16
    if-eqz v2, :cond_1

    .line 17
    .line 18
    const-string v3, "_airplay._tcp.local."

    .line 19
    .line 20
    invoke-virtual {v0, v3, v2}, Ljavax/jmdns/JmDNS;->removeServiceListener(Ljava/lang/String;Ljavax/jmdns/ServiceListener;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 24
    .line 25
    const-string v2, "_raop._tcp.local."

    .line 26
    .line 27
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 28
    .line 29
    invoke-virtual {v0, v2, v3}, Ljavax/jmdns/JmDNS;->removeServiceListener(Ljava/lang/String;Ljavax/jmdns/ServiceListener;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 33
    .line 34
    const-string v2, "_appletv._tcp.local."

    .line 35
    .line 36
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 37
    .line 38
    invoke-virtual {v0, v2, v3}, Ljavax/jmdns/JmDNS;->removeServiceListener(Ljava/lang/String;Ljavax/jmdns/ServiceListener;)V

    .line 39
    .line 40
    .line 41
    goto :goto_0

    .line 42
    :catchall_0
    move-exception v0

    .line 43
    goto :goto_4

    .line 44
    :catch_0
    move-exception v0

    .line 45
    goto :goto_2

    .line 46
    :catch_1
    move-exception v0

    .line 47
    goto :goto_3

    .line 48
    :cond_1
    :goto_0
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 49
    .line 50
    invoke-interface {v0}, Ljava/io/Closeable;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 51
    .line 52
    .line 53
    :try_start_2
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 54
    .line 55
    :goto_1
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 56
    .line 57
    goto :goto_5

    .line 58
    :catch_2
    move-exception v0

    .line 59
    goto :goto_8

    .line 60
    :goto_2
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 61
    .line 62
    .line 63
    :try_start_4
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    .line 64
    .line 65
    goto :goto_1

    .line 66
    :goto_3
    :try_start_5
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 67
    .line 68
    .line 69
    :try_start_6
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 70
    .line 71
    goto :goto_1

    .line 72
    :goto_4
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->jmDNS:Ljavax/jmdns/JmDNS;

    .line 73
    .line 74
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->serviceListener:Ljavax/jmdns/ServiceListener;

    .line 75
    .line 76
    throw v0

    .line 77
    :cond_2
    :goto_5
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 78
    .line 79
    if-eqz v0, :cond_3

    .line 80
    .line 81
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->isHeld()Z

    .line 82
    .line 83
    .line 84
    move-result v0
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_2

    .line 85
    if-eqz v0, :cond_3

    .line 86
    .line 87
    :try_start_7
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 88
    .line 89
    invoke-virtual {v0}, Landroid/net/wifi/WifiManager$MulticastLock;->release()V
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_3
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    .line 90
    .line 91
    .line 92
    :goto_6
    :try_start_8
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_2

    .line 93
    .line 94
    goto :goto_9

    .line 95
    :catchall_1
    move-exception v0

    .line 96
    goto :goto_7

    .line 97
    :catch_3
    move-exception v0

    .line 98
    :try_start_9
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_1

    .line 99
    .line 100
    .line 101
    goto :goto_6

    .line 102
    :goto_7
    :try_start_a
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->multicastLock:Landroid/net/wifi/WifiManager$MulticastLock;

    .line 103
    .line 104
    throw v0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_2

    .line 105
    :goto_8
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    :cond_3
    :goto_9
    return-void
.end method
