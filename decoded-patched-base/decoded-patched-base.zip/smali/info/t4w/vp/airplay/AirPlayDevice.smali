.class public Linfo/t4w/vp/airplay/AirPlayDevice;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private address:Ljava/net/InetAddress;

.field private model:Ljava/lang/String;

.field private name:Ljava/lang/String;

.field private port:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/net/InetAddress;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->name:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->model:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->address:Ljava/net/InetAddress;

    .line 9
    .line 10
    iput p4, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->port:I

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    const/4 v1, 0x0

    .line 6
    if-eqz p1, :cond_2

    .line 7
    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    if-eq v2, v3, :cond_1

    .line 17
    .line 18
    goto :goto_0

    .line 19
    :cond_1
    check-cast p1, Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 20
    .line 21
    iget v2, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->port:I

    .line 22
    .line 23
    iget v3, p1, Linfo/t4w/vp/airplay/AirPlayDevice;->port:I

    .line 24
    .line 25
    if-ne v2, v3, :cond_2

    .line 26
    .line 27
    iget-object v2, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->address:Ljava/net/InetAddress;

    .line 28
    .line 29
    iget-object p1, p1, Linfo/t4w/vp/airplay/AirPlayDevice;->address:Ljava/net/InetAddress;

    .line 30
    .line 31
    invoke-virtual {v2, p1}, Ljava/net/InetAddress;->equals(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    if-eqz p1, :cond_2

    .line 36
    .line 37
    return v0

    .line 38
    :cond_2
    :goto_0
    return v1
.end method

.method public getAddress()Ljava/net/InetAddress;
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->address:Ljava/net/InetAddress;

    .line 2
    .line 3
    return-object v0
.end method

.method public getModel()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->model:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->name:Ljava/lang/String;

    .line 2
    .line 3
    return-object v0
.end method

.method public getPort()I
    .locals 1

    .line 1
    iget v0, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->port:I

    .line 2
    .line 3
    return v0
.end method

.method public hashCode()I
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->address:Ljava/net/InetAddress;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/net/InetAddress;->hashCode()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    mul-int/lit8 v0, v0, 0x1f

    .line 8
    .line 9
    iget v1, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->port:I

    .line 10
    .line 11
    add-int/2addr v0, v1

    .line 12
    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->name:Ljava/lang/String;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, " ("

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->address:Ljava/net/InetAddress;

    .line 17
    .line 18
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    const-string v1, ":"

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    iget v1, p0, Linfo/t4w/vp/airplay/AirPlayDevice;->port:I

    .line 31
    .line 32
    const-string v2, ")"

    .line 33
    .line 34
    invoke-static {v0, v1, v2}, LBRK_m_;->jPos3709(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    return-object v0
.end method
