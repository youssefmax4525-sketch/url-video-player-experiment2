.class Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljavax/jmdns/ServiceListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->startDiscovery()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;


# direct methods
.method public constructor <init>(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)V
    .locals 0

    .line 1
    iput-object p1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;->this$0:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public serviceAdded(Ljavax/jmdns/ServiceEvent;)V
    .locals 2

    .line 1
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getType()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;->this$0:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;

    .line 8
    .line 9
    invoke-static {v0}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->waiBKÀ(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)Ljavax/jmdns/JmDNS;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getType()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-virtual {v0, v1, p1}, Ljavax/jmdns/JmDNS;->requestServiceInfo(Ljava/lang/String;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public serviceRemoved(Ljavax/jmdns/ServiceEvent;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getType()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;->this$0:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;

    .line 8
    .line 9
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-static {v0, p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->POOl(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public serviceResolved(Ljavax/jmdns/ServiceEvent;)V
    .locals 1

    .line 1
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getName()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljavax/jmdns/ServiceEvent;->getType()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;->this$0:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;

    .line 8
    .line 9
    invoke-static {v0, p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->JKEoÙX(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;Ljavax/jmdns/ServiceEvent;)V

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, Linfo/t4w/vp/airplay/AirPlayDiscoveryService$1;->this$0:Linfo/t4w/vp/airplay/AirPlayDiscoveryService;

    .line 13
    .line 14
    invoke-static {p1}, Linfo/t4w/vp/airplay/AirPlayDiscoveryService;->rz__9J_(Linfo/t4w/vp/airplay/AirPlayDiscoveryService;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method
