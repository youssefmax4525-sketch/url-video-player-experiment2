.class public Linfo/t4w/vp/airplay/AirPlayClient;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final AIRPLAY_VERSION_1:I = 0x1

.field private static final AIRPLAY_VERSION_2:I = 0x2

.field private static final AIRPLAY_VERSION_UNKNOWN:I = 0x0

.field private static final MAX_RETRY_COUNT:I = 0x2

.field private static final TAG:Ljava/lang/String; = "AirPlayClient"


# instance fields
.field private currentSessionId:Ljava/lang/String;

.field private detectedAirPlayVersion:I

.field private final device:Linfo/t4w/vp/airplay/AirPlayDevice;

.field private deviceCapabilities:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private retryCount:I

.field private userAgent:Ljava/lang/String;


# direct methods
.method public constructor <init>(Linfo/t4w/vp/airplay/AirPlayDevice;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 9
    .line 10
    iput v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 11
    .line 12
    new-instance v0, Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->deviceCapabilities:Ljava/util/Map;

    .line 18
    .line 19
    iput-object p1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 20
    .line 21
    return-void
.end method

.method private escapeXml(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    .line 1
    if-nez p1, :cond_0

    .line 2
    .line 3
    const-string p1, ""

    .line 4
    .line 5
    return-object p1

    .line 6
    :cond_0
    const-string v0, "&"

    .line 7
    .line 8
    const-string v1, "&amp;"

    .line 9
    .line 10
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    const-string v0, "<"

    .line 15
    .line 16
    const-string v1, "&lt;"

    .line 17
    .line 18
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    const-string v0, ">"

    .line 23
    .line 24
    const-string v1, "&gt;"

    .line 25
    .line 26
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    const-string v0, "\""

    .line 31
    .line 32
    const-string v1, "&quot;"

    .line 33
    .line 34
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    const-string v0, "\'"

    .line 39
    .line 40
    const-string v1, "&apos;"

    .line 41
    .line 42
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    return-object p1
.end method

.method private generateSessionId()Ljava/lang/String;
    .locals 6

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    :goto_0
    const/16 v2, 0x10

    .line 8
    .line 9
    if-ge v1, v2, :cond_0

    .line 10
    .line 11
    invoke-static {}, Ljava/lang/Math;->random()D

    .line 12
    .line 13
    .line 14
    move-result-wide v2

    .line 15
    const/16 v4, 0x3e

    .line 16
    .line 17
    int-to-double v4, v4

    .line 18
    mul-double v2, v2, v4

    .line 19
    .line 20
    double-to-int v2, v2

    .line 21
    const-string v3, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"

    .line 22
    .line 23
    invoke-virtual {v3, v2}, Ljava/lang/String;->charAt(I)C

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    add-int/lit8 v1, v1, 0x1

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    return-object v0
.end method

.method private getFormattedTransmitDate()Ljava/lang/String;
    .locals 6

    .line 1
    const-string v0, "UTC"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v1}, Ljava/util/Calendar;->getInstance(Ljava/util/TimeZone;)Ljava/util/Calendar;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    new-instance v2, Ljava/text/SimpleDateFormat;

    .line 12
    .line 13
    sget-object v3, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 14
    .line 15
    const-string v4, "yyyy-MM-dd\'T\'HH:mm:ss"

    .line 16
    .line 17
    invoke-direct {v2, v4, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 18
    .line 19
    .line 20
    invoke-static {v0}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {v2, v0}, Ljava/text/DateFormat;->setTimeZone(Ljava/util/TimeZone;)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/util/Calendar;->getTime()Ljava/util/Date;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v2, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 36
    .line 37
    .line 38
    move-result-wide v1

    .line 39
    const-wide/16 v4, 0x3e8

    .line 40
    .line 41
    rem-long/2addr v1, v4

    .line 42
    mul-long v1, v1, v4

    .line 43
    .line 44
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    const/4 v2, 0x1

    .line 49
    new-array v2, v2, [Ljava/lang/Object;

    .line 50
    .line 51
    const/4 v4, 0x0

    .line 52
    aput-object v1, v2, v4

    .line 53
    .line 54
    const-string v1, "%06d"

    .line 55
    .line 56
    invoke-static {v3, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    new-instance v2, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    const-string v0, "."

    .line 69
    .line 70
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string v0, "Z"

    .line 77
    .line 78
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    return-object v0
.end method

.method private getPlaybackStatusWithRetry(I)Z
    .locals 11

    .line 1
    const-string v0, "duration"

    .line 2
    .line 3
    const-string v1, "http://"

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x0

    .line 7
    const/4 v4, 0x1

    .line 8
    :try_start_0
    iget-object v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 9
    .line 10
    if-nez v5, :cond_0

    .line 11
    .line 12
    return v4

    .line 13
    :cond_0
    new-instance v5, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    invoke-direct {v5, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 19
    .line 20
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string v1, ":"

    .line 32
    .line 33
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 37
    .line 38
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    const-string v1, "/playback-info"

    .line 46
    .line 47
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    new-instance v5, Ljava/net/URL;

    .line 55
    .line 56
    invoke-direct {v5, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {v5}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    check-cast v1, Ljava/net/HttpURLConnection;

    .line 64
    .line 65
    const-string v5, "GET"

    .line 66
    .line 67
    invoke-virtual {v1, v5}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    const-string v5, "User-Agent"

    .line 71
    .line 72
    iget-object v6, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 73
    .line 74
    if-eqz v6, :cond_1

    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_1
    const-string v6, "AirPlay/420.10"

    .line 78
    .line 79
    :goto_0
    invoke-virtual {v1, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    const-string v5, "X-Apple-Session-ID"

    .line 83
    .line 84
    iget-object v6, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 85
    .line 86
    invoke-virtual {v1, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    const-string v5, "X-Apple-Device-ID"

    .line 90
    .line 91
    const-string v6, "0x1234ABCD"

    .line 92
    .line 93
    invoke-virtual {v1, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    const-string v5, "Connection"

    .line 97
    .line 98
    const-string v6, "keep-alive"

    .line 99
    .line 100
    invoke-virtual {v1, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 101
    .line 102
    .line 103
    const/16 v5, 0x3a98

    .line 104
    .line 105
    invoke-virtual {v1, v5}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v1, v5}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 112
    .line 113
    .line 114
    move-result v5

    .line 115
    const/16 v6, 0xc8

    .line 116
    .line 117
    const/4 v7, 0x5

    .line 118
    if-ne v5, v6, :cond_a

    .line 119
    .line 120
    new-instance v5, Ljava/io/BufferedReader;

    .line 121
    .line 122
    new-instance v6, Ljava/io/InputStreamReader;

    .line 123
    .line 124
    invoke-virtual {v1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-direct {v6, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 129
    .line 130
    .line 131
    invoke-direct {v5, v6}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 132
    .line 133
    .line 134
    new-instance v1, Ljava/lang/StringBuilder;

    .line 135
    .line 136
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 137
    .line 138
    .line 139
    :goto_1
    invoke-virtual {v5}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v6

    .line 143
    if-eqz v6, :cond_2

    .line 144
    .line 145
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    goto :goto_1

    .line 149
    :catch_0
    move-exception v0

    .line 150
    goto/16 :goto_a

    .line 151
    .line 152
    :cond_2
    invoke-virtual {v5}, Ljava/io/BufferedReader;->close()V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 160
    .line 161
    .line 162
    move-result v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 163
    const-string v6, "rate"

    .line 164
    .line 165
    if-nez v5, :cond_4

    .line 166
    .line 167
    :try_start_1
    const-string v5, "position"

    .line 168
    .line 169
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 170
    .line 171
    .line 172
    move-result v5

    .line 173
    if-nez v5, :cond_4

    .line 174
    .line 175
    invoke-virtual {v1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 176
    .line 177
    .line 178
    move-result v5

    .line 179
    if-nez v5, :cond_4

    .line 180
    .line 181
    const-string v5, "readyToPlay"

    .line 182
    .line 183
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 184
    .line 185
    .line 186
    move-result v5

    .line 187
    if-nez v5, :cond_4

    .line 188
    .line 189
    const-string v5, "playing"

    .line 190
    .line 191
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 192
    .line 193
    .line 194
    move-result v5

    .line 195
    if-nez v5, :cond_4

    .line 196
    .line 197
    const-string v5, "playbackLikelyToKeepUp"

    .line 198
    .line 199
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 200
    .line 201
    .line 202
    move-result v5

    .line 203
    if-nez v5, :cond_4

    .line 204
    .line 205
    const-string v5, "uuid"

    .line 206
    .line 207
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 208
    .line 209
    .line 210
    move-result v5

    .line 211
    if-nez v5, :cond_4

    .line 212
    .line 213
    const-string v5, "progressPercent"

    .line 214
    .line 215
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 216
    .line 217
    .line 218
    move-result v5

    .line 219
    if-nez v5, :cond_4

    .line 220
    .line 221
    const-string v5, "timePos"

    .line 222
    .line 223
    invoke-virtual {v1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 224
    .line 225
    .line 226
    move-result v5

    .line 227
    if-eqz v5, :cond_3

    .line 228
    .line 229
    goto :goto_2

    .line 230
    :cond_3
    const/4 v5, 0x0

    .line 231
    goto :goto_3

    .line 232
    :cond_4
    :goto_2
    const/4 v5, 0x1

    .line 233
    :goto_3
    invoke-virtual {v1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 234
    .line 235
    .line 236
    move-result v8
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 237
    if-eqz v8, :cond_8

    .line 238
    .line 239
    :try_start_2
    invoke-virtual {v1, v6}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 240
    .line 241
    .line 242
    move-result v6

    .line 243
    add-int/2addr v6, v7

    .line 244
    :goto_4
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 245
    .line 246
    .line 247
    move-result v7

    .line 248
    const/16 v8, 0x2d

    .line 249
    .line 250
    if-ge v6, v7, :cond_5

    .line 251
    .line 252
    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    .line 253
    .line 254
    .line 255
    move-result v7

    .line 256
    invoke-static {v7}, Ljava/lang/Character;->isDigit(C)Z

    .line 257
    .line 258
    .line 259
    move-result v7

    .line 260
    if-nez v7, :cond_5

    .line 261
    .line 262
    invoke-virtual {v1, v6}, Ljava/lang/String;->charAt(I)C

    .line 263
    .line 264
    .line 265
    move-result v7

    .line 266
    if-eq v7, v8, :cond_5

    .line 267
    .line 268
    add-int/lit8 v6, v6, 0x1

    .line 269
    .line 270
    goto :goto_4

    .line 271
    :catch_1
    move-exception v0

    .line 272
    goto :goto_6

    .line 273
    :cond_5
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 274
    .line 275
    .line 276
    move-result v7

    .line 277
    if-ge v6, v7, :cond_8

    .line 278
    .line 279
    move v7, v6

    .line 280
    :goto_5
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 281
    .line 282
    .line 283
    move-result v9

    .line 284
    if-ge v7, v9, :cond_7

    .line 285
    .line 286
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 287
    .line 288
    .line 289
    move-result v9

    .line 290
    invoke-static {v9}, Ljava/lang/Character;->isDigit(C)Z

    .line 291
    .line 292
    .line 293
    move-result v9

    .line 294
    if-nez v9, :cond_6

    .line 295
    .line 296
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 297
    .line 298
    .line 299
    move-result v9

    .line 300
    const/16 v10, 0x2e

    .line 301
    .line 302
    if-eq v9, v10, :cond_6

    .line 303
    .line 304
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 305
    .line 306
    .line 307
    move-result v9

    .line 308
    if-ne v9, v8, :cond_7

    .line 309
    .line 310
    :cond_6
    add-int/lit8 v7, v7, 0x1

    .line 311
    .line 312
    goto :goto_5

    .line 313
    :cond_7
    if-le v7, v6, :cond_8

    .line 314
    .line 315
    invoke-virtual {v1, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 316
    .line 317
    .line 318
    move-result-object v6

    .line 319
    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    .line 320
    .line 321
    .line 322
    move-result v6

    .line 323
    const/4 v7, 0x0

    .line 324
    cmpl-float v6, v6, v7

    .line 325
    .line 326
    if-nez v6, :cond_8

    .line 327
    .line 328
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 329
    .line 330
    .line 331
    move-result v0
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 332
    if-eqz v0, :cond_8

    .line 333
    .line 334
    const/4 v5, 0x1

    .line 335
    goto :goto_7

    .line 336
    :goto_6
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    :cond_8
    :goto_7
    if-nez v5, :cond_9

    .line 340
    .line 341
    if-gt p1, v4, :cond_9

    .line 342
    .line 343
    return v4

    .line 344
    :cond_9
    return v5

    .line 345
    :cond_a
    const/16 v0, 0xcc

    .line 346
    .line 347
    if-ne v5, v0, :cond_b

    .line 348
    .line 349
    return v4

    .line 350
    :cond_b
    const/16 v0, 0x1f4

    .line 351
    .line 352
    if-ne v5, v0, :cond_f

    .line 353
    .line 354
    invoke-direct {p0, v1}, Linfo/t4w/vp/airplay/AirPlayClient;->readErrorResponse(Ljava/net/HttpURLConnection;)Ljava/lang/String;

    .line 355
    .line 356
    .line 357
    move-result-object v0

    .line 358
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 359
    .line 360
    .line 361
    if-ge p1, v7, :cond_e

    .line 362
    .line 363
    add-int/lit8 v0, p1, 0x1

    .line 364
    .line 365
    mul-int/lit16 v1, v0, 0x3e8

    .line 366
    .line 367
    int-to-long v5, v1

    .line 368
    :try_start_4
    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V
    :try_end_4
    .catch Ljava/lang/InterruptedException; {:try_start_4 .. :try_end_4} :catch_2
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 369
    .line 370
    .line 371
    goto :goto_8

    .line 372
    :catch_2
    nop

    .line 373
    :goto_8
    if-lez p1, :cond_d

    .line 374
    .line 375
    :try_start_5
    rem-int/lit8 v1, p1, 0x2

    .line 376
    .line 377
    if-nez v1, :cond_c

    .line 378
    .line 379
    const/high16 v1, 0x3f800000    # 1.0f

    .line 380
    .line 381
    invoke-direct {p0, v1}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z

    .line 382
    .line 383
    .line 384
    goto :goto_9

    .line 385
    :cond_c
    const-wide/16 v5, 0x0

    .line 386
    .line 387
    invoke-direct {p0, v5, v6}, Linfo/t4w/vp/airplay/AirPlayClient;->sendScrubRequest(D)Z
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    .line 388
    .line 389
    .line 390
    :goto_9
    const-wide/16 v5, 0x12c

    .line 391
    .line 392
    :try_start_6
    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V
    :try_end_6
    .catch Ljava/lang/InterruptedException; {:try_start_6 .. :try_end_6} :catch_3
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 393
    .line 394
    .line 395
    :catch_3
    :cond_d
    :try_start_7
    invoke-direct {p0, v0}, Linfo/t4w/vp/airplay/AirPlayClient;->getPlaybackStatusWithRetry(I)Z

    .line 396
    .line 397
    .line 398
    move-result p1

    .line 399
    return p1

    .line 400
    :cond_e
    return v4

    .line 401
    :cond_f
    const/16 v0, 0x191

    .line 402
    .line 403
    if-ne v5, v0, :cond_11

    .line 404
    .line 405
    if-ge p1, v2, :cond_10

    .line 406
    .line 407
    return v4

    .line 408
    :cond_10
    return v3

    .line 409
    :cond_11
    invoke-direct {p0, v1}, Linfo/t4w/vp/airplay/AirPlayClient;->readErrorResponse(Ljava/net/HttpURLConnection;)Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object v0

    .line 413
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    .line 414
    .line 415
    .line 416
    if-nez p1, :cond_12

    .line 417
    .line 418
    return v4

    .line 419
    :cond_12
    return v3

    .line 420
    :goto_a
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 421
    .line 422
    .line 423
    if-ge p1, v2, :cond_13

    .line 424
    .line 425
    const/4 v3, 0x1

    .line 426
    :cond_13
    return v3
.end method

.method private parseDeviceCapabilities(Ljava/lang/String;)V
    .locals 14

    .line 1
    const-string v0, "protovers="

    .line 2
    .line 3
    const-string v1, "model="

    .line 4
    .line 5
    const-string v2, "deviceid="

    .line 6
    .line 7
    const-string v3, "features=0x"

    .line 8
    .line 9
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->deviceCapabilities:Ljava/util/Map;

    .line 10
    .line 11
    invoke-interface {v4}, Ljava/util/Map;->clear()V

    .line 12
    .line 13
    .line 14
    const/4 v4, 0x0

    .line 15
    :try_start_0
    invoke-virtual {p1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 16
    .line 17
    .line 18
    move-result v5

    .line 19
    const/4 v6, 0x1

    .line 20
    if-eqz v5, :cond_1

    .line 21
    .line 22
    const-string v5, "model=AppleTV"

    .line 23
    .line 24
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 25
    .line 26
    .line 27
    move-result v5

    .line 28
    if-nez v5, :cond_0

    .line 29
    .line 30
    const-string v5, "model=AudioAccessory"

    .line 31
    .line 32
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 33
    .line 34
    .line 35
    move-result v5

    .line 36
    if-nez v5, :cond_0

    .line 37
    .line 38
    const-string v5, "model=HomePod"

    .line 39
    .line 40
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    if-nez v5, :cond_0

    .line 45
    .line 46
    const-string v5, "features=0x4A7FDFF9"

    .line 47
    .line 48
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-nez v5, :cond_0

    .line 53
    .line 54
    const-string v5, "features=0x39F7FFFF"

    .line 55
    .line 56
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 57
    .line 58
    .line 59
    move-result v5

    .line 60
    if-nez v5, :cond_0

    .line 61
    .line 62
    const-string v5, "protovers=1.1"

    .line 63
    .line 64
    invoke-virtual {p1, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 65
    .line 66
    .line 67
    move-result v5

    .line 68
    if-eqz v5, :cond_1

    .line 69
    .line 70
    goto :goto_0

    .line 71
    :catch_0
    move-exception p1

    .line 72
    goto/16 :goto_4

    .line 73
    .line 74
    :cond_0
    :goto_0
    const/4 v5, 0x1

    .line 75
    goto :goto_1

    .line 76
    :cond_1
    const/4 v5, 0x0

    .line 77
    :goto_1
    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 78
    .line 79
    .line 80
    move-result v7

    .line 81
    if-eqz v7, :cond_2

    .line 82
    .line 83
    const-string v7, "features="

    .line 84
    .line 85
    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 86
    .line 87
    .line 88
    move-result v7

    .line 89
    if-eqz v7, :cond_3

    .line 90
    .line 91
    :cond_2
    const-string v7, "protovers=1.0"

    .line 92
    .line 93
    invoke-virtual {p1, v7}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 94
    .line 95
    .line 96
    move-result v7

    .line 97
    if-eqz v7, :cond_4

    .line 98
    .line 99
    :cond_3
    const/4 v7, 0x1

    .line 100
    goto :goto_2

    .line 101
    :cond_4
    const/4 v7, 0x0

    .line 102
    :goto_2
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 103
    .line 104
    .line 105
    move-result v8

    .line 106
    const/16 v9, 0x22

    .line 107
    .line 108
    if-eqz v8, :cond_6

    .line 109
    .line 110
    invoke-virtual {p1, v1}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 111
    .line 112
    .line 113
    move-result v1

    .line 114
    add-int/lit8 v1, v1, 0x6

    .line 115
    .line 116
    invoke-virtual {p1, v9, v1}, Ljava/lang/String;->indexOf(II)I

    .line 117
    .line 118
    .line 119
    move-result v8

    .line 120
    if-le v8, v1, :cond_6

    .line 121
    .line 122
    invoke-virtual {p1, v1, v8}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object v1

    .line 126
    iget-object v8, p0, Linfo/t4w/vp/airplay/AirPlayClient;->deviceCapabilities:Ljava/util/Map;

    .line 127
    .line 128
    const-string v10, "model"

    .line 129
    .line 130
    invoke-interface {v8, v10, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    const-string v8, "AppleTV"

    .line 134
    .line 135
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 136
    .line 137
    .line 138
    move-result v8

    .line 139
    if-nez v8, :cond_5

    .line 140
    .line 141
    const-string v8, "HomePod"

    .line 142
    .line 143
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 144
    .line 145
    .line 146
    move-result v8

    .line 147
    if-nez v8, :cond_5

    .line 148
    .line 149
    const-string v8, "AudioAccessory"

    .line 150
    .line 151
    invoke-virtual {v1, v8}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    if-eqz v1, :cond_6

    .line 156
    .line 157
    :cond_5
    const/4 v5, 0x1

    .line 158
    :cond_6
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 159
    .line 160
    .line 161
    move-result v1

    .line 162
    if-eqz v1, :cond_8

    .line 163
    .line 164
    invoke-virtual {p1, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 165
    .line 166
    .line 167
    move-result v0

    .line 168
    add-int/lit8 v0, v0, 0xa

    .line 169
    .line 170
    invoke-virtual {p1, v9, v0}, Ljava/lang/String;->indexOf(II)I

    .line 171
    .line 172
    .line 173
    move-result v1

    .line 174
    if-le v1, v0, :cond_8

    .line 175
    .line 176
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object v0

    .line 180
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->deviceCapabilities:Ljava/util/Map;

    .line 181
    .line 182
    const-string v8, "protovers"

    .line 183
    .line 184
    invoke-interface {v1, v8, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    const-string v1, "1.1"

    .line 188
    .line 189
    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 190
    .line 191
    .line 192
    move-result v1

    .line 193
    if-eqz v1, :cond_7

    .line 194
    .line 195
    const/4 v5, 0x1

    .line 196
    goto :goto_3

    .line 197
    :cond_7
    const-string v1, "1.0"

    .line 198
    .line 199
    invoke-virtual {v0, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 200
    .line 201
    .line 202
    move-result v0

    .line 203
    if-eqz v0, :cond_8

    .line 204
    .line 205
    const/4 v7, 0x1

    .line 206
    :cond_8
    :goto_3
    invoke-virtual {p1, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 207
    .line 208
    .line 209
    move-result v0

    .line 210
    if-eqz v0, :cond_a

    .line 211
    .line 212
    invoke-virtual {p1, v3}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    add-int/lit8 v0, v0, 0xb

    .line 217
    .line 218
    invoke-virtual {p1, v9, v0}, Ljava/lang/String;->indexOf(II)I

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    if-le v1, v0, :cond_a

    .line 223
    .line 224
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 225
    .line 226
    .line 227
    move-result-object v0

    .line 228
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->deviceCapabilities:Ljava/util/Map;

    .line 229
    .line 230
    const-string v3, "features"

    .line 231
    .line 232
    invoke-interface {v1, v3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 233
    .line 234
    .line 235
    const/16 v1, 0x10

    .line 236
    .line 237
    :try_start_1
    invoke-static {v0, v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;I)J

    .line 238
    .line 239
    .line 240
    move-result-wide v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 241
    const-wide v10, 0x4000000000L

    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    and-long/2addr v10, v0

    .line 247
    const-wide/16 v12, 0x0

    .line 248
    .line 249
    cmp-long v3, v10, v12

    .line 250
    .line 251
    if-nez v3, :cond_9

    .line 252
    .line 253
    const-wide v10, 0x2000000000L

    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    and-long/2addr v0, v10

    .line 259
    cmp-long v3, v0, v12

    .line 260
    .line 261
    if-eqz v3, :cond_a

    .line 262
    .line 263
    :cond_9
    const/4 v5, 0x1

    .line 264
    :catch_1
    :cond_a
    :try_start_2
    invoke-virtual {p1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 265
    .line 266
    .line 267
    move-result v0

    .line 268
    if-eqz v0, :cond_b

    .line 269
    .line 270
    invoke-virtual {p1, v2}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    .line 271
    .line 272
    .line 273
    move-result v0

    .line 274
    add-int/lit8 v0, v0, 0x9

    .line 275
    .line 276
    invoke-virtual {p1, v9, v0}, Ljava/lang/String;->indexOf(II)I

    .line 277
    .line 278
    .line 279
    move-result v1

    .line 280
    if-le v1, v0, :cond_b

    .line 281
    .line 282
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 283
    .line 284
    .line 285
    move-result-object p1

    .line 286
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->deviceCapabilities:Ljava/util/Map;

    .line 287
    .line 288
    const-string v1, "deviceid"

    .line 289
    .line 290
    invoke-interface {v0, v1, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    :cond_b
    if-eqz v5, :cond_c

    .line 294
    .line 295
    const/4 p1, 0x2

    .line 296
    iput p1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 297
    .line 298
    goto :goto_5

    .line 299
    :cond_c
    if-eqz v7, :cond_d

    .line 300
    .line 301
    iput v6, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_d
    iput v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 305
    .line 306
    goto :goto_5

    .line 307
    :goto_4
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 308
    .line 309
    .line 310
    iput v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 311
    .line 312
    :goto_5
    return-void
.end method

.method private readErrorResponse(Ljava/net/HttpURLConnection;)Ljava/lang/String;
    .locals 3

    .line 1
    :try_start_0
    new-instance v0, Ljava/io/BufferedReader;

    .line 2
    .line 3
    new-instance v1, Ljava/io/InputStreamReader;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    if-eqz v2, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/net/HttpURLConnection;->getErrorStream()Ljava/io/InputStream;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    goto :goto_0

    .line 16
    :catch_0
    move-exception p1

    .line 17
    goto :goto_2

    .line 18
    :cond_0
    invoke-virtual {p1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    :goto_0
    invoke-direct {v1, p1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 23
    .line 24
    .line 25
    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 26
    .line 27
    .line 28
    new-instance p1, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 31
    .line 32
    .line 33
    :goto_1
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    if-eqz v1, :cond_1

    .line 38
    .line 39
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 50
    return-object p1

    .line 51
    :goto_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    const-string p1, ""

    .line 55
    .line 56
    return-object p1
.end method

.method private sendPlayRequestWithPlistXml(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 11

    .line 1
    const-string v0, "X-Apple-Session-ID"

    .line 2
    .line 3
    const-string v1, "User-Agent"

    .line 4
    .line 5
    const-string v2, "Content-Type"

    .line 6
    .line 7
    const-string v3, "</string>\n</dict>\n</plist>"

    .line 8
    .line 9
    const-string v4, "</string>\n  <key>Start-Position</key>\n  <real>0</real>\n  <key>uuid</key>\n  <string>"

    .line 10
    .line 11
    const-string v5, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\">\n<dict>\n  <key>Content-Location</key>\n  <string>"

    .line 12
    .line 13
    const-string v6, "http://"

    .line 14
    .line 15
    const/4 v7, 0x0

    .line 16
    :try_start_0
    new-instance v8, Ljava/lang/StringBuilder;

    .line 17
    .line 18
    invoke-direct {v8, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 19
    .line 20
    .line 21
    iget-object v6, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 22
    .line 23
    invoke-virtual {v6}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 24
    .line 25
    .line 26
    move-result-object v6

    .line 27
    invoke-virtual {v6}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v6

    .line 31
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string v6, ":"

    .line 35
    .line 36
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    iget-object v6, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 40
    .line 41
    invoke-virtual {v6}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 42
    .line 43
    .line 44
    move-result v6

    .line 45
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    const-string v6, "/play"

    .line 49
    .line 50
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v6

    .line 57
    new-instance v8, Ljava/net/URL;

    .line 58
    .line 59
    invoke-direct {v8, v6}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {v8}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 63
    .line 64
    .line 65
    move-result-object v6

    .line 66
    check-cast v6, Ljava/net/HttpURLConnection;

    .line 67
    .line 68
    const-string v8, "POST"

    .line 69
    .line 70
    invoke-virtual {v6, v8}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 71
    .line 72
    .line 73
    const-string v8, "application/x-apple-binary-plist"

    .line 74
    .line 75
    invoke-virtual {v6, v2, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    iget-object v8, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 79
    .line 80
    if-eqz v8, :cond_0

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_0
    const-string v8, "AirPlay/845.6.1"

    .line 84
    .line 85
    :goto_0
    invoke-virtual {v6, v1, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 86
    .line 87
    .line 88
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->generateSessionId()Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v8

    .line 92
    iput-object v8, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {v6, v0, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    const-string v8, "X-Apple-Device-ID"

    .line 98
    .line 99
    const-string v9, "0xa64e4f3f6c42"

    .line 100
    .line 101
    invoke-virtual {v6, v8, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    const-string v8, "X-Apple-Client-Name"

    .line 105
    .line 106
    const-string v9, "iPhone"

    .line 107
    .line 108
    const-string v10, "UTF-8"

    .line 109
    .line 110
    invoke-static {v9, v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v9

    .line 114
    invoke-virtual {v6, v8, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    const-string v8, "X-Transmit-Date"

    .line 118
    .line 119
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->getFormattedTransmitDate()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v9

    .line 123
    invoke-virtual {v6, v8, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    const-string v8, "Connection"

    .line 127
    .line 128
    const-string v9, "keep-alive"

    .line 129
    .line 130
    invoke-virtual {v6, v8, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    const/16 v8, 0x2ee0

    .line 134
    .line 135
    invoke-virtual {v6, v8}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v6, v8}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 139
    .line 140
    .line 141
    const/4 v8, 0x1

    .line 142
    invoke-virtual {v6, v8}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 143
    .line 144
    .line 145
    new-instance v9, Ljava/lang/StringBuilder;

    .line 146
    .line 147
    invoke-direct {v9, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    invoke-direct {p0, p1}, Linfo/t4w/vp/airplay/AirPlayClient;->escapeXml(Ljava/lang/String;)Ljava/lang/String;

    .line 151
    .line 152
    .line 153
    move-result-object v5

    .line 154
    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 158
    .line 159
    .line 160
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 161
    .line 162
    .line 163
    move-result-object v4

    .line 164
    invoke-virtual {v4}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v4

    .line 168
    sget-object v5, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 169
    .line 170
    invoke-virtual {v4, v5}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v4

    .line 174
    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    invoke-virtual {v9, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v3

    .line 184
    invoke-virtual {v6, v2}, Ljava/net/URLConnection;->getRequestProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    invoke-virtual {v6, v1}, Ljava/net/URLConnection;->getRequestProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    invoke-virtual {v6, v0}, Ljava/net/URLConnection;->getRequestProperty(Ljava/lang/String;)Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    sget-object v0, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 194
    .line 195
    invoke-virtual {v3, v0}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    const-string v1, "Content-Length"

    .line 200
    .line 201
    array-length v2, v0

    .line 202
    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v2

    .line 206
    invoke-virtual {v6, v1, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    new-instance v1, Ljava/io/DataOutputStream;

    .line 210
    .line 211
    invoke-virtual {v6}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 212
    .line 213
    .line 214
    move-result-object v2

    .line 215
    invoke-direct {v1, v2}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write([B)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v1}, Ljava/io/OutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 225
    .line 226
    .line 227
    const-wide/16 v0, 0x64

    .line 228
    .line 229
    :try_start_1
    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 230
    .line 231
    .line 232
    goto :goto_1

    .line 233
    :catch_0
    move-exception v0

    .line 234
    goto :goto_2

    .line 235
    :catch_1
    :goto_1
    :try_start_2
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 236
    .line 237
    .line 238
    move-result v0

    .line 239
    invoke-virtual {v6}, Ljava/net/HttpURLConnection;->getResponseMessage()Ljava/lang/String;

    .line 240
    .line 241
    .line 242
    const/16 v1, 0xc8

    .line 243
    .line 244
    if-eq v0, v1, :cond_3

    .line 245
    .line 246
    invoke-direct {p0, v6}, Linfo/t4w/vp/airplay/AirPlayClient;->readErrorResponse(Ljava/net/HttpURLConnection;)Ljava/lang/String;

    .line 247
    .line 248
    .line 249
    move-result-object v2

    .line 250
    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    .line 251
    .line 252
    .line 253
    move-result v2

    .line 254
    if-nez v2, :cond_1

    .line 255
    .line 256
    invoke-virtual {v6}, Ljava/net/URLConnection;->getHeaderFields()Ljava/util/Map;

    .line 257
    .line 258
    .line 259
    move-result-object v2

    .line 260
    invoke-static {v2}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    :cond_1
    const/16 v2, 0x190

    .line 264
    .line 265
    if-eq v0, v2, :cond_2

    .line 266
    .line 267
    const/16 v2, 0x19f

    .line 268
    .line 269
    if-ne v0, v2, :cond_3

    .line 270
    .line 271
    :cond_2
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryAlternatePlaybackFormats(Ljava/lang/String;Ljava/lang/String;)Z

    .line 272
    .line 273
    .line 274
    move-result p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 275
    return p1

    .line 276
    :cond_3
    if-ne v0, v1, :cond_4

    .line 277
    .line 278
    return v8

    .line 279
    :cond_4
    return v7

    .line 280
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 281
    .line 282
    .line 283
    iget v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 284
    .line 285
    const/4 v1, 0x2

    .line 286
    if-ge v0, v1, :cond_5

    .line 287
    .line 288
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryAlternatePlaybackFormats(Ljava/lang/String;Ljava/lang/String;)Z

    .line 289
    .line 290
    .line 291
    move-result p1

    .line 292
    return p1

    .line 293
    :cond_5
    return v7
.end method

.method private sendScrubRequest(D)Z
    .locals 6

    .line 1
    const-string v0, "position="

    .line 2
    .line 3
    const-string v1, "http://"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    :try_start_0
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 7
    .line 8
    if-nez v3, :cond_0

    .line 9
    .line 10
    return v2

    .line 11
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 17
    .line 18
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const-string v1, ":"

    .line 30
    .line 31
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 35
    .line 36
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, "/scrub"

    .line 44
    .line 45
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    new-instance v3, Ljava/net/URL;

    .line 53
    .line 54
    invoke-direct {v3, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Ljava/net/HttpURLConnection;

    .line 62
    .line 63
    const-string v3, "POST"

    .line 64
    .line 65
    invoke-virtual {v1, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const-string v3, "Content-Type"

    .line 69
    .line 70
    const-string v4, "text/parameters"

    .line 71
    .line 72
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    const-string v3, "User-Agent"

    .line 76
    .line 77
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 78
    .line 79
    if-eqz v4, :cond_1

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_1
    const-string v4, "AirPlay/420.10"

    .line 83
    .line 84
    :goto_0
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    const-string v3, "X-Apple-Session-ID"

    .line 88
    .line 89
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 90
    .line 91
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    const-string v3, "Connection"

    .line 95
    .line 96
    const-string v4, "keep-alive"

    .line 97
    .line 98
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    const/4 v3, 0x1

    .line 102
    invoke-virtual {v1, v3}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 103
    .line 104
    .line 105
    new-instance v4, Ljava/io/DataOutputStream;

    .line 106
    .line 107
    invoke-virtual {v1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    invoke-direct {v4, v5}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 112
    .line 113
    .line 114
    new-instance v5, Ljava/lang/StringBuilder;

    .line 115
    .line 116
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v5, p1, p2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-virtual {v4, p1}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 133
    .line 134
    .line 135
    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 136
    const/16 p2, 0xc8

    .line 137
    .line 138
    if-ne p1, p2, :cond_2

    .line 139
    .line 140
    return v3

    .line 141
    :cond_2
    return v2

    .line 142
    :catch_0
    move-exception p1

    .line 143
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    return v2
.end method

.method private sendStopRequest()Z
    .locals 5

    .line 1
    const-string v0, "http://"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_0
    new-instance v2, Ljava/lang/StringBuilder;

    .line 5
    .line 6
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 10
    .line 11
    invoke-virtual {v0}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    const-string v0, ":"

    .line 23
    .line 24
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 28
    .line 29
    invoke-virtual {v0}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    const-string v0, "/stop"

    .line 37
    .line 38
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    new-instance v2, Ljava/net/URL;

    .line 46
    .line 47
    invoke-direct {v2, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v2}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 51
    .line 52
    .line 53
    move-result-object v0

    .line 54
    check-cast v0, Ljava/net/HttpURLConnection;

    .line 55
    .line 56
    const-string v2, "POST"

    .line 57
    .line 58
    invoke-virtual {v0, v2}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    const-string v2, "Content-Type"

    .line 62
    .line 63
    const-string v3, "text/parameters"

    .line 64
    .line 65
    invoke-virtual {v0, v2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const-string v2, "User-Agent"

    .line 69
    .line 70
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 71
    .line 72
    if-eqz v3, :cond_0

    .line 73
    .line 74
    goto :goto_0

    .line 75
    :cond_0
    const-string v3, "AirPlay/420.10"

    .line 76
    .line 77
    :goto_0
    invoke-virtual {v0, v2, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 78
    .line 79
    .line 80
    iget-object v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 81
    .line 82
    if-eqz v2, :cond_1

    .line 83
    .line 84
    const-string v3, "X-Apple-Session-ID"

    .line 85
    .line 86
    invoke-virtual {v0, v3, v2}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :catch_0
    move-exception v0

    .line 91
    goto :goto_2

    .line 92
    :cond_1
    :goto_1
    const/4 v2, 0x1

    .line 93
    invoke-virtual {v0, v2}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 94
    .line 95
    .line 96
    new-instance v3, Ljava/io/DataOutputStream;

    .line 97
    .line 98
    invoke-virtual {v0}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 99
    .line 100
    .line 101
    move-result-object v4

    .line 102
    invoke-direct {v3, v4}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v3}, Ljava/io/DataOutputStream;->flush()V

    .line 106
    .line 107
    .line 108
    invoke-virtual {v3}, Ljava/io/OutputStream;->close()V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 112
    .line 113
    .line 114
    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 115
    const/16 v3, 0xc8

    .line 116
    .line 117
    if-ne v0, v3, :cond_2

    .line 118
    .line 119
    return v2

    .line 120
    :cond_2
    return v1

    .line 121
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    return v1
.end method

.method private tryAlternatePlaybackFormats(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 11

    .line 1
    const/4 v0, 0x0

    .line 2
    :try_start_0
    iget v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 3
    .line 4
    const/4 v2, 0x2

    .line 5
    if-lt v1, v2, :cond_0

    .line 6
    .line 7
    return v0

    .line 8
    :cond_0
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->stopPlayback()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    .line 12
    .line 13
    const-wide/16 v3, 0x12c

    .line 14
    .line 15
    :try_start_1
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 16
    .line 17
    .line 18
    goto :goto_0

    .line 19
    :catch_0
    move-exception p1

    .line 20
    goto/16 :goto_1

    .line 21
    .line 22
    :catch_1
    :goto_0
    :try_start_2
    iget v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 23
    .line 24
    const/4 v6, 0x1

    .line 25
    add-int/2addr v5, v6

    .line 26
    iput v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 27
    .line 28
    iget v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 29
    .line 30
    const/16 v7, 0x320

    .line 31
    .line 32
    const/4 v8, 0x4

    .line 33
    const/16 v9, 0x1f4

    .line 34
    .line 35
    const/4 v10, 0x3

    .line 36
    if-ne v5, v6, :cond_2

    .line 37
    .line 38
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryTextParametersFormat(Ljava/lang/String;Ljava/lang/String;)Z

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    if-eqz v5, :cond_1

    .line 43
    .line 44
    invoke-direct {p0, v10, v9}, Linfo/t4w/vp/airplay/AirPlayClient;->verifyPlaybackWithRetries(II)Z

    .line 45
    .line 46
    .line 47
    move-result v5

    .line 48
    if-eqz v5, :cond_1

    .line 49
    .line 50
    return v6

    .line 51
    :cond_1
    iget v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 52
    .line 53
    if-ge v5, v2, :cond_4

    .line 54
    .line 55
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->stopPlayback()Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 56
    .line 57
    .line 58
    :try_start_3
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 59
    .line 60
    .line 61
    :catch_2
    :try_start_4
    iget v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 62
    .line 63
    add-int/2addr v2, v6

    .line 64
    iput v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 65
    .line 66
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryJsonFormat(Ljava/lang/String;Ljava/lang/String;)Z

    .line 67
    .line 68
    .line 69
    move-result p1

    .line 70
    if-eqz p1, :cond_4

    .line 71
    .line 72
    invoke-direct {p0, v8, v7}, Linfo/t4w/vp/airplay/AirPlayClient;->verifyPlaybackWithRetries(II)Z

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    if-eqz p1, :cond_4

    .line 77
    .line 78
    return v6

    .line 79
    :cond_2
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryJsonFormat(Ljava/lang/String;Ljava/lang/String;)Z

    .line 80
    .line 81
    .line 82
    move-result v5

    .line 83
    if-eqz v5, :cond_3

    .line 84
    .line 85
    invoke-direct {p0, v8, v7}, Linfo/t4w/vp/airplay/AirPlayClient;->verifyPlaybackWithRetries(II)Z

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    if-eqz v5, :cond_3

    .line 90
    .line 91
    return v6

    .line 92
    :cond_3
    iget v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 93
    .line 94
    if-ge v5, v2, :cond_4

    .line 95
    .line 96
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->stopPlayback()Z
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 97
    .line 98
    .line 99
    :try_start_5
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_3
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    .line 100
    .line 101
    .line 102
    :catch_3
    :try_start_6
    iget v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 103
    .line 104
    add-int/2addr v2, v6

    .line 105
    iput v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 106
    .line 107
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryTextParametersFormat(Ljava/lang/String;Ljava/lang/String;)Z

    .line 108
    .line 109
    .line 110
    move-result p1

    .line 111
    if-eqz p1, :cond_4

    .line 112
    .line 113
    invoke-direct {p0, v10, v9}, Linfo/t4w/vp/airplay/AirPlayClient;->verifyPlaybackWithRetries(II)Z

    .line 114
    .line 115
    .line 116
    move-result p1

    .line 117
    if-eqz p1, :cond_4

    .line 118
    .line 119
    return v6

    .line 120
    :cond_4
    if-eqz v1, :cond_5

    .line 121
    .line 122
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 123
    .line 124
    const/high16 p1, 0x3f800000    # 1.0f

    .line 125
    .line 126
    invoke-direct {p0, p1}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 127
    .line 128
    .line 129
    const-wide/16 p1, 0x320

    .line 130
    .line 131
    :try_start_7
    invoke-static {p1, p2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_7
    .catch Ljava/lang/InterruptedException; {:try_start_7 .. :try_end_7} :catch_4
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    .line 132
    .line 133
    .line 134
    :catch_4
    :try_start_8
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->getPlaybackStatus()Z

    .line 135
    .line 136
    .line 137
    move-result p1
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 138
    if-eqz p1, :cond_5

    .line 139
    .line 140
    return v6

    .line 141
    :cond_5
    return v0

    .line 142
    :goto_1
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    return v0
.end method

.method private tryJsonFormat(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    .line 1
    const-string p2, "\",\"Start-Position\": 0,\"Rate\": 1.0,\"Asset-Action\": \"play\"}"

    .line 2
    .line 3
    const-string v0, "{\"Content-Location\": \""

    .line 4
    .line 5
    const-string v1, "http://"

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    :try_start_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 14
    .line 15
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    const-string v1, ":"

    .line 27
    .line 28
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 32
    .line 33
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v1, "/play"

    .line 41
    .line 42
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    new-instance v3, Ljava/net/URL;

    .line 50
    .line 51
    invoke-direct {v3, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    check-cast v1, Ljava/net/HttpURLConnection;

    .line 59
    .line 60
    const-string v3, "POST"

    .line 61
    .line 62
    invoke-virtual {v1, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    const-string v3, "Content-Type"

    .line 66
    .line 67
    const-string v4, "application/json"

    .line 68
    .line 69
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    const-string v3, "User-Agent"

    .line 73
    .line 74
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 75
    .line 76
    if-eqz v4, :cond_0

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_0
    const-string v4, "AirPlay/420.10"

    .line 80
    .line 81
    :goto_0
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->generateSessionId()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    iput-object v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 89
    .line 90
    const-string v4, "X-Apple-AssetAction"

    .line 91
    .line 92
    const-string v5, "play"

    .line 93
    .line 94
    invoke-virtual {v1, v4, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    const-string v4, "X-Apple-Session-ID"

    .line 98
    .line 99
    invoke-virtual {v1, v4, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    const-string v3, "X-Apple-Device-ID"

    .line 103
    .line 104
    const-string v4, "0x1234ABCD"

    .line 105
    .line 106
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    const-string v3, "X-Apple-Client-Name"

    .line 110
    .line 111
    const-string v4, "Android AirPlay Client"

    .line 112
    .line 113
    const-string v5, "UTF-8"

    .line 114
    .line 115
    invoke-static {v4, v5}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    const-string v3, "Connection"

    .line 123
    .line 124
    const-string v4, "keep-alive"

    .line 125
    .line 126
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    const/4 v3, 0x1

    .line 130
    invoke-virtual {v1, v3}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 131
    .line 132
    .line 133
    new-instance v4, Ljava/lang/StringBuilder;

    .line 134
    .line 135
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 142
    .line 143
    .line 144
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 149
    .line 150
    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    const-string p2, "Content-Length"

    .line 155
    .line 156
    array-length v0, p1

    .line 157
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    invoke-virtual {v1, p2, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    new-instance p2, Ljava/io/DataOutputStream;

    .line 165
    .line 166
    invoke-virtual {v1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-direct {p2, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {p2, p1}, Ljava/io/OutputStream;->write([B)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {p2}, Ljava/io/DataOutputStream;->flush()V

    .line 177
    .line 178
    .line 179
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 180
    .line 181
    .line 182
    const-wide/16 p1, 0x64

    .line 183
    .line 184
    :try_start_1
    invoke-static {p1, p2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 185
    .line 186
    .line 187
    goto :goto_1

    .line 188
    :catch_0
    move-exception p1

    .line 189
    goto :goto_2

    .line 190
    :catch_1
    :goto_1
    :try_start_2
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 191
    .line 192
    .line 193
    move-result p1

    .line 194
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseMessage()Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    const/16 p2, 0xc8

    .line 198
    .line 199
    if-eq p1, p2, :cond_1

    .line 200
    .line 201
    invoke-direct {p0, v1}, Linfo/t4w/vp/airplay/AirPlayClient;->readErrorResponse(Ljava/net/HttpURLConnection;)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 206
    .line 207
    .line 208
    :cond_1
    if-ne p1, p2, :cond_2

    .line 209
    .line 210
    const/4 v2, 0x1

    .line 211
    :cond_2
    return v2

    .line 212
    :goto_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 213
    .line 214
    .line 215
    return v2
.end method

.method private trySetPlaybackRate(F)Z
    .locals 6

    .line 1
    const-string v0, "value="

    .line 2
    .line 3
    const-string v1, "http://"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    :try_start_0
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 7
    .line 8
    if-nez v3, :cond_0

    .line 9
    .line 10
    return v2

    .line 11
    :cond_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 14
    .line 15
    .line 16
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 17
    .line 18
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 27
    .line 28
    .line 29
    const-string v1, ":"

    .line 30
    .line 31
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 35
    .line 36
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, "/rate"

    .line 44
    .line 45
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    new-instance v3, Ljava/net/URL;

    .line 53
    .line 54
    invoke-direct {v3, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Ljava/net/HttpURLConnection;

    .line 62
    .line 63
    const-string v3, "POST"

    .line 64
    .line 65
    invoke-virtual {v1, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const-string v3, "Content-Type"

    .line 69
    .line 70
    const-string v4, "text/parameters"

    .line 71
    .line 72
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    const-string v3, "User-Agent"

    .line 76
    .line 77
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 78
    .line 79
    if-eqz v4, :cond_1

    .line 80
    .line 81
    goto :goto_0

    .line 82
    :cond_1
    const-string v4, "AirPlay/420.10"

    .line 83
    .line 84
    :goto_0
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    const-string v3, "X-Apple-Session-ID"

    .line 88
    .line 89
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 90
    .line 91
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    const-string v3, "Connection"

    .line 95
    .line 96
    const-string v4, "keep-alive"

    .line 97
    .line 98
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    const/4 v3, 0x1

    .line 102
    invoke-virtual {v1, v3}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 103
    .line 104
    .line 105
    new-instance v4, Ljava/io/DataOutputStream;

    .line 106
    .line 107
    invoke-virtual {v1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 108
    .line 109
    .line 110
    move-result-object v5

    .line 111
    invoke-direct {v4, v5}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 112
    .line 113
    .line 114
    new-instance v5, Ljava/lang/StringBuilder;

    .line 115
    .line 116
    invoke-direct {v5, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-virtual {v4, p1}, Ljava/io/DataOutputStream;->writeBytes(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 133
    .line 134
    .line 135
    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 136
    const/16 v0, 0xc8

    .line 137
    .line 138
    if-ne p1, v0, :cond_2

    .line 139
    .line 140
    return v3

    .line 141
    :cond_2
    return v2

    .line 142
    :catch_0
    move-exception p1

    .line 143
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    return v2
.end method

.method private tryTextParametersFormat(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    .line 1
    const-string p2, "\r\nStart-Position: 0\r\nPlayback-Info: 1.0\r\nAsset-Action: play\r\nRate: 1.0\r\n"

    .line 2
    .line 3
    const-string v0, "Content-Location: "

    .line 4
    .line 5
    const-string v1, "http://"

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    :try_start_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 14
    .line 15
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 24
    .line 25
    .line 26
    const-string v1, ":"

    .line 27
    .line 28
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 32
    .line 33
    invoke-virtual {v1}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 34
    .line 35
    .line 36
    move-result v1

    .line 37
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string v1, "/play"

    .line 41
    .line 42
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    new-instance v3, Ljava/net/URL;

    .line 50
    .line 51
    invoke-direct {v3, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    check-cast v1, Ljava/net/HttpURLConnection;

    .line 59
    .line 60
    const-string v3, "POST"

    .line 61
    .line 62
    invoke-virtual {v1, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    const-string v3, "Content-Type"

    .line 66
    .line 67
    const-string v4, "text/parameters"

    .line 68
    .line 69
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    const-string v3, "User-Agent"

    .line 73
    .line 74
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 75
    .line 76
    if-eqz v4, :cond_0

    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_0
    const-string v4, "AppleTV/10.1"

    .line 80
    .line 81
    :goto_0
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->generateSessionId()Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    iput-object v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 89
    .line 90
    const-string v4, "X-Apple-Session-ID"

    .line 91
    .line 92
    invoke-virtual {v1, v4, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 93
    .line 94
    .line 95
    const-string v3, "X-Apple-Device-ID"

    .line 96
    .line 97
    const-string v4, "0x1234ABCD"

    .line 98
    .line 99
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 100
    .line 101
    .line 102
    const-string v3, "X-Apple-Client-Name"

    .line 103
    .line 104
    const-string v4, "Android AirPlay Client"

    .line 105
    .line 106
    const-string v5, "UTF-8"

    .line 107
    .line 108
    invoke-static {v4, v5}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    invoke-virtual {v1, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    const/16 v3, 0x2710

    .line 116
    .line 117
    invoke-virtual {v1, v3}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v1, v3}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 121
    .line 122
    .line 123
    const/4 v3, 0x1

    .line 124
    invoke-virtual {v1, v3}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 125
    .line 126
    .line 127
    new-instance v4, Ljava/lang/StringBuilder;

    .line 128
    .line 129
    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 133
    .line 134
    .line 135
    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 136
    .line 137
    .line 138
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object p1

    .line 142
    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 143
    .line 144
    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    .line 145
    .line 146
    .line 147
    move-result-object p1

    .line 148
    const-string p2, "Content-Length"

    .line 149
    .line 150
    array-length v0, p1

    .line 151
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    invoke-virtual {v1, p2, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    new-instance p2, Ljava/io/DataOutputStream;

    .line 159
    .line 160
    invoke-virtual {v1}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 161
    .line 162
    .line 163
    move-result-object v0

    .line 164
    invoke-direct {p2, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 165
    .line 166
    .line 167
    invoke-virtual {p2, p1}, Ljava/io/OutputStream;->write([B)V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p2}, Ljava/io/DataOutputStream;->flush()V

    .line 171
    .line 172
    .line 173
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 174
    .line 175
    .line 176
    const-wide/16 p1, 0x64

    .line 177
    .line 178
    :try_start_1
    invoke-static {p1, p2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 179
    .line 180
    .line 181
    goto :goto_1

    .line 182
    :catch_0
    move-exception p1

    .line 183
    goto :goto_2

    .line 184
    :catch_1
    :goto_1
    :try_start_2
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 185
    .line 186
    .line 187
    move-result p1

    .line 188
    invoke-virtual {v1}, Ljava/net/HttpURLConnection;->getResponseMessage()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    const/16 p2, 0xc8

    .line 192
    .line 193
    if-eq p1, p2, :cond_1

    .line 194
    .line 195
    invoke-direct {p0, v1}, Linfo/t4w/vp/airplay/AirPlayClient;->readErrorResponse(Ljava/net/HttpURLConnection;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 200
    .line 201
    .line 202
    :cond_1
    if-ne p1, p2, :cond_2

    .line 203
    .line 204
    const/4 v2, 0x1

    .line 205
    :cond_2
    return v2

    .line 206
    :goto_2
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    return v2
.end method

.method private verifyPlaybackWithRetries(II)Z
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x0

    .line 3
    :goto_0
    if-ge v1, p1, :cond_3

    .line 4
    .line 5
    mul-int/lit16 v2, v1, 0x12c

    .line 6
    .line 7
    add-int/2addr v2, p2

    .line 8
    int-to-long v2, v2

    .line 9
    :try_start_0
    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    .line 10
    .line 11
    .line 12
    goto :goto_1

    .line 13
    :catch_0
    nop

    .line 14
    :goto_1
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->getPlaybackStatus()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    const/4 v3, 0x1

    .line 19
    if-eqz v2, :cond_0

    .line 20
    .line 21
    return v3

    .line 22
    :cond_0
    if-ne v1, v3, :cond_1

    .line 23
    .line 24
    const/high16 v2, 0x3f800000    # 1.0f

    .line 25
    .line 26
    invoke-direct {p0, v2}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z

    .line 27
    .line 28
    .line 29
    goto :goto_2

    .line 30
    :cond_1
    const/4 v2, 0x2

    .line 31
    if-ne v1, v2, :cond_2

    .line 32
    .line 33
    const-wide/16 v2, 0x0

    .line 34
    .line 35
    invoke-direct {p0, v2, v3}, Linfo/t4w/vp/airplay/AirPlayClient;->sendScrubRequest(D)Z

    .line 36
    .line 37
    .line 38
    :cond_2
    :goto_2
    add-int/lit8 v1, v1, 0x1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_3
    return v0
.end method


# virtual methods
.method public checkDeviceStatus()Z
    .locals 13

    .line 1
    const-string v0, "keep-alive"

    .line 2
    .line 3
    const-string v1, "Connection"

    .line 4
    .line 5
    const-string v2, "User-Agent"

    .line 6
    .line 7
    const-string v3, "GET"

    .line 8
    .line 9
    const-string v4, "http://"

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    :try_start_0
    new-instance v6, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    invoke-direct {v6, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 18
    .line 19
    invoke-virtual {v4}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    invoke-virtual {v4}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    const-string v4, ":"

    .line 31
    .line 32
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 36
    .line 37
    invoke-virtual {v4}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 38
    .line 39
    .line 40
    move-result v4

    .line 41
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    const-string v4, "/server-info"

    .line 45
    .line 46
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 47
    .line 48
    .line 49
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    new-instance v6, Ljava/net/URL;

    .line 54
    .line 55
    invoke-direct {v6, v4}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v6}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 59
    .line 60
    .line 61
    move-result-object v4

    .line 62
    check-cast v4, Ljava/net/HttpURLConnection;

    .line 63
    .line 64
    invoke-virtual {v4, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 65
    .line 66
    .line 67
    iget-object v7, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 68
    .line 69
    if-eqz v7, :cond_0

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_0
    const-string v7, "AirPlay/420.10"

    .line 73
    .line 74
    :goto_0
    const-string v8, "AppleTV/105.1"

    .line 75
    .line 76
    const-string v9, "MediaControl/1.0"

    .line 77
    .line 78
    filled-new-array {v7, v8, v9}, [Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v7

    .line 82
    aget-object v8, v7, v5

    .line 83
    .line 84
    invoke-virtual {v4, v2, v8}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v4, v1, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    const-string v8, "X-Apple-Device-ID"

    .line 91
    .line 92
    const-string v9, "0x1234ABCD"

    .line 93
    .line 94
    invoke-virtual {v4, v8, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    const-string v8, "X-Apple-Client-Name"

    .line 98
    .line 99
    const-string v9, "Android AirPlay Client"

    .line 100
    .line 101
    const-string v10, "UTF-8"

    .line 102
    .line 103
    invoke-static {v9, v10}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    .line 105
    .line 106
    move-result-object v9

    .line 107
    invoke-virtual {v4, v8, v9}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    const/16 v8, 0x3a98

    .line 111
    .line 112
    invoke-virtual {v4, v8}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v4, v8}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v4}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 119
    .line 120
    .line 121
    move-result v8

    .line 122
    const/16 v9, 0xc8

    .line 123
    .line 124
    const/4 v10, 0x1

    .line 125
    if-ne v8, v9, :cond_3

    .line 126
    .line 127
    new-instance v0, Ljava/io/BufferedReader;

    .line 128
    .line 129
    new-instance v1, Ljava/io/InputStreamReader;

    .line 130
    .line 131
    invoke-virtual {v4}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 132
    .line 133
    .line 134
    move-result-object v2

    .line 135
    invoke-direct {v1, v2}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 136
    .line 137
    .line 138
    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 139
    .line 140
    .line 141
    new-instance v1, Ljava/lang/StringBuilder;

    .line 142
    .line 143
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 144
    .line 145
    .line 146
    :goto_1
    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v2

    .line 150
    if-eqz v2, :cond_1

    .line 151
    .line 152
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    goto :goto_1

    .line 156
    :catch_0
    move-exception v0

    .line 157
    goto/16 :goto_5

    .line 158
    .line 159
    :cond_1
    invoke-virtual {v0}, Ljava/io/BufferedReader;->close()V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    invoke-direct {p0, v0}, Linfo/t4w/vp/airplay/AirPlayClient;->parseDeviceCapabilities(Ljava/lang/String;)V

    .line 167
    .line 168
    .line 169
    const-string v1, "model"

    .line 170
    .line 171
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    if-nez v1, :cond_2

    .line 176
    .line 177
    const-string v1, "deviceid"

    .line 178
    .line 179
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 180
    .line 181
    .line 182
    move-result v1

    .line 183
    if-nez v1, :cond_2

    .line 184
    .line 185
    const-string v1, "features"

    .line 186
    .line 187
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 188
    .line 189
    .line 190
    move-result v1

    .line 191
    if-nez v1, :cond_2

    .line 192
    .line 193
    const-string v1, "macaddress"

    .line 194
    .line 195
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 196
    .line 197
    .line 198
    move-result v1

    .line 199
    if-nez v1, :cond_2

    .line 200
    .line 201
    const-string v1, "protovers"

    .line 202
    .line 203
    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 204
    .line 205
    .line 206
    :cond_2
    return v10

    .line 207
    :cond_3
    const/16 v4, 0x191

    .line 208
    .line 209
    if-ne v8, v4, :cond_4

    .line 210
    .line 211
    const/4 v0, 0x2

    .line 212
    iput v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 213
    .line 214
    return v10

    .line 215
    :cond_4
    const/16 v4, 0x190

    .line 216
    .line 217
    const/16 v11, 0x1f4

    .line 218
    .line 219
    if-lt v8, v4, :cond_8

    .line 220
    .line 221
    if-ge v8, v11, :cond_8

    .line 222
    .line 223
    const/4 v4, 0x1

    .line 224
    :goto_2
    const/4 v8, 0x3

    .line 225
    if-ge v4, v8, :cond_7

    .line 226
    .line 227
    :try_start_1
    aget-object v8, v7, v4

    .line 228
    .line 229
    invoke-virtual {v6}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 230
    .line 231
    .line 232
    move-result-object v8

    .line 233
    check-cast v8, Ljava/net/HttpURLConnection;

    .line 234
    .line 235
    invoke-virtual {v8, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    aget-object v11, v7, v4

    .line 239
    .line 240
    invoke-virtual {v8, v2, v11}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v8, v1, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    const/16 v11, 0x2710

    .line 247
    .line 248
    invoke-virtual {v8, v11}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    .line 249
    .line 250
    .line 251
    invoke-virtual {v8, v11}, Ljava/net/URLConnection;->setReadTimeout(I)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v8}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 255
    .line 256
    .line 257
    move-result v11

    .line 258
    if-ne v11, v9, :cond_6

    .line 259
    .line 260
    new-instance v11, Ljava/io/BufferedReader;

    .line 261
    .line 262
    new-instance v12, Ljava/io/InputStreamReader;

    .line 263
    .line 264
    invoke-virtual {v8}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    .line 265
    .line 266
    .line 267
    move-result-object v8

    .line 268
    invoke-direct {v12, v8}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    .line 269
    .line 270
    .line 271
    invoke-direct {v11, v12}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    .line 272
    .line 273
    .line 274
    new-instance v8, Ljava/lang/StringBuilder;

    .line 275
    .line 276
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 277
    .line 278
    .line 279
    :goto_3
    invoke-virtual {v11}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    move-result-object v12

    .line 283
    if-eqz v12, :cond_5

    .line 284
    .line 285
    invoke-virtual {v8, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 286
    .line 287
    .line 288
    goto :goto_3

    .line 289
    :catch_1
    move-exception v8

    .line 290
    goto :goto_4

    .line 291
    :cond_5
    invoke-virtual {v11}, Ljava/io/BufferedReader;->close()V

    .line 292
    .line 293
    .line 294
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 295
    .line 296
    .line 297
    move-result-object v8

    .line 298
    invoke-direct {p0, v8}, Linfo/t4w/vp/airplay/AirPlayClient;->parseDeviceCapabilities(Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 299
    .line 300
    .line 301
    return v10

    .line 302
    :goto_4
    :try_start_2
    invoke-virtual {v8}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 303
    .line 304
    .line 305
    :cond_6
    add-int/lit8 v4, v4, 0x1

    .line 306
    .line 307
    goto :goto_2

    .line 308
    :cond_7
    iput v10, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 309
    .line 310
    return v10

    .line 311
    :cond_8
    if-lt v8, v11, :cond_9

    .line 312
    .line 313
    iput v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 314
    .line 315
    return v10

    .line 316
    :cond_9
    return v5

    .line 317
    :goto_5
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 318
    .line 319
    .line 320
    return v5
.end method

.method public getPlaybackStatus()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Linfo/t4w/vp/airplay/AirPlayClient;->getPlaybackStatusWithRetry(I)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public pausePlayback()Z
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, v0}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z

    .line 3
    .line 4
    .line 5
    move-result v0

    .line 6
    return v0
.end method

.method public playVideo(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_d

    .line 3
    .line 4
    :try_start_0
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    goto/16 :goto_6

    .line 11
    .line 12
    :cond_0
    iput v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    iput-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->checkDeviceStatus()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_1

    .line 22
    .line 23
    return v0

    .line 24
    :cond_1
    iget-object v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 25
    .line 26
    if-eqz v1, :cond_2

    .line 27
    .line 28
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->stopPlayback()Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 29
    .line 30
    .line 31
    const-wide/16 v1, 0x12c

    .line 32
    .line 33
    :try_start_1
    invoke-static {v1, v2}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :catch_0
    move-exception p1

    .line 38
    goto/16 :goto_5

    .line 39
    .line 40
    :catch_1
    :cond_2
    :goto_0
    :try_start_2
    iget v1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->detectedAirPlayVersion:I

    .line 41
    .line 42
    const/4 v2, 0x2

    .line 43
    const/4 v3, 0x1

    .line 44
    if-ne v1, v2, :cond_3

    .line 45
    .line 46
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->sendPlayRequestWithPlistXml(Ljava/lang/String;Ljava/lang/String;)Z

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    goto :goto_1

    .line 51
    :cond_3
    if-ne v1, v3, :cond_4

    .line 52
    .line 53
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryTextParametersFormat(Ljava/lang/String;Ljava/lang/String;)Z

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    goto :goto_1

    .line 58
    :cond_4
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->sendPlayRequestWithPlistXml(Ljava/lang/String;Ljava/lang/String;)Z

    .line 59
    .line 60
    .line 61
    move-result v1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 62
    :goto_1
    if-eqz v1, :cond_a

    .line 63
    .line 64
    const/4 v1, 0x0

    .line 65
    :goto_2
    const/16 v4, 0x8

    .line 66
    .line 67
    if-ge v1, v4, :cond_9

    .line 68
    .line 69
    mul-int/lit16 v4, v1, 0x258

    .line 70
    .line 71
    add-int/lit16 v4, v4, 0x258

    .line 72
    .line 73
    int-to-long v4, v4

    .line 74
    :try_start_3
    invoke-static {v4, v5}, Ljava/lang/Thread;->sleep(J)V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 75
    .line 76
    .line 77
    :catch_2
    :try_start_4
    invoke-virtual {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->getPlaybackStatus()Z

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    if-eqz v4, :cond_5

    .line 82
    .line 83
    return v3

    .line 84
    :cond_5
    if-ne v1, v3, :cond_6

    .line 85
    .line 86
    const-wide/16 v4, 0x0

    .line 87
    .line 88
    invoke-direct {p0, v4, v5}, Linfo/t4w/vp/airplay/AirPlayClient;->sendScrubRequest(D)Z

    .line 89
    .line 90
    .line 91
    goto :goto_4

    .line 92
    :cond_6
    const/high16 v4, 0x3f800000    # 1.0f

    .line 93
    .line 94
    if-ne v1, v2, :cond_7

    .line 95
    .line 96
    invoke-direct {p0, v4}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z

    .line 97
    .line 98
    .line 99
    goto :goto_4

    .line 100
    :cond_7
    const/4 v5, 0x3

    .line 101
    if-ne v1, v5, :cond_8

    .line 102
    .line 103
    iget-object v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 104
    .line 105
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->sendStopRequest()Z
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    .line 106
    .line 107
    .line 108
    const-wide/16 v6, 0xc8

    .line 109
    .line 110
    :try_start_5
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_5
    .catch Ljava/lang/InterruptedException; {:try_start_5 .. :try_end_5} :catch_3
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    .line 111
    .line 112
    .line 113
    goto :goto_3

    .line 114
    :catch_3
    nop

    .line 115
    :goto_3
    if-eqz v5, :cond_8

    .line 116
    .line 117
    :try_start_6
    iput-object v5, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 118
    .line 119
    invoke-direct {p0, v4}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z

    .line 120
    .line 121
    .line 122
    :cond_8
    :goto_4
    add-int/lit8 v1, v1, 0x1

    .line 123
    .line 124
    goto :goto_2

    .line 125
    :cond_9
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryAlternatePlaybackFormats(Ljava/lang/String;Ljava/lang/String;)Z

    .line 126
    .line 127
    .line 128
    move-result p1

    .line 129
    return p1

    .line 130
    :cond_a
    if-nez v1, :cond_b

    .line 131
    .line 132
    iget v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->retryCount:I

    .line 133
    .line 134
    if-ge v3, v2, :cond_b

    .line 135
    .line 136
    invoke-direct {p0, p1, p2}, Linfo/t4w/vp/airplay/AirPlayClient;->tryAlternatePlaybackFormats(Ljava/lang/String;Ljava/lang/String;)Z

    .line 137
    .line 138
    .line 139
    move-result p1

    .line 140
    return p1

    .line 141
    :cond_b
    iget-object p1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 142
    .line 143
    if-nez p1, :cond_c

    .line 144
    .line 145
    invoke-direct {p0}, Linfo/t4w/vp/airplay/AirPlayClient;->generateSessionId()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    iput-object p1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 150
    .line 151
    :cond_c
    return v1

    .line 152
    :goto_5
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    :cond_d
    :goto_6
    return v0
.end method

.method public resumePlayback()Z
    .locals 1

    .line 1
    const/high16 v0, 0x3f800000    # 1.0f

    .line 2
    .line 3
    invoke-direct {p0, v0}, Linfo/t4w/vp/airplay/AirPlayClient;->trySetPlaybackRate(F)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    return v0
.end method

.method public seekTo(F)Z
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    return p1

    .line 7
    :cond_0
    float-to-double v0, p1

    .line 8
    invoke-direct {p0, v0, v1}, Linfo/t4w/vp/airplay/AirPlayClient;->sendScrubRequest(D)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1
.end method

.method public setUserAgent(Ljava/lang/String;)V
    .locals 0

    .line 1
    iput-object p1, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 2
    .line 3
    return-void
.end method

.method public stopPlayback()Z
    .locals 6

    .line 1
    const-string v0, "http://"

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    :try_start_0
    new-instance v3, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 11
    .line 12
    invoke-virtual {v0}, Linfo/t4w/vp/airplay/AirPlayDevice;->getAddress()Ljava/net/InetAddress;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v0, ":"

    .line 24
    .line 25
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-object v0, p0, Linfo/t4w/vp/airplay/AirPlayClient;->device:Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 29
    .line 30
    invoke-virtual {v0}, Linfo/t4w/vp/airplay/AirPlayDevice;->getPort()I

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 35
    .line 36
    .line 37
    const-string v0, "/stop"

    .line 38
    .line 39
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object v0

    .line 46
    new-instance v3, Ljava/net/URL;

    .line 47
    .line 48
    invoke-direct {v3, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    check-cast v0, Ljava/net/HttpURLConnection;

    .line 56
    .line 57
    const-string v3, "POST"

    .line 58
    .line 59
    invoke-virtual {v0, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    .line 60
    .line 61
    .line 62
    const-string v3, "Content-Type"

    .line 63
    .line 64
    const-string v4, "text/parameters"

    .line 65
    .line 66
    invoke-virtual {v0, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    const-string v3, "User-Agent"

    .line 70
    .line 71
    iget-object v4, p0, Linfo/t4w/vp/airplay/AirPlayClient;->userAgent:Ljava/lang/String;

    .line 72
    .line 73
    if-eqz v4, :cond_0

    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_0
    const-string v4, "MediaControl/1.0"

    .line 77
    .line 78
    :goto_0
    invoke-virtual {v0, v3, v4}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    iget-object v3, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 82
    .line 83
    if-eqz v3, :cond_1

    .line 84
    .line 85
    const-string v4, "X-Apple-Session-ID"

    .line 86
    .line 87
    invoke-virtual {v0, v4, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :catch_0
    move-exception v0

    .line 92
    goto :goto_2

    .line 93
    :cond_1
    :goto_1
    const/4 v3, 0x1

    .line 94
    invoke-virtual {v0, v3}, Ljava/net/URLConnection;->setDoOutput(Z)V

    .line 95
    .line 96
    .line 97
    new-instance v4, Ljava/io/DataOutputStream;

    .line 98
    .line 99
    invoke-virtual {v0}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    .line 100
    .line 101
    .line 102
    move-result-object v5

    .line 103
    invoke-direct {v4, v5}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v4}, Ljava/io/DataOutputStream;->flush()V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4}, Ljava/io/OutputStream;->close()V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    .line 113
    .line 114
    .line 115
    move-result v4

    .line 116
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseMessage()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    iput-object v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 120
    .line 121
    const/16 v0, 0xc8

    .line 122
    .line 123
    if-ne v4, v0, :cond_2

    .line 124
    .line 125
    return v3

    .line 126
    :cond_2
    return v1

    .line 127
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    iput-object v2, p0, Linfo/t4w/vp/airplay/AirPlayClient;->currentSessionId:Ljava/lang/String;

    .line 131
    .line 132
    return v1
.end method
