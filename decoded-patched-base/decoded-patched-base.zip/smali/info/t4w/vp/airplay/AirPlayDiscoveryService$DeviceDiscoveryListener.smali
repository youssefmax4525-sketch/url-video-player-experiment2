.class public interface abstract Linfo/t4w/vp/airplay/AirPlayDiscoveryService$DeviceDiscoveryListener;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Linfo/t4w/vp/airplay/AirPlayDiscoveryService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "DeviceDiscoveryListener"
.end annotation


# virtual methods
.method public abstract onDeviceAdded(Linfo/t4w/vp/airplay/AirPlayDevice;)V
.end method

.method public abstract onDeviceRemoved(Linfo/t4w/vp/airplay/AirPlayDevice;)V
.end method
