.class public Linfo/t4w/vp/CastOptionsProvider;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LhasSize9243;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public getAdditionalSessionProviders(Landroid/content/Context;)Ljava/util/List;
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "LSpyB;",
            ">;"
        }
    .end annotation

    const/4 p1, 0x0

    return-object p1
.end method

.method public getCastOptions(Landroid/content/Context;)LGtVP;
    .locals 27

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 9
    .line 10
    .line 11
    const-string v1, "com.google.android.gms.cast.framework.action.STOP_CASTING"

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    new-instance v1, LTfH_qg$Fs_;

    .line 17
    .line 18
    invoke-direct {v1}, LTfH_qg$Fs_;-><init>()V

    .line 19
    .line 20
    .line 21
    const/4 v2, 0x1

    .line 22
    const/4 v3, 0x0

    .line 23
    filled-new-array {v3, v2}, [I

    .line 24
    .line 25
    .line 26
    move-result-object v2

    .line 27
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 28
    .line 29
    .line 30
    move-result v4

    .line 31
    const/4 v5, 0x2

    .line 32
    if-gt v5, v4, :cond_3

    .line 33
    .line 34
    :goto_0
    if-ge v3, v5, :cond_1

    .line 35
    .line 36
    aget v6, v2, v3

    .line 37
    .line 38
    if-ltz v6, :cond_0

    .line 39
    .line 40
    if-ge v6, v4, :cond_0

    .line 41
    .line 42
    add-int/lit8 v3, v3, 0x1

    .line 43
    .line 44
    goto :goto_0

    .line 45
    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 46
    .line 47
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 48
    .line 49
    add-int/lit8 v4, v4, -0x1

    .line 50
    .line 51
    new-instance v1, Ljava/lang/StringBuilder;

    .line 52
    .line 53
    const-string v2, "Index "

    .line 54
    .line 55
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    const-string v2, " in compatActionIndices out of range: [0, "

    .line 62
    .line 63
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    const-string v2, "]"

    .line 70
    .line 71
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v1

    .line 78
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    throw v0

    .line 82
    :cond_1
    new-instance v3, Ljava/util/ArrayList;

    .line 83
    .line 84
    invoke-direct {v3, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 85
    .line 86
    .line 87
    iput-object v3, v1, LTfH_qg$Fs_;->e8$mp_s$:Ljava/util/AbstractCollection;

    .line 88
    .line 89
    invoke-static {v2, v5}, Ljava/util/Arrays;->copyOf([II)[I

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    iput-object v0, v1, LTfH_qg$Fs_;->waiBKÀ:[I

    .line 94
    .line 95
    invoke-virtual {v1}, LTfH_qg$Fs_;->e8$mp_s$()LPVN$Zh_Vn$;

    .line 96
    .line 97
    .line 98
    move-result-object v6

    .line 99
    new-instance v0, LTfH_qg$Fs_;

    .line 100
    .line 101
    invoke-direct {v0}, LTfH_qg$Fs_;-><init>()V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v0}, LTfH_qg$Fs_;->e8$mp_s$()LPVN$Zh_Vn$;

    .line 105
    .line 106
    .line 107
    new-instance v2, LUF$r$;

    .line 108
    .line 109
    const/4 v4, 0x0

    .line 110
    const/4 v7, 0x0

    .line 111
    const-string v3, "com.google.android.gms.cast.framework.media.MediaIntentReceiver"

    .line 112
    .line 113
    const/4 v5, 0x0

    .line 114
    const/4 v8, 0x1

    .line 115
    invoke-direct/range {v2 .. v8}, LUF$r$;-><init>(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;LPVN$Zh_Vn$;ZZ)V

    .line 116
    .line 117
    .line 118
    new-instance v9, Ljava/util/ArrayList;

    .line 119
    .line 120
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 121
    .line 122
    .line 123
    new-instance v11, LHU$s$;

    .line 124
    .line 125
    invoke-direct {v11}, LHU$s$;-><init>()V

    .line 126
    .line 127
    .line 128
    new-instance v20, Ljava/util/ArrayList;

    .line 129
    .line 130
    invoke-direct/range {v20 .. v20}, Ljava/util/ArrayList;-><init>()V

    .line 131
    .line 132
    .line 133
    sget v0, LcJLÌfz;->cast_app_id:I

    .line 134
    .line 135
    move-object/from16 v1, p1

    .line 136
    .line 137
    invoke-virtual {v1, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    sget-object v0, LGtVP;->ll:LUF$r$;

    .line 142
    .line 143
    if-eqz v0, :cond_2

    .line 144
    .line 145
    sget-object v23, LGtVP;->sKey6064:LiItem9502;

    .line 146
    .line 147
    sget-object v24, LGtVP;->tzKù7Ol1:LgValue6857;

    .line 148
    .line 149
    new-instance v7, LGtVP;

    .line 150
    .line 151
    const/16 v25, 0x0

    .line 152
    .line 153
    const/16 v26, 0x0

    .line 154
    .line 155
    const/4 v10, 0x0

    .line 156
    const/4 v12, 0x1

    .line 157
    const/4 v14, 0x1

    .line 158
    const-wide v15, 0x3fa99999a0000000L    # 0.05000000074505806

    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    const/16 v17, 0x0

    .line 164
    .line 165
    const/16 v18, 0x0

    .line 166
    .line 167
    const/16 v19, 0x0

    .line 168
    .line 169
    const/16 v22, 0x0

    .line 170
    .line 171
    move/from16 v21, v14

    .line 172
    .line 173
    move-object v13, v2

    .line 174
    invoke-direct/range {v7 .. v26}, LGtVP;-><init>(Ljava/lang/String;Ljava/util/ArrayList;ZLHU$s$;ZLUF$r$;ZDZZZLjava/util/ArrayList;ZZLiItem9502;LgValue6857;ZZ)V

    .line 175
    .line 176
    .line 177
    return-object v7

    .line 178
    :cond_2
    new-instance v0, Ljava/lang/NullPointerException;

    .line 179
    .line 180
    const-string v1, "use Optional.orNull() instead of Optional.or(null)"

    .line 181
    .line 182
    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw v0

    .line 186
    :cond_3
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 187
    .line 188
    sget-object v1, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 189
    .line 190
    const-string v1, "Invalid number of compat actions: 2 > "

    .line 191
    .line 192
    const-string v2, "."

    .line 193
    .line 194
    invoke-static {v1, v4, v2}, LBRK_m_;->sKey7917(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v1

    .line 198
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    throw v0
.end method
