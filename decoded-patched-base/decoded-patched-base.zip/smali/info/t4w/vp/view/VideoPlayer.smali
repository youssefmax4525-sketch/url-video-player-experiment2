.class public Linfo/t4w/vp/view/VideoPlayer;
.super LUd$5_1h$;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/cast/SessionAvailabilityListener;
.implements LGl1ID;


# annotations
.annotation build Landroidx/media3/common/util/UnstableApi;
.end annotation


# static fields
.field public static final synthetic datl:I


# instance fields
.field public BCIm:Landroid/widget/ImageView;

.field public final CA$b_$K$:LDOl;

.field public CcZMD:Z

.field public ChI_KH_:Z

.field public Iey:Ljava/lang/String;

.field public IiI1iI:J

.field public Iii:Landroidx/media3/ui/PlayerView;

.field public K11ID:Landroid/view/View;

.field public RD:LVA_r_;

.field public Txy$$d_w$:Landroid/widget/ImageView;

.field public WoI_9_:Linfo/t4w/vp/view/VerticalSeekBar;

.field public YOD0:Landroidx/media3/common/MediaItem;

.field public cEi_G$x5_:F

.field public colnt:I

.field public datI:Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;

.field public dnN$d$:LILA_l$V_;

.field public gCount1961:Landroid/widget/FrameLayout;

.field public gSy_FG$D_:Landroid/widget/ImageView;

.field public gc_$M_w2$:F

.field public iCount5302:Landroid/media/AudioManager;

.field public final iQ0D:Ljava/util/concurrent/ExecutorService;

.field public iSize4906:Landroid/widget/ImageView;

.field public inlex:Z

.field public final jI:Ljava/lang/String;

.field public k1y:Landroidx/mediarouter/app/MediaRouteButton;

.field public l1:Landroidx/media3/exoplayer/ExoPlayer;

.field public lIl1:F

.field public lelgth:Ljava/lang/String;

.field public mQQI:Ljava/util/HashMap;

.field public oO:Landroid/widget/LinearLayout;

.field public oaX_6_:Landroidx/media3/common/Player;

.field public pQ1Il:Landroidx/media3/cast/CastPlayer;

.field public pZDcLvd:Landroid/view/View;

.field public po0:F

.field public rMBhl:I

.field public s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

.field public sTxÒ7:Ljava/lang/String;

.field public vData2659:I

.field public vSize1911:Ljava/lang/String;

.field public valu0:LgIXQù;

.field public final valu1:LDOl;

.field public vz$a$:Z

.field public final xlOI:LoZ0DQtS6;

.field public zAt$p:Landroid/widget/ImageView;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 1
    invoke-direct {p0}, LUd$5_1h$;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 6
    .line 7
    iput-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 8
    .line 9
    const/high16 v1, 0x3f800000    # 1.0f

    .line 10
    .line 11
    iput v1, p0, Linfo/t4w/vp/view/VideoPlayer;->gc_$M_w2$:F

    .line 12
    .line 13
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->iQ0D:Ljava/util/concurrent/ExecutorService;

    .line 18
    .line 19
    iput-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->CcZMD:Z

    .line 20
    .line 21
    iput-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->inlex:Z

    .line 22
    .line 23
    iput v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vData2659:I

    .line 24
    .line 25
    const-string v1, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"

    .line 26
    .line 27
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->jI:Ljava/lang/String;

    .line 28
    .line 29
    new-instance v1, LoZ0DQtS6;

    .line 30
    .line 31
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 32
    .line 33
    .line 34
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->xlOI:LoZ0DQtS6;

    .line 35
    .line 36
    new-instance v1, LDOl;

    .line 37
    .line 38
    const/16 v2, 0x9

    .line 39
    .line 40
    invoke-direct {v1, p0, v2}, LDOl;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 41
    .line 42
    .line 43
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->valu1:LDOl;

    .line 44
    .line 45
    new-instance v1, LDOl;

    .line 46
    .line 47
    const/16 v2, 0xa

    .line 48
    .line 49
    invoke-direct {v1, p0, v2}, LDOl;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 50
    .line 51
    .line 52
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->CA$b_$K$:LDOl;

    .line 53
    .line 54
    iput v0, p0, Linfo/t4w/vp/view/VideoPlayer;->rMBhl:I

    .line 55
    .line 56
    return-void
.end method

.method public static Oey(Ljava/lang/String;)Z
    .locals 1

    .line 1
    if-eqz p0, :cond_2

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    const-string v0, ".m3u8"

    .line 17
    .line 18
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_1

    .line 23
    .line 24
    const-string v0, ".mpd"

    .line 25
    .line 26
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    if-nez v0, :cond_1

    .line 31
    .line 32
    const-string v0, ".json"

    .line 33
    .line 34
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-nez v0, :cond_1

    .line 39
    .line 40
    const-string v0, "/live/"

    .line 41
    .line 42
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    if-nez v0, :cond_1

    .line 47
    .line 48
    const-string v0, "/hls/"

    .line 49
    .line 50
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 51
    .line 52
    .line 53
    move-result v0

    .line 54
    if-nez v0, :cond_1

    .line 55
    .line 56
    const-string v0, "/dash/"

    .line 57
    .line 58
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-nez v0, :cond_1

    .line 63
    .line 64
    const-string v0, "live=true"

    .line 65
    .line 66
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-nez v0, :cond_1

    .line 71
    .line 72
    const-string v0, "livestream"

    .line 73
    .line 74
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 75
    .line 76
    .line 77
    move-result p0

    .line 78
    if-eqz p0, :cond_2

    .line 79
    .line 80
    :cond_1
    const/4 p0, 0x1

    .line 81
    return p0

    .line 82
    :cond_2
    :goto_0
    const/4 p0, 0x0

    .line 83
    return p0
.end method

.method public static UC_n_(Landroidx/media3/common/MediaItem$Builder;Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-static {p1}, Linfo/t4w/vp/view/VideoPlayer;->Oey(Ljava/lang/String;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    new-instance p1, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 9
    .line 10
    invoke-direct {p1}, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;-><init>()V

    .line 11
    .line 12
    .line 13
    const-wide/16 v0, 0x7530

    .line 14
    .line 15
    invoke-virtual {p1, v0, v1}, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->setTargetOffsetMs(J)Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    const-wide/16 v0, 0x2710

    .line 20
    .line 21
    invoke-virtual {p1, v0, v1}, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->setMinOffsetMs(J)Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    const-wide/32 v0, 0xea60

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1, v0, v1}, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->setMaxOffsetMs(J)Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$LiveConfiguration$Builder;->build()Landroidx/media3/common/MediaItem$LiveConfiguration;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-virtual {p0, p1}, Landroidx/media3/common/MediaItem$Builder;->setLiveConfiguration(Landroidx/media3/common/MediaItem$LiveConfiguration;)Landroidx/media3/common/MediaItem$Builder;

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public static ll(Landroidx/media3/common/Tracks;I)[Landroidx/media3/common/Tracks$Group;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/media3/common/Tracks;->getGroups()LleOgth;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {p0, v1}, LleOgth;->Ialue(I)LdzP$A$;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    :cond_0
    :goto_0
    invoke-virtual {p0}, LBCIm;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    invoke-virtual {p0}, LBCIm;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Landroidx/media3/common/Tracks$Group;

    .line 26
    .line 27
    invoke-virtual {v2}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-ne v3, p1, :cond_0

    .line 32
    .line 33
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    new-array p0, v1, [Landroidx/media3/common/Tracks$Group;

    .line 38
    .line 39
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    check-cast p0, [Landroidx/media3/common/Tracks$Group;

    .line 44
    .line 45
    return-object p0
.end method

.method public static oy_R$Xx_([Landroidx/media3/common/Tracks$Group;)[Ljava/lang/String;
    .locals 10

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    array-length v1, p0

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    :goto_0
    if-ge v3, v1, :cond_7

    .line 10
    .line 11
    aget-object v4, p0, v3

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    :goto_1
    iget v6, v4, Landroidx/media3/common/Tracks$Group;->length:I

    .line 15
    .line 16
    if-ge v5, v6, :cond_6

    .line 17
    .line 18
    invoke-virtual {v4, v5}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(I)Z

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    if-eqz v6, :cond_5

    .line 23
    .line 24
    invoke-virtual {v4, v5}, Landroidx/media3/common/Tracks$Group;->getTrackFormat(I)Landroidx/media3/common/Format;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    iget-object v7, v6, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    .line 29
    .line 30
    if-eqz v7, :cond_0

    .line 31
    .line 32
    goto :goto_2

    .line 33
    :cond_0
    iget-object v7, v6, Landroidx/media3/common/Format;->language:Ljava/lang/String;

    .line 34
    .line 35
    if-eqz v7, :cond_1

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_1
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 39
    .line 40
    .line 41
    move-result v7

    .line 42
    const/4 v8, 0x2

    .line 43
    if-ne v7, v8, :cond_3

    .line 44
    .line 45
    iget v7, v6, Landroidx/media3/common/Format;->width:I

    .line 46
    .line 47
    if-lez v7, :cond_2

    .line 48
    .line 49
    iget v7, v6, Landroidx/media3/common/Format;->height:I

    .line 50
    .line 51
    if-lez v7, :cond_2

    .line 52
    .line 53
    new-instance v7, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 56
    .line 57
    .line 58
    iget v8, v6, Landroidx/media3/common/Format;->width:I

    .line 59
    .line 60
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v8, "x"

    .line 64
    .line 65
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    iget v8, v6, Landroidx/media3/common/Format;->height:I

    .line 69
    .line 70
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v7

    .line 77
    iget v8, v6, Landroidx/media3/common/Format;->frameRate:F

    .line 78
    .line 79
    const/4 v9, 0x0

    .line 80
    cmpl-float v8, v8, v9

    .line 81
    .line 82
    if-lez v8, :cond_4

    .line 83
    .line 84
    const-string v8, " @ "

    .line 85
    .line 86
    invoke-static {v7, v8}, LRQU_K6$Kv_;->pCXDYg(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    iget v6, v6, Landroidx/media3/common/Format;->frameRate:F

    .line 91
    .line 92
    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    .line 93
    .line 94
    .line 95
    move-result v6

    .line 96
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    const-string v6, "fps"

    .line 100
    .line 101
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v7

    .line 108
    goto :goto_2

    .line 109
    :cond_2
    const-string v6, "Video Track "

    .line 110
    .line 111
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v7

    .line 115
    goto :goto_2

    .line 116
    :cond_3
    const-string v6, "Track "

    .line 117
    .line 118
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 119
    .line 120
    .line 121
    move-result-object v7

    .line 122
    :cond_4
    :goto_2
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    :cond_5
    add-int/lit8 v5, v5, 0x1

    .line 126
    .line 127
    goto :goto_1

    .line 128
    :cond_6
    add-int/lit8 v3, v3, 0x1

    .line 129
    .line 130
    goto :goto_0

    .line 131
    :cond_7
    new-array p0, v2, [Ljava/lang/String;

    .line 132
    .line 133
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p0

    .line 137
    check-cast p0, [Ljava/lang/String;

    .line 138
    .line 139
    return-object p0
.end method

.method public static sKey6064(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    .line 1
    const-string v0, "="

    .line 2
    .line 3
    const-string v1, ""

    .line 4
    .line 5
    if-eqz p0, :cond_3

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eqz v2, :cond_0

    .line 12
    .line 13
    goto :goto_2

    .line 14
    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    const/4 v2, 0x0

    .line 19
    :try_start_0
    invoke-static {p0, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    invoke-static {v3, v2}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    invoke-virtual {v3}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    invoke-virtual {v3, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    move-result-object v3

    .line 35
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 43
    goto :goto_0

    .line 44
    :catch_0
    nop

    .line 45
    const/4 v1, 0x0

    .line 46
    :goto_0
    if-nez v1, :cond_1

    .line 47
    .line 48
    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    const/4 v1, 0x2

    .line 53
    invoke-static {p0, v1}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    :cond_1
    :goto_1
    invoke-virtual {p0, v0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    if-eqz v1, :cond_2

    .line 62
    .line 63
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    add-int/lit8 v1, v1, -0x1

    .line 68
    .line 69
    invoke-virtual {p0, v2, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    goto :goto_1

    .line 74
    :cond_2
    return-object p0

    .line 75
    :cond_3
    :goto_2
    return-object v1
.end method

.method public static tzKù7Ol1(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    .line 1
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-static {v1}, Landroid/webkit/MimeTypeMap;->getFileExtensionFromUrl(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const/4 v2, 0x1

    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    if-eqz v3, :cond_1

    .line 19
    .line 20
    :cond_0
    const/16 v3, 0x2e

    .line 21
    .line 22
    invoke-virtual {p0, v3}, Ljava/lang/String;->lastIndexOf(I)I

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-ltz v3, :cond_1

    .line 27
    .line 28
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 29
    .line 30
    .line 31
    move-result v4

    .line 32
    sub-int/2addr v4, v2

    .line 33
    if-ge v3, v4, :cond_1

    .line 34
    .line 35
    add-int/2addr v3, v2

    .line 36
    invoke-virtual {p0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    invoke-virtual {v1, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    :cond_1
    const-string v0, "mpd"

    .line 45
    .line 46
    const-string v3, "ism"

    .line 47
    .line 48
    if-eqz v1, :cond_d

    .line 49
    .line 50
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    const/4 v4, -0x1

    .line 55
    sparse-switch p0, :sswitch_data_0

    .line 56
    .line 57
    .line 58
    :goto_0
    const/4 v2, -0x1

    .line 59
    goto/16 :goto_1

    .line 60
    .line 61
    :sswitch_0
    const-string p0, "webm"

    .line 62
    .line 63
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p0

    .line 67
    if-nez p0, :cond_2

    .line 68
    .line 69
    goto :goto_0

    .line 70
    :cond_2
    const/16 v2, 0xa

    .line 71
    .line 72
    goto/16 :goto_1

    .line 73
    .line 74
    :sswitch_1
    const-string p0, "isml"

    .line 75
    .line 76
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result p0

    .line 80
    if-nez p0, :cond_3

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :cond_3
    const/16 v2, 0x9

    .line 84
    .line 85
    goto/16 :goto_1

    .line 86
    .line 87
    :sswitch_2
    const-string p0, "flac"

    .line 88
    .line 89
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result p0

    .line 93
    if-nez p0, :cond_4

    .line 94
    .line 95
    goto :goto_0

    .line 96
    :cond_4
    const/16 v2, 0x8

    .line 97
    .line 98
    goto :goto_1

    .line 99
    :sswitch_3
    const-string p0, "ogg"

    .line 100
    .line 101
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result p0

    .line 105
    if-nez p0, :cond_5

    .line 106
    .line 107
    goto :goto_0

    .line 108
    :cond_5
    const/4 v2, 0x7

    .line 109
    goto :goto_1

    .line 110
    :sswitch_4
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result p0

    .line 114
    if-nez p0, :cond_6

    .line 115
    .line 116
    goto :goto_0

    .line 117
    :cond_6
    const/4 v2, 0x6

    .line 118
    goto :goto_1

    .line 119
    :sswitch_5
    const-string p0, "mp4"

    .line 120
    .line 121
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    move-result p0

    .line 125
    if-nez p0, :cond_7

    .line 126
    .line 127
    goto :goto_0

    .line 128
    :cond_7
    const/4 v2, 0x5

    .line 129
    goto :goto_1

    .line 130
    :sswitch_6
    const-string p0, "mp3"

    .line 131
    .line 132
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 133
    .line 134
    .line 135
    move-result p0

    .line 136
    if-nez p0, :cond_8

    .line 137
    .line 138
    goto :goto_0

    .line 139
    :cond_8
    const/4 v2, 0x4

    .line 140
    goto :goto_1

    .line 141
    :sswitch_7
    const-string p0, "mkv"

    .line 142
    .line 143
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result p0

    .line 147
    if-nez p0, :cond_9

    .line 148
    .line 149
    goto :goto_0

    .line 150
    :cond_9
    const/4 v2, 0x3

    .line 151
    goto :goto_1

    .line 152
    :sswitch_8
    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result p0

    .line 156
    if-nez p0, :cond_a

    .line 157
    .line 158
    goto :goto_0

    .line 159
    :cond_a
    const/4 v2, 0x2

    .line 160
    goto :goto_1

    .line 161
    :sswitch_9
    const-string p0, "aac"

    .line 162
    .line 163
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 164
    .line 165
    .line 166
    move-result p0

    .line 167
    if-nez p0, :cond_c

    .line 168
    .line 169
    goto :goto_0

    .line 170
    :sswitch_a
    const-string p0, "ts"

    .line 171
    .line 172
    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    move-result p0

    .line 176
    if-nez p0, :cond_b

    .line 177
    .line 178
    goto :goto_0

    .line 179
    :cond_b
    const/4 v2, 0x0

    .line 180
    :cond_c
    :goto_1
    packed-switch v2, :pswitch_data_0

    .line 181
    .line 182
    .line 183
    goto :goto_4

    .line 184
    :pswitch_0
    const-string p0, "video/webm"

    .line 185
    .line 186
    return-object p0

    .line 187
    :pswitch_1
    const-string p0, "audio/flac"

    .line 188
    .line 189
    return-object p0

    .line 190
    :pswitch_2
    const-string p0, "audio/ogg"

    .line 191
    .line 192
    return-object p0

    .line 193
    :pswitch_3
    const-string p0, "audio/mpeg"

    .line 194
    .line 195
    return-object p0

    .line 196
    :pswitch_4
    const-string p0, "video/x-matroska"

    .line 197
    .line 198
    return-object p0

    .line 199
    :pswitch_5
    const-string p0, "audio/mp4a-latm"

    .line 200
    .line 201
    return-object p0

    .line 202
    :pswitch_6
    const-string p0, "video/mp2t"

    .line 203
    .line 204
    return-object p0

    .line 205
    :cond_d
    const-string v1, "m3u8"

    .line 206
    .line 207
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 208
    .line 209
    .line 210
    move-result v1

    .line 211
    if-nez v1, :cond_13

    .line 212
    .line 213
    const-string v1, "hls"

    .line 214
    .line 215
    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 216
    .line 217
    .line 218
    move-result v1

    .line 219
    if-eqz v1, :cond_e

    .line 220
    .line 221
    goto :goto_4

    .line 222
    :cond_e
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 223
    .line 224
    .line 225
    move-result v0

    .line 226
    if-nez v0, :cond_12

    .line 227
    .line 228
    const-string v0, "dash"

    .line 229
    .line 230
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 231
    .line 232
    .line 233
    move-result v0

    .line 234
    if-eqz v0, :cond_f

    .line 235
    .line 236
    goto :goto_3

    .line 237
    :cond_f
    invoke-virtual {p0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 238
    .line 239
    .line 240
    move-result v0

    .line 241
    if-nez v0, :cond_11

    .line 242
    .line 243
    const-string v0, "smooth"

    .line 244
    .line 245
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 246
    .line 247
    .line 248
    move-result p0

    .line 249
    if-eqz p0, :cond_10

    .line 250
    .line 251
    goto :goto_2

    .line 252
    :cond_10
    :pswitch_7
    const-string p0, "video/mp4"

    .line 253
    .line 254
    return-object p0

    .line 255
    :cond_11
    :goto_2
    :pswitch_8
    const-string p0, "application/vnd.ms-sstr+xml"

    .line 256
    .line 257
    return-object p0

    .line 258
    :cond_12
    :goto_3
    :pswitch_9
    const-string p0, "application/dash+xml"

    .line 259
    .line 260
    return-object p0

    .line 261
    :cond_13
    :goto_4
    const-string p0, "application/x-mpegURL"

    .line 262
    .line 263
    return-object p0

    .line 264
    nop

    .line 265
    :sswitch_data_0
    .sparse-switch
        0xe7f -> :sswitch_a
        0x17843 -> :sswitch_9
        0x19883 -> :sswitch_8
        0x1a698 -> :sswitch_7
        0x1a6f0 -> :sswitch_6
        0x1a6f1 -> :sswitch_5
        0x1a721 -> :sswitch_4
        0x1ad8f -> :sswitch_3
        0x2fff68 -> :sswitch_2
        0x317849 -> :sswitch_1
        0x379f99 -> :sswitch_0
    .end sparse-switch

    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_8
        :pswitch_4
        :pswitch_3
        :pswitch_7
        :pswitch_9
        :pswitch_2
        :pswitch_1
        :pswitch_8
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public final $ÒcdS(Landroidx/media3/common/MediaItem;Landroidx/media3/datasource/DefaultHttpDataSource$Factory;Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;)Landroidx/media3/exoplayer/source/BaseMediaSource;
    .locals 5

    .line 1
    if-eqz p1, :cond_10

    .line 2
    .line 3
    iget-object v0, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    goto/16 :goto_6

    .line 8
    .line 9
    :cond_0
    iget-object v1, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 10
    .line 11
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->mimeType:Ljava/lang/String;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    if-eqz v1, :cond_1

    .line 15
    .line 16
    invoke-virtual {v1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    goto :goto_0

    .line 21
    :cond_1
    move-object v3, v2

    .line 22
    :goto_0
    if-eqz v1, :cond_2

    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    goto :goto_1

    .line 29
    :cond_2
    const-string v1, ""

    .line 30
    .line 31
    :goto_1
    if-eqz v0, :cond_3

    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    if-eqz v4, :cond_4

    .line 38
    .line 39
    :cond_3
    invoke-static {v1}, Linfo/t4w/vp/view/VideoPlayer;->tzKù7Ol1(Ljava/lang/String;)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    :cond_4
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    if-nez v4, :cond_e

    .line 48
    .line 49
    :try_start_0
    const-string v4, "application/dash+xml"

    .line 50
    .line 51
    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v4

    .line 55
    if-nez v4, :cond_c

    .line 56
    .line 57
    const-string v4, ".mpd"

    .line 58
    .line 59
    invoke-virtual {v1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 60
    .line 61
    .line 62
    move-result v4

    .line 63
    if-nez v4, :cond_c

    .line 64
    .line 65
    const-string v4, "dash"

    .line 66
    .line 67
    invoke-virtual {v1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-eqz v4, :cond_5

    .line 72
    .line 73
    goto/16 :goto_4

    .line 74
    .line 75
    :cond_5
    const-string v2, "application/x-mpegURL"

    .line 76
    .line 77
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    if-nez v2, :cond_a

    .line 82
    .line 83
    if-eqz v3, :cond_6

    .line 84
    .line 85
    const-string v2, ".m3u8"

    .line 86
    .line 87
    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    if-nez v2, :cond_a

    .line 92
    .line 93
    goto :goto_2

    .line 94
    :catch_0
    move-exception v0

    .line 95
    goto/16 :goto_5

    .line 96
    .line 97
    :cond_6
    :goto_2
    const-string v2, "m3u8"

    .line 98
    .line 99
    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 100
    .line 101
    .line 102
    move-result v2

    .line 103
    if-nez v2, :cond_a

    .line 104
    .line 105
    const-string v2, "hls"

    .line 106
    .line 107
    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 108
    .line 109
    .line 110
    move-result v2

    .line 111
    if-eqz v2, :cond_7

    .line 112
    .line 113
    goto :goto_3

    .line 114
    :cond_7
    const-string v2, "application/vnd.ms-sstr+xml"

    .line 115
    .line 116
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v0

    .line 120
    if-nez v0, :cond_8

    .line 121
    .line 122
    const-string v0, ".ism"

    .line 123
    .line 124
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 125
    .line 126
    .line 127
    move-result v0

    .line 128
    if-nez v0, :cond_8

    .line 129
    .line 130
    const-string v0, ".isml"

    .line 131
    .line 132
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 133
    .line 134
    .line 135
    move-result v0

    .line 136
    if-nez v0, :cond_8

    .line 137
    .line 138
    const-string v0, "smooth"

    .line 139
    .line 140
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 141
    .line 142
    .line 143
    move-result v0

    .line 144
    if-eqz v0, :cond_e

    .line 145
    .line 146
    :cond_8
    new-instance v0, Landroidx/media3/exoplayer/smoothstreaming/SsMediaSource$Factory;

    .line 147
    .line 148
    invoke-direct {v0, p2}, Landroidx/media3/exoplayer/smoothstreaming/SsMediaSource$Factory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    .line 149
    .line 150
    .line 151
    if-eqz p3, :cond_9

    .line 152
    .line 153
    new-instance v1, LJQQ;

    .line 154
    .line 155
    const/4 v2, 0x1

    .line 156
    invoke-direct {v1, p3, v2}, LJQQ;-><init>(Landroidx/media3/exoplayer/drm/DrmSessionManager;I)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v0, v1}, Landroidx/media3/exoplayer/smoothstreaming/SsMediaSource$Factory;->setDrmSessionManagerProvider(Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;)Landroidx/media3/exoplayer/smoothstreaming/SsMediaSource$Factory;

    .line 160
    .line 161
    .line 162
    :cond_9
    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/smoothstreaming/SsMediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/smoothstreaming/SsMediaSource;

    .line 163
    .line 164
    .line 165
    move-result-object p1

    .line 166
    return-object p1

    .line 167
    :cond_a
    :goto_3
    new-instance v0, LdaIa;

    .line 168
    .line 169
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->lelgth:Ljava/lang/String;

    .line 170
    .line 171
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 172
    .line 173
    invoke-direct {v0, v1, v2}, LdaIa;-><init>(Ljava/lang/String;Ljava/util/HashMap;)V

    .line 174
    .line 175
    .line 176
    new-instance v1, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;

    .line 177
    .line 178
    invoke-direct {v1, v0}, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    .line 179
    .line 180
    .line 181
    const/4 v0, 0x1

    .line 182
    invoke-virtual {v1, v0}, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->setAllowChunklessPreparation(Z)Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;

    .line 183
    .line 184
    .line 185
    if-eqz p3, :cond_b

    .line 186
    .line 187
    new-instance v0, LJQQ;

    .line 188
    .line 189
    const/4 v2, 0x1

    .line 190
    invoke-direct {v0, p3, v2}, LJQQ;-><init>(Landroidx/media3/exoplayer/drm/DrmSessionManager;I)V

    .line 191
    .line 192
    .line 193
    invoke-virtual {v1, v0}, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->setDrmSessionManagerProvider(Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;)Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;

    .line 194
    .line 195
    .line 196
    :cond_b
    invoke-virtual {v1, p1}, Landroidx/media3/exoplayer/hls/HlsMediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/hls/HlsMediaSource;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    return-object p1

    .line 201
    :cond_c
    :goto_4
    new-instance v0, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;

    .line 202
    .line 203
    invoke-direct {v0, p2}, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    .line 204
    .line 205
    .line 206
    new-instance v1, Landroidx/media3/exoplayer/offline/FilteringManifestParser;

    .line 207
    .line 208
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->datI:Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;

    .line 209
    .line 210
    invoke-direct {v1, v3, v2}, Landroidx/media3/exoplayer/offline/FilteringManifestParser;-><init>(Landroidx/media3/exoplayer/upstream/ParsingLoadable$Parser;Ljava/util/List;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v0, v1}, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->setManifestParser(Landroidx/media3/exoplayer/upstream/ParsingLoadable$Parser;)Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    if-eqz p3, :cond_d

    .line 218
    .line 219
    new-instance v1, LJQQ;

    .line 220
    .line 221
    const/4 v2, 0x1

    .line 222
    invoke-direct {v1, p3, v2}, LJQQ;-><init>(Landroidx/media3/exoplayer/drm/DrmSessionManager;I)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {v0, v1}, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->setDrmSessionManagerProvider(Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;)Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;

    .line 226
    .line 227
    .line 228
    :cond_d
    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/dash/DashMediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/dash/DashMediaSource;

    .line 229
    .line 230
    .line 231
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 232
    return-object p1

    .line 233
    :goto_5
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    :cond_e
    new-instance v0, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;

    .line 237
    .line 238
    invoke-direct {v0, p2}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    .line 239
    .line 240
    .line 241
    if-eqz p3, :cond_f

    .line 242
    .line 243
    new-instance p2, LJQQ;

    .line 244
    .line 245
    const/4 v1, 0x1

    .line 246
    invoke-direct {p2, p3, v1}, LJQQ;-><init>(Landroidx/media3/exoplayer/drm/DrmSessionManager;I)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v0, p2}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;->setDrmSessionManagerProvider(Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;)Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;

    .line 250
    .line 251
    .line 252
    :cond_f
    invoke-virtual {v0, p1}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/source/ProgressiveMediaSource;

    .line 253
    .line 254
    .line 255
    move-result-object p1

    .line 256
    return-object p1

    .line 257
    :cond_10
    :goto_6
    new-instance p1, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;

    .line 258
    .line 259
    invoke-direct {p1, p2}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;-><init>(Landroidx/media3/datasource/DataSource$Factory;)V

    .line 260
    .line 261
    .line 262
    if-eqz p3, :cond_11

    .line 263
    .line 264
    new-instance p2, LJQQ;

    .line 265
    .line 266
    const/4 v0, 0x1

    .line 267
    invoke-direct {p2, p3, v0}, LJQQ;-><init>(Landroidx/media3/exoplayer/drm/DrmSessionManager;I)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {p1, p2}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;->setDrmSessionManagerProvider(Landroidx/media3/exoplayer/drm/DrmSessionManagerProvider;)Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;

    .line 271
    .line 272
    .line 273
    :cond_11
    sget-object p2, Landroid/net/Uri;->EMPTY:Landroid/net/Uri;

    .line 274
    .line 275
    invoke-static {p2}, Landroidx/media3/common/MediaItem;->fromUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem;

    .line 276
    .line 277
    .line 278
    move-result-object p2

    .line 279
    invoke-virtual {p1, p2}, Landroidx/media3/exoplayer/source/ProgressiveMediaSource$Factory;->createMediaSource(Landroidx/media3/common/MediaItem;)Landroidx/media3/exoplayer/source/ProgressiveMediaSource;

    .line 280
    .line 281
    .line 282
    move-result-object p1

    .line 283
    return-object p1
.end method

.method public final BCIm()V
    .locals 4

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->CA$b_$K$:LDOl;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 11
    .line 12
    const-wide/16 v2, 0x9c4

    .line 13
    .line 14
    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method

.method public final ChI_KH_(Ljava/lang/String;)V
    .locals 2

    .line 1
    if-eqz p1, :cond_1

    .line 2
    .line 3
    const-string v0, "###"

    .line 4
    .line 5
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    const-string v0, ".json"

    .line 16
    .line 17
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    if-eqz p1, :cond_1

    .line 22
    .line 23
    :cond_0
    const/4 p1, 0x1

    .line 24
    goto :goto_0

    .line 25
    :cond_1
    const/4 p1, 0x0

    .line 26
    :goto_0
    invoke-virtual {p0}, Linfo/t4w/vp/view/VideoPlayer;->Iii()Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    new-instance v1, LgValue7067;

    .line 31
    .line 32
    invoke-direct {v1, p0, p1, v0}, LgValue7067;-><init>(Linfo/t4w/vp/view/VideoPlayer;ZZ)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0, v1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final Iii()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "android.software.leanback"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    const-string v1, "android.hardware.type.television"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v0, 0x0

    .line 23
    return v0

    .line 24
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 25
    return v0
.end method

.method public final Q1_f_(Ljava/lang/String;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;
    .locals 4

    .line 1
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/VideoPlayer;->tmpSize211(Ljava/lang/String;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    .line 6
    .line 7
    .line 8
    new-instance v0, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;

    .line 9
    .line 10
    new-instance v1, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 11
    .line 12
    invoke-direct {v1}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->lelgth:Ljava/lang/String;

    .line 16
    .line 17
    invoke-virtual {v1, v2}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    const-string v2, ""

    .line 22
    .line 23
    invoke-direct {v0, v2, v1}, Landroidx/media3/exoplayer/drm/HttpMediaDrmCallback;-><init>(Ljava/lang/String;Landroidx/media3/datasource/DataSource$Factory;)V

    .line 24
    .line 25
    .line 26
    new-instance v0, Landroidx/media3/exoplayer/drm/LocalMediaDrmCallback;

    .line 27
    .line 28
    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-direct {v0, p1}, Landroidx/media3/exoplayer/drm/LocalMediaDrmCallback;-><init>([B)V

    .line 33
    .line 34
    .line 35
    new-instance p1, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    .line 36
    .line 37
    invoke-direct {p1}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;-><init>()V

    .line 38
    .line 39
    .line 40
    sget-object v1, Landroidx/media3/common/C;->CLEARKEY_UUID:Ljava/util/UUID;

    .line 41
    .line 42
    new-instance v2, Lebj_F$t_;

    .line 43
    .line 44
    const/4 v3, 0x1

    .line 45
    invoke-direct {v2, v3}, Lebj_F$t_;-><init>(I)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p1, v1, v2}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setUuidAndExoMediaDrmProvider(Ljava/util/UUID;Landroidx/media3/exoplayer/drm/ExoMediaDrm$Provider;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    const/4 v1, 0x0

    .line 53
    invoke-virtual {p1, v1}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->setMultiSession(Z)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    invoke-virtual {p1, v0}, Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager$Builder;->build(Landroidx/media3/exoplayer/drm/MediaDrmCallback;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    return-object p1
.end method

.method public final Txy$$d_w$()V
    .locals 10

    .line 1
    iget-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x1

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    const/4 v0, -0x1

    .line 8
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 12
    .line 13
    invoke-virtual {v0, v2}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 14
    .line 15
    .line 16
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 17
    .line 18
    sget v2, LindeQ;->video_scale_stretch:I

    .line 19
    .line 20
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->zAt$p:Landroid/widget/ImageView;

    .line 24
    .line 25
    sget v2, LindeQ;->ic_fullscreen:I

    .line 26
    .line 27
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 28
    .line 29
    .line 30
    iput-boolean v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 31
    .line 32
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 33
    .line 34
    const/16 v1, 0x8

    .line 35
    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 39
    .line 40
    .line 41
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 42
    .line 43
    if-eqz v0, :cond_1

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 46
    .line 47
    .line 48
    :cond_1
    return-void

    .line 49
    :cond_2
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 50
    .line 51
    const-wide/16 v3, 0x0

    .line 52
    .line 53
    if-eqz v0, :cond_3

    .line 54
    .line 55
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 56
    .line 57
    .line 58
    move-result-wide v5

    .line 59
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 60
    .line 61
    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    .line 62
    .line 63
    .line 64
    move-result v0

    .line 65
    goto :goto_0

    .line 66
    :cond_3
    move-wide v5, v3

    .line 67
    const/4 v0, 0x1

    .line 68
    :goto_0
    iget-object v7, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 69
    .line 70
    const/4 v8, 0x3

    .line 71
    invoke-virtual {v7, v8}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 72
    .line 73
    .line 74
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 75
    .line 76
    const/16 v9, 0x1c

    .line 77
    .line 78
    if-lt v7, v9, :cond_4

    .line 79
    .line 80
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 81
    .line 82
    .line 83
    move-result-object v7

    .line 84
    invoke-virtual {v7}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 85
    .line 86
    .line 87
    move-result-object v7

    .line 88
    invoke-static {v7}, LCA$b_$K$;->gKey4112(Landroid/view/WindowManager$LayoutParams;)V

    .line 89
    .line 90
    .line 91
    :cond_4
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 92
    .line 93
    .line 94
    move-result-object v7

    .line 95
    const/16 v9, 0x600

    .line 96
    .line 97
    invoke-virtual {v7, v9, v9}, Landroid/view/Window;->setFlags(II)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 101
    .line 102
    .line 103
    move-result-object v7

    .line 104
    invoke-virtual {v7}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 105
    .line 106
    .line 107
    move-result-object v7

    .line 108
    const/16 v9, 0x1706

    .line 109
    .line 110
    invoke-virtual {v7, v9}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 114
    .line 115
    .line 116
    iget-object v7, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 117
    .line 118
    if-eqz v7, :cond_6

    .line 119
    .line 120
    cmp-long v9, v5, v3

    .line 121
    .line 122
    if-lez v9, :cond_5

    .line 123
    .line 124
    invoke-interface {v7, v5, v6}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 125
    .line 126
    .line 127
    :cond_5
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 128
    .line 129
    invoke-interface {v3, v0}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 130
    .line 131
    .line 132
    iget v0, p0, Linfo/t4w/vp/view/VideoPlayer;->gc_$M_w2$:F

    .line 133
    .line 134
    const/high16 v3, 0x3f800000    # 1.0f

    .line 135
    .line 136
    cmpl-float v0, v0, v3

    .line 137
    .line 138
    if-eqz v0, :cond_6

    .line 139
    .line 140
    new-instance v0, Landroidx/media3/common/PlaybackParameters;

    .line 141
    .line 142
    iget v3, p0, Linfo/t4w/vp/view/VideoPlayer;->gc_$M_w2$:F

    .line 143
    .line 144
    invoke-direct {v0, v3}, Landroidx/media3/common/PlaybackParameters;-><init>(F)V

    .line 145
    .line 146
    .line 147
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 148
    .line 149
    invoke-interface {v3, v0}, Landroidx/media3/common/Player;->setPlaybackParameters(Landroidx/media3/common/PlaybackParameters;)V

    .line 150
    .line 151
    .line 152
    :cond_6
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 153
    .line 154
    invoke-virtual {v0, v8}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 155
    .line 156
    .line 157
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->BCIm:Landroid/widget/ImageView;

    .line 158
    .line 159
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 160
    .line 161
    .line 162
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->zAt$p:Landroid/widget/ImageView;

    .line 163
    .line 164
    sget v1, LindeQ;->ic_fullscreen_exit:I

    .line 165
    .line 166
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 167
    .line 168
    .line 169
    iput-boolean v2, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 170
    .line 171
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 172
    .line 173
    invoke-interface {v0}, Landroidx/media3/common/Player;->play()V

    .line 174
    .line 175
    .line 176
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 5

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_9

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x4

    .line 16
    const/4 v2, 0x1

    .line 17
    if-eq v0, v1, :cond_8

    .line 18
    .line 19
    const/16 v1, 0x42

    .line 20
    .line 21
    if-eq v0, v1, :cond_7

    .line 22
    .line 23
    const/16 v1, 0x55

    .line 24
    .line 25
    if-eq v0, v1, :cond_4

    .line 26
    .line 27
    const/16 v1, 0x59

    .line 28
    .line 29
    const-wide/16 v3, 0x2710

    .line 30
    .line 31
    if-eq v0, v1, :cond_3

    .line 32
    .line 33
    const/16 v1, 0x5a

    .line 34
    .line 35
    if-eq v0, v1, :cond_2

    .line 36
    .line 37
    const/16 v1, 0x7e

    .line 38
    .line 39
    if-eq v0, v1, :cond_1

    .line 40
    .line 41
    const/16 v1, 0x7f

    .line 42
    .line 43
    if-eq v0, v1, :cond_0

    .line 44
    .line 45
    packed-switch v0, :pswitch_data_0

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 50
    .line 51
    if-eqz p1, :cond_6

    .line 52
    .line 53
    invoke-interface {p1}, Landroidx/media3/common/Player;->pause()V

    .line 54
    .line 55
    .line 56
    return v2

    .line 57
    :cond_1
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 58
    .line 59
    if-eqz p1, :cond_6

    .line 60
    .line 61
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 62
    .line 63
    .line 64
    return v2

    .line 65
    :cond_2
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 66
    .line 67
    if-eqz p1, :cond_6

    .line 68
    .line 69
    invoke-interface {p1}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 70
    .line 71
    .line 72
    move-result-wide v0

    .line 73
    add-long/2addr v0, v3

    .line 74
    invoke-interface {p1, v0, v1}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 75
    .line 76
    .line 77
    return v2

    .line 78
    :cond_3
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 79
    .line 80
    if-eqz p1, :cond_6

    .line 81
    .line 82
    invoke-interface {p1}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 83
    .line 84
    .line 85
    move-result-wide v0

    .line 86
    sub-long/2addr v0, v3

    .line 87
    const-wide/16 v3, 0x0

    .line 88
    .line 89
    invoke-static {v3, v4, v0, v1}, Ljava/lang/Math;->max(JJ)J

    .line 90
    .line 91
    .line 92
    move-result-wide v0

    .line 93
    invoke-interface {p1, v0, v1}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 94
    .line 95
    .line 96
    return v2

    .line 97
    :cond_4
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 98
    .line 99
    if-eqz p1, :cond_6

    .line 100
    .line 101
    invoke-interface {p1}, Landroidx/media3/common/Player;->isPlaying()Z

    .line 102
    .line 103
    .line 104
    move-result p1

    .line 105
    if-eqz p1, :cond_5

    .line 106
    .line 107
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 108
    .line 109
    invoke-interface {p1}, Landroidx/media3/common/Player;->pause()V

    .line 110
    .line 111
    .line 112
    return v2

    .line 113
    :cond_5
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 114
    .line 115
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 116
    .line 117
    .line 118
    :cond_6
    return v2

    .line 119
    :cond_7
    :pswitch_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 120
    .line 121
    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->isControllerFullyVisible()Z

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-nez v0, :cond_9

    .line 126
    .line 127
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 128
    .line 129
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->showController()V

    .line 130
    .line 131
    .line 132
    return v2

    .line 133
    :cond_8
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 134
    .line 135
    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->isControllerFullyVisible()Z

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    if-eqz v0, :cond_9

    .line 140
    .line 141
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 142
    .line 143
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->hideController()V

    .line 144
    .line 145
    .line 146
    return v2

    .line 147
    :cond_9
    :goto_0
    invoke-super {p0, p1}, LUd$5_1h$;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 148
    .line 149
    .line 150
    move-result p1

    .line 151
    return p1

    .line 152
    nop

    .line 153
    :pswitch_data_0
    .packed-switch 0x13
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public final enterPictureInPictureMode()V
    .locals 6

    .line 1
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1a

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-lt v0, v1, :cond_4

    .line 7
    .line 8
    invoke-static {}, LKcÒ2;->jPos3709()V

    .line 9
    .line 10
    .line 11
    invoke-static {}, LrMBhl;->JKEoÙX()Landroid/app/PictureInPictureParams$Builder;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 16
    .line 17
    if-eqz v3, :cond_0

    .line 18
    .line 19
    invoke-interface {v3}, Landroidx/media3/common/Player;->getVideoSize()Landroidx/media3/common/VideoSize;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    iget v3, v3, Landroidx/media3/common/VideoSize;->width:I

    .line 24
    .line 25
    if-lez v3, :cond_0

    .line 26
    .line 27
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 28
    .line 29
    invoke-interface {v3}, Landroidx/media3/common/Player;->getVideoSize()Landroidx/media3/common/VideoSize;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    iget v3, v3, Landroidx/media3/common/VideoSize;->height:I

    .line 34
    .line 35
    if-lez v3, :cond_0

    .line 36
    .line 37
    new-instance v3, Landroid/util/Rational;

    .line 38
    .line 39
    iget-object v4, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 40
    .line 41
    invoke-interface {v4}, Landroidx/media3/common/Player;->getVideoSize()Landroidx/media3/common/VideoSize;

    .line 42
    .line 43
    .line 44
    move-result-object v4

    .line 45
    iget v4, v4, Landroidx/media3/common/VideoSize;->width:I

    .line 46
    .line 47
    iget-object v5, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 48
    .line 49
    invoke-interface {v5}, Landroidx/media3/common/Player;->getVideoSize()Landroidx/media3/common/VideoSize;

    .line 50
    .line 51
    .line 52
    move-result-object v5

    .line 53
    iget v5, v5, Landroidx/media3/common/VideoSize;->height:I

    .line 54
    .line 55
    invoke-direct {v3, v4, v5}, Landroid/util/Rational;-><init>(II)V

    .line 56
    .line 57
    .line 58
    invoke-static {v1, v3}, LKcÒ2;->valuI(Landroid/app/PictureInPictureParams$Builder;Landroid/util/Rational;)V

    .line 59
    .line 60
    .line 61
    :cond_0
    const/16 v3, 0x1f

    .line 62
    .line 63
    if-lt v0, v3, :cond_1

    .line 64
    .line 65
    invoke-static {v1}, LVlO1I;->valuI(Landroid/app/PictureInPictureParams$Builder;)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 69
    .line 70
    if-eqz v0, :cond_1

    .line 71
    .line 72
    new-instance v0, Landroid/graphics/Rect;

    .line 73
    .line 74
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 75
    .line 76
    .line 77
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 78
    .line 79
    invoke-virtual {v3, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    .line 80
    .line 81
    .line 82
    invoke-static {v1, v0}, LrMBhl;->K0I(Landroid/app/PictureInPictureParams$Builder;Landroid/graphics/Rect;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 83
    .line 84
    .line 85
    :cond_1
    :try_start_1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 86
    .line 87
    if-eqz v0, :cond_3

    .line 88
    .line 89
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 90
    .line 91
    .line 92
    move-result-wide v3

    .line 93
    iput-wide v3, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 94
    .line 95
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 96
    .line 97
    invoke-virtual {v0}, Landroidx/media3/ui/PlayerView;->hideController()V

    .line 98
    .line 99
    .line 100
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 101
    .line 102
    invoke-interface {v0}, Landroidx/media3/common/Player;->isPlaying()Z

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    if-nez v0, :cond_2

    .line 107
    .line 108
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 109
    .line 110
    invoke-interface {v0}, Landroidx/media3/common/Player;->play()V

    .line 111
    .line 112
    .line 113
    :cond_2
    const/4 v0, 0x1

    .line 114
    iput-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 115
    .line 116
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 117
    .line 118
    .line 119
    move-result-object v3

    .line 120
    const/16 v4, 0x80

    .line 121
    .line 122
    invoke-virtual {v3, v4}, Landroid/view/Window;->addFlags(I)V

    .line 123
    .line 124
    .line 125
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 126
    .line 127
    invoke-virtual {v3, v0}, Landroid/view/View;->setKeepScreenOn(Z)V

    .line 128
    .line 129
    .line 130
    :cond_3
    invoke-static {v1}, LrMBhl;->tmpData3485(Landroid/app/PictureInPictureParams$Builder;)Landroid/app/PictureInPictureParams;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    invoke-static {p0, v0}, LKcÒ2;->Qp_Hp$i_(Linfo/t4w/vp/view/VideoPlayer;Landroid/app/PictureInPictureParams;)V

    .line 135
    .line 136
    .line 137
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 138
    .line 139
    if-eqz v0, :cond_5

    .line 140
    .line 141
    invoke-interface {v0}, Landroidx/media3/common/Player;->play()V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 142
    .line 143
    .line 144
    goto :goto_0

    .line 145
    :catch_0
    :try_start_2
    iput-boolean v2, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 146
    .line 147
    const-string v0, "Picture-in-Picture mode is not supported"

    .line 148
    .line 149
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 154
    .line 155
    .line 156
    goto :goto_0

    .line 157
    :cond_4
    const-string v0, "Picture-in-Picture mode requires Android 8.0 or later"

    .line 158
    .line 159
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 164
    .line 165
    .line 166
    :catch_1
    :cond_5
    :goto_0
    return-void
.end method

.method public final gSy_FG$D_([Landroidx/media3/common/Tracks$Group;)V
    .locals 12

    .line 1
    array-length v0, p1

    .line 2
    if-nez v0, :cond_0

    .line 3
    .line 4
    goto/16 :goto_5

    .line 5
    .line 6
    :cond_0
    array-length v0, p1

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    :goto_0
    const/4 v3, 0x0

    .line 10
    if-ge v2, v0, :cond_2

    .line 11
    .line 12
    aget-object v4, p1, v2

    .line 13
    .line 14
    iget v5, v4, Landroidx/media3/common/Tracks$Group;->length:I

    .line 15
    .line 16
    const/4 v6, 0x1

    .line 17
    if-le v5, v6, :cond_1

    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_1
    add-int/lit8 v2, v2, 0x1

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_2
    move-object v4, v3

    .line 24
    :goto_1
    if-nez v4, :cond_3

    .line 25
    .line 26
    const-string p1, "No multiple tracks available"

    .line 27
    .line 28
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_3
    iget p1, v4, Landroidx/media3/common/Tracks$Group;->length:I

    .line 37
    .line 38
    new-array v0, p1, [Ljava/lang/String;

    .line 39
    .line 40
    new-array v2, p1, [Z

    .line 41
    .line 42
    const/4 v5, 0x0

    .line 43
    :goto_2
    iget v6, v4, Landroidx/media3/common/Tracks$Group;->length:I

    .line 44
    .line 45
    if-ge v5, v6, :cond_a

    .line 46
    .line 47
    invoke-virtual {v4, v5}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(I)Z

    .line 48
    .line 49
    .line 50
    move-result v6

    .line 51
    if-eqz v6, :cond_9

    .line 52
    .line 53
    invoke-virtual {v4, v5}, Landroidx/media3/common/Tracks$Group;->getTrackFormat(I)Landroidx/media3/common/Format;

    .line 54
    .line 55
    .line 56
    move-result-object v6

    .line 57
    iget-object v7, v6, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    .line 58
    .line 59
    if-eqz v7, :cond_4

    .line 60
    .line 61
    goto :goto_3

    .line 62
    :cond_4
    iget-object v7, v6, Landroidx/media3/common/Format;->language:Ljava/lang/String;

    .line 63
    .line 64
    if-eqz v7, :cond_5

    .line 65
    .line 66
    goto :goto_3

    .line 67
    :cond_5
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 68
    .line 69
    .line 70
    move-result v7

    .line 71
    const/4 v8, 0x2

    .line 72
    if-ne v7, v8, :cond_7

    .line 73
    .line 74
    iget v7, v6, Landroidx/media3/common/Format;->width:I

    .line 75
    .line 76
    if-lez v7, :cond_6

    .line 77
    .line 78
    iget v7, v6, Landroidx/media3/common/Format;->height:I

    .line 79
    .line 80
    if-lez v7, :cond_6

    .line 81
    .line 82
    new-instance v7, Ljava/lang/StringBuilder;

    .line 83
    .line 84
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 85
    .line 86
    .line 87
    iget v8, v6, Landroidx/media3/common/Format;->width:I

    .line 88
    .line 89
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string v8, "x"

    .line 93
    .line 94
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    iget v8, v6, Landroidx/media3/common/Format;->height:I

    .line 98
    .line 99
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object v7

    .line 106
    iget v8, v6, Landroidx/media3/common/Format;->frameRate:F

    .line 107
    .line 108
    const/4 v9, 0x0

    .line 109
    cmpl-float v8, v8, v9

    .line 110
    .line 111
    if-lez v8, :cond_8

    .line 112
    .line 113
    const-string v8, " @ "

    .line 114
    .line 115
    invoke-static {v7, v8}, LRQU_K6$Kv_;->pCXDYg(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    move-result-object v7

    .line 119
    iget v6, v6, Landroidx/media3/common/Format;->frameRate:F

    .line 120
    .line 121
    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    .line 122
    .line 123
    .line 124
    move-result v6

    .line 125
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    const-string v6, "fps"

    .line 129
    .line 130
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    goto :goto_3

    .line 138
    :cond_6
    const-string v6, "Video Track "

    .line 139
    .line 140
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v7

    .line 144
    goto :goto_3

    .line 145
    :cond_7
    const-string v6, "Track "

    .line 146
    .line 147
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v7

    .line 151
    :cond_8
    :goto_3
    aput-object v7, v0, v5

    .line 152
    .line 153
    aput-boolean v1, v2, v5

    .line 154
    .line 155
    :cond_9
    add-int/lit8 v5, v5, 0x1

    .line 156
    .line 157
    goto :goto_2

    .line 158
    :cond_a
    sget v5, LindeQ;->ic_track_selection:I

    .line 159
    .line 160
    new-instance v6, LAz_Y_;

    .line 161
    .line 162
    const/16 v7, 0x13

    .line 163
    .line 164
    invoke-direct {v6, v7, p0, v4}, LAz_Y_;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 165
    .line 166
    .line 167
    const-string v4, "Select Multiple Tracks"

    .line 168
    .line 169
    invoke-static {p0, v4, v5}, LdQta;->tmpData3485(Landroid/app/Activity;Ljava/lang/String;I)Landroid/app/Dialog;

    .line 170
    .line 171
    .line 172
    move-result-object v4

    .line 173
    sget v5, LRO1QI;->options_dialog_title:I

    .line 174
    .line 175
    invoke-virtual {v4, v5}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    .line 176
    .line 177
    .line 178
    move-result-object v5

    .line 179
    invoke-virtual {v5}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 180
    .line 181
    .line 182
    move-result-object v5

    .line 183
    sget v7, LRO1QI;->options_container:I

    .line 184
    .line 185
    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 186
    .line 187
    .line 188
    move-result-object v7

    .line 189
    check-cast v7, Landroid/widget/LinearLayout;

    .line 190
    .line 191
    sget v8, LvKey3407;->text_primary:I

    .line 192
    .line 193
    invoke-static {p0, v8}, LvData2646;->vaIue(Landroid/content/Context;I)I

    .line 194
    .line 195
    .line 196
    move-result v8

    .line 197
    const/4 v9, 0x0

    .line 198
    :goto_4
    if-ge v9, p1, :cond_b

    .line 199
    .line 200
    aget-boolean v10, v2, v9

    .line 201
    .line 202
    aget-object v11, v0, v9

    .line 203
    .line 204
    invoke-static {p0, v11, v10}, LdQta;->sKey7917(Landroid/app/Activity;Ljava/lang/String;Z)Landroid/widget/TextView;

    .line 205
    .line 206
    .line 207
    move-result-object v10

    .line 208
    invoke-static {p0}, LdQta;->yàÒZ(Landroid/app/Activity;)Landroid/widget/LinearLayout$LayoutParams;

    .line 209
    .line 210
    .line 211
    move-result-object v11

    .line 212
    invoke-virtual {v7, v10, v11}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 213
    .line 214
    .line 215
    new-instance v11, LDn$oQ$;

    .line 216
    .line 217
    invoke-direct {v11, v10, v8}, LDn$oQ$;-><init>(Landroid/widget/TextView;I)V

    .line 218
    .line 219
    .line 220
    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 221
    .line 222
    .line 223
    add-int/lit8 v9, v9, 0x1

    .line 224
    .line 225
    goto :goto_4

    .line 226
    :cond_b
    sget p1, LRO1QI;->options_apply_button:I

    .line 227
    .line 228
    invoke-virtual {v5, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 229
    .line 230
    .line 231
    move-result-object p1

    .line 232
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 233
    .line 234
    .line 235
    new-instance v0, LHEMimY;

    .line 236
    .line 237
    invoke-direct {v0, v7, v4, v6}, LHEMimY;-><init>(Landroid/widget/LinearLayout;Landroid/app/Dialog;LAz_Y_;)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v4}, Landroid/app/Dialog;->show()V

    .line 244
    .line 245
    .line 246
    invoke-virtual {v7}, Landroid/view/ViewGroup;->getChildCount()I

    .line 247
    .line 248
    .line 249
    move-result p1

    .line 250
    if-lez p1, :cond_c

    .line 251
    .line 252
    invoke-virtual {v7, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 253
    .line 254
    .line 255
    move-result-object v3

    .line 256
    :cond_c
    if-eqz v3, :cond_d

    .line 257
    .line 258
    invoke-virtual {v3}, Landroid/view/View;->requestFocus()Z

    .line 259
    .line 260
    .line 261
    :cond_d
    :goto_5
    return-void
.end method

.method public final iSize4906(Landroidx/media3/common/Player;)V
    .locals 4

    .line 1
    if-eqz p1, :cond_2

    .line 2
    .line 3
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 4
    .line 5
    if-ne v0, p1, :cond_0

    .line 6
    .line 7
    goto :goto_1

    .line 8
    :cond_0
    if-eqz v0, :cond_1

    .line 9
    .line 10
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 15
    .line 16
    invoke-interface {v2}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 21
    .line 22
    invoke-interface {v3}, Landroidx/media3/common/Player;->stop()V

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    const-wide/16 v0, 0x0

    .line 27
    .line 28
    const/4 v2, 0x0

    .line 29
    :goto_0
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 30
    .line 31
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 32
    .line 33
    invoke-virtual {v3, p1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 34
    .line 35
    .line 36
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 37
    .line 38
    if-eqz v3, :cond_2

    .line 39
    .line 40
    invoke-interface {p1, v3, v0, v1}, Landroidx/media3/common/Player;->setMediaItem(Landroidx/media3/common/MediaItem;J)V

    .line 41
    .line 42
    .line 43
    invoke-interface {p1}, Landroidx/media3/common/Player;->prepare()V

    .line 44
    .line 45
    .line 46
    invoke-interface {p1, v2}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 47
    .line 48
    .line 49
    iget v0, p0, Linfo/t4w/vp/view/VideoPlayer;->gc_$M_w2$:F

    .line 50
    .line 51
    const/high16 v1, 0x3f800000    # 1.0f

    .line 52
    .line 53
    cmpl-float v0, v0, v1

    .line 54
    .line 55
    if-eqz v0, :cond_2

    .line 56
    .line 57
    new-instance v0, Landroidx/media3/common/PlaybackParameters;

    .line 58
    .line 59
    iget v1, p0, Linfo/t4w/vp/view/VideoPlayer;->gc_$M_w2$:F

    .line 60
    .line 61
    invoke-direct {v0, v1}, Landroidx/media3/common/PlaybackParameters;-><init>(F)V

    .line 62
    .line 63
    .line 64
    invoke-interface {p1, v0}, Landroidx/media3/common/Player;->setPlaybackParameters(Landroidx/media3/common/PlaybackParameters;)V

    .line 65
    .line 66
    .line 67
    :cond_2
    :goto_1
    return-void
.end method

.method public final kCount1402([Landroidx/media3/common/Tracks$Group;I)V
    .locals 9

    .line 1
    array-length v0, p1

    .line 2
    const/4 v1, 0x0

    .line 3
    const/4 v2, 0x0

    .line 4
    const/4 v3, -0x1

    .line 5
    const/4 v4, 0x0

    .line 6
    const/4 v5, 0x0

    .line 7
    :goto_0
    if-ge v4, v0, :cond_4

    .line 8
    .line 9
    aget-object v6, p1, v4

    .line 10
    .line 11
    const/4 v7, 0x0

    .line 12
    :goto_1
    iget v8, v6, Landroidx/media3/common/Tracks$Group;->length:I

    .line 13
    .line 14
    if-ge v7, v8, :cond_2

    .line 15
    .line 16
    invoke-virtual {v6, v7}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(I)Z

    .line 17
    .line 18
    .line 19
    move-result v8

    .line 20
    if-eqz v8, :cond_1

    .line 21
    .line 22
    if-ne v5, p2, :cond_0

    .line 23
    .line 24
    move-object v2, v6

    .line 25
    move v3, v7

    .line 26
    goto :goto_2

    .line 27
    :cond_0
    add-int/lit8 v5, v5, 0x1

    .line 28
    .line 29
    :cond_1
    add-int/lit8 v7, v7, 0x1

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_2
    :goto_2
    if-eqz v2, :cond_3

    .line 33
    .line 34
    goto :goto_3

    .line 35
    :cond_3
    add-int/lit8 v4, v4, 0x1

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_4
    :goto_3
    if-eqz v2, :cond_5

    .line 39
    .line 40
    if-ltz v3, :cond_5

    .line 41
    .line 42
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 43
    .line 44
    invoke-interface {p1}, Landroidx/media3/common/Player;->getTrackSelectionParameters()Landroidx/media3/common/TrackSelectionParameters;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 49
    .line 50
    .line 51
    move-result-object p1

    .line 52
    new-instance p2, Landroidx/media3/common/TrackSelectionOverride;

    .line 53
    .line 54
    invoke-virtual {v2}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    invoke-static {v1}, LleOgth;->pCXDYg(Ljava/lang/Object;)LrÒTB;

    .line 63
    .line 64
    .line 65
    move-result-object v1

    .line 66
    invoke-direct {p2, v0, v1}, Landroidx/media3/common/TrackSelectionOverride;-><init>(Landroidx/media3/common/TrackGroup;Ljava/util/List;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1, p2}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setOverrideForType(Landroidx/media3/common/TrackSelectionOverride;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 70
    .line 71
    .line 72
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 73
    .line 74
    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    .line 75
    .line 76
    .line 77
    move-result-object p1

    .line 78
    invoke-interface {p2, p1}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    .line 79
    .line 80
    .line 81
    :cond_5
    return-void
.end method

.method public final l1(Ljava/lang/String;Ljava/lang/String;)V
    .locals 11

    .line 1
    const-string v0, "data:application/json;base64,"

    .line 2
    .line 3
    if-eqz p1, :cond_c

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    goto/16 :goto_6

    .line 12
    .line 13
    :cond_0
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 14
    .line 15
    if-nez v1, :cond_1

    .line 16
    .line 17
    goto/16 :goto_7

    .line 18
    .line 19
    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    const/16 v2, 0x80

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Landroid/view/Window;->addFlags(I)V

    .line 26
    .line 27
    .line 28
    if-eqz p2, :cond_2

    .line 29
    .line 30
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-nez v1, :cond_2

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_2
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->jI:Ljava/lang/String;

    .line 38
    .line 39
    :goto_0
    iput-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->lelgth:Ljava/lang/String;

    .line 40
    .line 41
    const-string p2, "###"

    .line 42
    .line 43
    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    const/4 v2, 0x0

    .line 48
    const/4 v3, 0x1

    .line 49
    const/4 v4, 0x0

    .line 50
    const/4 v5, 0x2

    .line 51
    if-eqz v1, :cond_3

    .line 52
    .line 53
    invoke-virtual {p1, p2, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    array-length v1, p2

    .line 58
    if-ne v1, v5, :cond_3

    .line 59
    .line 60
    aget-object v1, p2, v4

    .line 61
    .line 62
    aget-object p2, p2, v3

    .line 63
    .line 64
    :try_start_0
    invoke-virtual {p0, p2}, Linfo/t4w/vp/view/VideoPlayer;->Q1_f_(Ljava/lang/String;)Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;

    .line 65
    .line 66
    .line 67
    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    goto :goto_1

    .line 69
    :catch_0
    const-string v6, "Error setting up DRM "

    .line 70
    .line 71
    invoke-static {p0, v6, v3}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 72
    .line 73
    .line 74
    move-result-object v6

    .line 75
    invoke-virtual {v6}, Landroid/widget/Toast;->show()V

    .line 76
    .line 77
    .line 78
    goto :goto_1

    .line 79
    :cond_3
    move-object v1, p1

    .line 80
    move-object p2, v2

    .line 81
    :goto_1
    invoke-static {v1}, Linfo/t4w/vp/view/VideoPlayer;->tzKù7Ol1(Ljava/lang/String;)Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v6

    .line 85
    new-instance v7, Landroidx/media3/common/MediaItem$Builder;

    .line 86
    .line 87
    invoke-direct {v7}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v7, v1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 91
    .line 92
    .line 93
    move-result-object v7

    .line 94
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 95
    .line 96
    .line 97
    move-result v8

    .line 98
    if-nez v8, :cond_4

    .line 99
    .line 100
    invoke-virtual {v7, v6}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 101
    .line 102
    .line 103
    :cond_4
    invoke-static {v7, v1}, Linfo/t4w/vp/view/VideoPlayer;->UC_n_(Landroidx/media3/common/MediaItem$Builder;Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    if-eqz v2, :cond_5

    .line 107
    .line 108
    sget-object v8, Landroidx/media3/common/C;->CLEARKEY_UUID:Ljava/util/UUID;

    .line 109
    .line 110
    invoke-virtual {v7, v8}, Landroidx/media3/common/MediaItem$Builder;->setDrmUuid(Ljava/util/UUID;)Landroidx/media3/common/MediaItem$Builder;

    .line 111
    .line 112
    .line 113
    move-result-object v8

    .line 114
    invoke-virtual {v8, v4}, Landroidx/media3/common/MediaItem$Builder;->setDrmMultiSession(Z)Landroidx/media3/common/MediaItem$Builder;

    .line 115
    .line 116
    .line 117
    :cond_5
    invoke-virtual {v7}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 118
    .line 119
    .line 120
    move-result-object v7

    .line 121
    iput-object v7, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 122
    .line 123
    iget-object v8, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 124
    .line 125
    iget-object v9, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 126
    .line 127
    if-ne v8, v9, :cond_8

    .line 128
    .line 129
    invoke-virtual {v9}, Landroidx/media3/cast/CastPlayer;->isCastSessionAvailable()Z

    .line 130
    .line 131
    .line 132
    move-result v8

    .line 133
    if-eqz v8, :cond_8

    .line 134
    .line 135
    new-instance p1, Landroidx/media3/common/MediaItem$Builder;

    .line 136
    .line 137
    invoke-direct {p1}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 138
    .line 139
    .line 140
    invoke-virtual {p1, v1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 141
    .line 142
    .line 143
    move-result-object p1

    .line 144
    invoke-virtual {v6}, Ljava/lang/String;->isEmpty()Z

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    if-nez v1, :cond_6

    .line 149
    .line 150
    invoke-virtual {p1, v6}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 151
    .line 152
    .line 153
    :cond_6
    if-eqz v2, :cond_7

    .line 154
    .line 155
    if-eqz p2, :cond_7

    .line 156
    .line 157
    :try_start_1
    invoke-virtual {p0, p2}, Linfo/t4w/vp/view/VideoPlayer;->tmpSize211(Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    sget-object v1, Landroidx/media3/common/C;->CLEARKEY_UUID:Ljava/util/UUID;

    .line 162
    .line 163
    invoke-virtual {p1, v1}, Landroidx/media3/common/MediaItem$Builder;->setDrmUuid(Ljava/util/UUID;)Landroidx/media3/common/MediaItem$Builder;

    .line 164
    .line 165
    .line 166
    move-result-object v1

    .line 167
    new-instance v2, Ljava/lang/StringBuilder;

    .line 168
    .line 169
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {p2}, Ljava/lang/String;->getBytes()[B

    .line 173
    .line 174
    .line 175
    move-result-object p2

    .line 176
    invoke-static {p2, v5}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 177
    .line 178
    .line 179
    move-result-object p2

    .line 180
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object p2

    .line 187
    invoke-virtual {v1, p2}, Landroidx/media3/common/MediaItem$Builder;->setDrmLicenseUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 188
    .line 189
    .line 190
    move-result-object p2

    .line 191
    invoke-virtual {p2, v4}, Landroidx/media3/common/MediaItem$Builder;->setDrmMultiSession(Z)Landroidx/media3/common/MediaItem$Builder;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 192
    .line 193
    .line 194
    goto :goto_2

    .line 195
    :catch_1
    move-exception p2

    .line 196
    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    :cond_7
    :goto_2
    invoke-virtual {p1}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 200
    .line 201
    .line 202
    move-result-object p1

    .line 203
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 204
    .line 205
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 206
    .line 207
    invoke-virtual {p2, p1}, Landroidx/media3/common/BasePlayer;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 208
    .line 209
    .line 210
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 211
    .line 212
    invoke-virtual {p1}, Landroidx/media3/cast/CastPlayer;->prepare()V

    .line 213
    .line 214
    .line 215
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 216
    .line 217
    invoke-virtual {p1}, Landroidx/media3/common/BasePlayer;->play()V

    .line 218
    .line 219
    .line 220
    goto/16 :goto_5

    .line 221
    .line 222
    :cond_8
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 223
    .line 224
    invoke-interface {p2}, Landroidx/media3/common/Player;->stop()V

    .line 225
    .line 226
    .line 227
    new-instance p2, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 228
    .line 229
    invoke-direct {p2, p0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    .line 230
    .line 231
    .line 232
    new-instance v0, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    .line 233
    .line 234
    invoke-direct {v0}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;-><init>()V

    .line 235
    .line 236
    .line 237
    const/16 v6, 0x9c4

    .line 238
    .line 239
    const/16 v8, 0x1388

    .line 240
    .line 241
    const/16 v9, 0x7530

    .line 242
    .line 243
    const v10, 0x1d4c0

    .line 244
    .line 245
    .line 246
    invoke-virtual {v0, v9, v10, v6, v8}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBufferDurationsMs(IIII)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    invoke-virtual {v0, v10, v3}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBackBuffer(IZ)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    invoke-virtual {v0}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->build()Landroidx/media3/exoplayer/DefaultLoadControl;

    .line 255
    .line 256
    .line 257
    move-result-object v0

    .line 258
    invoke-virtual {p2, v0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setLoadControl(Landroidx/media3/exoplayer/LoadControl;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 259
    .line 260
    .line 261
    new-instance v0, Landroidx/media3/exoplayer/DefaultRenderersFactory;

    .line 262
    .line 263
    invoke-direct {v0, p0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;-><init>(Landroid/content/Context;)V

    .line 264
    .line 265
    .line 266
    invoke-virtual {v0, v5}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setExtensionRendererMode(I)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    .line 267
    .line 268
    .line 269
    move-result-object v0

    .line 270
    invoke-virtual {p2, v0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setRenderersFactory(Landroidx/media3/exoplayer/RenderersFactory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 271
    .line 272
    .line 273
    new-instance v0, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 274
    .line 275
    invoke-direct {v0}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    .line 276
    .line 277
    .line 278
    iget-object v5, p0, Linfo/t4w/vp/view/VideoPlayer;->lelgth:Ljava/lang/String;

    .line 279
    .line 280
    invoke-virtual {v0, v5}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 281
    .line 282
    .line 283
    move-result-object v0

    .line 284
    invoke-virtual {v0, v3}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setAllowCrossProtocolRedirects(Z)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 285
    .line 286
    .line 287
    move-result-object v0

    .line 288
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 289
    .line 290
    if-eqz v3, :cond_9

    .line 291
    .line 292
    invoke-virtual {v3}, Ljava/util/HashMap;->isEmpty()Z

    .line 293
    .line 294
    .line 295
    move-result v3

    .line 296
    if-nez v3, :cond_9

    .line 297
    .line 298
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 299
    .line 300
    invoke-virtual {v0, v3}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setDefaultRequestProperties(Ljava/util/Map;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 301
    .line 302
    .line 303
    :cond_9
    invoke-virtual {p0, v7, v0, v2}, Linfo/t4w/vp/view/VideoPlayer;->$ÒcdS(Landroidx/media3/common/MediaItem;Landroidx/media3/datasource/DefaultHttpDataSource$Factory;Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;)Landroidx/media3/exoplayer/source/BaseMediaSource;

    .line 304
    .line 305
    .line 306
    new-instance v3, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 307
    .line 308
    invoke-direct {v3, p0}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;-><init>(Landroid/content/Context;)V

    .line 309
    .line 310
    .line 311
    invoke-virtual {p2, v3}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setMediaSourceFactory(Landroidx/media3/exoplayer/source/MediaSource$Factory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 312
    .line 313
    .line 314
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 315
    .line 316
    invoke-interface {v3}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    .line 317
    .line 318
    .line 319
    invoke-virtual {p2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    .line 320
    .line 321
    .line 322
    move-result-object p2

    .line 323
    iput-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 324
    .line 325
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 326
    .line 327
    invoke-virtual {v3, p2}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 328
    .line 329
    .line 330
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 331
    .line 332
    invoke-static {v1}, Linfo/t4w/vp/view/VideoPlayer;->Oey(Ljava/lang/String;)Z

    .line 333
    .line 334
    .line 335
    move-result v1

    .line 336
    if-nez v1, :cond_a

    .line 337
    .line 338
    goto :goto_3

    .line 339
    :cond_a
    new-instance v1, LxQ$D__g$;

    .line 340
    .line 341
    invoke-direct {v1, p2}, LxQ$D__g$;-><init>(Landroidx/media3/exoplayer/ExoPlayer;)V

    .line 342
    .line 343
    .line 344
    invoke-interface {p2, v1}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 345
    .line 346
    .line 347
    :goto_3
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 348
    .line 349
    new-instance v1, LXsìGsB;

    .line 350
    .line 351
    invoke-direct {v1, p0, p1}, LXsìGsB;-><init>(Linfo/t4w/vp/view/VideoPlayer;Ljava/lang/String;)V

    .line 352
    .line 353
    .line 354
    invoke-interface {p2, v1}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 355
    .line 356
    .line 357
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 358
    .line 359
    if-nez p1, :cond_b

    .line 360
    .line 361
    goto :goto_4

    .line 362
    :cond_b
    new-instance p2, LPUS_x_;

    .line 363
    .line 364
    invoke-direct {p2, p0}, LPUS_x_;-><init>(Linfo/t4w/vp/view/VideoPlayer;)V

    .line 365
    .line 366
    .line 367
    invoke-interface {p1, p2}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 368
    .line 369
    .line 370
    :goto_4
    invoke-virtual {p0, v7, v0, v2}, Linfo/t4w/vp/view/VideoPlayer;->$ÒcdS(Landroidx/media3/common/MediaItem;Landroidx/media3/datasource/DefaultHttpDataSource$Factory;Landroidx/media3/exoplayer/drm/DefaultDrmSessionManager;)Landroidx/media3/exoplayer/source/BaseMediaSource;

    .line 371
    .line 372
    .line 373
    move-result-object p1

    .line 374
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 375
    .line 376
    invoke-interface {p2, p1}, Landroidx/media3/exoplayer/ExoPlayer;->setMediaSource(Landroidx/media3/exoplayer/source/MediaSource;)V

    .line 377
    .line 378
    .line 379
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 380
    .line 381
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 382
    .line 383
    invoke-interface {p1}, Landroidx/media3/common/Player;->getTrackSelectionParameters()Landroidx/media3/common/TrackSelectionParameters;

    .line 384
    .line 385
    .line 386
    move-result-object p1

    .line 387
    iget-object p2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 388
    .line 389
    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 390
    .line 391
    .line 392
    move-result-object p1

    .line 393
    const-string v0, "ara"

    .line 394
    .line 395
    invoke-virtual {p1, v0}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setPreferredAudioLanguage(Ljava/lang/String;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 396
    .line 397
    .line 398
    move-result-object p1

    .line 399
    invoke-virtual {p1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    .line 400
    .line 401
    .line 402
    move-result-object p1

    .line 403
    invoke-interface {p2, p1}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    .line 404
    .line 405
    .line 406
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 407
    .line 408
    invoke-interface {p1}, Landroidx/media3/common/Player;->prepare()V

    .line 409
    .line 410
    .line 411
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 412
    .line 413
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 414
    .line 415
    .line 416
    :goto_5
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 417
    .line 418
    invoke-virtual {p1, v4}, Landroidx/media3/ui/PlayerView;->setVisibility(I)V

    .line 419
    .line 420
    .line 421
    return-void

    .line 422
    :cond_c
    :goto_6
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 423
    .line 424
    if-eqz p1, :cond_d

    .line 425
    .line 426
    invoke-interface {p1}, Landroidx/media3/common/Player;->stop()V

    .line 427
    .line 428
    .line 429
    :cond_d
    :goto_7
    return-void
.end method

.method public final oaX_6_()V
    .locals 11

    .line 1
    const-string v0, "urlvqlay://"

    .line 2
    .line 3
    const-string v1, "urlvplay://"

    .line 4
    .line 5
    const-string v2, "urlvplayer://"

    .line 6
    .line 7
    const-string v3, "urlplayer://"

    .line 8
    .line 9
    const/4 v4, 0x1

    .line 10
    :try_start_0
    iget-object v5, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 11
    .line 12
    invoke-virtual {v5, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 16
    const-string v6, "blue"

    .line 17
    .line 18
    const-string v7, "agent"

    .line 19
    .line 20
    const-string v8, "url"

    .line 21
    .line 22
    const-string v9, "android.intent.action.VIEW"

    .line 23
    .line 24
    const-class v10, Linfo/t4w/vp/view/VideoPlayer;

    .line 25
    .line 26
    if-eqz v5, :cond_0

    .line 27
    .line 28
    :try_start_1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 29
    .line 30
    invoke-virtual {v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    aget-object v0, v0, v4

    .line 35
    .line 36
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 37
    .line 38
    new-instance v0, Landroid/content/Intent;

    .line 39
    .line 40
    invoke-direct {v0, p0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 41
    .line 42
    .line 43
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 44
    .line 45
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    invoke-virtual {v1, v9}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 54
    .line 55
    .line 56
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 57
    .line 58
    invoke-virtual {v0, v8, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 59
    .line 60
    .line 61
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 62
    .line 63
    invoke-virtual {v0, v7, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 67
    .line 68
    .line 69
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 73
    .line 74
    invoke-interface {v0}, Landroidx/media3/common/Player;->stop()V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 78
    .line 79
    .line 80
    goto/16 :goto_0

    .line 81
    .line 82
    :catch_0
    nop

    .line 83
    goto/16 :goto_0

    .line 84
    .line 85
    :cond_0
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {v3, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 88
    .line 89
    .line 90
    move-result v3

    .line 91
    if-eqz v3, :cond_1

    .line 92
    .line 93
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 94
    .line 95
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    aget-object v0, v0, v4

    .line 100
    .line 101
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 102
    .line 103
    new-instance v0, Landroid/content/Intent;

    .line 104
    .line 105
    invoke-direct {v0, p0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 106
    .line 107
    .line 108
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 109
    .line 110
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 115
    .line 116
    .line 117
    move-result-object v1

    .line 118
    invoke-virtual {v1, v9}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 119
    .line 120
    .line 121
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 122
    .line 123
    invoke-virtual {v0, v8, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 124
    .line 125
    .line 126
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 127
    .line 128
    invoke-virtual {v0, v7, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v0, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 132
    .line 133
    .line 134
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 135
    .line 136
    .line 137
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 138
    .line 139
    invoke-interface {v0}, Landroidx/media3/common/Player;->stop()V

    .line 140
    .line 141
    .line 142
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 143
    .line 144
    .line 145
    goto/16 :goto_0

    .line 146
    .line 147
    :cond_1
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 148
    .line 149
    invoke-virtual {v2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    if-eqz v2, :cond_2

    .line 154
    .line 155
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 156
    .line 157
    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    aget-object v0, v0, v4

    .line 162
    .line 163
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 164
    .line 165
    new-instance v0, Landroid/content/Intent;

    .line 166
    .line 167
    invoke-direct {v0, p0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 168
    .line 169
    .line 170
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 171
    .line 172
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 173
    .line 174
    .line 175
    move-result-object v1

    .line 176
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 177
    .line 178
    .line 179
    move-result-object v1

    .line 180
    invoke-virtual {v1, v9}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 181
    .line 182
    .line 183
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 184
    .line 185
    invoke-virtual {v0, v8, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 186
    .line 187
    .line 188
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 189
    .line 190
    invoke-virtual {v0, v7, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 191
    .line 192
    .line 193
    invoke-virtual {v0, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 194
    .line 195
    .line 196
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 197
    .line 198
    .line 199
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 200
    .line 201
    invoke-interface {v0}, Landroidx/media3/common/Player;->stop()V

    .line 202
    .line 203
    .line 204
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 205
    .line 206
    .line 207
    goto :goto_0

    .line 208
    :cond_2
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 209
    .line 210
    invoke-virtual {v1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 211
    .line 212
    .line 213
    move-result v1

    .line 214
    if-eqz v1, :cond_3

    .line 215
    .line 216
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 217
    .line 218
    invoke-virtual {v1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    aget-object v0, v0, v4

    .line 223
    .line 224
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 225
    .line 226
    new-instance v0, Landroid/content/Intent;

    .line 227
    .line 228
    invoke-direct {v0, p0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 229
    .line 230
    .line 231
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 232
    .line 233
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 234
    .line 235
    .line 236
    move-result-object v1

    .line 237
    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 238
    .line 239
    .line 240
    move-result-object v1

    .line 241
    invoke-virtual {v1, v9}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 242
    .line 243
    .line 244
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 245
    .line 246
    invoke-virtual {v0, v8, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 247
    .line 248
    .line 249
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 250
    .line 251
    invoke-virtual {v0, v7, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 252
    .line 253
    .line 254
    invoke-virtual {v0, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 255
    .line 256
    .line 257
    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 258
    .line 259
    .line 260
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 261
    .line 262
    invoke-interface {v0}, Landroidx/media3/common/Player;->stop()V

    .line 263
    .line 264
    .line 265
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 266
    .line 267
    .line 268
    :cond_3
    :goto_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 269
    .line 270
    invoke-interface {v0, v4}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 271
    .line 272
    .line 273
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 274
    .line 275
    invoke-interface {v0}, Landroidx/media3/common/Player;->getPlaybackState()I

    .line 276
    .line 277
    .line 278
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 279
    .line 280
    invoke-interface {v0}, Landroidx/media3/common/Player;->play()V

    .line 281
    .line 282
    .line 283
    iget-wide v0, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 284
    .line 285
    const-wide/16 v2, 0x1

    .line 286
    .line 287
    cmp-long v4, v0, v2

    .line 288
    .line 289
    if-lez v4, :cond_4

    .line 290
    .line 291
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 292
    .line 293
    invoke-interface {v2, v0, v1}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 294
    .line 295
    .line 296
    :cond_4
    return-void
.end method

.method public final onBackPressed()V
    .locals 1

    .line 1
    invoke-virtual {p0}, LUd$5_1h$;->kQy()LvItem2059;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, LisCount8814;->POOl:Ljava/util/ArrayList;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :goto_0
    if-lez v0, :cond_1

    .line 16
    .line 17
    invoke-super {p0}, LqboÌWm;->onBackPressed()V

    .line 18
    .line 19
    .line 20
    return-void

    .line 21
    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->isTaskRoot()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_2

    .line 26
    .line 27
    invoke-super {p0}, LqboÌWm;->onBackPressed()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_2
    invoke-virtual {p0}, Landroid/app/Activity;->finishAffinity()V

    .line 32
    .line 33
    .line 34
    return-void
.end method

.method public final onCastSessionAvailable()V
    .locals 11

    .line 1
    const-string v0, "###"

    .line 2
    .line 3
    const-string v1, "data:application/json;base64,"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    :try_start_0
    iget-object v3, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 7
    .line 8
    const-string v4, "Cast player not available"

    .line 9
    .line 10
    if-eqz v3, :cond_a

    .line 11
    .line 12
    :try_start_1
    iget-object v5, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 13
    .line 14
    if-eqz v5, :cond_a

    .line 15
    .line 16
    iget-object v5, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 17
    .line 18
    if-eqz v5, :cond_0

    .line 19
    .line 20
    invoke-interface {v5}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 21
    .line 22
    .line 23
    move-result-wide v5

    .line 24
    goto :goto_0

    .line 25
    :catch_0
    move-exception v0

    .line 26
    goto/16 :goto_2

    .line 27
    .line 28
    :cond_0
    const-wide/16 v5, 0x0

    .line 29
    .line 30
    :goto_0
    new-instance v7, Landroidx/media3/common/MediaItem$Builder;

    .line 31
    .line 32
    invoke-direct {v7}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 33
    .line 34
    .line 35
    iget-object v8, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 36
    .line 37
    iget-object v8, v8, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 38
    .line 39
    invoke-virtual {v7, v8}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    .line 40
    .line 41
    .line 42
    move-result-object v7

    .line 43
    iget-object v8, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 44
    .line 45
    iget-object v8, v8, Landroidx/media3/common/MediaItem$LocalConfiguration;->mimeType:Ljava/lang/String;

    .line 46
    .line 47
    if-eqz v8, :cond_1

    .line 48
    .line 49
    invoke-virtual {v7, v8}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 50
    .line 51
    .line 52
    :cond_1
    iget-object v8, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 53
    .line 54
    iget-object v9, v8, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 55
    .line 56
    if-eqz v9, :cond_5

    .line 57
    .line 58
    iget-object v8, v8, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 59
    .line 60
    invoke-virtual {v8}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v8

    .line 64
    invoke-virtual {v8, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 65
    .line 66
    .line 67
    move-result v9

    .line 68
    if-eqz v9, :cond_2

    .line 69
    .line 70
    const/4 v9, 0x2

    .line 71
    invoke-virtual {v8, v0, v9}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    array-length v8, v0

    .line 76
    if-ne v8, v9, :cond_5

    .line 77
    .line 78
    aget-object v8, v0, v2

    .line 79
    .line 80
    invoke-static {v8}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 81
    .line 82
    .line 83
    move-result-object v8

    .line 84
    invoke-virtual {v7, v8}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 85
    .line 86
    .line 87
    const/4 v8, 0x1

    .line 88
    :try_start_2
    aget-object v0, v0, v8

    .line 89
    .line 90
    invoke-virtual {p0, v0}, Linfo/t4w/vp/view/VideoPlayer;->tmpSize211(Ljava/lang/String;)Ljava/lang/String;

    .line 91
    .line 92
    .line 93
    move-result-object v0

    .line 94
    sget-object v8, Landroidx/media3/common/C;->CLEARKEY_UUID:Ljava/util/UUID;

    .line 95
    .line 96
    invoke-virtual {v7, v8}, Landroidx/media3/common/MediaItem$Builder;->setDrmUuid(Ljava/util/UUID;)Landroidx/media3/common/MediaItem$Builder;

    .line 97
    .line 98
    .line 99
    move-result-object v8

    .line 100
    new-instance v10, Ljava/lang/StringBuilder;

    .line 101
    .line 102
    invoke-direct {v10, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-static {v0, v9}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    invoke-virtual {v8, v0}, Landroidx/media3/common/MediaItem$Builder;->setDrmLicenseUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    invoke-virtual {v0, v2}, Landroidx/media3/common/MediaItem$Builder;->setDrmMultiSession(Z)Landroidx/media3/common/MediaItem$Builder;
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 125
    .line 126
    .line 127
    goto :goto_1

    .line 128
    :catch_1
    move-exception v0

    .line 129
    :try_start_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    goto :goto_1

    .line 133
    :cond_2
    iget-object v0, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 134
    .line 135
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 136
    .line 137
    iget-object v0, v0, Landroidx/media3/common/MediaItem$DrmConfiguration;->uuid:Ljava/util/UUID;

    .line 138
    .line 139
    if-eqz v0, :cond_3

    .line 140
    .line 141
    invoke-virtual {v7, v0}, Landroidx/media3/common/MediaItem$Builder;->setDrmUuid(Ljava/util/UUID;)Landroidx/media3/common/MediaItem$Builder;

    .line 142
    .line 143
    .line 144
    :cond_3
    iget-object v0, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 145
    .line 146
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 147
    .line 148
    iget-object v0, v0, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseUri:Landroid/net/Uri;

    .line 149
    .line 150
    if-eqz v0, :cond_4

    .line 151
    .line 152
    invoke-virtual {v7, v0}, Landroidx/media3/common/MediaItem$Builder;->setDrmLicenseUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    .line 153
    .line 154
    .line 155
    :cond_4
    iget-object v0, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 156
    .line 157
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 158
    .line 159
    iget-boolean v0, v0, Landroidx/media3/common/MediaItem$DrmConfiguration;->multiSession:Z

    .line 160
    .line 161
    invoke-virtual {v7, v0}, Landroidx/media3/common/MediaItem$Builder;->setDrmMultiSession(Z)Landroidx/media3/common/MediaItem$Builder;

    .line 162
    .line 163
    .line 164
    :cond_5
    :goto_1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 165
    .line 166
    if-eqz v0, :cond_6

    .line 167
    .line 168
    invoke-virtual {v0}, Ljava/util/HashMap;->isEmpty()Z

    .line 169
    .line 170
    .line 171
    move-result v0

    .line 172
    if-eqz v0, :cond_7

    .line 173
    .line 174
    :cond_6
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->lelgth:Ljava/lang/String;

    .line 175
    .line 176
    if-eqz v0, :cond_8

    .line 177
    .line 178
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 179
    .line 180
    .line 181
    move-result v0

    .line 182
    if-nez v0, :cond_8

    .line 183
    .line 184
    :cond_7
    iget-object v0, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 185
    .line 186
    iget-object v0, v0, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 187
    .line 188
    invoke-virtual {v7, v0}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    iget-object v1, v3, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 193
    .line 194
    iget-object v1, v1, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 195
    .line 196
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-virtual {v0, v1}, Landroidx/media3/common/MediaItem$Builder;->setCustomCacheKey(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 201
    .line 202
    .line 203
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 204
    .line 205
    if-eqz v0, :cond_8

    .line 206
    .line 207
    invoke-virtual {v0}, Ljava/util/HashMap;->isEmpty()Z

    .line 208
    .line 209
    .line 210
    :cond_8
    invoke-virtual {v7}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 211
    .line 212
    .line 213
    move-result-object v0

    .line 214
    const-string v1, "Casting to TV..."

    .line 215
    .line 216
    invoke-static {p0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 217
    .line 218
    .line 219
    move-result-object v1

    .line 220
    invoke-virtual {v1}, Landroid/widget/Toast;->show()V

    .line 221
    .line 222
    .line 223
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 224
    .line 225
    if-eqz v1, :cond_9

    .line 226
    .line 227
    invoke-virtual {p0, v1}, Linfo/t4w/vp/view/VideoPlayer;->iSize4906(Landroidx/media3/common/Player;)V

    .line 228
    .line 229
    .line 230
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 231
    .line 232
    invoke-virtual {v1, v0, v5, v6}, Landroidx/media3/common/BasePlayer;->setMediaItem(Landroidx/media3/common/MediaItem;J)V

    .line 233
    .line 234
    .line 235
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 236
    .line 237
    invoke-virtual {v0}, Landroidx/media3/cast/CastPlayer;->prepare()V

    .line 238
    .line 239
    .line 240
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 241
    .line 242
    invoke-virtual {v0}, Landroidx/media3/common/BasePlayer;->play()V

    .line 243
    .line 244
    .line 245
    goto :goto_3

    .line 246
    :cond_9
    invoke-static {p0, v4, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 247
    .line 248
    .line 249
    move-result-object v0

    .line 250
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 251
    .line 252
    .line 253
    goto :goto_3

    .line 254
    :cond_a
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 255
    .line 256
    if-eqz v0, :cond_b

    .line 257
    .line 258
    invoke-virtual {p0, v0}, Linfo/t4w/vp/view/VideoPlayer;->iSize4906(Landroidx/media3/common/Player;)V

    .line 259
    .line 260
    .line 261
    const-string v0, "Please load a video first"

    .line 262
    .line 263
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 264
    .line 265
    .line 266
    move-result-object v0

    .line 267
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 268
    .line 269
    .line 270
    goto :goto_3

    .line 271
    :cond_b
    invoke-static {p0, v4, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 272
    .line 273
    .line 274
    move-result-object v0

    .line 275
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 276
    .line 277
    .line 278
    goto :goto_3

    .line 279
    :goto_2
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 280
    .line 281
    .line 282
    const-string v0, "Error starting cast session"

    .line 283
    .line 284
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 285
    .line 286
    .line 287
    move-result-object v0

    .line 288
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 289
    .line 290
    .line 291
    :goto_3
    return-void
.end method

.method public final onCastSessionUnavailable()V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Linfo/t4w/vp/view/VideoPlayer;->iSize4906(Landroidx/media3/common/Player;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    :try_start_0
    iget-boolean p1, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 5
    .line 6
    if-eqz p1, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    const/16 v0, 0x1006

    .line 17
    .line 18
    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sget v1, LvKey3407;->primary:I

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    .line 38
    .line 39
    :catch_0
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 6

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, LKùiu;->activity_vplayer:I

    .line 5
    .line 6
    invoke-virtual {p0, p1}, LUd$5_1h$;->setContentView(I)V

    .line 7
    .line 8
    .line 9
    new-instance p1, Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;

    .line 10
    .line 11
    invoke-direct {p1}, Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;-><init>()V

    .line 12
    .line 13
    .line 14
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->datI:Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;

    .line 15
    .line 16
    sget p1, LRO1QI;->ad_layout:I

    .line 17
    .line 18
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 19
    .line 20
    .line 21
    move-result-object p1

    .line 22
    check-cast p1, Landroid/widget/LinearLayout;

    .line 23
    .line 24
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oO:Landroid/widget/LinearLayout;

    .line 25
    .line 26
    sget p1, LcJLÌfz;->admob_ad_id:I

    .line 27
    .line 28
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iey:Ljava/lang/String;

    .line 33
    .line 34
    new-instance p1, LCD;

    .line 35
    .line 36
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 37
    .line 38
    .line 39
    invoke-static {p0, p1}, Lcom/google/android/gms/ads/MobileAds;->waiBKÀ(LUd$5_1h$;LZ8_O$y_;)V

    .line 40
    .line 41
    .line 42
    const-string p1, "audio"

    .line 43
    .line 44
    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    check-cast p1, Landroid/media/AudioManager;

    .line 49
    .line 50
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->iCount5302:Landroid/media/AudioManager;

    .line 51
    .line 52
    invoke-virtual {p0}, Linfo/t4w/vp/view/VideoPlayer;->Iii()Z

    .line 53
    .line 54
    .line 55
    move-result p1

    .line 56
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->iQ0D:Ljava/util/concurrent/ExecutorService;

    .line 57
    .line 58
    if-eqz p1, :cond_0

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_0
    :try_start_0
    sget-object p1, LOòZx;->POOl:LOòZx;

    .line 62
    .line 63
    sget v1, LI6R$9$;->e8$mp_s$:I

    .line 64
    .line 65
    invoke-virtual {p1, p0, v1}, LI6R$9$;->rz__9J_(Landroid/content/Context;I)I

    .line 66
    .line 67
    .line 68
    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 69
    if-nez p1, :cond_1

    .line 70
    .line 71
    :try_start_1
    invoke-static {p0, v0}, LVA_r_;->tmpData3485(LUd$5_1h$;Ljava/util/concurrent/ExecutorService;)LGIlO;

    .line 72
    .line 73
    .line 74
    new-instance p1, LisIndex8129;

    .line 75
    .line 76
    const/4 v1, 0x5

    .line 77
    invoke-direct {p1, p0, v1}, LisIndex8129;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 78
    .line 79
    .line 80
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->valu0:LgIXQù;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 81
    .line 82
    goto :goto_0

    .line 83
    :catch_0
    move-exception p1

    .line 84
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 85
    .line 86
    .line 87
    goto :goto_0

    .line 88
    :catch_1
    nop

    .line 89
    :cond_1
    :goto_0
    sget p1, LRO1QI;->player_view:I

    .line 90
    .line 91
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 92
    .line 93
    .line 94
    move-result-object p1

    .line 95
    check-cast p1, Landroidx/media3/ui/PlayerView;

    .line 96
    .line 97
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 98
    .line 99
    sget v1, LRO1QI;->exo_rew:I

    .line 100
    .line 101
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    check-cast p1, Landroid/widget/ImageButton;

    .line 106
    .line 107
    sget v1, LindeQ;->backward_5_seconds:I

    .line 108
    .line 109
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 110
    .line 111
    .line 112
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 113
    .line 114
    sget v1, LRO1QI;->exo_ffwd:I

    .line 115
    .line 116
    invoke-virtual {p1, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    check-cast p1, Landroid/widget/ImageButton;

    .line 121
    .line 122
    sget v1, LindeQ;->forward_15_seconds:I

    .line 123
    .line 124
    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 125
    .line 126
    .line 127
    new-instance p1, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    .line 128
    .line 129
    invoke-direct {p1}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;-><init>()V

    .line 130
    .line 131
    .line 132
    const/16 v1, 0x9c4

    .line 133
    .line 134
    const/16 v2, 0x1388

    .line 135
    .line 136
    const/16 v3, 0x3a98

    .line 137
    .line 138
    const v4, 0x1d4c0

    .line 139
    .line 140
    .line 141
    invoke-virtual {p1, v3, v4, v1, v2}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBufferDurationsMs(IIII)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    const/4 v1, 0x1

    .line 146
    invoke-virtual {p1, v4, v1}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->setBackBuffer(IZ)Landroidx/media3/exoplayer/DefaultLoadControl$Builder;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    invoke-virtual {p1}, Landroidx/media3/exoplayer/DefaultLoadControl$Builder;->build()Landroidx/media3/exoplayer/DefaultLoadControl;

    .line 151
    .line 152
    .line 153
    move-result-object p1

    .line 154
    new-instance v2, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 155
    .line 156
    invoke-direct {v2, p0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    .line 157
    .line 158
    .line 159
    invoke-virtual {v2, p1}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setLoadControl(Landroidx/media3/exoplayer/LoadControl;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 160
    .line 161
    .line 162
    move-result-object p1

    .line 163
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 168
    .line 169
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 170
    .line 171
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 172
    .line 173
    invoke-virtual {v2, p1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 174
    .line 175
    .line 176
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 177
    .line 178
    sget v2, LRO1QI;->back_btn:I

    .line 179
    .line 180
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    check-cast p1, Landroid/widget/ImageView;

    .line 185
    .line 186
    new-instance v2, LcoOnt;

    .line 187
    .line 188
    const/4 v3, 0x0

    .line 189
    invoke-direct {v2, p0, v3}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 193
    .line 194
    .line 195
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 196
    .line 197
    new-instance v2, Ll3$hA$;

    .line 198
    .line 199
    invoke-direct {v2, p0}, Ll3$hA$;-><init>(Linfo/t4w/vp/view/VideoPlayer;)V

    .line 200
    .line 201
    .line 202
    invoke-interface {p1, v2}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 203
    .line 204
    .line 205
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 206
    .line 207
    sget v2, LRO1QI;->media_route_button:I

    .line 208
    .line 209
    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 210
    .line 211
    .line 212
    move-result-object p1

    .line 213
    check-cast p1, Landroidx/mediarouter/app/MediaRouteButton;

    .line 214
    .line 215
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->k1y:Landroidx/mediarouter/app/MediaRouteButton;

    .line 216
    .line 217
    invoke-virtual {p0}, Linfo/t4w/vp/view/VideoPlayer;->Iii()Z

    .line 218
    .line 219
    .line 220
    move-result p1

    .line 221
    const/16 v2, 0x8

    .line 222
    .line 223
    if-eqz p1, :cond_2

    .line 224
    .line 225
    goto :goto_1

    .line 226
    :cond_2
    :try_start_2
    sget-object p1, LOòZx;->POOl:LOòZx;

    .line 227
    .line 228
    sget v4, LI6R$9$;->e8$mp_s$:I

    .line 229
    .line 230
    invoke-virtual {p1, p0, v4}, LI6R$9$;->rz__9J_(Landroid/content/Context;I)I

    .line 231
    .line 232
    .line 233
    move-result p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    .line 234
    if-nez p1, :cond_4

    .line 235
    .line 236
    :try_start_3
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->k1y:Landroidx/mediarouter/app/MediaRouteButton;

    .line 237
    .line 238
    if-eqz p1, :cond_3

    .line 239
    .line 240
    invoke-virtual {p1, v3}, Landroidx/mediarouter/app/MediaRouteButton;->setVisibility(I)V

    .line 241
    .line 242
    .line 243
    :cond_3
    invoke-static {p0}, LILA_l$V_;->POOl(Landroid/content/Context;)LILA_l$V_;

    .line 244
    .line 245
    .line 246
    move-result-object p1

    .line 247
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->dnN$d$:LILA_l$V_;

    .line 248
    .line 249
    invoke-static {p0, v0}, LVA_r_;->tmpData3485(LUd$5_1h$;Ljava/util/concurrent/ExecutorService;)LGIlO;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    new-instance v0, LisIndex8129;

    .line 254
    .line 255
    const/4 v4, 0x0

    .line 256
    invoke-direct {v0, p0, v4}, LisIndex8129;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 257
    .line 258
    .line 259
    sget-object v4, LGi$EL$;->e8$mp_s$:Lab_w_;

    .line 260
    .line 261
    invoke-virtual {p1, v4, v0}, LGIlO;->waiBKÀ(Ljava/util/concurrent/Executor;LisPos2138;)V

    .line 262
    .line 263
    .line 264
    new-instance v0, LtmpCount6792;

    .line 265
    .line 266
    const/16 v5, 0x13

    .line 267
    .line 268
    invoke-direct {v0, v5}, LtmpCount6792;-><init>(I)V

    .line 269
    .line 270
    .line 271
    new-instance v5, LmData56;

    .line 272
    .line 273
    invoke-direct {v5, v4, v0}, LmData56;-><init>(Ljava/util/concurrent/Executor;LHàWLI;)V

    .line 274
    .line 275
    .line 276
    iget-object v0, p1, LGIlO;->waiBKÀ:LlO;

    .line 277
    .line 278
    invoke-virtual {v0, v5}, LlO;->tmpData3485(LmData56;)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {p1}, LGIlO;->jPos3709()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 282
    .line 283
    .line 284
    goto :goto_2

    .line 285
    :catch_2
    nop

    .line 286
    goto :goto_2

    .line 287
    :catch_3
    nop

    .line 288
    :cond_4
    :goto_1
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->k1y:Landroidx/mediarouter/app/MediaRouteButton;

    .line 289
    .line 290
    if-eqz p1, :cond_5

    .line 291
    .line 292
    invoke-virtual {p1, v2}, Landroidx/mediarouter/app/MediaRouteButton;->setVisibility(I)V

    .line 293
    .line 294
    .line 295
    :cond_5
    :goto_2
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 296
    .line 297
    invoke-virtual {p1, v1}, Landroidx/media3/ui/PlayerView;->setControllerHideOnTouch(Z)V

    .line 298
    .line 299
    .line 300
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 301
    .line 302
    const/4 v0, 0x2

    .line 303
    invoke-virtual {p1, v0}, Landroidx/media3/ui/PlayerView;->setShowBuffering(I)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {p0}, Linfo/t4w/vp/view/VideoPlayer;->Iii()Z

    .line 307
    .line 308
    .line 309
    move-result p1

    .line 310
    if-eqz p1, :cond_6

    .line 311
    .line 312
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 313
    .line 314
    new-instance v0, LisIndex8129;

    .line 315
    .line 316
    const/4 v1, 0x1

    .line 317
    invoke-direct {v0, p0, v1}, LisIndex8129;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 318
    .line 319
    .line 320
    invoke-virtual {p1, v0}, Landroidx/media3/ui/PlayerView;->setControllerVisibilityListener(Landroidx/media3/ui/PlayerView$ControllerVisibilityListener;)V

    .line 321
    .line 322
    .line 323
    :cond_6
    sget p1, LRO1QI;->main_layout:I

    .line 324
    .line 325
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 326
    .line 327
    .line 328
    move-result-object p1

    .line 329
    check-cast p1, Landroid/widget/FrameLayout;

    .line 330
    .line 331
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->gCount1961:Landroid/widget/FrameLayout;

    .line 332
    .line 333
    sget p1, LRO1QI;->exo_pip:I

    .line 334
    .line 335
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 336
    .line 337
    .line 338
    move-result-object p1

    .line 339
    check-cast p1, Landroid/widget/ImageView;

    .line 340
    .line 341
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->BCIm:Landroid/widget/ImageView;

    .line 342
    .line 343
    sget p1, LRO1QI;->fullscreen_icon:I

    .line 344
    .line 345
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 346
    .line 347
    .line 348
    move-result-object p1

    .line 349
    check-cast p1, Landroid/widget/ImageView;

    .line 350
    .line 351
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->zAt$p:Landroid/widget/ImageView;

    .line 352
    .line 353
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->BCIm:Landroid/widget/ImageView;

    .line 354
    .line 355
    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 356
    .line 357
    .line 358
    sget p1, LRO1QI;->track_selection_button:I

    .line 359
    .line 360
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 361
    .line 362
    .line 363
    move-result-object p1

    .line 364
    check-cast p1, Landroid/widget/ImageView;

    .line 365
    .line 366
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->gSy_FG$D_:Landroid/widget/ImageView;

    .line 367
    .line 368
    sget p1, LRO1QI;->scale_icon:I

    .line 369
    .line 370
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 371
    .line 372
    .line 373
    move-result-object p1

    .line 374
    check-cast p1, Landroid/widget/ImageView;

    .line 375
    .line 376
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 377
    .line 378
    sget p1, LRO1QI;->speed_icon:I

    .line 379
    .line 380
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 381
    .line 382
    .line 383
    move-result-object p1

    .line 384
    check-cast p1, Landroid/widget/ImageView;

    .line 385
    .line 386
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Txy$$d_w$:Landroid/widget/ImageView;

    .line 387
    .line 388
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->zAt$p:Landroid/widget/ImageView;

    .line 389
    .line 390
    new-instance v0, LcoOnt;

    .line 391
    .line 392
    const/4 v1, 0x3

    .line 393
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 394
    .line 395
    .line 396
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 397
    .line 398
    .line 399
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->BCIm:Landroid/widget/ImageView;

    .line 400
    .line 401
    new-instance v0, LcoOnt;

    .line 402
    .line 403
    const/4 v1, 0x4

    .line 404
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 405
    .line 406
    .line 407
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 408
    .line 409
    .line 410
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->gSy_FG$D_:Landroid/widget/ImageView;

    .line 411
    .line 412
    if-eqz p1, :cond_7

    .line 413
    .line 414
    new-instance v0, LcoOnt;

    .line 415
    .line 416
    const/4 v1, 0x5

    .line 417
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 418
    .line 419
    .line 420
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 421
    .line 422
    .line 423
    :cond_7
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 424
    .line 425
    if-eqz p1, :cond_8

    .line 426
    .line 427
    new-instance v0, LcoOnt;

    .line 428
    .line 429
    const/4 v1, 0x6

    .line 430
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 434
    .line 435
    .line 436
    :cond_8
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Txy$$d_w$:Landroid/widget/ImageView;

    .line 437
    .line 438
    if-eqz p1, :cond_9

    .line 439
    .line 440
    new-instance v0, LcoOnt;

    .line 441
    .line 442
    const/4 v1, 0x7

    .line 443
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 444
    .line 445
    .line 446
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 447
    .line 448
    .line 449
    :cond_9
    sget p1, LRO1QI;->fullscreen_button:I

    .line 450
    .line 451
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 452
    .line 453
    .line 454
    move-result-object p1

    .line 455
    if-eqz p1, :cond_a

    .line 456
    .line 457
    new-instance v0, LcoOnt;

    .line 458
    .line 459
    const/16 v1, 0x8

    .line 460
    .line 461
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 462
    .line 463
    .line 464
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 465
    .line 466
    .line 467
    :cond_a
    sget p1, LRO1QI;->scale_button:I

    .line 468
    .line 469
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 470
    .line 471
    .line 472
    move-result-object p1

    .line 473
    if-eqz p1, :cond_b

    .line 474
    .line 475
    new-instance v0, LcoOnt;

    .line 476
    .line 477
    const/4 v1, 0x1

    .line 478
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 479
    .line 480
    .line 481
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 482
    .line 483
    .line 484
    :cond_b
    sget p1, LRO1QI;->speed_button:I

    .line 485
    .line 486
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 487
    .line 488
    .line 489
    move-result-object p1

    .line 490
    if-eqz p1, :cond_c

    .line 491
    .line 492
    new-instance v0, LcoOnt;

    .line 493
    .line 494
    const/4 v1, 0x2

    .line 495
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 496
    .line 497
    .line 498
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 499
    .line 500
    .line 501
    :cond_c
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 502
    .line 503
    new-instance v0, LaxK$H_S$;

    .line 504
    .line 505
    const/4 v1, 0x2

    .line 506
    invoke-direct {v0, v1, p0}, LaxK$H_S$;-><init>(ILjava/lang/Object;)V

    .line 507
    .line 508
    .line 509
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 510
    .line 511
    .line 512
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 513
    .line 514
    new-instance v0, LKòBT;

    .line 515
    .line 516
    invoke-direct {v0, p0}, LKòBT;-><init>(Linfo/t4w/vp/view/VideoPlayer;)V

    .line 517
    .line 518
    .line 519
    invoke-interface {p1, v0}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 520
    .line 521
    .line 522
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 523
    .line 524
    .line 525
    move-result-object p1

    .line 526
    sget v0, LKùiu;->volume_brightness_control:I

    .line 527
    .line 528
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->gCount1961:Landroid/widget/FrameLayout;

    .line 529
    .line 530
    invoke-virtual {p1, v0, v1, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 531
    .line 532
    .line 533
    move-result-object p1

    .line 534
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 535
    .line 536
    sget v0, LRO1QI;->volume_seekbar:I

    .line 537
    .line 538
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 539
    .line 540
    .line 541
    move-result-object p1

    .line 542
    check-cast p1, Linfo/t4w/vp/view/VerticalSeekBar;

    .line 543
    .line 544
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->WoI_9_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 545
    .line 546
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 547
    .line 548
    sget v0, LRO1QI;->volume_icon:I

    .line 549
    .line 550
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 551
    .line 552
    .line 553
    move-result-object p1

    .line 554
    check-cast p1, Landroid/widget/ImageView;

    .line 555
    .line 556
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 557
    .line 558
    .line 559
    move-result-object p1

    .line 560
    sget v0, LKùiu;->volume_brightness_control:I

    .line 561
    .line 562
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->gCount1961:Landroid/widget/FrameLayout;

    .line 563
    .line 564
    invoke-virtual {p1, v0, v1, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 565
    .line 566
    .line 567
    move-result-object p1

    .line 568
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 569
    .line 570
    sget v0, LRO1QI;->volume_seekbar:I

    .line 571
    .line 572
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 573
    .line 574
    .line 575
    move-result-object p1

    .line 576
    check-cast p1, Linfo/t4w/vp/view/VerticalSeekBar;

    .line 577
    .line 578
    iput-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 579
    .line 580
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 581
    .line 582
    sget v0, LRO1QI;->volume_icon:I

    .line 583
    .line 584
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 585
    .line 586
    .line 587
    move-result-object p1

    .line 588
    check-cast p1, Landroid/widget/ImageView;

    .line 589
    .line 590
    sget v0, LindeQ;->ic_brightness:I

    .line 591
    .line 592
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 593
    .line 594
    .line 595
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->iCount5302:Landroid/media/AudioManager;

    .line 596
    .line 597
    const/4 v0, 0x3

    .line 598
    invoke-virtual {p1, v0}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    .line 599
    .line 600
    .line 601
    move-result p1

    .line 602
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->WoI_9_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 603
    .line 604
    invoke-virtual {v1, p1}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 605
    .line 606
    .line 607
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->WoI_9_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 608
    .line 609
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->iCount5302:Landroid/media/AudioManager;

    .line 610
    .line 611
    invoke-virtual {v1, v0}, Landroid/media/AudioManager;->getStreamVolume(I)I

    .line 612
    .line 613
    .line 614
    move-result v0

    .line 615
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setProgress(I)V

    .line 616
    .line 617
    .line 618
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->WoI_9_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 619
    .line 620
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 621
    .line 622
    .line 623
    move-result-object v0

    .line 624
    sget v1, LvKey3407;->white:I

    .line 625
    .line 626
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    .line 627
    .line 628
    .line 629
    move-result v0

    .line 630
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setThumbColor(I)V

    .line 631
    .line 632
    .line 633
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->WoI_9_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 634
    .line 635
    new-instance v0, LFH_D3_;

    .line 636
    .line 637
    invoke-direct {v0, p0}, LFH_D3_;-><init>(Linfo/t4w/vp/view/VideoPlayer;)V

    .line 638
    .line 639
    .line 640
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 641
    .line 642
    .line 643
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 644
    .line 645
    const/16 v0, 0xff

    .line 646
    .line 647
    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 648
    .line 649
    .line 650
    :try_start_4
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 651
    .line 652
    .line 653
    move-result-object p1

    .line 654
    const-string v0, "screen_brightness"

    .line 655
    .line 656
    invoke-static {p1, v0}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    .line 657
    .line 658
    .line 659
    move-result p1

    .line 660
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 661
    .line 662
    invoke-virtual {v0, p1}, Linfo/t4w/vp/view/VerticalSeekBar;->setProgress(I)V
    :try_end_4
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_4 .. :try_end_4} :catch_4

    .line 663
    .line 664
    .line 665
    goto :goto_3

    .line 666
    :catch_4
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 667
    .line 668
    const/16 v0, 0x80

    .line 669
    .line 670
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setProgress(I)V

    .line 671
    .line 672
    .line 673
    :goto_3
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 674
    .line 675
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 676
    .line 677
    .line 678
    move-result-object v0

    .line 679
    sget v1, LvKey3407;->white:I

    .line 680
    .line 681
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    .line 682
    .line 683
    .line 684
    move-result v0

    .line 685
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setThumbColor(I)V

    .line 686
    .line 687
    .line 688
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 689
    .line 690
    new-instance v0, LjIndex3920;

    .line 691
    .line 692
    invoke-direct {v0, p0}, LjIndex3920;-><init>(Linfo/t4w/vp/view/VideoPlayer;)V

    .line 693
    .line 694
    .line 695
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 696
    .line 697
    .line 698
    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    .line 699
    .line 700
    const/4 v0, -0x2

    .line 701
    invoke-direct {p1, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 702
    .line 703
    .line 704
    const v1, 0x800013

    .line 705
    .line 706
    .line 707
    iput v1, p1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 708
    .line 709
    const/16 v1, 0x96

    .line 710
    .line 711
    iput v1, p1, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 712
    .line 713
    new-instance v4, Landroid/widget/FrameLayout$LayoutParams;

    .line 714
    .line 715
    invoke-direct {v4, v0, v0}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 716
    .line 717
    .line 718
    const v0, 0x800015

    .line 719
    .line 720
    .line 721
    iput v0, v4, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 722
    .line 723
    iput v1, v4, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 724
    .line 725
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 726
    .line 727
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 728
    .line 729
    invoke-virtual {v0, v1, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 730
    .line 731
    .line 732
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 733
    .line 734
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 735
    .line 736
    invoke-virtual {p1, v0, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 737
    .line 738
    .line 739
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 740
    .line 741
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 742
    .line 743
    .line 744
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 745
    .line 746
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 747
    .line 748
    .line 749
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 750
    .line 751
    sget v0, LRO1QI;->dlna_cast_button:I

    .line 752
    .line 753
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 754
    .line 755
    .line 756
    move-result-object p1

    .line 757
    check-cast p1, Landroid/widget/ImageView;

    .line 758
    .line 759
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 760
    .line 761
    sget v1, LRO1QI;->external_cast_button:I

    .line 762
    .line 763
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 764
    .line 765
    .line 766
    move-result-object v0

    .line 767
    check-cast v0, Landroid/widget/ImageView;

    .line 768
    .line 769
    invoke-virtual {p0}, Linfo/t4w/vp/view/VideoPlayer;->Iii()Z

    .line 770
    .line 771
    .line 772
    move-result v1

    .line 773
    if-eqz v1, :cond_e

    .line 774
    .line 775
    if-eqz p1, :cond_d

    .line 776
    .line 777
    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 778
    .line 779
    .line 780
    :cond_d
    if-eqz v0, :cond_10

    .line 781
    .line 782
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 783
    .line 784
    .line 785
    goto :goto_5

    .line 786
    :cond_e
    if-eqz p1, :cond_10

    .line 787
    .line 788
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 789
    .line 790
    if-eqz v1, :cond_f

    .line 791
    .line 792
    iget-object v1, v1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 793
    .line 794
    if-eqz v1, :cond_f

    .line 795
    .line 796
    iget-object v1, v1, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 797
    .line 798
    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 799
    .line 800
    .line 801
    move-result-object v1

    .line 802
    const-string v4, "###"

    .line 803
    .line 804
    invoke-virtual {v1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 805
    .line 806
    .line 807
    move-result v1

    .line 808
    if-eqz v1, :cond_f

    .line 809
    .line 810
    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 811
    .line 812
    .line 813
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 814
    .line 815
    .line 816
    goto :goto_4

    .line 817
    :cond_f
    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 818
    .line 819
    .line 820
    invoke-virtual {v0, v3}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 821
    .line 822
    .line 823
    :goto_4
    new-instance v1, LcoOnt;

    .line 824
    .line 825
    const/16 v2, 0x9

    .line 826
    .line 827
    invoke-direct {v1, p0, v2}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 828
    .line 829
    .line 830
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 831
    .line 832
    .line 833
    new-instance v0, LcoOnt;

    .line 834
    .line 835
    const/16 v1, 0xa

    .line 836
    .line 837
    invoke-direct {v0, p0, v1}, LcoOnt;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 838
    .line 839
    .line 840
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 841
    .line 842
    .line 843
    :cond_10
    :goto_5
    :try_start_5
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 844
    .line 845
    invoke-interface {p1}, Landroidx/media3/common/Player;->pause()V

    .line 846
    .line 847
    .line 848
    new-instance p1, LjSize1789;

    .line 849
    .line 850
    invoke-direct {p1, p0, p0}, LjSize1789;-><init>(Landroid/app/Activity;LGl1ID;)V

    .line 851
    .line 852
    .line 853
    invoke-virtual {p1}, LjSize1789;->rz__9J_()V

    .line 854
    .line 855
    .line 856
    new-instance p1, LIli;

    .line 857
    .line 858
    const/4 v0, 0x2

    .line 859
    invoke-direct {p1, v0}, LIli;-><init>(I)V

    .line 860
    .line 861
    .line 862
    new-instance v0, LtmpOffset3178;

    .line 863
    .line 864
    invoke-direct {v0, p1}, LtmpOffset3178;-><init>(LIli;)V

    .line 865
    .line 866
    .line 867
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iey:Ljava/lang/String;

    .line 868
    .line 869
    new-instance v1, LlenIth;

    .line 870
    .line 871
    const/4 v2, 0x1

    .line 872
    invoke-direct {v1, p0, v2}, LlenIth;-><init>(LUd$5_1h$;I)V

    .line 873
    .line 874
    .line 875
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, LlenIth;->$ÒcdS(LD6$Ff_rK$;)V
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_5

    .line 876
    .line 877
    .line 878
    :catch_5
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onDestroy()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->dnN$d$:LILA_l$V_;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->xlOI:LoZ0DQtS6;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0, v1}, LILA_l$V_;->DDù8(LrIlI0;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    :try_start_0
    invoke-virtual {v0, v1}, Landroidx/media3/cast/CastPlayer;->setSessionAvailabilityListener(Landroidx/media3/cast/SessionAvailabilityListener;)V

    .line 21
    .line 22
    .line 23
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 24
    .line 25
    invoke-virtual {v0}, Landroidx/media3/cast/CastPlayer;->release()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 26
    .line 27
    .line 28
    :catch_0
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 29
    .line 30
    :cond_1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 31
    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    .line 35
    .line 36
    .line 37
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 38
    .line 39
    :cond_2
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, LqboÌWm;->onNewIntent(Landroid/content/Intent;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/VideoPlayer;->yPN$A_n$(Landroid/content/Intent;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onPause()V
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    iput-wide v0, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 10
    .line 11
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-boolean v1, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 16
    .line 17
    if-nez v1, :cond_1

    .line 18
    .line 19
    invoke-interface {v0}, Landroidx/media3/common/Player;->pause()V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    if-eqz v0, :cond_2

    .line 24
    .line 25
    invoke-interface {v0}, Landroidx/media3/common/Player;->play()V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    const/16 v1, 0x80

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 35
    .line 36
    .line 37
    :cond_2
    :goto_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->RD:LVA_r_;

    .line 38
    .line 39
    if-eqz v0, :cond_3

    .line 40
    .line 41
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->valu0:LgIXQù;

    .line 42
    .line 43
    invoke-virtual {v0, v1}, LVA_r_;->sKey7917(LgIXQù;)V

    .line 44
    .line 45
    .line 46
    :cond_3
    invoke-super {p0}, LUd$5_1h$;->onPause()V

    .line 47
    .line 48
    .line 49
    return-void
.end method

.method public final onPictureInPictureModeChanged(Z)V
    .locals 4

    .line 1
    :try_start_0
    iput-boolean p1, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 2
    .line 3
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 4
    .line 5
    const/16 v1, 0x80

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 10
    .line 11
    .line 12
    move-result-wide v2

    .line 13
    iput-wide v2, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 14
    .line 15
    if-eqz p1, :cond_0

    .line 16
    .line 17
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 22
    .line 23
    .line 24
    :cond_0
    invoke-super {p0, p1}, LqboÌWm;->onPictureInPictureModeChanged(Z)V

    .line 25
    .line 26
    .line 27
    if-eqz p1, :cond_4

    .line 28
    .line 29
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 30
    .line 31
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->hideController()V

    .line 32
    .line 33
    .line 34
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 35
    .line 36
    if-eqz p1, :cond_1

    .line 37
    .line 38
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 39
    .line 40
    .line 41
    :cond_1
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 42
    .line 43
    const/16 v0, 0x8

    .line 44
    .line 45
    if-eqz p1, :cond_2

    .line 46
    .line 47
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 48
    .line 49
    .line 50
    :cond_2
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->pZDcLvd:Landroid/view/View;

    .line 51
    .line 52
    if-eqz p1, :cond_3

    .line 53
    .line 54
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 55
    .line 56
    .line 57
    :cond_3
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    invoke-virtual {p1, v1}, Landroid/view/Window;->clearFlags(I)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :cond_4
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 66
    .line 67
    if-eqz p1, :cond_5

    .line 68
    .line 69
    invoke-interface {p1}, Landroidx/media3/common/Player;->isPlaying()Z

    .line 70
    .line 71
    .line 72
    move-result p1

    .line 73
    if-eqz p1, :cond_5

    .line 74
    .line 75
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-virtual {p1, v1}, Landroid/view/Window;->addFlags(I)V

    .line 80
    .line 81
    .line 82
    :cond_5
    iget-boolean p1, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 83
    .line 84
    if-eqz p1, :cond_6

    .line 85
    .line 86
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 87
    .line 88
    .line 89
    move-result-object p1

    .line 90
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    const/16 v0, 0x1706

    .line 95
    .line 96
    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 97
    .line 98
    .line 99
    :cond_6
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 100
    .line 101
    if-eqz p1, :cond_7

    .line 102
    .line 103
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 104
    .line 105
    if-eqz p1, :cond_7

    .line 106
    .line 107
    new-instance v0, LDOl;

    .line 108
    .line 109
    const/16 v1, 0x8

    .line 110
    .line 111
    invoke-direct {v0, p0, v1}, LDOl;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 115
    .line 116
    .line 117
    :catch_0
    :cond_7
    return-void
.end method

.method public final onResume()V
    .locals 8

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onResume()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->RD:LVA_r_;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->valu0:LgIXQù;

    .line 10
    .line 11
    invoke-virtual {v0, v2}, LVA_r_;->e8$mp_s$(LgIXQù;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->RD:LVA_r_;

    .line 15
    .line 16
    invoke-virtual {v0}, LVA_r_;->waiBKÀ()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eq v0, v1, :cond_1

    .line 21
    .line 22
    invoke-virtual {p0}, Linfo/t4w/vp/view/VideoPlayer;->Iii()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    new-instance v0, LDOl;

    .line 30
    .line 31
    const/16 v2, 0xb

    .line 32
    .line 33
    invoke-direct {v0, p0, v2}, LDOl;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    :goto_0
    iget-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 40
    .line 41
    const/16 v2, 0x1706

    .line 42
    .line 43
    const/4 v3, 0x0

    .line 44
    if-nez v0, :cond_4

    .line 45
    .line 46
    sget v0, LRO1QI;->main_layout:I

    .line 47
    .line 48
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    check-cast v0, Landroid/widget/FrameLayout;

    .line 53
    .line 54
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->gCount1961:Landroid/widget/FrameLayout;

    .line 55
    .line 56
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 57
    .line 58
    const/16 v4, 0x1c

    .line 59
    .line 60
    if-lt v0, v4, :cond_2

    .line 61
    .line 62
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 63
    .line 64
    .line 65
    move-result-object v0

    .line 66
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    invoke-static {v0}, LCA$b_$K$;->gKey4112(Landroid/view/WindowManager$LayoutParams;)V

    .line 71
    .line 72
    .line 73
    :cond_2
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    const/16 v4, 0x600

    .line 78
    .line 79
    invoke-virtual {v0, v4, v4}, Landroid/view/Window;->setFlags(II)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 87
    .line 88
    .line 89
    move-result-object v0

    .line 90
    invoke-virtual {v0, v2}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {p0, v3}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 94
    .line 95
    .line 96
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 97
    .line 98
    if-eqz v0, :cond_3

    .line 99
    .line 100
    const/4 v2, 0x3

    .line 101
    invoke-virtual {v0, v2}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 102
    .line 103
    .line 104
    :cond_3
    iput-boolean v1, p0, Linfo/t4w/vp/view/VideoPlayer;->vz$a$:Z

    .line 105
    .line 106
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 107
    .line 108
    if-eqz v0, :cond_5

    .line 109
    .line 110
    invoke-interface {v0}, Landroidx/media3/common/Player;->play()V

    .line 111
    .line 112
    .line 113
    goto :goto_1

    .line 114
    :cond_4
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 119
    .line 120
    .line 121
    move-result-object v0

    .line 122
    invoke-virtual {v0, v2}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 123
    .line 124
    .line 125
    :cond_5
    :goto_1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 126
    .line 127
    if-eqz v0, :cond_6

    .line 128
    .line 129
    iget-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 130
    .line 131
    if-nez v0, :cond_6

    .line 132
    .line 133
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 134
    .line 135
    if-eqz v0, :cond_6

    .line 136
    .line 137
    const/4 v2, 0x0

    .line 138
    invoke-virtual {v0, v2}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 139
    .line 140
    .line 141
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 142
    .line 143
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 144
    .line 145
    invoke-virtual {v0, v2}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 146
    .line 147
    .line 148
    iget-wide v4, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 149
    .line 150
    const-wide/16 v6, 0x0

    .line 151
    .line 152
    cmp-long v0, v4, v6

    .line 153
    .line 154
    if-lez v0, :cond_6

    .line 155
    .line 156
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 157
    .line 158
    invoke-interface {v0, v4, v5}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 159
    .line 160
    .line 161
    :cond_6
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 162
    .line 163
    if-eqz v0, :cond_a

    .line 164
    .line 165
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->oaX_6_:Landroidx/media3/common/Player;

    .line 166
    .line 167
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 168
    .line 169
    if-ne v0, v2, :cond_a

    .line 170
    .line 171
    invoke-virtual {v2}, Landroidx/media3/cast/CastPlayer;->isCastSessionAvailable()Z

    .line 172
    .line 173
    .line 174
    move-result v0

    .line 175
    if-eqz v0, :cond_a

    .line 176
    .line 177
    new-instance v0, Landroidx/media3/common/MediaItem$Builder;

    .line 178
    .line 179
    invoke-direct {v0}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 180
    .line 181
    .line 182
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 183
    .line 184
    iget-object v2, v2, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 185
    .line 186
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 187
    .line 188
    invoke-virtual {v0, v2}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 193
    .line 194
    iget-object v2, v2, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 195
    .line 196
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->mimeType:Ljava/lang/String;

    .line 197
    .line 198
    if-eqz v2, :cond_7

    .line 199
    .line 200
    invoke-virtual {v0, v2}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 201
    .line 202
    .line 203
    :cond_7
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 204
    .line 205
    iget-object v2, v2, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 206
    .line 207
    iget-object v4, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 208
    .line 209
    if-eqz v4, :cond_9

    .line 210
    .line 211
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 212
    .line 213
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    const-string v4, "###"

    .line 218
    .line 219
    invoke-virtual {v2, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 220
    .line 221
    .line 222
    move-result v5

    .line 223
    if-eqz v5, :cond_8

    .line 224
    .line 225
    const/4 v5, 0x2

    .line 226
    invoke-virtual {v2, v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object v2

    .line 230
    array-length v4, v2

    .line 231
    if-ne v4, v5, :cond_9

    .line 232
    .line 233
    aget-object v4, v2, v3

    .line 234
    .line 235
    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 236
    .line 237
    .line 238
    move-result-object v4

    .line 239
    invoke-virtual {v0, v4}, Landroidx/media3/common/MediaItem$Builder;->setUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    .line 240
    .line 241
    .line 242
    sget-object v4, Landroidx/media3/common/C;->CLEARKEY_UUID:Ljava/util/UUID;

    .line 243
    .line 244
    invoke-virtual {v0, v4}, Landroidx/media3/common/MediaItem$Builder;->setDrmUuid(Ljava/util/UUID;)Landroidx/media3/common/MediaItem$Builder;

    .line 245
    .line 246
    .line 247
    move-result-object v4

    .line 248
    new-instance v5, Ljava/lang/StringBuilder;

    .line 249
    .line 250
    const-string v6, "data:application/xml;base64,"

    .line 251
    .line 252
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    aget-object v6, v2, v1

    .line 256
    .line 257
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 258
    .line 259
    .line 260
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 261
    .line 262
    .line 263
    move-result-object v5

    .line 264
    invoke-virtual {v4, v5}, Landroidx/media3/common/MediaItem$Builder;->setDrmLicenseUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 265
    .line 266
    .line 267
    move-result-object v4

    .line 268
    invoke-virtual {v4, v3}, Landroidx/media3/common/MediaItem$Builder;->setDrmMultiSession(Z)Landroidx/media3/common/MediaItem$Builder;

    .line 269
    .line 270
    .line 271
    aget-object v1, v2, v1

    .line 272
    .line 273
    goto :goto_2

    .line 274
    :cond_8
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 275
    .line 276
    iget-object v1, v1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 277
    .line 278
    iget-object v1, v1, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 279
    .line 280
    iget-object v1, v1, Landroidx/media3/common/MediaItem$DrmConfiguration;->uuid:Ljava/util/UUID;

    .line 281
    .line 282
    invoke-virtual {v0, v1}, Landroidx/media3/common/MediaItem$Builder;->setDrmUuid(Ljava/util/UUID;)Landroidx/media3/common/MediaItem$Builder;

    .line 283
    .line 284
    .line 285
    move-result-object v1

    .line 286
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 287
    .line 288
    iget-object v2, v2, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 289
    .line 290
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 291
    .line 292
    iget-object v2, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->licenseUri:Landroid/net/Uri;

    .line 293
    .line 294
    invoke-virtual {v1, v2}, Landroidx/media3/common/MediaItem$Builder;->setDrmLicenseUri(Landroid/net/Uri;)Landroidx/media3/common/MediaItem$Builder;

    .line 295
    .line 296
    .line 297
    move-result-object v1

    .line 298
    iget-object v2, p0, Linfo/t4w/vp/view/VideoPlayer;->YOD0:Landroidx/media3/common/MediaItem;

    .line 299
    .line 300
    iget-object v2, v2, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 301
    .line 302
    iget-object v2, v2, Landroidx/media3/common/MediaItem$LocalConfiguration;->drmConfiguration:Landroidx/media3/common/MediaItem$DrmConfiguration;

    .line 303
    .line 304
    iget-boolean v2, v2, Landroidx/media3/common/MediaItem$DrmConfiguration;->multiSession:Z

    .line 305
    .line 306
    invoke-virtual {v1, v2}, Landroidx/media3/common/MediaItem$Builder;->setDrmMultiSession(Z)Landroidx/media3/common/MediaItem$Builder;

    .line 307
    .line 308
    .line 309
    :cond_9
    :goto_2
    invoke-virtual {v0}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 310
    .line 311
    .line 312
    move-result-object v0

    .line 313
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 314
    .line 315
    invoke-virtual {v1, v0}, Landroidx/media3/common/BasePlayer;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 316
    .line 317
    .line 318
    :cond_a
    return-void
.end method

.method public final onStop()V
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-boolean v1, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 10
    .line 11
    .line 12
    move-result-wide v0

    .line 13
    iput-wide v0, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 14
    .line 15
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 16
    .line 17
    invoke-interface {v0}, Landroidx/media3/common/Player;->pause()V

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    if-eqz v0, :cond_1

    .line 22
    .line 23
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    iput-wide v0, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 28
    .line 29
    :cond_1
    :goto_0
    invoke-super {p0}, LUd$5_1h$;->onStop()V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final onUserLeaveHint()V
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    iput-wide v0, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 10
    .line 11
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 12
    .line 13
    invoke-interface {v0}, Landroidx/media3/common/Player;->isPlaying()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    iget-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 20
    .line 21
    if-nez v0, :cond_0

    .line 22
    .line 23
    const/4 v0, 0x1

    .line 24
    iput-boolean v0, p0, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_:Z

    .line 25
    .line 26
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    const/16 v1, 0x80

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 33
    .line 34
    .line 35
    :cond_0
    invoke-super {p0}, LqboÌWm;->onUserLeaveHint()V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public final pQ1Il()V
    .locals 4

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 6
    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    :try_start_0
    new-instance v0, Landroid/os/Handler;

    .line 17
    .line 18
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 23
    .line 24
    .line 25
    new-instance v1, LDOl;

    .line 26
    .line 27
    const/4 v2, 0x3

    .line 28
    invoke-direct {v1, p0, v2}, LDOl;-><init>(Linfo/t4w/vp/view/VideoPlayer;I)V

    .line 29
    .line 30
    .line 31
    const-wide/16 v2, 0x1f4

    .line 32
    .line 33
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    .line 35
    .line 36
    :catch_0
    :cond_1
    :goto_0
    return-void
.end method

.method public final tmpSize211(Ljava/lang/String;)Ljava/lang/String;
    .locals 10

    .line 1
    const-string v0, "\\|"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    new-instance v0, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 10
    .line 11
    .line 12
    array-length v1, p1

    .line 13
    const/4 v2, 0x1

    .line 14
    const/4 v3, 0x0

    .line 15
    const/4 v4, 0x0

    .line 16
    const/4 v5, 0x1

    .line 17
    :goto_0
    if-ge v4, v1, :cond_2

    .line 18
    .line 19
    aget-object v6, p1, v4

    .line 20
    .line 21
    const-string v7, ":"

    .line 22
    .line 23
    const/4 v8, 0x2

    .line 24
    invoke-virtual {v6, v7, v8}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v7

    .line 28
    array-length v9, v7

    .line 29
    if-ne v9, v8, :cond_1

    .line 30
    .line 31
    aget-object v6, v7, v3

    .line 32
    .line 33
    invoke-virtual {v6}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v6

    .line 37
    aget-object v7, v7, v2

    .line 38
    .line 39
    invoke-virtual {v7}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v7

    .line 43
    invoke-static {v6}, Linfo/t4w/vp/view/VideoPlayer;->sKey6064(Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    invoke-static {v7}, Linfo/t4w/vp/view/VideoPlayer;->sKey6064(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v7

    .line 51
    invoke-static {v7, v3}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    .line 52
    .line 53
    .line 54
    move-result-object v8

    .line 55
    invoke-static {v8}, Ljava/util/UUID;->nameUUIDFromBytes([B)Ljava/util/UUID;

    .line 56
    .line 57
    .line 58
    move-result-object v8

    .line 59
    iget-object v9, p0, Linfo/t4w/vp/view/VideoPlayer;->datI:Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;

    .line 60
    .line 61
    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v8

    .line 65
    invoke-virtual {v9, v8}, Landroidx/media3/exoplayer/dash/manifest/DashManifestParser;->set_default_kid(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    if-nez v5, :cond_0

    .line 69
    .line 70
    const-string v8, ","

    .line 71
    .line 72
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    goto :goto_1

    .line 76
    :cond_0
    const/4 v5, 0x0

    .line 77
    :goto_1
    const-string v8, "{\"kty\":\"oct\",\"k\":\""

    .line 78
    .line 79
    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 83
    .line 84
    .line 85
    const-string v6, "\",\"kid\":\""

    .line 86
    .line 87
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 91
    .line 92
    .line 93
    const-string v6, "\",\"alg\":\"A128KW\"}"

    .line 94
    .line 95
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    add-int/lit8 v4, v4, 0x1

    .line 99
    .line 100
    goto :goto_0

    .line 101
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 102
    .line 103
    const-string v0, "Invalid ClearKey format, expected key:kid but got: "

    .line 104
    .line 105
    invoke-virtual {v0, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 110
    .line 111
    .line 112
    throw p1

    .line 113
    :cond_2
    new-instance p1, Ljava/lang/StringBuilder;

    .line 114
    .line 115
    const-string v1, "{\"keys\":["

    .line 116
    .line 117
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    .line 126
    .line 127
    const-string v0, "],\"type\":\"temporary\"}"

    .line 128
    .line 129
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 130
    .line 131
    .line 132
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object p1

    .line 136
    return-object p1
.end method

.method public final vz$a$()V
    .locals 5

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->Iii:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iget v1, p0, Linfo/t4w/vp/view/VideoPlayer;->rMBhl:I

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    add-int/2addr v1, v2

    .line 10
    const/4 v3, 0x4

    .line 11
    rem-int/2addr v1, v3

    .line 12
    iput v1, p0, Linfo/t4w/vp/view/VideoPlayer;->rMBhl:I

    .line 13
    .line 14
    if-eqz v1, :cond_4

    .line 15
    .line 16
    if-eq v1, v2, :cond_3

    .line 17
    .line 18
    const/4 v3, 0x2

    .line 19
    const/4 v4, 0x3

    .line 20
    if-eq v1, v3, :cond_2

    .line 21
    .line 22
    if-eq v1, v4, :cond_1

    .line 23
    .line 24
    :goto_0
    return-void

    .line 25
    :cond_1
    invoke-virtual {v0, v2}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 26
    .line 27
    .line 28
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 29
    .line 30
    sget v1, LindeQ;->video_scale_stretch:I

    .line 31
    .line 32
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :cond_2
    invoke-virtual {v0, v4}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 37
    .line 38
    .line 39
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 40
    .line 41
    sget v1, LindeQ;->video_scale_fill:I

    .line 42
    .line 43
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_3
    invoke-virtual {v0, v3}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 48
    .line 49
    .line 50
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 51
    .line 52
    sget v1, LindeQ;->video_scale_zoom:I

    .line 53
    .line 54
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :cond_4
    const/4 v1, 0x0

    .line 59
    invoke-virtual {v0, v1}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 60
    .line 61
    .line 62
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->iSize4906:Landroid/widget/ImageView;

    .line 63
    .line 64
    sget v1, LindeQ;->video_scale_fit:I

    .line 65
    .line 66
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 67
    .line 68
    .line 69
    return-void
.end method

.method public final yPN$A_n$(Landroid/content/Intent;)V
    .locals 5

    .line 1
    if-eqz p1, :cond_6

    .line 2
    .line 3
    const-string v0, "url"

    .line 4
    .line 5
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 10
    .line 11
    const-string v0, "agent"

    .line 12
    .line 13
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 18
    .line 19
    const-string v0, "position"

    .line 20
    .line 21
    const-wide/16 v1, 0x1

    .line 22
    .line 23
    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    .line 24
    .line 25
    .line 26
    move-result-wide v0

    .line 27
    iput-wide v0, p0, Linfo/t4w/vp/view/VideoPlayer;->IiI1iI:J

    .line 28
    .line 29
    const-string v0, "headers"

    .line 30
    .line 31
    invoke-virtual {p1, v0}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    if-eqz v0, :cond_1

    .line 36
    .line 37
    new-instance v1, Ljava/util/HashMap;

    .line 38
    .line 39
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 40
    .line 41
    .line 42
    iput-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 43
    .line 44
    invoke-virtual {v0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    :cond_0
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    if-eqz v2, :cond_2

    .line 57
    .line 58
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v2

    .line 62
    check-cast v2, Ljava/lang/String;

    .line 63
    .line 64
    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    if-eqz v3, :cond_0

    .line 69
    .line 70
    iget-object v4, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 71
    .line 72
    invoke-virtual {v4, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    goto :goto_0

    .line 76
    :cond_1
    const/4 v0, 0x0

    .line 77
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->mQQI:Ljava/util/HashMap;

    .line 78
    .line 79
    :cond_2
    :try_start_0
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 80
    .line 81
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    const-string v2, "2"

    .line 86
    .line 87
    invoke-static {v1, v2}, Linfo/t4w/vp/database/Next;->rz__9J_(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    const-string v2, ""

    .line 92
    .line 93
    invoke-virtual {v0, v1, v2}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 98
    .line 99
    goto :goto_1

    .line 100
    :catch_0
    nop

    .line 101
    :goto_1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 102
    .line 103
    if-eqz v0, :cond_3

    .line 104
    .line 105
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_4

    .line 110
    .line 111
    :cond_3
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->jI:Ljava/lang/String;

    .line 112
    .line 113
    iput-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 114
    .line 115
    :cond_4
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 116
    .line 117
    if-eqz v0, :cond_5

    .line 118
    .line 119
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 120
    .line 121
    .line 122
    move-result v0

    .line 123
    if-nez v0, :cond_5

    .line 124
    .line 125
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 126
    .line 127
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    iget-object p1, p0, Linfo/t4w/vp/view/VideoPlayer;->vSize1911:Ljava/lang/String;

    .line 131
    .line 132
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->sTxÒ7:Ljava/lang/String;

    .line 133
    .line 134
    invoke-virtual {p0, p1, v0}, Linfo/t4w/vp/view/VideoPlayer;->l1(Ljava/lang/String;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    return-void

    .line 138
    :cond_5
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 139
    .line 140
    .line 141
    move-result-object v0

    .line 142
    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 143
    .line 144
    .line 145
    move-result-object p1

    .line 146
    const-string v1, "android.intent.action.VIEW"

    .line 147
    .line 148
    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 149
    .line 150
    .line 151
    move-result v0

    .line 152
    if-eqz v0, :cond_6

    .line 153
    .line 154
    if-eqz p1, :cond_6

    .line 155
    .line 156
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object p1

    .line 160
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/VideoPlayer;->ChI_KH_(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->lelgth:Ljava/lang/String;

    .line 164
    .line 165
    invoke-virtual {p0, p1, v0}, Linfo/t4w/vp/view/VideoPlayer;->l1(Ljava/lang/String;Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    :cond_6
    return-void
.end method

.method public final zAt$p()V
    .locals 4

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, p0, Linfo/t4w/vp/view/VideoPlayer;->valu1:LDOl;

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Linfo/t4w/vp/view/VideoPlayer;->K11ID:Landroid/view/View;

    .line 11
    .line 12
    const-wide/16 v2, 0x9c4

    .line 13
    .line 14
    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 15
    .line 16
    .line 17
    :cond_0
    return-void
.end method
