.class public abstract Linfo/t4w/vp/view/HlsKeyDecryptor;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    const-string v0, "next"

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public static POOl([B)Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {p0, v0}, Linfo/t4w/vp/view/HlsKeyDecryptor;->d1([BI)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method private static native d0([B)[B
.end method

.method private static native d1([BI)Z
.end method

.method private static native d2([B)[B
.end method

.method public static e8$mp_s$([B)[B
    .locals 1

    .line 1
    invoke-static {p0}, Linfo/t4w/vp/view/HlsKeyDecryptor;->d0([B)[B

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    if-eqz p0, :cond_0

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    new-instance p0, Ljava/lang/Exception;

    .line 9
    .line 10
    const-string v0, "d0"

    .line 11
    .line 12
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw p0
.end method

.method public static rz__9J_([B)Z
    .locals 1

    .line 1
    const/4 v0, 0x2

    .line 2
    invoke-static {p0, v0}, Linfo/t4w/vp/view/HlsKeyDecryptor;->d1([BI)Z

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    return p0
.end method

.method public static waiBKÀ([B)[B
    .locals 1

    .line 1
    invoke-static {p0}, Linfo/t4w/vp/view/HlsKeyDecryptor;->d2([B)[B

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    if-eqz p0, :cond_0

    .line 6
    .line 7
    return-object p0

    .line 8
    :cond_0
    new-instance p0, Ljava/lang/Exception;

    .line 9
    .line 10
    const-string v0, "d2"

    .line 11
    .line 12
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 13
    .line 14
    .line 15
    throw p0
.end method
