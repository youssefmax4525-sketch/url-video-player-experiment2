.class public Linfo/t4w/vp/view/MultiCastActivity;
.super LUd$5_1h$;
.source "SourceFile"

# interfaces
.implements LisItem6344;


# static fields
.field public static final synthetic lIl1:I


# instance fields
.field public BCIm:Landroid/widget/ImageButton;

.field public final ChI_KH_:Ljava/util/ArrayList;

.field public Iii:Landroid/widget/TextView;

.field public K11ID:Z

.field public RD:Landroid/os/Handler;

.field public Txy$$d_w$:Landroid/widget/ImageButton;

.field public WoI_9_:Ljava/lang/String;

.field public YOD0:Lorg/cybergarage/upnp/Device;

.field public dnN$d$:LsIndex9566;

.field public final gCount1961:Ljava/util/ArrayList;

.field public gSy_FG$D_:Landroid/widget/ImageButton;

.field public gc_$M_w2$:Linfo/t4w/vp/airplay/AirPlayDevice;

.field public iQ0D:Z

.field public iSize4906:Landroid/widget/ImageButton;

.field public k1y:LMàCqss;

.field public l1:Landroid/widget/TextView;

.field public oaX_6_:Landroid/widget/ProgressBar;

.field public pQ1Il:Landroid/widget/ListView;

.field public pZDcLvd:Ljava/lang/String;

.field public s$_D_:Ljava/lang/String;

.field public valu0:Ljava/util/concurrent/ExecutorService;

.field public vz$a$:Landroid/widget/ImageButton;

.field public zAt$p:Landroid/view/View;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LUd$5_1h$;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 10
    .line 11
    new-instance v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->gCount1961:Ljava/util/ArrayList;

    .line 17
    .line 18
    const/4 v0, 0x0

    .line 19
    iput-boolean v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->iQ0D:Z

    .line 20
    .line 21
    iput-boolean v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->K11ID:Z

    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final $ÒcdS(Ljava/lang/String;)V
    .locals 4

    .line 1
    const-string v0, "Error updating UI: "

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    :try_start_0
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->oaX_6_:Landroid/widget/ProgressBar;

    .line 5
    .line 6
    const/16 v3, 0x8

    .line 7
    .line 8
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 9
    .line 10
    .line 11
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->pQ1Il:Landroid/widget/ListView;

    .line 12
    .line 13
    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    .line 14
    .line 15
    .line 16
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->Iii:Landroid/widget/TextView;

    .line 17
    .line 18
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 19
    .line 20
    .line 21
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->Iii:Landroid/widget/TextView;

    .line 22
    .line 23
    invoke-virtual {v2, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 24
    .line 25
    .line 26
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->l1:Landroid/widget/TextView;

    .line 27
    .line 28
    invoke-virtual {v2, v1}, Landroid/view/View;->setVisibility(I)V

    .line 29
    .line 30
    .line 31
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->l1:Landroid/widget/TextView;

    .line 32
    .line 33
    const-string v3, "No casting devices found"

    .line 34
    .line 35
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :catch_0
    :try_start_1
    new-instance v2, Ljava/lang/StringBuilder;

    .line 40
    .line 41
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 56
    .line 57
    .line 58
    :catch_1
    return-void
.end method

.method public final UC_n_()V
    .locals 3

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->dnN$d$:LsIndex9566;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    const-string v0, "Stopping..."

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 16
    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 26
    .line 27
    new-instance v1, Lcn_v_;

    .line 28
    .line 29
    const/4 v2, 0x4

    .line 30
    invoke-direct {v1, p0, v2}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 31
    .line 32
    .line 33
    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_0
    const-string v0, "Playback control service not available"

    .line 38
    .line 39
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 44
    .line 45
    .line 46
    :cond_1
    return-void
.end method

.method public final kCount1402()V
    .locals 3

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 2
    .line 3
    new-instance v1, Lcn_v_;

    .line 4
    .line 5
    const/16 v2, 0xd

    .line 6
    .line 7
    invoke-direct {v1, p0, v2}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final onBackPressed()V
    .locals 3

    .line 1
    iget-boolean v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->K11ID:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Landroid/app/AlertDialog$Builder;

    .line 6
    .line 7
    invoke-direct {v0, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    const-string v1, "Disconnect"

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    const-string v1, "Do you want to disconnect from the device?"

    .line 17
    .line 18
    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    new-instance v1, LADXSR;

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    invoke-direct {v1, p0, v2}, LADXSR;-><init>(LUd$5_1h$;I)V

    .line 26
    .line 27
    .line 28
    const-string v2, "Yes"

    .line 29
    .line 30
    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    const-string v1, "No"

    .line 35
    .line 36
    const/4 v2, 0x0

    .line 37
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :cond_0
    invoke-super {p0}, LqboÌWm;->onBackPressed()V

    .line 46
    .line 47
    .line 48
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, LKùiu;->activity_multicast_cast:I

    .line 5
    .line 6
    invoke-virtual {p0, p1}, LUd$5_1h$;->setContentView(I)V

    .line 7
    .line 8
    .line 9
    new-instance p1, Landroid/os/Handler;

    .line 10
    .line 11
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-direct {p1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 16
    .line 17
    .line 18
    iput-object p1, p0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 19
    .line 20
    const/4 p1, 0x3

    .line 21
    invoke-static {p1}, Ljava/util/concurrent/Executors;->newFixedThreadPool(I)Ljava/util/concurrent/ExecutorService;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 26
    .line 27
    sget v0, LRO1QI;->toolbar:I

    .line 28
    .line 29
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Landroidx/appcompat/widget/Toolbar;

    .line 34
    .line 35
    invoke-virtual {p0, v0}, LUd$5_1h$;->Qp_Hp$i_(Landroidx/appcompat/widget/Toolbar;)V

    .line 36
    .line 37
    .line 38
    sget v0, LRO1QI;->main_layout:I

    .line 39
    .line 40
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    new-instance v1, LI1I;

    .line 45
    .line 46
    const/16 v2, 0x19

    .line 47
    .line 48
    invoke-direct {v1, v2}, LI1I;-><init>(I)V

    .line 49
    .line 50
    .line 51
    sget-object v2, Ll11Il;->e8$mp_s$:Ljava/util/WeakHashMap;

    .line 52
    .line 53
    invoke-static {v0, v1}, LI11l;->kQy(Landroid/view/View;LvllDQ;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    if-eqz v0, :cond_0

    .line 61
    .line 62
    const-string v1, "videoUrl"

    .line 63
    .line 64
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    iput-object v1, p0, Linfo/t4w/vp/view/MultiCastActivity;->pZDcLvd:Ljava/lang/String;

    .line 69
    .line 70
    const-string v1, "videoTitle"

    .line 71
    .line 72
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    iput-object v1, p0, Linfo/t4w/vp/view/MultiCastActivity;->WoI_9_:Ljava/lang/String;

    .line 77
    .line 78
    const-string v1, "userAgent"

    .line 79
    .line 80
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->s$_D_:Ljava/lang/String;

    .line 85
    .line 86
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->pZDcLvd:Ljava/lang/String;

    .line 87
    .line 88
    const/4 v1, 0x0

    .line 89
    if-eqz v0, :cond_2

    .line 90
    .line 91
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_1

    .line 96
    .line 97
    goto/16 :goto_0

    .line 98
    .line 99
    :cond_1
    sget v0, LRO1QI;->status_text:I

    .line 100
    .line 101
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    check-cast v0, Landroid/widget/TextView;

    .line 106
    .line 107
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->Iii:Landroid/widget/TextView;

    .line 108
    .line 109
    sget v0, LRO1QI;->no_devices_text:I

    .line 110
    .line 111
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Landroid/widget/TextView;

    .line 116
    .line 117
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->l1:Landroid/widget/TextView;

    .line 118
    .line 119
    sget v0, LRO1QI;->device_list:I

    .line 120
    .line 121
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 122
    .line 123
    .line 124
    move-result-object v0

    .line 125
    check-cast v0, Landroid/widget/ListView;

    .line 126
    .line 127
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->pQ1Il:Landroid/widget/ListView;

    .line 128
    .line 129
    sget v0, LRO1QI;->loading_spinner:I

    .line 130
    .line 131
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 132
    .line 133
    .line 134
    move-result-object v0

    .line 135
    check-cast v0, Landroid/widget/ProgressBar;

    .line 136
    .line 137
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->oaX_6_:Landroid/widget/ProgressBar;

    .line 138
    .line 139
    sget v0, LRO1QI;->refresh_button:I

    .line 140
    .line 141
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    check-cast v0, Landroid/widget/ImageButton;

    .line 146
    .line 147
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->BCIm:Landroid/widget/ImageButton;

    .line 148
    .line 149
    sget v0, LRO1QI;->media_controls_container:I

    .line 150
    .line 151
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->zAt$p:Landroid/view/View;

    .line 156
    .line 157
    sget v0, LRO1QI;->btn_play_pause:I

    .line 158
    .line 159
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    check-cast v0, Landroid/widget/ImageButton;

    .line 164
    .line 165
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->gSy_FG$D_:Landroid/widget/ImageButton;

    .line 166
    .line 167
    sget v0, LRO1QI;->btn_rewind:I

    .line 168
    .line 169
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    check-cast v0, Landroid/widget/ImageButton;

    .line 174
    .line 175
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->iSize4906:Landroid/widget/ImageButton;

    .line 176
    .line 177
    sget v0, LRO1QI;->btn_fast_forward:I

    .line 178
    .line 179
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    check-cast v0, Landroid/widget/ImageButton;

    .line 184
    .line 185
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->Txy$$d_w$:Landroid/widget/ImageButton;

    .line 186
    .line 187
    sget v0, LRO1QI;->btn_stop:I

    .line 188
    .line 189
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    check-cast v0, Landroid/widget/ImageButton;

    .line 194
    .line 195
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->vz$a$:Landroid/widget/ImageButton;

    .line 196
    .line 197
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->zAt$p:Landroid/view/View;

    .line 198
    .line 199
    const/16 v2, 0x8

    .line 200
    .line 201
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 202
    .line 203
    .line 204
    new-instance v0, LMàCqss;

    .line 205
    .line 206
    invoke-direct {v0, p0}, LMàCqss;-><init>(Linfo/t4w/vp/view/MultiCastActivity;)V

    .line 207
    .line 208
    .line 209
    iput-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->k1y:LMàCqss;

    .line 210
    .line 211
    iget-object v2, p0, Linfo/t4w/vp/view/MultiCastActivity;->pQ1Il:Landroid/widget/ListView;

    .line 212
    .line 213
    invoke-virtual {v2, v0}, Landroid/widget/ListView;->setAdapter(Landroid/widget/ListAdapter;)V

    .line 214
    .line 215
    .line 216
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->BCIm:Landroid/widget/ImageButton;

    .line 217
    .line 218
    new-instance v2, Lind0x;

    .line 219
    .line 220
    invoke-direct {v2, p0, v1}, Lind0x;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 221
    .line 222
    .line 223
    invoke-virtual {v0, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 224
    .line 225
    .line 226
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->gSy_FG$D_:Landroid/widget/ImageButton;

    .line 227
    .line 228
    new-instance v1, Lind0x;

    .line 229
    .line 230
    const/4 v2, 0x1

    .line 231
    invoke-direct {v1, p0, v2}, Lind0x;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 232
    .line 233
    .line 234
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 235
    .line 236
    .line 237
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->vz$a$:Landroid/widget/ImageButton;

    .line 238
    .line 239
    new-instance v1, Lind0x;

    .line 240
    .line 241
    const/4 v2, 0x2

    .line 242
    invoke-direct {v1, p0, v2}, Lind0x;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 243
    .line 244
    .line 245
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 246
    .line 247
    .line 248
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->iSize4906:Landroid/widget/ImageButton;

    .line 249
    .line 250
    new-instance v1, Lind0x;

    .line 251
    .line 252
    invoke-direct {v1, p0, p1}, Lind0x;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 256
    .line 257
    .line 258
    iget-object p1, p0, Linfo/t4w/vp/view/MultiCastActivity;->Txy$$d_w$:Landroid/widget/ImageButton;

    .line 259
    .line 260
    new-instance v0, Lind0x;

    .line 261
    .line 262
    const/4 v1, 0x4

    .line 263
    invoke-direct {v0, p0, v1}, Lind0x;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 264
    .line 265
    .line 266
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 267
    .line 268
    .line 269
    iget-object p1, p0, Linfo/t4w/vp/view/MultiCastActivity;->pQ1Il:Landroid/widget/ListView;

    .line 270
    .line 271
    new-instance v0, LsXz$g_$;

    .line 272
    .line 273
    invoke-direct {v0, p0}, LsXz$g_$;-><init>(Linfo/t4w/vp/view/MultiCastActivity;)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {p1, v0}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 277
    .line 278
    .line 279
    iget-object p1, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 280
    .line 281
    new-instance v0, Lcn_v_;

    .line 282
    .line 283
    const/16 v1, 0x13

    .line 284
    .line 285
    invoke-direct {v0, p0, v1}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 286
    .line 287
    .line 288
    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 289
    .line 290
    .line 291
    return-void

    .line 292
    :cond_2
    :goto_0
    const-string p1, "No video URL provided"

    .line 293
    .line 294
    invoke-static {p0, p1, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 295
    .line 296
    .line 297
    move-result-object p1

    .line 298
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 299
    .line 300
    .line 301
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 302
    .line 303
    .line 304
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onDestroy()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->RD:Landroid/os/Handler;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 13
    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_1

    .line 21
    .line 22
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 23
    .line 24
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    .line 25
    .line 26
    .line 27
    iput-object v1, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 28
    .line 29
    :cond_1
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->dnN$d$:LsIndex9566;

    .line 30
    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    :try_start_0
    invoke-virtual {v0}, LsIndex9566;->iOffset934()V

    .line 34
    .line 35
    .line 36
    iput-object v1, p0, Linfo/t4w/vp/view/MultiCastActivity;->dnN$d$:LsIndex9566;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 37
    .line 38
    goto :goto_0

    .line 39
    :catch_0
    move-exception v0

    .line 40
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    :cond_2
    :goto_0
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->ChI_KH_:Ljava/util/ArrayList;

    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 46
    .line 47
    .line 48
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->gCount1961:Ljava/util/ArrayList;

    .line 49
    .line 50
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->k1y:LMàCqss;

    .line 54
    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    iput-object v1, p0, Linfo/t4w/vp/view/MultiCastActivity;->k1y:LMàCqss;

    .line 58
    .line 59
    :cond_3
    return-void
.end method

.method public final onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 2

    .line 1
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, 0x102002c

    .line 6
    .line 7
    .line 8
    if-ne v0, v1, :cond_0

    .line 9
    .line 10
    invoke-virtual {p0}, Linfo/t4w/vp/view/MultiCastActivity;->onBackPressed()V

    .line 11
    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    return p1

    .line 15
    :cond_0
    invoke-super {p0, p1}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    return p1
.end method

.method public final onPause()V
    .locals 3

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onPause()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->dnN$d$:LsIndex9566;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    :try_start_0
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 19
    .line 20
    new-instance v1, Lcn_v_;

    .line 21
    .line 22
    const/16 v2, 0x8

    .line 23
    .line 24
    invoke-direct {v1, p0, v2}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 25
    .line 26
    .line 27
    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :catch_0
    move-exception v0

    .line 32
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    :cond_0
    return-void
.end method

.method public final onResume()V
    .locals 3

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onResume()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->dnN$d$:LsIndex9566;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    :try_start_0
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->isShutdown()Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_0

    .line 17
    .line 18
    iget-object v0, p0, Linfo/t4w/vp/view/MultiCastActivity;->valu0:Ljava/util/concurrent/ExecutorService;

    .line 19
    .line 20
    new-instance v1, Lcn_v_;

    .line 21
    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-direct {v1, p0, v2}, Lcn_v_;-><init>(Linfo/t4w/vp/view/MultiCastActivity;I)V

    .line 24
    .line 25
    .line 26
    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :catch_0
    move-exception v0

    .line 31
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 32
    .line 33
    .line 34
    const-string v0, "Error resuming device discovery"

    .line 35
    .line 36
    const/4 v1, 0x0

    .line 37
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 42
    .line 43
    .line 44
    :cond_0
    return-void
.end method
