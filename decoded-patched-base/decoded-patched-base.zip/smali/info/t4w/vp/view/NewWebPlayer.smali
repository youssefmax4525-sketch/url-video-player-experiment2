.class public Linfo/t4w/vp/view/NewWebPlayer;
.super LUd$5_1h$;
.source "SourceFile"

# interfaces
.implements LGl1ID;


# static fields
.field public static final synthetic colnt:I


# instance fields
.field public BCIm:Landroid/widget/LinearLayout;

.field public ChI_KH_:Ljava/util/HashMap;

.field public Iii:Landroid/webkit/WebView;

.field public K11ID:[Ljava/lang/String;

.field public RD:Z

.field public Txy$$d_w$:Landroid/widget/ImageButton;

.field public WoI_9_:Ljava/util/HashMap;

.field public YOD0:Ljava/lang/String;

.field public dnN$d$:LtmpKey8240;

.field public final gCount1961:Landroid/os/Handler;

.field public gSy_FG$D_:Landroid/widget/Button;

.field public gc_$M_w2$:[Ljava/lang/String;

.field public iQ0D:[Ljava/lang/String;

.field public iSize4906:Landroid/widget/ImageButton;

.field public k1y:LQun$1$;

.field public l1:Landroidx/recyclerview/widget/RecyclerView;

.field public lIl1:Ljava/lang/String;

.field public oaX_6_:Landroid/widget/TextView;

.field public pQ1Il:LBa8àhzR;

.field public pZDcLvd:Z

.field public po0:Landroid/widget/LinearLayout;

.field public s$_D_:Ljava/lang/String;

.field public valu0:Z

.field public vz$a$:Landroid/widget/ImageButton;

.field public zAt$p:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, LUd$5_1h$;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/os/Handler;

    .line 5
    .line 6
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->gCount1961:Landroid/os/Handler;

    .line 14
    .line 15
    const/4 v0, 0x0

    .line 16
    iput-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->RD:Z

    .line 17
    .line 18
    const/4 v1, 0x1

    .line 19
    iput-boolean v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->valu0:Z

    .line 20
    .line 21
    const-string v1, ""

    .line 22
    .line 23
    iput-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->YOD0:Ljava/lang/String;

    .line 24
    .line 25
    iput-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->pZDcLvd:Z

    .line 26
    .line 27
    new-instance v0, Ljava/util/HashMap;

    .line 28
    .line 29
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->WoI_9_:Ljava/util/HashMap;

    .line 33
    .line 34
    iput-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->s$_D_:Ljava/lang/String;

    .line 35
    .line 36
    return-void
.end method

.method public static UC_n_(Linfo/t4w/vp/view/NewWebPlayer;I)Ljava/lang/String;
    .locals 0

    .line 1
    const/16 p0, 0xcc

    .line 2
    .line 3
    if-eq p1, p0, :cond_6

    .line 4
    .line 5
    const/16 p0, 0x130

    .line 6
    .line 7
    if-eq p1, p0, :cond_5

    .line 8
    .line 9
    const/16 p0, 0x1f4

    .line 10
    .line 11
    if-eq p1, p0, :cond_4

    .line 12
    .line 13
    const/16 p0, 0x12d

    .line 14
    .line 15
    if-eq p1, p0, :cond_3

    .line 16
    .line 17
    const/16 p0, 0x12e

    .line 18
    .line 19
    if-eq p1, p0, :cond_2

    .line 20
    .line 21
    const/16 p0, 0x190

    .line 22
    .line 23
    if-eq p1, p0, :cond_1

    .line 24
    .line 25
    const/16 p0, 0x191

    .line 26
    .line 27
    if-eq p1, p0, :cond_0

    .line 28
    .line 29
    packed-switch p1, :pswitch_data_0

    .line 30
    .line 31
    .line 32
    packed-switch p1, :pswitch_data_1

    .line 33
    .line 34
    .line 35
    packed-switch p1, :pswitch_data_2

    .line 36
    .line 37
    .line 38
    const-string p0, "Unknown"

    .line 39
    .line 40
    return-object p0

    .line 41
    :pswitch_0
    const-string p0, "Gateway Timeout"

    .line 42
    .line 43
    return-object p0

    .line 44
    :pswitch_1
    const-string p0, "Service Unavailable"

    .line 45
    .line 46
    return-object p0

    .line 47
    :pswitch_2
    const-string p0, "Bad Gateway"

    .line 48
    .line 49
    return-object p0

    .line 50
    :pswitch_3
    const-string p0, "Method Not Allowed"

    .line 51
    .line 52
    return-object p0

    .line 53
    :pswitch_4
    const-string p0, "Not Found"

    .line 54
    .line 55
    return-object p0

    .line 56
    :pswitch_5
    const-string p0, "Forbidden"

    .line 57
    .line 58
    return-object p0

    .line 59
    :pswitch_6
    const-string p0, "Accepted"

    .line 60
    .line 61
    return-object p0

    .line 62
    :pswitch_7
    const-string p0, "Created"

    .line 63
    .line 64
    return-object p0

    .line 65
    :pswitch_8
    const-string p0, "OK"

    .line 66
    .line 67
    return-object p0

    .line 68
    :cond_0
    const-string p0, "Unauthorized"

    .line 69
    .line 70
    return-object p0

    .line 71
    :cond_1
    const-string p0, "Bad Request"

    .line 72
    .line 73
    return-object p0

    .line 74
    :cond_2
    const-string p0, "Found"

    .line 75
    .line 76
    return-object p0

    .line 77
    :cond_3
    const-string p0, "Moved Permanently"

    .line 78
    .line 79
    return-object p0

    .line 80
    :cond_4
    const-string p0, "Internal Server Error"

    .line 81
    .line 82
    return-object p0

    .line 83
    :cond_5
    const-string p0, "Not Modified"

    .line 84
    .line 85
    return-object p0

    .line 86
    :cond_6
    const-string p0, "No Content"

    .line 87
    .line 88
    return-object p0

    .line 89
    :pswitch_data_0
    .packed-switch 0xc8
        :pswitch_8
        :pswitch_7
        :pswitch_6
    .end packed-switch

    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    :pswitch_data_1
    .packed-switch 0x193
        :pswitch_5
        :pswitch_4
        :pswitch_3
    .end packed-switch

    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    :pswitch_data_2
    .packed-switch 0x1f6
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static kCount1402(Linfo/t4w/vp/view/NewWebPlayer;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 0

    .line 1
    sget-object p0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2
    .line 3
    invoke-virtual {p1, p0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const-string p1, "video/"

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 10
    .line 11
    .line 12
    move-result p1

    .line 13
    if-eqz p1, :cond_0

    .line 14
    .line 15
    invoke-static {p2}, Linfo/t4w/vp/view/NewWebPlayer;->sKey6064(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    if-nez p1, :cond_5

    .line 20
    .line 21
    :cond_0
    const-string p1, "application/x-mpegurl"

    .line 22
    .line 23
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    invoke-static {p2}, Linfo/t4w/vp/view/NewWebPlayer;->sKey6064(Ljava/lang/String;)Z

    .line 30
    .line 31
    .line 32
    move-result p1

    .line 33
    if-nez p1, :cond_5

    .line 34
    .line 35
    :cond_1
    const-string p1, "application/vnd.apple.mpegurl"

    .line 36
    .line 37
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result p1

    .line 41
    if-eqz p1, :cond_2

    .line 42
    .line 43
    invoke-static {p2}, Linfo/t4w/vp/view/NewWebPlayer;->sKey6064(Ljava/lang/String;)Z

    .line 44
    .line 45
    .line 46
    move-result p1

    .line 47
    if-nez p1, :cond_5

    .line 48
    .line 49
    :cond_2
    const-string p1, "application/dash+xml"

    .line 50
    .line 51
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result p1

    .line 55
    if-eqz p1, :cond_3

    .line 56
    .line 57
    invoke-static {p2}, Linfo/t4w/vp/view/NewWebPlayer;->sKey6064(Ljava/lang/String;)Z

    .line 58
    .line 59
    .line 60
    move-result p1

    .line 61
    if-nez p1, :cond_5

    .line 62
    .line 63
    :cond_3
    const-string p1, "application/x-shockwave-flash"

    .line 64
    .line 65
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    if-eqz p1, :cond_4

    .line 70
    .line 71
    invoke-static {p2}, Linfo/t4w/vp/view/NewWebPlayer;->sKey6064(Ljava/lang/String;)Z

    .line 72
    .line 73
    .line 74
    move-result p1

    .line 75
    if-nez p1, :cond_5

    .line 76
    .line 77
    :cond_4
    const-string p1, "application/octet-stream"

    .line 78
    .line 79
    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    move-result p0

    .line 83
    if-eqz p0, :cond_6

    .line 84
    .line 85
    invoke-static {p2}, Linfo/t4w/vp/view/NewWebPlayer;->sKey6064(Ljava/lang/String;)Z

    .line 86
    .line 87
    .line 88
    move-result p0

    .line 89
    if-eqz p0, :cond_6

    .line 90
    .line 91
    :cond_5
    const/4 p0, 0x1

    .line 92
    return p0

    .line 93
    :cond_6
    const/4 p0, 0x0

    .line 94
    return p0
.end method

.method public static sKey6064(Ljava/lang/String;)Z
    .locals 1

    .line 1
    if-nez p0, :cond_0

    .line 2
    .line 3
    goto :goto_0

    .line 4
    :cond_0
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const-string v0, ".mp4"

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    if-nez v0, :cond_2

    .line 17
    .line 18
    const-string v0, ".mov"

    .line 19
    .line 20
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    if-nez v0, :cond_2

    .line 25
    .line 26
    const-string v0, ".flv"

    .line 27
    .line 28
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-nez v0, :cond_2

    .line 33
    .line 34
    const-string v0, ".webm"

    .line 35
    .line 36
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_2

    .line 41
    .line 42
    const-string v0, ".mkv"

    .line 43
    .line 44
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-nez v0, :cond_2

    .line 49
    .line 50
    const-string v0, ".m3u8"

    .line 51
    .line 52
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_2

    .line 57
    .line 58
    const-string v0, ".mpd"

    .line 59
    .line 60
    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 61
    .line 62
    .line 63
    move-result p0

    .line 64
    if-eqz p0, :cond_1

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_1
    :goto_0
    const/4 p0, 0x0

    .line 68
    return p0

    .line 69
    :cond_2
    :goto_1
    const/4 p0, 0x1

    .line 70
    return p0
.end method


# virtual methods
.method public final $ÒcdS()V
    .locals 3

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->RD:Z

    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Txy$$d_w$:Landroid/widget/ImageButton;

    .line 5
    .line 6
    sget v1, LindeQ;->ic_fullscreen_exit:I

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->tmpSize211()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->iSize4906:Landroid/widget/ImageButton;

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 20
    .line 21
    .line 22
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    const/16 v1, 0x400

    .line 27
    .line 28
    invoke-virtual {v0, v1, v1}, Landroid/view/Window;->setFlags(II)V

    .line 29
    .line 30
    .line 31
    const v0, 0x1020002

    .line 32
    .line 33
    .line 34
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    instance-of v1, v0, Landroid/view/ViewGroup;

    .line 39
    .line 40
    if-eqz v1, :cond_1

    .line 41
    .line 42
    check-cast v0, Landroid/view/ViewGroup;

    .line 43
    .line 44
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 45
    .line 46
    .line 47
    move-result v1

    .line 48
    if-lez v1, :cond_1

    .line 49
    .line 50
    const/4 v1, 0x0

    .line 51
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    instance-of v2, v0, Landroid/view/ViewGroup;

    .line 56
    .line 57
    if-eqz v2, :cond_1

    .line 58
    .line 59
    check-cast v0, Landroid/view/ViewGroup;

    .line 60
    .line 61
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    if-lez v2, :cond_1

    .line 66
    .line 67
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    const/16 v1, 0x8

    .line 72
    .line 73
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 74
    .line 75
    .line 76
    :cond_1
    return-void
.end method

.method public final Q1_f_()V
    .locals 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->RD:Z

    .line 3
    .line 4
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->Txy$$d_w$:Landroid/widget/ImageButton;

    .line 5
    .line 6
    sget v2, LindeQ;->ic_fullscreen:I

    .line 7
    .line 8
    invoke-virtual {v1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->tmpSize211()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->l1:Landroidx/recyclerview/widget/RecyclerView;

    .line 18
    .line 19
    new-instance v2, LQun$1$;

    .line 20
    .line 21
    const/4 v3, 0x1

    .line 22
    invoke-direct {v2, p0, v3}, LQun$1$;-><init>(Linfo/t4w/vp/view/NewWebPlayer;I)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v1, v2}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 26
    .line 27
    .line 28
    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    const/16 v2, 0x400

    .line 33
    .line 34
    invoke-virtual {v1, v2}, Landroid/view/Window;->clearFlags(I)V

    .line 35
    .line 36
    .line 37
    const v1, 0x1020002

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0, v1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    instance-of v2, v1, Landroid/view/ViewGroup;

    .line 45
    .line 46
    if-eqz v2, :cond_1

    .line 47
    .line 48
    check-cast v1, Landroid/view/ViewGroup;

    .line 49
    .line 50
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-lez v2, :cond_1

    .line 55
    .line 56
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v1

    .line 60
    instance-of v2, v1, Landroid/view/ViewGroup;

    .line 61
    .line 62
    if-eqz v2, :cond_1

    .line 63
    .line 64
    check-cast v1, Landroid/view/ViewGroup;

    .line 65
    .line 66
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    if-lez v2, :cond_1

    .line 71
    .line 72
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 77
    .line 78
    .line 79
    :cond_1
    return-void
.end method

.method public final enterPictureInPictureMode()V
    .locals 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1a

    .line 4
    .line 5
    if-lt v0, v1, :cond_1

    .line 6
    .line 7
    :try_start_0
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 8
    .line 9
    .line 10
    move-result-object v1

    .line 11
    const-string v2, "android.software.picture_in_picture"

    .line 12
    .line 13
    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    if-eqz v1, :cond_1

    .line 18
    .line 19
    new-instance v1, Landroid/util/Rational;

    .line 20
    .line 21
    const/16 v2, 0x10

    .line 22
    .line 23
    const/16 v3, 0x9

    .line 24
    .line 25
    invoke-direct {v1, v2, v3}, Landroid/util/Rational;-><init>(II)V

    .line 26
    .line 27
    .line 28
    invoke-static {}, LKcÒ2;->jPos3709()V

    .line 29
    .line 30
    .line 31
    invoke-static {}, LrMBhl;->JKEoÙX()Landroid/app/PictureInPictureParams$Builder;

    .line 32
    .line 33
    .line 34
    move-result-object v2

    .line 35
    invoke-static {v2, v1}, LKcÒ2;->POOl(Landroid/app/PictureInPictureParams$Builder;Landroid/util/Rational;)Landroid/app/PictureInPictureParams$Builder;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    const/16 v2, 0x1f

    .line 40
    .line 41
    if-lt v0, v2, :cond_0

    .line 42
    .line 43
    invoke-static {v1}, LVlO1I;->valuI(Landroid/app/PictureInPictureParams$Builder;)V

    .line 44
    .line 45
    .line 46
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 47
    .line 48
    if-eqz v0, :cond_0

    .line 49
    .line 50
    new-instance v0, Landroid/graphics/Rect;

    .line 51
    .line 52
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 53
    .line 54
    .line 55
    iget-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 56
    .line 57
    invoke-virtual {v2, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    .line 58
    .line 59
    .line 60
    invoke-static {v1, v0}, LrMBhl;->K0I(Landroid/app/PictureInPictureParams$Builder;Landroid/graphics/Rect;)V

    .line 61
    .line 62
    .line 63
    :cond_0
    invoke-static {v1}, LrMBhl;->tmpData3485(Landroid/app/PictureInPictureParams$Builder;)Landroid/app/PictureInPictureParams;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    invoke-static {p0, v0}, LKcÒ2;->K0I(Linfo/t4w/vp/view/NewWebPlayer;Landroid/app/PictureInPictureParams;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 68
    .line 69
    .line 70
    :catch_0
    :cond_1
    return-void
.end method

.method public final ll()V
    .locals 4

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->zAt$p:Landroid/widget/LinearLayout;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->s$_D_:Ljava/lang/String;

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    if-nez v0, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->gSy_FG$D_:Landroid/widget/Button;

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 20
    .line 21
    .line 22
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->k1y:LQun$1$;

    .line 23
    .line 24
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->gCount1961:Landroid/os/Handler;

    .line 25
    .line 26
    invoke-virtual {v1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->k1y:LQun$1$;

    .line 30
    .line 31
    const-wide/16 v2, 0x1388

    .line 32
    .line 33
    invoke-virtual {v1, v0, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 34
    .line 35
    .line 36
    return-void
.end method

.method public final onBackPressed()V
    .locals 1

    .line 1
    invoke-super {p0}, LqboÌWm;->onBackPressed()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->RD:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->Q1_f_()V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 13
    .line 14
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 7

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v0, 0x1a

    .line 7
    .line 8
    const/16 v1, 0x1c

    .line 9
    .line 10
    if-lt p1, v0, :cond_0

    .line 11
    .line 12
    if-lt p1, v1, :cond_0

    .line 13
    .line 14
    :try_start_0
    invoke-static {}, LCA$b_$K$;->tzKù7Ol1()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    :cond_0
    :goto_0
    sget p1, LKùiu;->activity_web_player_new:I

    .line 23
    .line 24
    invoke-virtual {p0, p1}, LUd$5_1h$;->setContentView(I)V

    .line 25
    .line 26
    .line 27
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 28
    .line 29
    if-lt p1, v1, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    invoke-static {p1}, LCA$b_$K$;->gKey4112(Landroid/view/WindowManager$LayoutParams;)V

    .line 40
    .line 41
    .line 42
    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const/16 v0, 0x600

    .line 47
    .line 48
    invoke-virtual {p1, v0, v0}, Landroid/view/Window;->setFlags(II)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    const/16 v0, 0x1706

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 62
    .line 63
    .line 64
    const/4 p1, 0x0

    .line 65
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    const-string v1, "url"

    .line 73
    .line 74
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->YOD0:Ljava/lang/String;

    .line 79
    .line 80
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    const-string v1, "agent"

    .line 85
    .line 86
    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    sget v0, LRO1QI;->ad_layout:I

    .line 90
    .line 91
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    check-cast v0, Landroid/widget/LinearLayout;

    .line 96
    .line 97
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->po0:Landroid/widget/LinearLayout;

    .line 98
    .line 99
    sget v0, LcJLÌfz;->admob_ad_id:I

    .line 100
    .line 101
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object v0

    .line 105
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->lIl1:Ljava/lang/String;

    .line 106
    .line 107
    sget v0, LRO1QI;->webView:I

    .line 108
    .line 109
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    check-cast v0, Landroid/webkit/WebView;

    .line 114
    .line 115
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 116
    .line 117
    sget v0, LRO1QI;->linkRecyclerView:I

    .line 118
    .line 119
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    check-cast v0, Landroidx/recyclerview/widget/RecyclerView;

    .line 124
    .line 125
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->l1:Landroidx/recyclerview/widget/RecyclerView;

    .line 126
    .line 127
    sget v0, LRO1QI;->statusText:I

    .line 128
    .line 129
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 130
    .line 131
    .line 132
    move-result-object v0

    .line 133
    check-cast v0, Landroid/widget/TextView;

    .line 134
    .line 135
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->oaX_6_:Landroid/widget/TextView;

    .line 136
    .line 137
    sget v0, LRO1QI;->loadingOverlay:I

    .line 138
    .line 139
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    check-cast v0, Landroid/widget/LinearLayout;

    .line 144
    .line 145
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->BCIm:Landroid/widget/LinearLayout;

    .line 146
    .line 147
    sget v0, LRO1QI;->webViewControls:I

    .line 148
    .line 149
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 150
    .line 151
    .line 152
    move-result-object v0

    .line 153
    check-cast v0, Landroid/widget/LinearLayout;

    .line 154
    .line 155
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->zAt$p:Landroid/widget/LinearLayout;

    .line 156
    .line 157
    sget v0, LRO1QI;->externel_player:I

    .line 158
    .line 159
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    check-cast v0, Landroid/widget/Button;

    .line 164
    .line 165
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->gSy_FG$D_:Landroid/widget/Button;

    .line 166
    .line 167
    sget v0, LRO1QI;->playPauseButton:I

    .line 168
    .line 169
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    check-cast v0, Landroid/widget/ImageButton;

    .line 174
    .line 175
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->iSize4906:Landroid/widget/ImageButton;

    .line 176
    .line 177
    sget v0, LRO1QI;->fullscreenButton:I

    .line 178
    .line 179
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    check-cast v0, Landroid/widget/ImageButton;

    .line 184
    .line 185
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Txy$$d_w$:Landroid/widget/ImageButton;

    .line 186
    .line 187
    sget v0, LRO1QI;->pipButton:I

    .line 188
    .line 189
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 190
    .line 191
    .line 192
    move-result-object v0

    .line 193
    check-cast v0, Landroid/widget/ImageButton;

    .line 194
    .line 195
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->vz$a$:Landroid/widget/ImageButton;

    .line 196
    .line 197
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->iSize4906:Landroid/widget/ImageButton;

    .line 198
    .line 199
    new-instance v1, LujAK;

    .line 200
    .line 201
    const/4 v2, 0x1

    .line 202
    invoke-direct {v1, p0, v2}, LujAK;-><init>(Linfo/t4w/vp/view/NewWebPlayer;I)V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 206
    .line 207
    .line 208
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Txy$$d_w$:Landroid/widget/ImageButton;

    .line 209
    .line 210
    new-instance v1, LujAK;

    .line 211
    .line 212
    const/4 v2, 0x2

    .line 213
    invoke-direct {v1, p0, v2}, LujAK;-><init>(Linfo/t4w/vp/view/NewWebPlayer;I)V

    .line 214
    .line 215
    .line 216
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 217
    .line 218
    .line 219
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->vz$a$:Landroid/widget/ImageButton;

    .line 220
    .line 221
    new-instance v1, LujAK;

    .line 222
    .line 223
    const/4 v2, 0x0

    .line 224
    invoke-direct {v1, p0, v2}, LujAK;-><init>(Linfo/t4w/vp/view/NewWebPlayer;I)V

    .line 225
    .line 226
    .line 227
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 228
    .line 229
    .line 230
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->gSy_FG$D_:Landroid/widget/Button;

    .line 231
    .line 232
    new-instance v1, LwLEyS;

    .line 233
    .line 234
    const/4 v2, 0x7

    .line 235
    invoke-direct {v1, v2, p0}, LwLEyS;-><init>(ILjava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 239
    .line 240
    .line 241
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 242
    .line 243
    new-instance v1, Lw0d$y$;

    .line 244
    .line 245
    const/4 v2, 0x2

    .line 246
    invoke-direct {v1, v2, p0}, Lw0d$y$;-><init>(ILjava/lang/Object;)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {v0, v1}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 250
    .line 251
    .line 252
    new-instance v0, LQun$1$;

    .line 253
    .line 254
    const/4 v1, 0x0

    .line 255
    invoke-direct {v0, p0, v1}, LQun$1$;-><init>(Linfo/t4w/vp/view/NewWebPlayer;I)V

    .line 256
    .line 257
    .line 258
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->k1y:LQun$1$;

    .line 259
    .line 260
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->ll()V

    .line 261
    .line 262
    .line 263
    new-instance v0, LHC_1$8_;

    .line 264
    .line 265
    invoke-direct {v0}, LHC_1$8_;-><init>()V

    .line 266
    .line 267
    .line 268
    const/4 v1, 0x1

    .line 269
    iput-boolean v1, v0, LHC_1$8_;->yON3x:Z

    .line 270
    .line 271
    iput-boolean v1, v0, LHC_1$8_;->vaIue:Z

    .line 272
    .line 273
    new-instance v2, LtmpKey8240;

    .line 274
    .line 275
    invoke-direct {v2, v0}, LtmpKey8240;-><init>(LHC_1$8_;)V

    .line 276
    .line 277
    .line 278
    iput-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->dnN$d$:LtmpKey8240;

    .line 279
    .line 280
    new-instance v0, Ljava/util/HashMap;

    .line 281
    .line 282
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 283
    .line 284
    .line 285
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->ChI_KH_:Ljava/util/HashMap;

    .line 286
    .line 287
    sget-object v2, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 288
    .line 289
    const-string v2, "User-Agent"

    .line 290
    .line 291
    const-string v3, "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36"

    .line 292
    .line 293
    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 294
    .line 295
    .line 296
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->ChI_KH_:Ljava/util/HashMap;

    .line 297
    .line 298
    const-string v3, "sec-ch-ua"

    .line 299
    .line 300
    const-string v4, "\"Chromium\";v=\"141\", \"Google Chrome\";v=\"141\", \"Not)A;Brand\";v=\"24\""

    .line 301
    .line 302
    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->ChI_KH_:Ljava/util/HashMap;

    .line 306
    .line 307
    const-string v3, "sec-ch-ua-mobile"

    .line 308
    .line 309
    const-string v4, "?1"

    .line 310
    .line 311
    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 312
    .line 313
    .line 314
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->ChI_KH_:Ljava/util/HashMap;

    .line 315
    .line 316
    const-string v3, "sec-ch-ua-platform"

    .line 317
    .line 318
    const-string v4, "\"Android\""

    .line 319
    .line 320
    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 321
    .line 322
    .line 323
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 324
    .line 325
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 330
    .line 331
    .line 332
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    .line 336
    .line 337
    .line 338
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    .line 339
    .line 340
    .line 341
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    .line 342
    .line 343
    .line 344
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setDisplayZoomControls(Z)V

    .line 345
    .line 346
    .line 347
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 348
    .line 349
    .line 350
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setMixedContentMode(I)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 354
    .line 355
    .line 356
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    .line 357
    .line 358
    .line 359
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    .line 363
    .line 364
    .line 365
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    .line 369
    .line 370
    .line 371
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setSupportMultipleWindows(Z)V

    .line 372
    .line 373
    .line 374
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setNeedInitialFocus(Z)V

    .line 375
    .line 376
    .line 377
    sget-object v3, Landroid/webkit/WebSettings$RenderPriority;->HIGH:Landroid/webkit/WebSettings$RenderPriority;

    .line 378
    .line 379
    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setRenderPriority(Landroid/webkit/WebSettings$RenderPriority;)V

    .line 380
    .line 381
    .line 382
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setSaveFormData(Z)V

    .line 383
    .line 384
    .line 385
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setSavePassword(Z)V

    .line 386
    .line 387
    .line 388
    const-string v3, "utf-8"

    .line 389
    .line 390
    invoke-virtual {v0, v3}, Landroid/webkit/WebSettings;->setDefaultTextEncodingName(Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    iget-object v3, p0, Linfo/t4w/vp/view/NewWebPlayer;->ChI_KH_:Ljava/util/HashMap;

    .line 394
    .line 395
    invoke-virtual {v3, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 396
    .line 397
    .line 398
    move-result v3

    .line 399
    if-eqz v3, :cond_2

    .line 400
    .line 401
    iget-object v3, p0, Linfo/t4w/vp/view/NewWebPlayer;->ChI_KH_:Ljava/util/HashMap;

    .line 402
    .line 403
    invoke-virtual {v3, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    move-result-object v2

    .line 407
    check-cast v2, Ljava/lang/String;

    .line 408
    .line 409
    invoke-virtual {v0, v2}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 410
    .line 411
    .line 412
    :cond_2
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setMixedContentMode(I)V

    .line 413
    .line 414
    .line 415
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 416
    .line 417
    new-instance v2, LisItem9465;

    .line 418
    .line 419
    iget-object v3, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 420
    .line 421
    invoke-direct {v2, p0, v3}, LisItem9465;-><init>(Linfo/t4w/vp/view/NewWebPlayer;Landroid/webkit/WebView;)V

    .line 422
    .line 423
    .line 424
    invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 425
    .line 426
    .line 427
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->YOD0:Ljava/lang/String;

    .line 428
    .line 429
    const-string v2, "!"

    .line 430
    .line 431
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 432
    .line 433
    .line 434
    move-result-object v0

    .line 435
    array-length v2, v0

    .line 436
    new-array v2, v2, [Ljava/lang/String;

    .line 437
    .line 438
    iput-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->gc_$M_w2$:[Ljava/lang/String;

    .line 439
    .line 440
    array-length v2, v0

    .line 441
    new-array v2, v2, [Ljava/lang/String;

    .line 442
    .line 443
    iput-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->iQ0D:[Ljava/lang/String;

    .line 444
    .line 445
    array-length v2, v0

    .line 446
    new-array v2, v2, [Ljava/lang/String;

    .line 447
    .line 448
    iput-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->K11ID:[Ljava/lang/String;

    .line 449
    .line 450
    const/4 v2, 0x0

    .line 451
    :goto_1
    array-length v3, v0

    .line 452
    if-ge v2, v3, :cond_4

    .line 453
    .line 454
    aget-object v3, v0, v2

    .line 455
    .line 456
    const-string v4, "<<R>>"

    .line 457
    .line 458
    invoke-virtual {v3, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 459
    .line 460
    .line 461
    move-result v5

    .line 462
    if-eqz v5, :cond_3

    .line 463
    .line 464
    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 465
    .line 466
    .line 467
    move-result-object v4

    .line 468
    array-length v5, v4

    .line 469
    const/4 v6, 0x2

    .line 470
    if-ne v5, v6, :cond_3

    .line 471
    .line 472
    aget-object v3, v4, p1

    .line 473
    .line 474
    aget-object v4, v4, v1

    .line 475
    .line 476
    goto :goto_2

    .line 477
    :cond_3
    const/4 v4, 0x0

    .line 478
    :goto_2
    iget-object v5, p0, Linfo/t4w/vp/view/NewWebPlayer;->gc_$M_w2$:[Ljava/lang/String;

    .line 479
    .line 480
    aput-object v3, v5, v2

    .line 481
    .line 482
    iget-object v5, p0, Linfo/t4w/vp/view/NewWebPlayer;->K11ID:[Ljava/lang/String;

    .line 483
    .line 484
    aput-object v4, v5, v2

    .line 485
    .line 486
    :try_start_1
    new-instance v4, Ljava/net/URL;

    .line 487
    .line 488
    invoke-direct {v4, v3}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    .line 489
    .line 490
    .line 491
    iget-object v3, p0, Linfo/t4w/vp/view/NewWebPlayer;->iQ0D:[Ljava/lang/String;

    .line 492
    .line 493
    invoke-virtual {v4}, Ljava/net/URL;->getHost()Ljava/lang/String;

    .line 494
    .line 495
    .line 496
    move-result-object v4

    .line 497
    aput-object v4, v3, v2
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 498
    .line 499
    :catch_1
    add-int/lit8 v2, v2, 0x1

    .line 500
    .line 501
    goto :goto_1

    .line 502
    :cond_4
    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 503
    .line 504
    invoke-direct {v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(I)V

    .line 505
    .line 506
    .line 507
    iget-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->l1:Landroidx/recyclerview/widget/RecyclerView;

    .line 508
    .line 509
    invoke-virtual {v2, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/JKEoÙX;)V

    .line 510
    .line 511
    .line 512
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->l1:Landroidx/recyclerview/widget/RecyclerView;

    .line 513
    .line 514
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setNestedScrollingEnabled(Z)V

    .line 515
    .line 516
    .line 517
    new-instance v0, LBa8àhzR;

    .line 518
    .line 519
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->iQ0D:[Ljava/lang/String;

    .line 520
    .line 521
    new-instance v2, LzdS_N$B_;

    .line 522
    .line 523
    const/16 v3, 0xb

    .line 524
    .line 525
    invoke-direct {v2, v3, p0}, LzdS_N$B_;-><init>(ILjava/lang/Object;)V

    .line 526
    .line 527
    .line 528
    invoke-direct {v0}, Landroidx/recyclerview/widget/rz__9J_;-><init>()V

    .line 529
    .line 530
    .line 531
    const/4 v3, -0x1

    .line 532
    iput v3, v0, LBa8àhzR;->rz__9J_:I

    .line 533
    .line 534
    iput-object v1, v0, LBa8àhzR;->e8$mp_s$:[Ljava/lang/String;

    .line 535
    .line 536
    iput-object v2, v0, LBa8àhzR;->waiBKÀ:LzdS_N$B_;

    .line 537
    .line 538
    iput-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->pQ1Il:LBa8àhzR;

    .line 539
    .line 540
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->l1:Landroidx/recyclerview/widget/RecyclerView;

    .line 541
    .line 542
    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/rz__9J_;)V

    .line 543
    .line 544
    .line 545
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->iQ0D:[Ljava/lang/String;

    .line 546
    .line 547
    array-length v0, v0

    .line 548
    if-lez v0, :cond_6

    .line 549
    .line 550
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->pQ1Il:LBa8àhzR;

    .line 551
    .line 552
    iget v1, v0, LBa8àhzR;->rz__9J_:I

    .line 553
    .line 554
    iput p1, v0, LBa8àhzR;->rz__9J_:I

    .line 555
    .line 556
    if-eq v1, v3, :cond_5

    .line 557
    .line 558
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/rz__9J_;->notifyItemChanged(I)V

    .line 559
    .line 560
    .line 561
    :cond_5
    iget v1, v0, LBa8àhzR;->rz__9J_:I

    .line 562
    .line 563
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/rz__9J_;->notifyItemChanged(I)V

    .line 564
    .line 565
    .line 566
    :cond_6
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->tmpSize211()Z

    .line 567
    .line 568
    .line 569
    move-result v0

    .line 570
    if-nez v0, :cond_7

    .line 571
    .line 572
    goto :goto_3

    .line 573
    :cond_7
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 574
    .line 575
    invoke-virtual {v0, p1}, Landroid/view/View;->setFocusable(Z)V

    .line 576
    .line 577
    .line 578
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 579
    .line 580
    invoke-virtual {v0, p1}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 581
    .line 582
    .line 583
    iget-object p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->l1:Landroidx/recyclerview/widget/RecyclerView;

    .line 584
    .line 585
    new-instance v0, LQun$1$;

    .line 586
    .line 587
    const/4 v1, 0x2

    .line 588
    invoke-direct {v0, p0, v1}, LQun$1$;-><init>(Linfo/t4w/vp/view/NewWebPlayer;I)V

    .line 589
    .line 590
    .line 591
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 592
    .line 593
    .line 594
    :goto_3
    new-instance p1, LsPos9472;

    .line 595
    .line 596
    const/4 v0, 0x0

    .line 597
    invoke-direct {p1, p0, v0}, LsPos9472;-><init>(LUd$5_1h$;I)V

    .line 598
    .line 599
    .line 600
    invoke-static {p0, p1}, Lcom/google/android/gms/ads/MobileAds;->waiBKÀ(LUd$5_1h$;LZ8_O$y_;)V

    .line 601
    .line 602
    .line 603
    iget-object p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->oaX_6_:Landroid/widget/TextView;

    .line 604
    .line 605
    sget v0, LcJLÌfz;->ready_to_connect:I

    .line 606
    .line 607
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 608
    .line 609
    .line 610
    move-result-object v0

    .line 611
    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 612
    .line 613
    .line 614
    return-void
.end method

.method public final onDestroy()V
    .locals 2

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onDestroy()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->gCount1961:Landroid/os/Handler;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->k1y:LQun$1$;

    .line 9
    .line 10
    if-eqz v1, :cond_0

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void
.end method

.method public final onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->ll()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x4

    .line 5
    const/4 v1, 0x1

    .line 6
    if-ne p1, v0, :cond_0

    .line 7
    .line 8
    iget-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->RD:Z

    .line 9
    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->Q1_f_()V

    .line 13
    .line 14
    .line 15
    return v1

    .line 16
    :cond_0
    const/16 v0, 0x55

    .line 17
    .line 18
    if-eq p1, v0, :cond_4

    .line 19
    .line 20
    const/16 v0, 0x7e

    .line 21
    .line 22
    if-eq p1, v0, :cond_2

    .line 23
    .line 24
    const/16 v0, 0x7f

    .line 25
    .line 26
    if-eq p1, v0, :cond_1

    .line 27
    .line 28
    invoke-super {p0, p1, p2}, LUd$5_1h$;->onKeyDown(ILandroid/view/KeyEvent;)Z

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    return p1

    .line 33
    :cond_1
    iget-boolean p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->valu0:Z

    .line 34
    .line 35
    if-eqz p1, :cond_3

    .line 36
    .line 37
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->oy_R$Xx_()V

    .line 38
    .line 39
    .line 40
    return v1

    .line 41
    :cond_2
    iget-boolean p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->valu0:Z

    .line 42
    .line 43
    if-nez p1, :cond_3

    .line 44
    .line 45
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->oy_R$Xx_()V

    .line 46
    .line 47
    .line 48
    :cond_3
    return v1

    .line 49
    :cond_4
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->oy_R$Xx_()V

    .line 50
    .line 51
    .line 52
    return v1
.end method

.method public final onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2}, LqboÌWm;->onPictureInPictureModeChanged(ZLandroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_1

    .line 5
    .line 6
    iget-object p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->zAt$p:Landroid/widget/LinearLayout;

    .line 7
    .line 8
    const/16 p2, 0x8

    .line 9
    .line 10
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->gSy_FG$D_:Landroid/widget/Button;

    .line 14
    .line 15
    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    .line 16
    .line 17
    .line 18
    iget-boolean p1, p0, Linfo/t4w/vp/view/NewWebPlayer;->RD:Z

    .line 19
    .line 20
    if-nez p1, :cond_0

    .line 21
    .line 22
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->$ÒcdS()V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void

    .line 26
    :cond_1
    invoke-virtual {p0}, Linfo/t4w/vp/view/NewWebPlayer;->ll()V

    .line 27
    .line 28
    .line 29
    return-void
.end method

.method public final oy_R$Xx_()V
    .locals 3

    .line 1
    iget-boolean v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->valu0:Z

    .line 2
    .line 3
    xor-int/lit8 v1, v0, 0x1

    .line 4
    .line 5
    iput-boolean v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->valu0:Z

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->iSize4906:Landroid/widget/ImageButton;

    .line 11
    .line 12
    sget v2, LindeQ;->ic_pause:I

    .line 13
    .line 14
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 18
    .line 19
    const-string v2, "document.querySelector(\'video\').play();"

    .line 20
    .line 21
    invoke-virtual {v0, v2, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->iSize4906:Landroid/widget/ImageButton;

    .line 26
    .line 27
    sget v2, LindeQ;->ic_play:I

    .line 28
    .line 29
    invoke-virtual {v0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 30
    .line 31
    .line 32
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 33
    .line 34
    const-string v2, "document.querySelector(\'video\').pause();"

    .line 35
    .line 36
    invoke-virtual {v0, v2, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final tmpSize211()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "android.software.leanback"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    const-string v1, "android.hardware.type.television"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v0, 0x0

    .line 23
    return v0

    .line 24
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 25
    return v0
.end method

.method public final tzKù7Ol1(I)V
    .locals 4

    .line 1
    if-ltz p1, :cond_1

    .line 2
    .line 3
    :try_start_0
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->gc_$M_w2$:[Ljava/lang/String;

    .line 4
    .line 5
    array-length v0, v0

    .line 6
    if-ge p1, v0, :cond_1

    .line 7
    .line 8
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->oaX_6_:Landroid/widget/TextView;

    .line 9
    .line 10
    new-instance v1, Ljava/lang/StringBuilder;

    .line 11
    .line 12
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->iQ0D:[Ljava/lang/String;

    .line 16
    .line 17
    aget-object v2, v2, p1

    .line 18
    .line 19
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    const-string v2, "..."

    .line 23
    .line 24
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 32
    .line 33
    .line 34
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->BCIm:Landroid/widget/LinearLayout;

    .line 35
    .line 36
    const/4 v1, 0x0

    .line 37
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 38
    .line 39
    .line 40
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->K11ID:[Ljava/lang/String;

    .line 41
    .line 42
    aget-object v0, v0, p1

    .line 43
    .line 44
    if-eqz v0, :cond_0

    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 47
    .line 48
    .line 49
    move-result v0

    .line 50
    if-nez v0, :cond_0

    .line 51
    .line 52
    new-instance v0, Ljava/util/HashMap;

    .line 53
    .line 54
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 55
    .line 56
    .line 57
    const-string v2, "Referer"

    .line 58
    .line 59
    iget-object v3, p0, Linfo/t4w/vp/view/NewWebPlayer;->K11ID:[Ljava/lang/String;

    .line 60
    .line 61
    aget-object v3, v3, p1

    .line 62
    .line 63
    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    iput-boolean v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->pZDcLvd:Z

    .line 67
    .line 68
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 69
    .line 70
    iget-object v2, p0, Linfo/t4w/vp/view/NewWebPlayer;->gc_$M_w2$:[Ljava/lang/String;

    .line 71
    .line 72
    aget-object p1, v2, p1

    .line 73
    .line 74
    invoke-virtual {v1, p1, v0}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;Ljava/util/Map;)V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_0
    iput-boolean v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->pZDcLvd:Z

    .line 79
    .line 80
    iget-object v0, p0, Linfo/t4w/vp/view/NewWebPlayer;->Iii:Landroid/webkit/WebView;

    .line 81
    .line 82
    iget-object v1, p0, Linfo/t4w/vp/view/NewWebPlayer;->gc_$M_w2$:[Ljava/lang/String;

    .line 83
    .line 84
    aget-object p1, v1, p1

    .line 85
    .line 86
    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 87
    .line 88
    .line 89
    :catch_0
    :cond_1
    return-void
.end method
