.class public Linfo/t4w/vp/view/MainActivity;
.super LUd$5_1h$;
.source "SourceFile"

# interfaces
.implements Landroidx/media3/cast/SessionAvailabilityListener;
.implements LGl1ID;


# annotations
.annotation build Landroidx/media3/common/util/UnstableApi;
.end annotation


# static fields
.field public static final synthetic oO:I


# instance fields
.field public BCIm:Lm1;

.field public CcZMD:Ljava/lang/String;

.field public ChI_KH_:Landroid/widget/ImageView;

.field public Iey:Landroid/widget/TextView;

.field public Iii:Landroidx/media3/ui/PlayerView;

.field public final K11ID:Ljava/util/concurrent/ExecutorService;

.field public RD:Landroidx/mediarouter/app/MediaRouteButton;

.field public Txy$$d_w$:Landroid/widget/ImageView;

.field public WoI_9_:Landroid/view/View;

.field public YOD0:Landroidx/media3/common/MediaItem;

.field public cEi_G$x5_:Z

.field public colnt:Z

.field public dnN$d$:LgIXQù;

.field public gCount1961:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

.field public gc_$M_w2$:Z

.field public final iCount5302:Ljava/lang/String;

.field public iQ0D:F

.field public iSize4906:Landroid/widget/ImageView;

.field public inlex:Ljava/lang/String;

.field public jI:Landroidx/appcompat/widget/Toolbar;

.field public k1y:Landroid/widget/TextView;

.field public l1:Landroidx/media3/exoplayer/ExoPlayer;

.field public lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

.field public lelgth:Ljava/lang/String;

.field public oaX_6_:Landroidx/media3/common/Player;

.field public pQ1Il:Landroidx/media3/cast/CastPlayer;

.field public pZDcLvd:Landroid/view/View;

.field public po0:Landroid/media/AudioManager;

.field public s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

.field public vData2659:Ljava/lang/String;

.field public valu0:LVA_r_;

.field public vz$a$:Landroid/widget/ImageView;

.field public zAt$p:Lcom/google/android/material/tabs/TabLayout;


# direct methods
.method public static $ÒcdS([Landroidx/media3/common/Tracks$Group;)[Ljava/lang/String;
    .locals 10

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    array-length v1, p0

    .line 7
    const/4 v2, 0x0

    .line 8
    const/4 v3, 0x0

    .line 9
    :goto_0
    if-ge v3, v1, :cond_8

    .line 10
    .line 11
    aget-object v4, p0, v3

    .line 12
    .line 13
    const/4 v5, 0x0

    .line 14
    :goto_1
    iget v6, v4, Landroidx/media3/common/Tracks$Group;->length:I

    .line 15
    .line 16
    if-ge v5, v6, :cond_7

    .line 17
    .line 18
    invoke-virtual {v4, v5}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(I)Z

    .line 19
    .line 20
    .line 21
    move-result v6

    .line 22
    if-eqz v6, :cond_6

    .line 23
    .line 24
    invoke-virtual {v4, v5}, Landroidx/media3/common/Tracks$Group;->getTrackFormat(I)Landroidx/media3/common/Format;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    iget-object v7, v6, Landroidx/media3/common/Format;->label:Ljava/lang/String;

    .line 29
    .line 30
    if-eqz v7, :cond_0

    .line 31
    .line 32
    goto :goto_2

    .line 33
    :cond_0
    iget-object v7, v6, Landroidx/media3/common/Format;->language:Ljava/lang/String;

    .line 34
    .line 35
    if-eqz v7, :cond_1

    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_1
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 39
    .line 40
    .line 41
    move-result v7

    .line 42
    const/4 v8, 0x2

    .line 43
    if-ne v7, v8, :cond_3

    .line 44
    .line 45
    iget v7, v6, Landroidx/media3/common/Format;->width:I

    .line 46
    .line 47
    if-lez v7, :cond_2

    .line 48
    .line 49
    iget v7, v6, Landroidx/media3/common/Format;->height:I

    .line 50
    .line 51
    if-lez v7, :cond_2

    .line 52
    .line 53
    new-instance v7, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    .line 56
    .line 57
    .line 58
    iget v8, v6, Landroidx/media3/common/Format;->width:I

    .line 59
    .line 60
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    const-string v8, "x"

    .line 64
    .line 65
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    iget v8, v6, Landroidx/media3/common/Format;->height:I

    .line 69
    .line 70
    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object v7

    .line 77
    iget v8, v6, Landroidx/media3/common/Format;->frameRate:F

    .line 78
    .line 79
    const/4 v9, 0x0

    .line 80
    cmpl-float v8, v8, v9

    .line 81
    .line 82
    if-lez v8, :cond_5

    .line 83
    .line 84
    const-string v8, " @ "

    .line 85
    .line 86
    invoke-static {v7, v8}, LRQU_K6$Kv_;->pCXDYg(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    move-result-object v7

    .line 90
    iget v6, v6, Landroidx/media3/common/Format;->frameRate:F

    .line 91
    .line 92
    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    .line 93
    .line 94
    .line 95
    move-result v6

    .line 96
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 97
    .line 98
    .line 99
    const-string v6, "fps"

    .line 100
    .line 101
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v7

    .line 108
    goto :goto_2

    .line 109
    :cond_2
    const-string v6, "Video Track "

    .line 110
    .line 111
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object v7

    .line 115
    goto :goto_2

    .line 116
    :cond_3
    invoke-virtual {v4}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 117
    .line 118
    .line 119
    move-result v6

    .line 120
    const/4 v7, 0x1

    .line 121
    if-ne v6, v7, :cond_4

    .line 122
    .line 123
    const-string v6, "Audio Track "

    .line 124
    .line 125
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v7

    .line 129
    goto :goto_2

    .line 130
    :cond_4
    const-string v6, "Track "

    .line 131
    .line 132
    invoke-static {v5, v6}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 133
    .line 134
    .line 135
    move-result-object v7

    .line 136
    :cond_5
    :goto_2
    invoke-virtual {v0, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    :cond_6
    add-int/lit8 v5, v5, 0x1

    .line 140
    .line 141
    goto :goto_1

    .line 142
    :cond_7
    add-int/lit8 v3, v3, 0x1

    .line 143
    .line 144
    goto/16 :goto_0

    .line 145
    .line 146
    :cond_8
    new-array p0, v2, [Ljava/lang/String;

    .line 147
    .line 148
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    check-cast p0, [Ljava/lang/String;

    .line 153
    .line 154
    return-object p0
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, LUd$5_1h$;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Linfo/t4w/vp/view/MainActivity;->gc_$M_w2$:Z

    .line 6
    .line 7
    const/high16 v1, 0x3f800000    # 1.0f

    .line 8
    .line 9
    iput v1, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 10
    .line 11
    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    iput-object v1, p0, Linfo/t4w/vp/view/MainActivity;->K11ID:Ljava/util/concurrent/ExecutorService;

    .line 16
    .line 17
    iput-boolean v0, p0, Linfo/t4w/vp/view/MainActivity;->colnt:Z

    .line 18
    .line 19
    iput-boolean v0, p0, Linfo/t4w/vp/view/MainActivity;->cEi_G$x5_:Z

    .line 20
    .line 21
    const-string v0, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"

    .line 22
    .line 23
    iput-object v0, p0, Linfo/t4w/vp/view/MainActivity;->iCount5302:Ljava/lang/String;

    .line 24
    .line 25
    new-instance v0, LhasOffset7462;

    .line 26
    .line 27
    const/4 v1, 0x6

    .line 28
    invoke-direct {v0, p0, v1}, LhasOffset7462;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 29
    .line 30
    .line 31
    new-instance v0, LhasOffset7462;

    .line 32
    .line 33
    const/4 v1, 0x7

    .line 34
    invoke-direct {v0, p0, v1}, LhasOffset7462;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public static kCount1402(Landroidx/media3/common/Tracks;I)[Landroidx/media3/common/Tracks$Group;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/media3/common/Tracks;->getGroups()LleOgth;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-virtual {p0, v1}, LleOgth;->Ialue(I)LdzP$A$;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    :cond_0
    :goto_0
    invoke-virtual {p0}, LBCIm;->hasNext()Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    if-eqz v2, :cond_1

    .line 20
    .line 21
    invoke-virtual {p0}, LBCIm;->next()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Landroidx/media3/common/Tracks$Group;

    .line 26
    .line 27
    invoke-virtual {v2}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-ne v3, p1, :cond_0

    .line 32
    .line 33
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_1
    new-array p0, v1, [Landroidx/media3/common/Tracks$Group;

    .line 38
    .line 39
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    check-cast p0, [Landroidx/media3/common/Tracks$Group;

    .line 44
    .line 45
    return-object p0
.end method

.method public static tzKù7Ol1(Landroid/view/ViewGroup;)V
    .locals 6

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->setTouchscreenBlocksFocus(Z)V

    .line 3
    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    :goto_0
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 7
    .line 8
    .line 9
    move-result v2

    .line 10
    if-ge v1, v2, :cond_2

    .line 11
    .line 12
    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    instance-of v3, v2, Landroidx/appcompat/widget/ActionMenuView;

    .line 17
    .line 18
    if-eqz v3, :cond_0

    .line 19
    .line 20
    check-cast v2, Landroid/view/ViewGroup;

    .line 21
    .line 22
    invoke-virtual {v2, v0}, Landroid/view/ViewGroup;->setTouchscreenBlocksFocus(Z)V

    .line 23
    .line 24
    .line 25
    const/4 v3, 0x0

    .line 26
    :goto_1
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-ge v3, v4, :cond_1

    .line 31
    .line 32
    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 33
    .line 34
    .line 35
    move-result-object v4

    .line 36
    const/4 v5, 0x1

    .line 37
    invoke-virtual {v4, v5}, Landroid/view/View;->setFocusable(Z)V

    .line 38
    .line 39
    .line 40
    add-int/lit8 v3, v3, 0x1

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_0
    instance-of v3, v2, Landroid/view/ViewGroup;

    .line 44
    .line 45
    if-eqz v3, :cond_1

    .line 46
    .line 47
    check-cast v2, Landroid/view/ViewGroup;

    .line 48
    .line 49
    invoke-static {v2}, Linfo/t4w/vp/view/MainActivity;->tzKù7Ol1(Landroid/view/ViewGroup;)V

    .line 50
    .line 51
    .line 52
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_2
    return-void
.end method


# virtual methods
.method public final Oey(Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->Iey:Landroid/widget/TextView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LIl;

    .line 6
    .line 7
    const/16 v1, 0xb

    .line 8
    .line 9
    invoke-direct {v0, v1, p0, p1}, LIl;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    return-void
.end method

.method public final Q1_f_(Landroid/content/Intent;)V
    .locals 12

    .line 1
    const-string v0, "https://play.google.com/store/apps/details?id="

    .line 2
    .line 3
    const-string v1, "market://details?id="

    .line 4
    .line 5
    if-eqz p1, :cond_7

    .line 6
    .line 7
    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    const-string v3, "android.intent.action.VIEW"

    .line 12
    .line 13
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v4

    .line 17
    if-nez v4, :cond_0

    .line 18
    .line 19
    const-string v4, "android.intent.action.SEND"

    .line 20
    .line 21
    invoke-virtual {v4, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    if-eqz v2, :cond_7

    .line 26
    .line 27
    :cond_0
    const-string v2, "url"

    .line 28
    .line 29
    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    const-string v5, "agent"

    .line 34
    .line 35
    invoke-virtual {p1, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object v6

    .line 39
    const-string v7, "player"

    .line 40
    .line 41
    invoke-virtual {p1, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v7

    .line 45
    const-string v8, ""

    .line 46
    .line 47
    if-eqz v4, :cond_1

    .line 48
    .line 49
    :try_start_0
    const-string v9, "<F>"

    .line 50
    .line 51
    const/4 v10, 0x2

    .line 52
    invoke-virtual {v4, v9, v10}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object v4

    .line 56
    const/4 v9, 0x0

    .line 57
    aget-object v9, v4, v9

    .line 58
    .line 59
    iput-object v9, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 60
    .line 61
    const/4 v9, 0x1

    .line 62
    aget-object v4, v4, v9

    .line 63
    .line 64
    goto :goto_0

    .line 65
    :cond_1
    new-instance v4, Ljava/lang/Exception;

    .line 66
    .line 67
    const-string v9, "Video URL is null"

    .line 68
    .line 69
    invoke-direct {v4, v9}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 70
    .line 71
    .line 72
    throw v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 73
    :catch_0
    iput-object v8, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 74
    .line 75
    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v4

    .line 79
    :goto_0
    iget-object v9, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 80
    .line 81
    invoke-virtual {v9}, Ljava/lang/String;->isEmpty()Z

    .line 82
    .line 83
    .line 84
    move-result v9

    .line 85
    if-nez v9, :cond_2

    .line 86
    .line 87
    iget-object v9, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 88
    .line 89
    const/16 v10, 0x19d

    .line 90
    .line 91
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v10

    .line 95
    invoke-virtual {v9, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 96
    .line 97
    .line 98
    move-result v9

    .line 99
    if-nez v9, :cond_2

    .line 100
    .line 101
    iget-object v9, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 102
    .line 103
    const/16 v10, 0x19c

    .line 104
    .line 105
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v10

    .line 109
    invoke-virtual {v9, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 110
    .line 111
    .line 112
    move-result v9

    .line 113
    if-nez v9, :cond_2

    .line 114
    .line 115
    iget-object v9, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 116
    .line 117
    const/16 v10, 0x19b

    .line 118
    .line 119
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v10

    .line 123
    invoke-virtual {v9, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    if-nez v9, :cond_2

    .line 128
    .line 129
    iget-object v9, p0, Linfo/t4w/vp/view/MainActivity;->lelgth:Ljava/lang/String;

    .line 130
    .line 131
    const/16 v10, 0x19a

    .line 132
    .line 133
    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object v10

    .line 137
    invoke-virtual {v9, v10}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    .line 138
    .line 139
    .line 140
    move-result v9

    .line 141
    if-nez v9, :cond_2

    .line 142
    .line 143
    :try_start_1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object v9
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 147
    :try_start_2
    new-instance v10, Landroid/content/Intent;

    .line 148
    .line 149
    new-instance v11, Ljava/lang/StringBuilder;

    .line 150
    .line 151
    invoke-direct {v11, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v11, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object v1

    .line 161
    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 162
    .line 163
    .line 164
    move-result-object v1

    .line 165
    invoke-direct {v10, v3, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p0, v10}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_2
    .catch Landroid/content/ActivityNotFoundException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1

    .line 169
    .line 170
    .line 171
    goto :goto_1

    .line 172
    :catch_1
    nop

    .line 173
    goto :goto_2

    .line 174
    :catch_2
    :try_start_3
    new-instance v1, Landroid/content/Intent;

    .line 175
    .line 176
    new-instance v10, Ljava/lang/StringBuilder;

    .line 177
    .line 178
    invoke-direct {v10, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 179
    .line 180
    .line 181
    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 182
    .line 183
    .line 184
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v0

    .line 188
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    invoke-direct {v1, v3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 193
    .line 194
    .line 195
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 196
    .line 197
    .line 198
    :goto_1
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    .line 199
    .line 200
    .line 201
    goto :goto_3

    .line 202
    :cond_2
    :goto_2
    if-nez v4, :cond_3

    .line 203
    .line 204
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 205
    .line 206
    .line 207
    return-void

    .line 208
    :cond_3
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    const-string v1, "1"

    .line 213
    .line 214
    invoke-static {v0, v1}, Linfo/t4w/vp/database/Next;->rz__9J_(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object v0

    .line 218
    invoke-virtual {v4, v0, v8}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    invoke-static {v7, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-result v1

    .line 226
    if-eqz v1, :cond_4

    .line 227
    .line 228
    new-instance v1, Landroid/content/Intent;

    .line 229
    .line 230
    const-class v4, Linfo/t4w/vp/view/VideoPlayer;

    .line 231
    .line 232
    invoke-direct {v1, p0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 233
    .line 234
    .line 235
    invoke-virtual {v1, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    .line 236
    .line 237
    .line 238
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 239
    .line 240
    .line 241
    invoke-virtual {v1, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 242
    .line 243
    .line 244
    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 245
    .line 246
    .line 247
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 248
    .line 249
    .line 250
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 251
    .line 252
    .line 253
    return-void

    .line 254
    :cond_4
    const-string v1, "55"

    .line 255
    .line 256
    invoke-static {v7, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    move-result v1

    .line 260
    if-eqz v1, :cond_5

    .line 261
    .line 262
    new-instance p1, Landroid/content/Intent;

    .line 263
    .line 264
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    invoke-direct {p1, v3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    .line 269
    .line 270
    .line 271
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 272
    .line 273
    .line 274
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 275
    .line 276
    .line 277
    return-void

    .line 278
    :cond_5
    const-string v1, "10"

    .line 279
    .line 280
    invoke-static {v7, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    if-eqz v1, :cond_6

    .line 285
    .line 286
    new-instance v1, Landroid/content/Intent;

    .line 287
    .line 288
    const-class v4, Linfo/t4w/vp/view/NewWebPlayer;

    .line 289
    .line 290
    invoke-direct {v1, p0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 291
    .line 292
    .line 293
    invoke-virtual {v1, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    .line 294
    .line 295
    .line 296
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 297
    .line 298
    .line 299
    invoke-virtual {v1, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 300
    .line 301
    .line 302
    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 303
    .line 304
    .line 305
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 306
    .line 307
    .line 308
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 309
    .line 310
    .line 311
    return-void

    .line 312
    :cond_6
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 313
    .line 314
    .line 315
    :cond_7
    :goto_3
    return-void
.end method

.method public final UC_n_([Landroidx/media3/common/Tracks$Group;I)V
    .locals 4

    .line 1
    if-ltz p2, :cond_3

    .line 2
    .line 3
    array-length v0, p1

    .line 4
    if-lt p2, v0, :cond_0

    .line 5
    .line 6
    goto :goto_1

    .line 7
    :cond_0
    aget-object p1, p1, p2

    .line 8
    .line 9
    const/4 p2, 0x0

    .line 10
    const/4 v0, 0x0

    .line 11
    :goto_0
    iget v1, p1, Landroidx/media3/common/Tracks$Group;->length:I

    .line 12
    .line 13
    if-ge v0, v1, :cond_3

    .line 14
    .line 15
    invoke-virtual {p1, v0}, Landroidx/media3/common/Tracks$Group;->isTrackSupported(I)Z

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-eqz v1, :cond_2

    .line 20
    .line 21
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 22
    .line 23
    invoke-interface {v1}, Landroidx/media3/common/Player;->getTrackSelectionParameters()Landroidx/media3/common/TrackSelectionParameters;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters;->buildUpon()Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    invoke-virtual {p1}, Landroidx/media3/common/Tracks$Group;->getType()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    const/4 v3, 0x3

    .line 36
    if-ne v2, v3, :cond_1

    .line 37
    .line 38
    invoke-virtual {v1, v3, p2}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setTrackTypeDisabled(IZ)Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 39
    .line 40
    .line 41
    :cond_1
    new-instance p2, Landroidx/media3/common/TrackSelectionOverride;

    .line 42
    .line 43
    invoke-virtual {p1}, Landroidx/media3/common/Tracks$Group;->getMediaTrackGroup()Landroidx/media3/common/TrackGroup;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    invoke-static {v0}, LleOgth;->pCXDYg(Ljava/lang/Object;)LrÒTB;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-direct {p2, p1, v0}, Landroidx/media3/common/TrackSelectionOverride;-><init>(Landroidx/media3/common/TrackGroup;Ljava/util/List;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {v1, p2}, Landroidx/media3/common/TrackSelectionParameters$Builder;->setOverrideForType(Landroidx/media3/common/TrackSelectionOverride;)Landroidx/media3/common/TrackSelectionParameters$Builder;

    .line 59
    .line 60
    .line 61
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 62
    .line 63
    invoke-virtual {v1}, Landroidx/media3/common/TrackSelectionParameters$Builder;->build()Landroidx/media3/common/TrackSelectionParameters;

    .line 64
    .line 65
    .line 66
    move-result-object p2

    .line 67
    invoke-interface {p1, p2}, Landroidx/media3/common/Player;->setTrackSelectionParameters(Landroidx/media3/common/TrackSelectionParameters;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 72
    .line 73
    goto :goto_0

    .line 74
    :cond_3
    :goto_1
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 5

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 2
    .line 3
    if-eqz v0, :cond_6

    .line 4
    .line 5
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_6

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const/4 v1, 0x4

    .line 16
    if-eq v0, v1, :cond_6

    .line 17
    .line 18
    const/16 v1, 0x42

    .line 19
    .line 20
    if-eq v0, v1, :cond_6

    .line 21
    .line 22
    const/16 v1, 0x55

    .line 23
    .line 24
    const/4 v2, 0x1

    .line 25
    if-eq v0, v1, :cond_4

    .line 26
    .line 27
    const/16 v1, 0x59

    .line 28
    .line 29
    const-wide/16 v3, 0x2710

    .line 30
    .line 31
    if-eq v0, v1, :cond_3

    .line 32
    .line 33
    const/16 v1, 0x5a

    .line 34
    .line 35
    if-eq v0, v1, :cond_2

    .line 36
    .line 37
    const/16 v1, 0x7e

    .line 38
    .line 39
    if-eq v0, v1, :cond_1

    .line 40
    .line 41
    const/16 v1, 0x7f

    .line 42
    .line 43
    if-eq v0, v1, :cond_0

    .line 44
    .line 45
    packed-switch v0, :pswitch_data_0

    .line 46
    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_0
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 50
    .line 51
    invoke-interface {p1}, Landroidx/media3/common/Player;->pause()V

    .line 52
    .line 53
    .line 54
    return v2

    .line 55
    :cond_1
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 56
    .line 57
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 58
    .line 59
    .line 60
    return v2

    .line 61
    :cond_2
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 62
    .line 63
    invoke-interface {p1}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 64
    .line 65
    .line 66
    move-result-wide v0

    .line 67
    add-long/2addr v0, v3

    .line 68
    invoke-interface {p1, v0, v1}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 69
    .line 70
    .line 71
    return v2

    .line 72
    :cond_3
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 73
    .line 74
    invoke-interface {p1}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 75
    .line 76
    .line 77
    move-result-wide v0

    .line 78
    sub-long/2addr v0, v3

    .line 79
    const-wide/16 v3, 0x0

    .line 80
    .line 81
    invoke-static {v3, v4, v0, v1}, Ljava/lang/Math;->max(JJ)J

    .line 82
    .line 83
    .line 84
    move-result-wide v0

    .line 85
    invoke-interface {p1, v0, v1}, Landroidx/media3/common/Player;->seekTo(J)V

    .line 86
    .line 87
    .line 88
    return v2

    .line 89
    :cond_4
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 90
    .line 91
    invoke-interface {p1}, Landroidx/media3/common/Player;->isPlaying()Z

    .line 92
    .line 93
    .line 94
    move-result p1

    .line 95
    if-eqz p1, :cond_5

    .line 96
    .line 97
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 98
    .line 99
    invoke-interface {p1}, Landroidx/media3/common/Player;->pause()V

    .line 100
    .line 101
    .line 102
    return v2

    .line 103
    :cond_5
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 104
    .line 105
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 106
    .line 107
    .line 108
    return v2

    .line 109
    :cond_6
    :goto_0
    :pswitch_0
    invoke-super {p0, p1}, LUd$5_1h$;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 110
    .line 111
    .line 112
    move-result p1

    .line 113
    return p1

    .line 114
    nop

    .line 115
    :pswitch_data_0
    .packed-switch 0x13
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public final enterPictureInPictureMode()V
    .locals 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1a

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-lt v0, v1, :cond_1

    .line 7
    .line 8
    invoke-static {}, LrMBhl;->JKEoÙX()Landroid/app/PictureInPictureParams$Builder;

    .line 9
    .line 10
    .line 11
    move-result-object v1

    .line 12
    const/16 v3, 0x1f

    .line 13
    .line 14
    if-lt v0, v3, :cond_0

    .line 15
    .line 16
    invoke-static {v1}, LVlO1I;->valuI(Landroid/app/PictureInPictureParams$Builder;)V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 20
    .line 21
    if-eqz v0, :cond_0

    .line 22
    .line 23
    new-instance v0, Landroid/graphics/Rect;

    .line 24
    .line 25
    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 26
    .line 27
    .line 28
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 29
    .line 30
    invoke-virtual {v3, v0}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    .line 31
    .line 32
    .line 33
    invoke-static {v1, v0}, LrMBhl;->K0I(Landroid/app/PictureInPictureParams$Builder;Landroid/graphics/Rect;)V

    .line 34
    .line 35
    .line 36
    :cond_0
    :try_start_0
    invoke-static {v1}, LrMBhl;->tmpData3485(Landroid/app/PictureInPictureParams$Builder;)Landroid/app/PictureInPictureParams;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    invoke-static {p0, v0}, LrMBhl;->tmpSize211(Linfo/t4w/vp/view/MainActivity;Landroid/app/PictureInPictureParams;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :catch_0
    const-string v0, "Picture-in-Picture mode is not supported"

    .line 45
    .line 46
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 51
    .line 52
    .line 53
    return-void

    .line 54
    :cond_1
    const-string v0, "Picture-in-Picture mode requires Android 8.0 or later"

    .line 55
    .line 56
    invoke-static {p0, v0, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 61
    .line 62
    .line 63
    return-void
.end method

.method public final ll(Landroidx/media3/common/Player;)V
    .locals 4

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    goto :goto_1

    .line 6
    :cond_0
    if-eqz v0, :cond_1

    .line 7
    .line 8
    invoke-interface {v0}, Landroidx/media3/common/Player;->getCurrentPosition()J

    .line 9
    .line 10
    .line 11
    move-result-wide v0

    .line 12
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 13
    .line 14
    invoke-interface {v2}, Landroidx/media3/common/Player;->getPlayWhenReady()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 19
    .line 20
    invoke-interface {v3}, Landroidx/media3/common/Player;->stop()V

    .line 21
    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    const-wide/16 v0, 0x0

    .line 25
    .line 26
    const/4 v2, 0x0

    .line 27
    :goto_0
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 28
    .line 29
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 30
    .line 31
    invoke-virtual {v3, p1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 32
    .line 33
    .line 34
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->YOD0:Landroidx/media3/common/MediaItem;

    .line 35
    .line 36
    if-eqz v3, :cond_2

    .line 37
    .line 38
    invoke-interface {p1, v3, v0, v1}, Landroidx/media3/common/Player;->setMediaItem(Landroidx/media3/common/MediaItem;J)V

    .line 39
    .line 40
    .line 41
    invoke-interface {p1}, Landroidx/media3/common/Player;->prepare()V

    .line 42
    .line 43
    .line 44
    invoke-interface {p1, v2}, Landroidx/media3/common/Player;->setPlayWhenReady(Z)V

    .line 45
    .line 46
    .line 47
    iget v0, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 48
    .line 49
    const/high16 v1, 0x3f800000    # 1.0f

    .line 50
    .line 51
    cmpl-float v0, v0, v1

    .line 52
    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    new-instance v0, Landroidx/media3/common/PlaybackParameters;

    .line 56
    .line 57
    iget v1, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 58
    .line 59
    invoke-direct {v0, v1}, Landroidx/media3/common/PlaybackParameters;-><init>(F)V

    .line 60
    .line 61
    .line 62
    invoke-interface {p1, v0}, Landroidx/media3/common/Player;->setPlaybackParameters(Landroidx/media3/common/PlaybackParameters;)V

    .line 63
    .line 64
    .line 65
    :cond_2
    :goto_1
    return-void
.end method

.method public final onCastSessionAvailable()V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Linfo/t4w/vp/view/MainActivity;->ll(Landroidx/media3/common/Player;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onCastSessionUnavailable()V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Linfo/t4w/vp/view/MainActivity;->ll(Landroidx/media3/common/Player;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    sget v1, LvKey3407;->primary:I

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 14

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    sget v1, LvKey3407;->primary:I

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getColor(I)I

    .line 15
    .line 16
    .line 17
    move-result v0

    .line 18
    invoke-virtual {p1, v0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/MainActivity;->Q1_f_(Landroid/content/Intent;)V

    .line 26
    .line 27
    .line 28
    sget p1, LKùiu;->activity_main:I

    .line 29
    .line 30
    invoke-virtual {p0, p1}, LUd$5_1h$;->setContentView(I)V

    .line 31
    .line 32
    .line 33
    sget p1, LRO1QI;->toolbar:I

    .line 34
    .line 35
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    check-cast p1, Landroidx/appcompat/widget/Toolbar;

    .line 40
    .line 41
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->jI:Landroidx/appcompat/widget/Toolbar;

    .line 42
    .line 43
    invoke-virtual {p0, p1}, LUd$5_1h$;->Qp_Hp$i_(Landroidx/appcompat/widget/Toolbar;)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    const/4 v1, 0x1

    .line 51
    const/4 v2, 0x0

    .line 52
    if-eqz p1, :cond_0

    .line 53
    .line 54
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 55
    .line 56
    .line 57
    move-result-object v0

    .line 58
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    const/high16 v3, 0x42400000    # 48.0f

    .line 63
    .line 64
    invoke-static {v1, v3, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    float-to-int v0, v0

    .line 69
    goto :goto_0

    .line 70
    :cond_0
    const/4 v0, 0x0

    .line 71
    :goto_0
    if-eqz p1, :cond_1

    .line 72
    .line 73
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    const/high16 v3, 0x41d80000    # 27.0f

    .line 82
    .line 83
    invoke-static {v1, v3, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 84
    .line 85
    .line 86
    move-result p1

    .line 87
    float-to-int p1, p1

    .line 88
    goto :goto_1

    .line 89
    :cond_1
    const/4 p1, 0x0

    .line 90
    :goto_1
    sget v3, LRO1QI;->main_layout:I

    .line 91
    .line 92
    invoke-virtual {p0, v3}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 93
    .line 94
    .line 95
    move-result-object v3

    .line 96
    new-instance v4, Lcoun1;

    .line 97
    .line 98
    invoke-direct {v4, v0, p1}, Lcoun1;-><init>(II)V

    .line 99
    .line 100
    .line 101
    sget-object p1, Ll11Il;->e8$mp_s$:Ljava/util/WeakHashMap;

    .line 102
    .line 103
    invoke-static {v3, v4}, LI11l;->kQy(Landroid/view/View;LvllDQ;)V

    .line 104
    .line 105
    .line 106
    new-instance p1, Lm1;

    .line 107
    .line 108
    invoke-direct {p1, p0}, Lm1;-><init>(Landroid/content/Context;)V

    .line 109
    .line 110
    .line 111
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->BCIm:Lm1;

    .line 112
    .line 113
    const-string p1, "audio"

    .line 114
    .line 115
    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    check-cast p1, Landroid/media/AudioManager;

    .line 120
    .line 121
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->po0:Landroid/media/AudioManager;

    .line 122
    .line 123
    const-string p1, "app_preferences"

    .line 124
    .line 125
    invoke-virtual {p0, p1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 126
    .line 127
    .line 128
    move-result-object p1

    .line 129
    const-string v0, "is_first_launch"

    .line 130
    .line 131
    invoke-interface {p1, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 132
    .line 133
    .line 134
    move-result v3

    .line 135
    if-eqz v3, :cond_2

    .line 136
    .line 137
    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    invoke-interface {p1, v0, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 142
    .line 143
    .line 144
    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 145
    .line 146
    .line 147
    new-instance p1, Landroid/app/AlertDialog$Builder;

    .line 148
    .line 149
    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 150
    .line 151
    .line 152
    const-string v0, "Add Demo Video"

    .line 153
    .line 154
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 155
    .line 156
    .line 157
    move-result-object p1

    .line 158
    const-string v0, "This is Your First Usage , Would you like to add a demo video link to your history?"

    .line 159
    .line 160
    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    new-instance v0, LADXSR;

    .line 165
    .line 166
    invoke-direct {v0, p0, v2}, LADXSR;-><init>(LUd$5_1h$;I)V

    .line 167
    .line 168
    .line 169
    const-string v3, "Yes"

    .line 170
    .line 171
    invoke-virtual {p1, v3, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 172
    .line 173
    .line 174
    move-result-object p1

    .line 175
    const-string v0, "No"

    .line 176
    .line 177
    const/4 v3, 0x0

    .line 178
    invoke-virtual {p1, v0, v3}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 179
    .line 180
    .line 181
    move-result-object p1

    .line 182
    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 183
    .line 184
    .line 185
    :cond_2
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 186
    .line 187
    .line 188
    move-result p1

    .line 189
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->K11ID:Ljava/util/concurrent/ExecutorService;

    .line 190
    .line 191
    if-eqz p1, :cond_3

    .line 192
    .line 193
    goto :goto_2

    .line 194
    :cond_3
    :try_start_0
    sget-object p1, LOòZx;->POOl:LOòZx;

    .line 195
    .line 196
    sget v0, LI6R$9$;->e8$mp_s$:I

    .line 197
    .line 198
    invoke-virtual {p1, p0, v0}, LI6R$9$;->rz__9J_(Landroid/content/Context;I)I

    .line 199
    .line 200
    .line 201
    move-result p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1

    .line 202
    if-nez p1, :cond_4

    .line 203
    .line 204
    :try_start_1
    invoke-static {p0, v3}, LVA_r_;->tmpData3485(LUd$5_1h$;Ljava/util/concurrent/ExecutorService;)LGIlO;

    .line 205
    .line 206
    .line 207
    new-instance p1, LVèM;

    .line 208
    .line 209
    invoke-direct {p1, p0, v2}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 210
    .line 211
    .line 212
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->dnN$d$:LgIXQù;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 213
    .line 214
    goto :goto_2

    .line 215
    :catch_0
    move-exception v0

    .line 216
    move-object p1, v0

    .line 217
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 218
    .line 219
    .line 220
    goto :goto_2

    .line 221
    :catch_1
    nop

    .line 222
    :cond_4
    :goto_2
    sget p1, LRO1QI;->player_view:I

    .line 223
    .line 224
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 225
    .line 226
    .line 227
    move-result-object p1

    .line 228
    check-cast p1, Landroidx/media3/ui/PlayerView;

    .line 229
    .line 230
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 231
    .line 232
    sget v0, LRO1QI;->exo_rew:I

    .line 233
    .line 234
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 235
    .line 236
    .line 237
    move-result-object p1

    .line 238
    check-cast p1, Landroid/widget/ImageButton;

    .line 239
    .line 240
    sget v0, LindeQ;->backward_5_seconds:I

    .line 241
    .line 242
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 243
    .line 244
    .line 245
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 246
    .line 247
    sget v0, LRO1QI;->exo_ffwd:I

    .line 248
    .line 249
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 250
    .line 251
    .line 252
    move-result-object p1

    .line 253
    check-cast p1, Landroid/widget/ImageButton;

    .line 254
    .line 255
    sget v0, LindeQ;->forward_15_seconds:I

    .line 256
    .line 257
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 258
    .line 259
    .line 260
    new-instance p1, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 261
    .line 262
    invoke-direct {p1, p0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {p1}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    .line 266
    .line 267
    .line 268
    move-result-object p1

    .line 269
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 270
    .line 271
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 272
    .line 273
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 274
    .line 275
    invoke-virtual {v0, p1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 276
    .line 277
    .line 278
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 279
    .line 280
    new-instance v0, LNz$NGù;

    .line 281
    .line 282
    invoke-direct {v0, p0}, LNz$NGù;-><init>(Linfo/t4w/vp/view/MainActivity;)V

    .line 283
    .line 284
    .line 285
    invoke-interface {p1, v0}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 286
    .line 287
    .line 288
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 289
    .line 290
    sget v0, LRO1QI;->media_route_button:I

    .line 291
    .line 292
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 293
    .line 294
    .line 295
    move-result-object p1

    .line 296
    check-cast p1, Landroidx/mediarouter/app/MediaRouteButton;

    .line 297
    .line 298
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->RD:Landroidx/mediarouter/app/MediaRouteButton;

    .line 299
    .line 300
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 301
    .line 302
    .line 303
    move-result p1

    .line 304
    const/4 v4, 0x3

    .line 305
    const/16 v5, 0x8

    .line 306
    .line 307
    if-eqz p1, :cond_5

    .line 308
    .line 309
    goto :goto_3

    .line 310
    :cond_5
    :try_start_2
    sget-object p1, LOòZx;->POOl:LOòZx;

    .line 311
    .line 312
    sget v0, LI6R$9$;->e8$mp_s$:I

    .line 313
    .line 314
    invoke-virtual {p1, p0, v0}, LI6R$9$;->rz__9J_(Landroid/content/Context;I)I

    .line 315
    .line 316
    .line 317
    move-result p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    .line 318
    if-nez p1, :cond_6

    .line 319
    .line 320
    :try_start_3
    invoke-static {p0, v3}, LVA_r_;->tmpData3485(LUd$5_1h$;Ljava/util/concurrent/ExecutorService;)LGIlO;

    .line 321
    .line 322
    .line 323
    move-result-object p1

    .line 324
    new-instance v0, LVèM;

    .line 325
    .line 326
    invoke-direct {v0, p0, v4}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 327
    .line 328
    .line 329
    sget-object v3, LGi$EL$;->e8$mp_s$:Lab_w_;

    .line 330
    .line 331
    invoke-virtual {p1, v3, v0}, LGIlO;->waiBKÀ(Ljava/util/concurrent/Executor;LisPos2138;)V

    .line 332
    .line 333
    .line 334
    new-instance v0, LI1I;

    .line 335
    .line 336
    const/16 v6, 0xc

    .line 337
    .line 338
    invoke-direct {v0, v6}, LI1I;-><init>(I)V

    .line 339
    .line 340
    .line 341
    new-instance v6, LmData56;

    .line 342
    .line 343
    invoke-direct {v6, v3, v0}, LmData56;-><init>(Ljava/util/concurrent/Executor;LHàWLI;)V

    .line 344
    .line 345
    .line 346
    iget-object v0, p1, LGIlO;->waiBKÀ:LlO;

    .line 347
    .line 348
    invoke-virtual {v0, v6}, LlO;->tmpData3485(LmData56;)V

    .line 349
    .line 350
    .line 351
    invoke-virtual {p1}, LGIlO;->jPos3709()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    .line 352
    .line 353
    .line 354
    goto :goto_4

    .line 355
    :catch_2
    move-exception v0

    .line 356
    move-object p1, v0

    .line 357
    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    .line 358
    .line 359
    .line 360
    goto :goto_4

    .line 361
    :catch_3
    nop

    .line 362
    :cond_6
    :goto_3
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->RD:Landroidx/mediarouter/app/MediaRouteButton;

    .line 363
    .line 364
    if-eqz p1, :cond_7

    .line 365
    .line 366
    invoke-virtual {p1, v5}, Landroidx/mediarouter/app/MediaRouteButton;->setVisibility(I)V

    .line 367
    .line 368
    .line 369
    :cond_7
    :goto_4
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 370
    .line 371
    const/16 v0, 0xbb8

    .line 372
    .line 373
    invoke-virtual {p1, v0}, Landroidx/media3/ui/PlayerView;->setControllerShowTimeoutMs(I)V

    .line 374
    .line 375
    .line 376
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 377
    .line 378
    invoke-virtual {p1, v1}, Landroidx/media3/ui/PlayerView;->setControllerHideOnTouch(Z)V

    .line 379
    .line 380
    .line 381
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 382
    .line 383
    const/4 v0, 0x2

    .line 384
    invoke-virtual {p1, v0}, Landroidx/media3/ui/PlayerView;->setShowBuffering(I)V

    .line 385
    .line 386
    .line 387
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 388
    .line 389
    .line 390
    move-result p1

    .line 391
    const/4 v3, 0x4

    .line 392
    if-eqz p1, :cond_8

    .line 393
    .line 394
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 395
    .line 396
    new-instance v6, LVèM;

    .line 397
    .line 398
    invoke-direct {v6, p0, v3}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 399
    .line 400
    .line 401
    invoke-virtual {p1, v6}, Landroidx/media3/ui/PlayerView;->setControllerVisibilityListener(Landroidx/media3/ui/PlayerView$ControllerVisibilityListener;)V

    .line 402
    .line 403
    .line 404
    :cond_8
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 405
    .line 406
    sget v6, LRO1QI;->back_btn:I

    .line 407
    .line 408
    invoke-virtual {p1, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 409
    .line 410
    .line 411
    move-result-object p1

    .line 412
    check-cast p1, Landroid/widget/ImageView;

    .line 413
    .line 414
    invoke-virtual {p1, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 415
    .line 416
    .line 417
    new-instance p1, Landroid/widget/TextView;

    .line 418
    .line 419
    invoke-direct {p1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 420
    .line 421
    .line 422
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 423
    .line 424
    sget v6, LcJLÌfz;->add_or_select_video:I

    .line 425
    .line 426
    invoke-virtual {p0, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 427
    .line 428
    .line 429
    move-result-object v6

    .line 430
    invoke-virtual {p1, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 431
    .line 432
    .line 433
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 434
    .line 435
    const/4 v6, -0x1

    .line 436
    invoke-virtual {p1, v6}, Landroid/widget/TextView;->setTextColor(I)V

    .line 437
    .line 438
    .line 439
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 440
    .line 441
    const/high16 v6, 0x41700000    # 15.0f

    .line 442
    .line 443
    invoke-virtual {p1, v0, v6}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 444
    .line 445
    .line 446
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 447
    .line 448
    const/16 v6, 0x23

    .line 449
    .line 450
    const/16 v7, 0x16

    .line 451
    .line 452
    invoke-virtual {p1, v6, v7, v6, v7}, Landroid/widget/TextView;->setPadding(IIII)V

    .line 453
    .line 454
    .line 455
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 456
    .line 457
    const/16 v6, 0x11

    .line 458
    .line 459
    invoke-virtual {p1, v6}, Landroid/widget/TextView;->setGravity(I)V

    .line 460
    .line 461
    .line 462
    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    .line 463
    .line 464
    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    .line 465
    .line 466
    .line 467
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    .line 468
    .line 469
    .line 470
    const-string v7, "#92575757"

    .line 471
    .line 472
    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    .line 473
    .line 474
    .line 475
    move-result v7

    .line 476
    invoke-virtual {p1, v7}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    .line 477
    .line 478
    .line 479
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 480
    .line 481
    .line 482
    move-result-object v7

    .line 483
    invoke-virtual {v7}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 484
    .line 485
    .line 486
    move-result-object v7

    .line 487
    const/high16 v8, 0x41200000    # 10.0f

    .line 488
    .line 489
    invoke-static {v0, v8, v7}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    .line 490
    .line 491
    .line 492
    move-result v7

    .line 493
    invoke-virtual {p1, v7}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    .line 494
    .line 495
    .line 496
    iget-object v7, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 497
    .line 498
    invoke-virtual {v7, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 499
    .line 500
    .line 501
    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    .line 502
    .line 503
    const/4 v7, -0x2

    .line 504
    invoke-direct {p1, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 505
    .line 506
    .line 507
    iput v6, p1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 508
    .line 509
    iget-object v6, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 510
    .line 511
    const/high16 v8, 0x447a0000    # 1000.0f

    .line 512
    .line 513
    invoke-virtual {v6, v8}, Landroid/view/View;->setElevation(F)V

    .line 514
    .line 515
    .line 516
    iget-object v6, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 517
    .line 518
    iget-object v8, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 519
    .line 520
    invoke-virtual {v6, v8, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 521
    .line 522
    .line 523
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 524
    .line 525
    if-eqz p1, :cond_9

    .line 526
    .line 527
    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 528
    .line 529
    .line 530
    :cond_9
    sget p1, LRO1QI;->main_layout:I

    .line 531
    .line 532
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 533
    .line 534
    .line 535
    move-result-object p1

    .line 536
    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 537
    .line 538
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->gCount1961:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 539
    .line 540
    sget p1, LRO1QI;->exo_pip:I

    .line 541
    .line 542
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 543
    .line 544
    .line 545
    move-result-object p1

    .line 546
    check-cast p1, Landroid/widget/ImageView;

    .line 547
    .line 548
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->iSize4906:Landroid/widget/ImageView;

    .line 549
    .line 550
    sget p1, LRO1QI;->fullscreen_icon:I

    .line 551
    .line 552
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 553
    .line 554
    .line 555
    move-result-object p1

    .line 556
    check-cast p1, Landroid/widget/ImageView;

    .line 557
    .line 558
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Txy$$d_w$:Landroid/widget/ImageView;

    .line 559
    .line 560
    sget p1, LRO1QI;->track_selection_button:I

    .line 561
    .line 562
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 563
    .line 564
    .line 565
    move-result-object p1

    .line 566
    check-cast p1, Landroid/widget/ImageView;

    .line 567
    .line 568
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->vz$a$:Landroid/widget/ImageView;

    .line 569
    .line 570
    sget p1, LRO1QI;->scale_icon:I

    .line 571
    .line 572
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 573
    .line 574
    .line 575
    move-result-object p1

    .line 576
    check-cast p1, Landroid/widget/ImageView;

    .line 577
    .line 578
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->ChI_KH_:Landroid/widget/ImageView;

    .line 579
    .line 580
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Txy$$d_w$:Landroid/widget/ImageView;

    .line 581
    .line 582
    new-instance v6, LODI0Q;

    .line 583
    .line 584
    invoke-direct {v6, p0, v0}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 585
    .line 586
    .line 587
    invoke-virtual {p1, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 588
    .line 589
    .line 590
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->iSize4906:Landroid/widget/ImageView;

    .line 591
    .line 592
    new-instance v6, LODI0Q;

    .line 593
    .line 594
    invoke-direct {v6, p0, v4}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 595
    .line 596
    .line 597
    invoke-virtual {p1, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 598
    .line 599
    .line 600
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->vz$a$:Landroid/widget/ImageView;

    .line 601
    .line 602
    if-eqz p1, :cond_a

    .line 603
    .line 604
    new-instance v6, LODI0Q;

    .line 605
    .line 606
    invoke-direct {v6, p0, v3}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 607
    .line 608
    .line 609
    invoke-virtual {p1, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 610
    .line 611
    .line 612
    :cond_a
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->ChI_KH_:Landroid/widget/ImageView;

    .line 613
    .line 614
    if-eqz p1, :cond_b

    .line 615
    .line 616
    new-instance v3, LODI0Q;

    .line 617
    .line 618
    const/4 v6, 0x5

    .line 619
    invoke-direct {v3, p0, v6}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 620
    .line 621
    .line 622
    invoke-virtual {p1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 623
    .line 624
    .line 625
    :cond_b
    sget p1, LRO1QI;->fullscreen_button:I

    .line 626
    .line 627
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 628
    .line 629
    .line 630
    move-result-object p1

    .line 631
    if-eqz p1, :cond_c

    .line 632
    .line 633
    new-instance v3, LODI0Q;

    .line 634
    .line 635
    const/4 v6, 0x6

    .line 636
    invoke-direct {v3, p0, v6}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 637
    .line 638
    .line 639
    invoke-virtual {p1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 640
    .line 641
    .line 642
    :cond_c
    sget p1, LRO1QI;->scale_button:I

    .line 643
    .line 644
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 645
    .line 646
    .line 647
    move-result-object p1

    .line 648
    if-eqz p1, :cond_d

    .line 649
    .line 650
    new-instance v3, LODI0Q;

    .line 651
    .line 652
    const/4 v6, 0x7

    .line 653
    invoke-direct {v3, p0, v6}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 654
    .line 655
    .line 656
    invoke-virtual {p1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 657
    .line 658
    .line 659
    :cond_d
    sget p1, LRO1QI;->speed_button:I

    .line 660
    .line 661
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 662
    .line 663
    .line 664
    move-result-object p1

    .line 665
    if-eqz p1, :cond_e

    .line 666
    .line 667
    new-instance v3, LODI0Q;

    .line 668
    .line 669
    invoke-direct {v3, p0, v5}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 670
    .line 671
    .line 672
    invoke-virtual {p1, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 673
    .line 674
    .line 675
    :cond_e
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 676
    .line 677
    new-instance v3, LEl0;

    .line 678
    .line 679
    invoke-direct {v3, p0}, LEl0;-><init>(Linfo/t4w/vp/view/MainActivity;)V

    .line 680
    .line 681
    .line 682
    invoke-interface {p1, v3}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 683
    .line 684
    .line 685
    sget p1, LRO1QI;->tab_layout:I

    .line 686
    .line 687
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 688
    .line 689
    .line 690
    move-result-object p1

    .line 691
    check-cast p1, Lcom/google/android/material/tabs/TabLayout;

    .line 692
    .line 693
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->zAt$p:Lcom/google/android/material/tabs/TabLayout;

    .line 694
    .line 695
    sget p1, LRO1QI;->view_pager:I

    .line 696
    .line 697
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 698
    .line 699
    .line 700
    move-result-object p1

    .line 701
    check-cast p1, Landroidx/viewpager2/widget/ViewPager2;

    .line 702
    .line 703
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 704
    .line 705
    new-instance p1, LZlW_m_;

    .line 706
    .line 707
    invoke-direct {p1, p0}, Landroidx/viewpager2/adapter/e8$mp_s$;-><init>(Linfo/t4w/vp/view/MainActivity;)V

    .line 708
    .line 709
    .line 710
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 711
    .line 712
    invoke-virtual {v3, p1}, Landroidx/viewpager2/widget/ViewPager2;->setAdapter(Landroidx/recyclerview/widget/rz__9J_;)V

    .line 713
    .line 714
    .line 715
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 716
    .line 717
    .line 718
    move-result p1

    .line 719
    if-eqz p1, :cond_f

    .line 720
    .line 721
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 722
    .line 723
    invoke-virtual {p1, v2}, Landroidx/viewpager2/widget/ViewPager2;->setUserInputEnabled(Z)V

    .line 724
    .line 725
    .line 726
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 727
    .line 728
    invoke-virtual {p1, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 729
    .line 730
    .line 731
    move-result-object p1

    .line 732
    instance-of v3, p1, Landroid/view/ViewGroup;

    .line 733
    .line 734
    if-eqz v3, :cond_f

    .line 735
    .line 736
    move-object v3, p1

    .line 737
    check-cast v3, Landroid/view/ViewGroup;

    .line 738
    .line 739
    const/high16 v6, 0x40000

    .line 740
    .line 741
    invoke-virtual {v3, v6}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    .line 742
    .line 743
    .line 744
    invoke-virtual {p1, v2}, Landroid/view/View;->setFocusable(Z)V

    .line 745
    .line 746
    .line 747
    :cond_f
    new-instance p1, LTqcZl;

    .line 748
    .line 749
    iget-object v8, p0, Linfo/t4w/vp/view/MainActivity;->zAt$p:Lcom/google/android/material/tabs/TabLayout;

    .line 750
    .line 751
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 752
    .line 753
    new-instance v6, LVèM;

    .line 754
    .line 755
    invoke-direct {v6, p0, v1}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 756
    .line 757
    .line 758
    invoke-direct {p1, v8, v3, v6}, LTqcZl;-><init>(Lcom/google/android/material/tabs/TabLayout;Landroidx/viewpager2/widget/ViewPager2;LVèM;)V

    .line 759
    .line 760
    .line 761
    iget-boolean v6, p1, LTqcZl;->yON3x:Z

    .line 762
    .line 763
    if-nez v6, :cond_17

    .line 764
    .line 765
    invoke-virtual {v3}, Landroidx/viewpager2/widget/ViewPager2;->getAdapter()Landroidx/recyclerview/widget/rz__9J_;

    .line 766
    .line 767
    .line 768
    move-result-object v6

    .line 769
    iput-object v6, p1, LTqcZl;->kQy:Ljava/lang/Object;

    .line 770
    .line 771
    if-eqz v6, :cond_16

    .line 772
    .line 773
    iput-boolean v1, p1, LTqcZl;->yON3x:Z

    .line 774
    .line 775
    new-instance v6, LnàBY;

    .line 776
    .line 777
    invoke-direct {v6, v8}, LnàBY;-><init>(Lcom/google/android/material/tabs/TabLayout;)V

    .line 778
    .line 779
    .line 780
    iget-object v9, v3, Landroidx/viewpager2/widget/ViewPager2;->jPos3709:LyN1MqnlP;

    .line 781
    .line 782
    iget-object v9, v9, LyN1MqnlP;->waiBKÀ:Ljava/lang/Object;

    .line 783
    .line 784
    check-cast v9, Ljava/util/ArrayList;

    .line 785
    .line 786
    invoke-virtual {v9, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 787
    .line 788
    .line 789
    new-instance v6, LMltFqiZz;

    .line 790
    .line 791
    invoke-direct {v6, v3}, LMltFqiZz;-><init>(Landroidx/viewpager2/widget/ViewPager2;)V

    .line 792
    .line 793
    .line 794
    iget-object v9, v8, Lcom/google/android/material/tabs/TabLayout;->k1y:Ljava/util/ArrayList;

    .line 795
    .line 796
    invoke-virtual {v9, v6}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 797
    .line 798
    .line 799
    move-result v10

    .line 800
    if-nez v10, :cond_10

    .line 801
    .line 802
    invoke-virtual {v9, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 803
    .line 804
    .line 805
    :cond_10
    new-instance v6, LqDI;

    .line 806
    .line 807
    invoke-direct {v6, v0, p1}, LqDI;-><init>(ILjava/lang/Object;)V

    .line 808
    .line 809
    .line 810
    iget-object v9, p1, LTqcZl;->kQy:Ljava/lang/Object;

    .line 811
    .line 812
    check-cast v9, Landroidx/recyclerview/widget/rz__9J_;

    .line 813
    .line 814
    invoke-virtual {v9, v6}, Landroidx/recyclerview/widget/rz__9J_;->registerAdapterDataObserver(LjCount5837;)V

    .line 815
    .line 816
    .line 817
    invoke-virtual {p1}, LTqcZl;->e8$mp_s$()V

    .line 818
    .line 819
    .line 820
    invoke-virtual {v3}, Landroidx/viewpager2/widget/ViewPager2;->getCurrentItem()I

    .line 821
    .line 822
    .line 823
    move-result v9

    .line 824
    const/4 v12, 0x1

    .line 825
    const/4 v13, 0x1

    .line 826
    const/4 v10, 0x0

    .line 827
    const/4 v11, 0x1

    .line 828
    invoke-virtual/range {v8 .. v13}, Lcom/google/android/material/tabs/TabLayout;->yON3x(IFZZZ)V

    .line 829
    .line 830
    .line 831
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 832
    .line 833
    .line 834
    move-result p1

    .line 835
    if-eqz p1, :cond_11

    .line 836
    .line 837
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->zAt$p:Lcom/google/android/material/tabs/TabLayout;

    .line 838
    .line 839
    new-instance v3, LhasOffset7462;

    .line 840
    .line 841
    invoke-direct {v3, p0, v0}, LhasOffset7462;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 842
    .line 843
    .line 844
    invoke-virtual {p1, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 845
    .line 846
    .line 847
    :cond_11
    sget p1, LRO1QI;->status_text:I

    .line 848
    .line 849
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 850
    .line 851
    .line 852
    move-result-object p1

    .line 853
    check-cast p1, Landroid/widget/TextView;

    .line 854
    .line 855
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iey:Landroid/widget/TextView;

    .line 856
    .line 857
    sget p1, LcJLÌfz;->ready_to_play:I

    .line 858
    .line 859
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 860
    .line 861
    .line 862
    move-result-object p1

    .line 863
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 864
    .line 865
    .line 866
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 867
    .line 868
    sget v0, LRO1QI;->speed_icon:I

    .line 869
    .line 870
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 871
    .line 872
    .line 873
    move-result-object p1

    .line 874
    check-cast p1, Landroid/widget/ImageView;

    .line 875
    .line 876
    if-eqz p1, :cond_12

    .line 877
    .line 878
    new-instance v0, LODI0Q;

    .line 879
    .line 880
    invoke-direct {v0, p0, v2}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 881
    .line 882
    .line 883
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 884
    .line 885
    .line 886
    :cond_12
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 887
    .line 888
    .line 889
    move-result-object p1

    .line 890
    sget v0, LKùiu;->volume_brightness_control:I

    .line 891
    .line 892
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->gCount1961:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 893
    .line 894
    invoke-virtual {p1, v0, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 895
    .line 896
    .line 897
    move-result-object p1

    .line 898
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pZDcLvd:Landroid/view/View;

    .line 899
    .line 900
    sget v0, LRO1QI;->volume_seekbar:I

    .line 901
    .line 902
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 903
    .line 904
    .line 905
    move-result-object p1

    .line 906
    check-cast p1, Linfo/t4w/vp/view/VerticalSeekBar;

    .line 907
    .line 908
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 909
    .line 910
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pZDcLvd:Landroid/view/View;

    .line 911
    .line 912
    sget v0, LRO1QI;->volume_icon:I

    .line 913
    .line 914
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 915
    .line 916
    .line 917
    move-result-object p1

    .line 918
    check-cast p1, Landroid/widget/ImageView;

    .line 919
    .line 920
    invoke-virtual {p0}, Landroid/app/Activity;->getLayoutInflater()Landroid/view/LayoutInflater;

    .line 921
    .line 922
    .line 923
    move-result-object p1

    .line 924
    sget v0, LKùiu;->volume_brightness_control:I

    .line 925
    .line 926
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->gCount1961:Landroidx/constraintlayout/widget/ConstraintLayout;

    .line 927
    .line 928
    invoke-virtual {p1, v0, v3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 929
    .line 930
    .line 931
    move-result-object p1

    .line 932
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->WoI_9_:Landroid/view/View;

    .line 933
    .line 934
    sget v0, LRO1QI;->volume_seekbar:I

    .line 935
    .line 936
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 937
    .line 938
    .line 939
    move-result-object p1

    .line 940
    check-cast p1, Linfo/t4w/vp/view/VerticalSeekBar;

    .line 941
    .line 942
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 943
    .line 944
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->WoI_9_:Landroid/view/View;

    .line 945
    .line 946
    sget v0, LRO1QI;->volume_icon:I

    .line 947
    .line 948
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 949
    .line 950
    .line 951
    move-result-object p1

    .line 952
    check-cast p1, Landroid/widget/ImageView;

    .line 953
    .line 954
    sget v0, LindeQ;->ic_brightness:I

    .line 955
    .line 956
    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 957
    .line 958
    .line 959
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->po0:Landroid/media/AudioManager;

    .line 960
    .line 961
    invoke-virtual {p1, v4}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    .line 962
    .line 963
    .line 964
    move-result p1

    .line 965
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 966
    .line 967
    invoke-virtual {v0, p1}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 968
    .line 969
    .line 970
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 971
    .line 972
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->po0:Landroid/media/AudioManager;

    .line 973
    .line 974
    invoke-virtual {v0, v4}, Landroid/media/AudioManager;->getStreamVolume(I)I

    .line 975
    .line 976
    .line 977
    move-result v0

    .line 978
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setProgress(I)V

    .line 979
    .line 980
    .line 981
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 982
    .line 983
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 984
    .line 985
    .line 986
    move-result-object v0

    .line 987
    sget v3, LvKey3407;->white:I

    .line 988
    .line 989
    invoke-virtual {v0, v3}, Landroid/content/res/Resources;->getColor(I)I

    .line 990
    .line 991
    .line 992
    move-result v0

    .line 993
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setThumbColor(I)V

    .line 994
    .line 995
    .line 996
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->s$_D_:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 997
    .line 998
    new-instance v0, LIsÒEz;

    .line 999
    .line 1000
    invoke-direct {v0, v2, p0}, LIsÒEz;-><init>(ILjava/lang/Object;)V

    .line 1001
    .line 1002
    .line 1003
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 1004
    .line 1005
    .line 1006
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 1007
    .line 1008
    const/16 v0, 0xff

    .line 1009
    .line 1010
    invoke-virtual {p1, v0}, Landroid/widget/ProgressBar;->setMax(I)V

    .line 1011
    .line 1012
    .line 1013
    :try_start_4
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 1014
    .line 1015
    .line 1016
    move-result-object p1

    .line 1017
    const-string v0, "screen_brightness"

    .line 1018
    .line 1019
    invoke-static {p1, v0}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    .line 1020
    .line 1021
    .line 1022
    move-result p1

    .line 1023
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 1024
    .line 1025
    invoke-virtual {v0, p1}, Linfo/t4w/vp/view/VerticalSeekBar;->setProgress(I)V
    :try_end_4
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_4 .. :try_end_4} :catch_4

    .line 1026
    .line 1027
    .line 1028
    goto :goto_5

    .line 1029
    :catch_4
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 1030
    .line 1031
    const/16 v0, 0x80

    .line 1032
    .line 1033
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setProgress(I)V

    .line 1034
    .line 1035
    .line 1036
    :goto_5
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 1037
    .line 1038
    invoke-virtual {p0}, LUd$5_1h$;->getResources()Landroid/content/res/Resources;

    .line 1039
    .line 1040
    .line 1041
    move-result-object v0

    .line 1042
    sget v2, LvKey3407;->white:I

    .line 1043
    .line 1044
    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getColor(I)I

    .line 1045
    .line 1046
    .line 1047
    move-result v0

    .line 1048
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setThumbColor(I)V

    .line 1049
    .line 1050
    .line 1051
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->lIl1:Linfo/t4w/vp/view/VerticalSeekBar;

    .line 1052
    .line 1053
    new-instance v0, LIsÒEz;

    .line 1054
    .line 1055
    invoke-direct {v0, v1, p0}, LIsÒEz;-><init>(ILjava/lang/Object;)V

    .line 1056
    .line 1057
    .line 1058
    invoke-virtual {p1, v0}, Linfo/t4w/vp/view/VerticalSeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 1059
    .line 1060
    .line 1061
    new-instance p1, Landroid/widget/FrameLayout$LayoutParams;

    .line 1062
    .line 1063
    invoke-direct {p1, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 1064
    .line 1065
    .line 1066
    const v0, 0x800013

    .line 1067
    .line 1068
    .line 1069
    iput v0, p1, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 1070
    .line 1071
    const/16 v0, 0x32

    .line 1072
    .line 1073
    iput v0, p1, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    .line 1074
    .line 1075
    new-instance v2, Landroid/widget/FrameLayout$LayoutParams;

    .line 1076
    .line 1077
    invoke-direct {v2, v7, v7}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    .line 1078
    .line 1079
    .line 1080
    const v3, 0x800015

    .line 1081
    .line 1082
    .line 1083
    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    .line 1084
    .line 1085
    iput v0, v2, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    .line 1086
    .line 1087
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 1088
    .line 1089
    iget-object v3, p0, Linfo/t4w/vp/view/MainActivity;->pZDcLvd:Landroid/view/View;

    .line 1090
    .line 1091
    invoke-virtual {v0, v3, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1092
    .line 1093
    .line 1094
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 1095
    .line 1096
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->WoI_9_:Landroid/view/View;

    .line 1097
    .line 1098
    invoke-virtual {p1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 1099
    .line 1100
    .line 1101
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pZDcLvd:Landroid/view/View;

    .line 1102
    .line 1103
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 1104
    .line 1105
    .line 1106
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->WoI_9_:Landroid/view/View;

    .line 1107
    .line 1108
    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    .line 1109
    .line 1110
    .line 1111
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 1112
    .line 1113
    .line 1114
    move-result p1

    .line 1115
    if-nez p1, :cond_13

    .line 1116
    .line 1117
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 1118
    .line 1119
    new-instance v0, Lw0d$y$;

    .line 1120
    .line 1121
    invoke-direct {v0, v1, p0}, Lw0d$y$;-><init>(ILjava/lang/Object;)V

    .line 1122
    .line 1123
    .line 1124
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    .line 1125
    .line 1126
    .line 1127
    :cond_13
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 1128
    .line 1129
    sget v0, LRO1QI;->dlna_cast_button:I

    .line 1130
    .line 1131
    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1132
    .line 1133
    .line 1134
    move-result-object p1

    .line 1135
    check-cast p1, Landroid/widget/ImageView;

    .line 1136
    .line 1137
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 1138
    .line 1139
    .line 1140
    move-result v0

    .line 1141
    if-eqz v0, :cond_14

    .line 1142
    .line 1143
    if-eqz p1, :cond_15

    .line 1144
    .line 1145
    invoke-virtual {p1, v5}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1146
    .line 1147
    .line 1148
    goto :goto_6

    .line 1149
    :cond_14
    if-eqz p1, :cond_15

    .line 1150
    .line 1151
    new-instance v0, LODI0Q;

    .line 1152
    .line 1153
    invoke-direct {v0, p0, v1}, LODI0Q;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 1154
    .line 1155
    .line 1156
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 1157
    .line 1158
    .line 1159
    :cond_15
    :goto_6
    new-instance p1, LjSize1789;

    .line 1160
    .line 1161
    invoke-direct {p1, p0, p0}, LjSize1789;-><init>(Landroid/app/Activity;LGl1ID;)V

    .line 1162
    .line 1163
    .line 1164
    invoke-virtual {p1}, LjSize1789;->rz__9J_()V

    .line 1165
    .line 1166
    .line 1167
    return-void

    .line 1168
    :cond_16
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 1169
    .line 1170
    const-string v0, "TabLayoutMediator attached before ViewPager2 has an adapter"

    .line 1171
    .line 1172
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1173
    .line 1174
    .line 1175
    throw p1

    .line 1176
    :cond_17
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 1177
    .line 1178
    const-string v0, "TabLayoutMediator is already attached"

    .line 1179
    .line 1180
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1181
    .line 1182
    .line 1183
    throw p1
.end method

.method public final onCreateOptionsMenu(Landroid/view/Menu;)Z
    .locals 2

    .line 1
    invoke-virtual {p0}, LUd$5_1h$;->getMenuInflater()Landroid/view/MenuInflater;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget v1, LWsM$WD_3o$;->top_menu:I

    .line 6
    .line 7
    invoke-virtual {v0, v1, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-eqz p1, :cond_0

    .line 15
    .line 16
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->jI:Landroidx/appcompat/widget/Toolbar;

    .line 17
    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    new-instance v0, LhasOffset7462;

    .line 21
    .line 22
    const/16 v1, 0x8

    .line 23
    .line 24
    invoke-direct {v0, p0, v1}, LhasOffset7462;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 28
    .line 29
    .line 30
    :cond_0
    const/4 p1, 0x1

    .line 31
    return p1
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onDestroy()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-interface {v0}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    .line 9
    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-object v0, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 13
    .line 14
    :cond_0
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, LqboÌWm;->onNewIntent(Landroid/content/Intent;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/MainActivity;->Q1_f_(Landroid/content/Intent;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .locals 2

    .line 1
    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    sget v1, LRO1QI;->action_privacy_policy:I

    .line 6
    .line 7
    if-ne v0, v1, :cond_0

    .line 8
    .line 9
    new-instance p1, Landroid/content/Intent;

    .line 10
    .line 11
    const-class v0, Linfo/t4w/vp/view/PrivacyPolicyActivity;

    .line 12
    .line 13
    invoke-direct {p1, p0, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    return p1

    .line 21
    :cond_0
    invoke-super {p0, p1}, Landroid/app/Activity;->onOptionsItemSelected(Landroid/view/MenuItem;)Z

    .line 22
    .line 23
    .line 24
    move-result p1

    .line 25
    return p1
.end method

.method public final onPause()V
    .locals 2

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onPause()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-interface {v0}, Landroidx/media3/common/Player;->pause()V

    .line 9
    .line 10
    .line 11
    :cond_0
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->valu0:LVA_r_;

    .line 12
    .line 13
    if-eqz v0, :cond_1

    .line 14
    .line 15
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->dnN$d$:LgIXQù;

    .line 16
    .line 17
    invoke-virtual {v0, v1}, LVA_r_;->sKey7917(LgIXQù;)V

    .line 18
    .line 19
    .line 20
    :cond_1
    return-void
.end method

.method public final onPictureInPictureModeChanged(Z)V
    .locals 1

    .line 1
    invoke-super {p0, p1}, LqboÌWm;->onPictureInPictureModeChanged(Z)V

    .line 2
    .line 3
    .line 4
    if-eqz p1, :cond_2

    .line 5
    .line 6
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 7
    .line 8
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->zAt$p:Lcom/google/android/material/tabs/TabLayout;

    .line 12
    .line 13
    const/16 v0, 0x8

    .line 14
    .line 15
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 16
    .line 17
    .line 18
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 19
    .line 20
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 21
    .line 22
    .line 23
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 24
    .line 25
    invoke-virtual {p1}, Landroidx/media3/ui/PlayerView;->hideController()V

    .line 26
    .line 27
    .line 28
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pZDcLvd:Landroid/view/View;

    .line 29
    .line 30
    if-eqz p1, :cond_0

    .line 31
    .line 32
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 33
    .line 34
    .line 35
    :cond_0
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->WoI_9_:Landroid/view/View;

    .line 36
    .line 37
    if-eqz p1, :cond_1

    .line 38
    .line 39
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 40
    .line 41
    .line 42
    :cond_1
    return-void

    .line 43
    :cond_2
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->zAt$p:Lcom/google/android/material/tabs/TabLayout;

    .line 44
    .line 45
    const/4 v0, 0x0

    .line 46
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 47
    .line 48
    .line 49
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->gSy_FG$D_:Landroidx/viewpager2/widget/ViewPager2;

    .line 50
    .line 51
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 52
    .line 53
    .line 54
    return-void
.end method

.method public final onResume()V
    .locals 3

    .line 1
    invoke-super {p0}, LUd$5_1h$;->onResume()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->valu0:LVA_r_;

    .line 5
    .line 6
    const/4 v1, 0x1

    .line 7
    if-eqz v0, :cond_1

    .line 8
    .line 9
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->dnN$d$:LgIXQù;

    .line 10
    .line 11
    invoke-virtual {v0, v2}, LVA_r_;->e8$mp_s$(LgIXQù;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->valu0:LVA_r_;

    .line 15
    .line 16
    invoke-virtual {v0}, LVA_r_;->waiBKÀ()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eq v0, v1, :cond_1

    .line 21
    .line 22
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_0

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    new-instance v0, LhasOffset7462;

    .line 30
    .line 31
    const/16 v2, 0x9

    .line 32
    .line 33
    invoke-direct {v0, p0, v2}, LhasOffset7462;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 37
    .line 38
    .line 39
    :cond_1
    :goto_0
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->YOD0:Landroidx/media3/common/MediaItem;

    .line 40
    .line 41
    if-eqz v0, :cond_2

    .line 42
    .line 43
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 44
    .line 45
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 46
    .line 47
    if-ne v0, v2, :cond_2

    .line 48
    .line 49
    invoke-virtual {v2}, Landroidx/media3/cast/CastPlayer;->isCastSessionAvailable()Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-eqz v0, :cond_2

    .line 54
    .line 55
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 56
    .line 57
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->YOD0:Landroidx/media3/common/MediaItem;

    .line 58
    .line 59
    invoke-virtual {v0, v2}, Landroidx/media3/common/BasePlayer;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 60
    .line 61
    .line 62
    :cond_2
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 63
    .line 64
    if-eqz v0, :cond_3

    .line 65
    .line 66
    iget v0, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 67
    .line 68
    const/high16 v2, 0x3f800000    # 1.0f

    .line 69
    .line 70
    cmpl-float v0, v0, v2

    .line 71
    .line 72
    if-eqz v0, :cond_3

    .line 73
    .line 74
    new-instance v0, Landroidx/media3/common/PlaybackParameters;

    .line 75
    .line 76
    iget v2, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 77
    .line 78
    invoke-direct {v0, v2}, Landroidx/media3/common/PlaybackParameters;-><init>(F)V

    .line 79
    .line 80
    .line 81
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 82
    .line 83
    invoke-interface {v2, v0}, Landroidx/media3/common/Player;->setPlaybackParameters(Landroidx/media3/common/PlaybackParameters;)V

    .line 84
    .line 85
    .line 86
    :cond_3
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 87
    .line 88
    const/16 v2, 0x1a

    .line 89
    .line 90
    if-lt v0, v2, :cond_4

    .line 91
    .line 92
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 93
    .line 94
    .line 95
    move-result-object v0

    .line 96
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 97
    .line 98
    .line 99
    move-result-object v0

    .line 100
    const/16 v2, 0x10

    .line 101
    .line 102
    invoke-virtual {v0, v2}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 103
    .line 104
    .line 105
    :cond_4
    invoke-virtual {p0}, Linfo/t4w/vp/view/MainActivity;->tmpSize211()Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-nez v0, :cond_5

    .line 110
    .line 111
    invoke-virtual {p0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 112
    .line 113
    .line 114
    :catch_0
    :cond_5
    return-void
.end method

.method public final oy_R$Xx_()V
    .locals 5

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 2
    .line 3
    invoke-interface {v0}, Landroidx/media3/common/Player;->getDuration()J

    .line 4
    .line 5
    .line 6
    move-result-wide v0

    .line 7
    const-wide/16 v2, 0x0

    .line 8
    .line 9
    cmp-long v4, v0, v2

    .line 10
    .line 11
    if-lez v4, :cond_0

    .line 12
    .line 13
    sget v0, LindeQ;->ic_fullscreen:I

    .line 14
    .line 15
    new-instance v1, LhasOffset7462;

    .line 16
    .line 17
    const/16 v2, 0xa

    .line 18
    .line 19
    invoke-direct {v1, p0, v2}, LhasOffset7462;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 20
    .line 21
    .line 22
    const-string v2, "Fullscreen Mode"

    .line 23
    .line 24
    const-string v3, "Do you want to enter fullscreen mode?"

    .line 25
    .line 26
    invoke-static {p0, v2, v0, v3, v1}, LdQta;->$ÒcdS(LUd$5_1h$;Ljava/lang/String;ILjava/lang/String;Ljava/lang/Runnable;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_0
    const-string v0, "Video Not Loaded"

    .line 31
    .line 32
    const/4 v1, 0x0

    .line 33
    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final sKey6064(Ljava/lang/String;Ljava/lang/String;)V
    .locals 12

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_1d

    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 5
    .line 6
    .line 7
    move-result v1

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    goto/16 :goto_7

    .line 11
    .line 12
    :cond_0
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 13
    .line 14
    if-nez v1, :cond_1

    .line 15
    .line 16
    goto/16 :goto_8

    .line 17
    .line 18
    :cond_1
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 19
    .line 20
    const/16 v2, 0x8

    .line 21
    .line 22
    if-eqz v1, :cond_2

    .line 23
    .line 24
    invoke-virtual {v1, v2}, Landroid/view/View;->setVisibility(I)V

    .line 25
    .line 26
    .line 27
    :cond_2
    const-string v1, "Loading Video..."

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    const/16 v3, 0x80

    .line 37
    .line 38
    invoke-virtual {v1, v3}, Landroid/view/Window;->addFlags(I)V

    .line 39
    .line 40
    .line 41
    if-eqz p2, :cond_3

    .line 42
    .line 43
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    if-nez v1, :cond_3

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_3
    iget-object p2, p0, Linfo/t4w/vp/view/MainActivity;->iCount5302:Ljava/lang/String;

    .line 51
    .line 52
    :goto_0
    iput-object p2, p0, Linfo/t4w/vp/view/MainActivity;->CcZMD:Ljava/lang/String;

    .line 53
    .line 54
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->inlex:Ljava/lang/String;

    .line 55
    .line 56
    iput-object p2, p0, Linfo/t4w/vp/view/MainActivity;->vData2659:Ljava/lang/String;

    .line 57
    .line 58
    sget-object p2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 59
    .line 60
    invoke-virtual {p1, p2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-static {v1}, Landroid/webkit/MimeTypeMap;->getFileExtensionFromUrl(Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object v1

    .line 68
    const/4 v3, 0x1

    .line 69
    if-eqz v1, :cond_4

    .line 70
    .line 71
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    if-eqz v4, :cond_5

    .line 76
    .line 77
    :cond_4
    const/16 v4, 0x2e

    .line 78
    .line 79
    invoke-virtual {p1, v4}, Ljava/lang/String;->lastIndexOf(I)I

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    if-ltz v4, :cond_5

    .line 84
    .line 85
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 86
    .line 87
    .line 88
    move-result v5

    .line 89
    sub-int/2addr v5, v3

    .line 90
    if-ge v4, v5, :cond_5

    .line 91
    .line 92
    add-int/2addr v4, v3

    .line 93
    invoke-virtual {p1, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v1

    .line 97
    invoke-virtual {v1, p2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    :cond_5
    const-string p2, "m3u8"

    .line 102
    .line 103
    const-string v4, "mpd"

    .line 104
    .line 105
    const/4 v5, 0x2

    .line 106
    const-string v6, "ism"

    .line 107
    .line 108
    const-string v7, "application/vnd.ms-sstr+xml"

    .line 109
    .line 110
    const-string v8, "application/dash+xml"

    .line 111
    .line 112
    const-string v9, "application/x-mpegURL"

    .line 113
    .line 114
    if-eqz v1, :cond_15

    .line 115
    .line 116
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 117
    .line 118
    .line 119
    move-result v10

    .line 120
    const/4 v11, -0x1

    .line 121
    sparse-switch v10, :sswitch_data_0

    .line 122
    .line 123
    .line 124
    :goto_1
    const/4 v2, -0x1

    .line 125
    goto/16 :goto_2

    .line 126
    .line 127
    :sswitch_0
    const-string p2, "webm"

    .line 128
    .line 129
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result p2

    .line 133
    if-nez p2, :cond_6

    .line 134
    .line 135
    goto :goto_1

    .line 136
    :cond_6
    const/16 v2, 0xc

    .line 137
    .line 138
    goto/16 :goto_2

    .line 139
    .line 140
    :sswitch_1
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result p2

    .line 144
    if-nez p2, :cond_7

    .line 145
    .line 146
    goto :goto_1

    .line 147
    :cond_7
    const/16 v2, 0xb

    .line 148
    .line 149
    goto/16 :goto_2

    .line 150
    .line 151
    :sswitch_2
    const-string p2, "json"

    .line 152
    .line 153
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result p2

    .line 157
    if-nez p2, :cond_8

    .line 158
    .line 159
    goto :goto_1

    .line 160
    :cond_8
    const/16 v2, 0xa

    .line 161
    .line 162
    goto/16 :goto_2

    .line 163
    .line 164
    :sswitch_3
    const-string p2, "isml"

    .line 165
    .line 166
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    move-result p2

    .line 170
    if-nez p2, :cond_9

    .line 171
    .line 172
    goto :goto_1

    .line 173
    :cond_9
    const/16 v2, 0x9

    .line 174
    .line 175
    goto/16 :goto_2

    .line 176
    .line 177
    :sswitch_4
    const-string p2, "flac"

    .line 178
    .line 179
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result p2

    .line 183
    if-nez p2, :cond_12

    .line 184
    .line 185
    goto :goto_1

    .line 186
    :sswitch_5
    const-string p2, "ogg"

    .line 187
    .line 188
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    move-result p2

    .line 192
    if-nez p2, :cond_a

    .line 193
    .line 194
    goto :goto_1

    .line 195
    :cond_a
    const/4 v2, 0x7

    .line 196
    goto :goto_2

    .line 197
    :sswitch_6
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 198
    .line 199
    .line 200
    move-result p2

    .line 201
    if-nez p2, :cond_b

    .line 202
    .line 203
    goto :goto_1

    .line 204
    :cond_b
    const/4 v2, 0x6

    .line 205
    goto :goto_2

    .line 206
    :sswitch_7
    const-string p2, "mp4"

    .line 207
    .line 208
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    move-result p2

    .line 212
    if-nez p2, :cond_c

    .line 213
    .line 214
    goto :goto_1

    .line 215
    :cond_c
    const/4 v2, 0x5

    .line 216
    goto :goto_2

    .line 217
    :sswitch_8
    const-string p2, "mp3"

    .line 218
    .line 219
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 220
    .line 221
    .line 222
    move-result p2

    .line 223
    if-nez p2, :cond_d

    .line 224
    .line 225
    goto :goto_1

    .line 226
    :cond_d
    const/4 v2, 0x4

    .line 227
    goto :goto_2

    .line 228
    :sswitch_9
    const-string p2, "mkv"

    .line 229
    .line 230
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 231
    .line 232
    .line 233
    move-result p2

    .line 234
    if-nez p2, :cond_e

    .line 235
    .line 236
    goto :goto_1

    .line 237
    :cond_e
    const/4 v2, 0x3

    .line 238
    goto :goto_2

    .line 239
    :sswitch_a
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 240
    .line 241
    .line 242
    move-result p2

    .line 243
    if-nez p2, :cond_f

    .line 244
    .line 245
    goto :goto_1

    .line 246
    :cond_f
    const/4 v2, 0x2

    .line 247
    goto :goto_2

    .line 248
    :sswitch_b
    const-string p2, "aac"

    .line 249
    .line 250
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 251
    .line 252
    .line 253
    move-result p2

    .line 254
    if-nez p2, :cond_10

    .line 255
    .line 256
    goto/16 :goto_1

    .line 257
    .line 258
    :cond_10
    const/4 v2, 0x1

    .line 259
    goto :goto_2

    .line 260
    :sswitch_c
    const-string p2, "ts"

    .line 261
    .line 262
    invoke-virtual {v1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 263
    .line 264
    .line 265
    move-result p2

    .line 266
    if-nez p2, :cond_11

    .line 267
    .line 268
    goto/16 :goto_1

    .line 269
    .line 270
    :cond_11
    const/4 v2, 0x0

    .line 271
    :cond_12
    :goto_2
    packed-switch v2, :pswitch_data_0

    .line 272
    .line 273
    .line 274
    const/4 v7, 0x0

    .line 275
    goto :goto_5

    .line 276
    :pswitch_0
    const-string v7, "video/webm"

    .line 277
    .line 278
    goto :goto_5

    .line 279
    :cond_13
    :goto_3
    :pswitch_1
    move-object v7, v9

    .line 280
    goto :goto_5

    .line 281
    :pswitch_2
    const-string v7, "audio/flac"

    .line 282
    .line 283
    goto :goto_5

    .line 284
    :pswitch_3
    const-string v7, "audio/ogg"

    .line 285
    .line 286
    goto :goto_5

    .line 287
    :cond_14
    :goto_4
    :pswitch_4
    move-object v7, v8

    .line 288
    goto :goto_5

    .line 289
    :pswitch_5
    const-string v7, "video/mp4"

    .line 290
    .line 291
    goto :goto_5

    .line 292
    :pswitch_6
    const-string v7, "audio/mpeg"

    .line 293
    .line 294
    goto :goto_5

    .line 295
    :pswitch_7
    const-string v7, "video/x-matroska"

    .line 296
    .line 297
    goto :goto_5

    .line 298
    :pswitch_8
    const-string v7, "audio/mp4a-latm"

    .line 299
    .line 300
    goto :goto_5

    .line 301
    :pswitch_9
    const-string v7, "video/mp2t"

    .line 302
    .line 303
    goto :goto_5

    .line 304
    :cond_15
    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 305
    .line 306
    .line 307
    move-result p2

    .line 308
    if-nez p2, :cond_13

    .line 309
    .line 310
    const-string p2, "hls"

    .line 311
    .line 312
    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 313
    .line 314
    .line 315
    move-result p2

    .line 316
    if-eqz p2, :cond_16

    .line 317
    .line 318
    goto :goto_3

    .line 319
    :cond_16
    invoke-virtual {p1, v4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 320
    .line 321
    .line 322
    move-result p2

    .line 323
    if-nez p2, :cond_14

    .line 324
    .line 325
    const-string p2, "dash"

    .line 326
    .line 327
    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 328
    .line 329
    .line 330
    move-result p2

    .line 331
    if-eqz p2, :cond_17

    .line 332
    .line 333
    goto :goto_4

    .line 334
    :cond_17
    invoke-virtual {p1, v6}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 335
    .line 336
    .line 337
    move-result p2

    .line 338
    if-nez p2, :cond_19

    .line 339
    .line 340
    const-string p2, "smooth"

    .line 341
    .line 342
    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 343
    .line 344
    .line 345
    move-result p2

    .line 346
    if-eqz p2, :cond_18

    .line 347
    .line 348
    goto :goto_5

    .line 349
    :cond_18
    const-string v7, "application/mp4"

    .line 350
    .line 351
    :cond_19
    :goto_5
    :pswitch_a
    new-instance p2, Landroidx/media3/common/MediaItem$Builder;

    .line 352
    .line 353
    invoke-direct {p2}, Landroidx/media3/common/MediaItem$Builder;-><init>()V

    .line 354
    .line 355
    .line 356
    invoke-virtual {p2, p1}, Landroidx/media3/common/MediaItem$Builder;->setUri(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 357
    .line 358
    .line 359
    move-result-object p2

    .line 360
    if-eqz v7, :cond_1a

    .line 361
    .line 362
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    .line 363
    .line 364
    .line 365
    move-result v1

    .line 366
    if-nez v1, :cond_1a

    .line 367
    .line 368
    invoke-virtual {p2, v7}, Landroidx/media3/common/MediaItem$Builder;->setMimeType(Ljava/lang/String;)Landroidx/media3/common/MediaItem$Builder;

    .line 369
    .line 370
    .line 371
    :cond_1a
    invoke-virtual {p2}, Landroidx/media3/common/MediaItem$Builder;->build()Landroidx/media3/common/MediaItem;

    .line 372
    .line 373
    .line 374
    move-result-object p2

    .line 375
    iput-object p2, p0, Linfo/t4w/vp/view/MainActivity;->YOD0:Landroidx/media3/common/MediaItem;

    .line 376
    .line 377
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 378
    .line 379
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 380
    .line 381
    if-ne v1, v2, :cond_1b

    .line 382
    .line 383
    invoke-virtual {v2}, Landroidx/media3/cast/CastPlayer;->isCastSessionAvailable()Z

    .line 384
    .line 385
    .line 386
    move-result v1

    .line 387
    if-eqz v1, :cond_1b

    .line 388
    .line 389
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 390
    .line 391
    invoke-virtual {p1, p2}, Landroidx/media3/common/BasePlayer;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 392
    .line 393
    .line 394
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 395
    .line 396
    invoke-virtual {p1}, Landroidx/media3/cast/CastPlayer;->prepare()V

    .line 397
    .line 398
    .line 399
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->pQ1Il:Landroidx/media3/cast/CastPlayer;

    .line 400
    .line 401
    invoke-virtual {p1}, Landroidx/media3/common/BasePlayer;->play()V

    .line 402
    .line 403
    .line 404
    goto :goto_6

    .line 405
    :cond_1b
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 406
    .line 407
    invoke-interface {v1}, Landroidx/media3/common/Player;->stop()V

    .line 408
    .line 409
    .line 410
    new-instance v1, Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 411
    .line 412
    invoke-direct {v1, p0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;-><init>(Landroid/content/Context;)V

    .line 413
    .line 414
    .line 415
    new-instance v2, Landroidx/media3/exoplayer/DefaultRenderersFactory;

    .line 416
    .line 417
    invoke-direct {v2, p0}, Landroidx/media3/exoplayer/DefaultRenderersFactory;-><init>(Landroid/content/Context;)V

    .line 418
    .line 419
    .line 420
    invoke-virtual {v2, v5}, Landroidx/media3/exoplayer/DefaultRenderersFactory;->setExtensionRendererMode(I)Landroidx/media3/exoplayer/DefaultRenderersFactory;

    .line 421
    .line 422
    .line 423
    move-result-object v2

    .line 424
    invoke-virtual {v1, v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setRenderersFactory(Landroidx/media3/exoplayer/RenderersFactory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 425
    .line 426
    .line 427
    new-instance v2, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 428
    .line 429
    invoke-direct {v2}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;-><init>()V

    .line 430
    .line 431
    .line 432
    iget-object v4, p0, Linfo/t4w/vp/view/MainActivity;->CcZMD:Ljava/lang/String;

    .line 433
    .line 434
    invoke-virtual {v2, v4}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setUserAgent(Ljava/lang/String;)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 435
    .line 436
    .line 437
    move-result-object v2

    .line 438
    invoke-virtual {v2, v3}, Landroidx/media3/datasource/DefaultHttpDataSource$Factory;->setAllowCrossProtocolRedirects(Z)Landroidx/media3/datasource/DefaultHttpDataSource$Factory;

    .line 439
    .line 440
    .line 441
    move-result-object v2

    .line 442
    new-instance v3, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 443
    .line 444
    invoke-direct {v3, p0}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;-><init>(Landroid/content/Context;)V

    .line 445
    .line 446
    .line 447
    invoke-virtual {v3, v2}, Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;->setDataSourceFactory(Landroidx/media3/datasource/DataSource$Factory;)Landroidx/media3/exoplayer/source/DefaultMediaSourceFactory;

    .line 448
    .line 449
    .line 450
    move-result-object v2

    .line 451
    invoke-virtual {v1, v2}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->setMediaSourceFactory(Landroidx/media3/exoplayer/source/MediaSource$Factory;)Landroidx/media3/exoplayer/ExoPlayer$Builder;

    .line 452
    .line 453
    .line 454
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 455
    .line 456
    invoke-interface {v2}, Landroidx/media3/exoplayer/ExoPlayer;->release()V

    .line 457
    .line 458
    .line 459
    invoke-virtual {v1}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->build()Landroidx/media3/exoplayer/ExoPlayer;

    .line 460
    .line 461
    .line 462
    move-result-object v1

    .line 463
    iput-object v1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 464
    .line 465
    iget-object v2, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 466
    .line 467
    invoke-virtual {v2, v1}, Landroidx/media3/ui/PlayerView;->setPlayer(Landroidx/media3/common/Player;)V

    .line 468
    .line 469
    .line 470
    iget-object v1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 471
    .line 472
    new-instance v2, LSZòyiGùS;

    .line 473
    .line 474
    invoke-direct {v2, p0, p1}, LSZòyiGùS;-><init>(Linfo/t4w/vp/view/MainActivity;Ljava/lang/String;)V

    .line 475
    .line 476
    .line 477
    invoke-interface {v1, v2}, Landroidx/media3/common/Player;->addListener(Landroidx/media3/common/Player$Listener;)V

    .line 478
    .line 479
    .line 480
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 481
    .line 482
    invoke-interface {p1, p2}, Landroidx/media3/common/Player;->setMediaItem(Landroidx/media3/common/MediaItem;)V

    .line 483
    .line 484
    .line 485
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 486
    .line 487
    iput-object p1, p0, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 488
    .line 489
    invoke-interface {p1}, Landroidx/media3/common/Player;->prepare()V

    .line 490
    .line 491
    .line 492
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 493
    .line 494
    invoke-interface {p1}, Landroidx/media3/common/Player;->play()V

    .line 495
    .line 496
    .line 497
    iget p1, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 498
    .line 499
    const/high16 p2, 0x3f800000    # 1.0f

    .line 500
    .line 501
    cmpl-float p1, p1, p2

    .line 502
    .line 503
    if-eqz p1, :cond_1c

    .line 504
    .line 505
    new-instance p1, Landroidx/media3/common/PlaybackParameters;

    .line 506
    .line 507
    iget p2, p0, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 508
    .line 509
    invoke-direct {p1, p2}, Landroidx/media3/common/PlaybackParameters;-><init>(F)V

    .line 510
    .line 511
    .line 512
    iget-object p2, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 513
    .line 514
    invoke-interface {p2, p1}, Landroidx/media3/common/Player;->setPlaybackParameters(Landroidx/media3/common/PlaybackParameters;)V

    .line 515
    .line 516
    .line 517
    :cond_1c
    :goto_6
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 518
    .line 519
    invoke-virtual {p1, v0}, Landroidx/media3/ui/PlayerView;->setVisibility(I)V

    .line 520
    .line 521
    .line 522
    return-void

    .line 523
    :cond_1d
    :goto_7
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->k1y:Landroid/widget/TextView;

    .line 524
    .line 525
    if-eqz p1, :cond_1e

    .line 526
    .line 527
    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 528
    .line 529
    .line 530
    :cond_1e
    sget p1, LcJLÌfz;->ready_to_play:I

    .line 531
    .line 532
    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 533
    .line 534
    .line 535
    move-result-object p1

    .line 536
    invoke-virtual {p0, p1}, Linfo/t4w/vp/view/MainActivity;->Oey(Ljava/lang/String;)V

    .line 537
    .line 538
    .line 539
    iget-object p1, p0, Linfo/t4w/vp/view/MainActivity;->l1:Landroidx/media3/exoplayer/ExoPlayer;

    .line 540
    .line 541
    if-eqz p1, :cond_1f

    .line 542
    .line 543
    invoke-interface {p1}, Landroidx/media3/common/Player;->stop()V

    .line 544
    .line 545
    .line 546
    :cond_1f
    :goto_8
    return-void

    .line 547
    :sswitch_data_0
    .sparse-switch
        0xe7f -> :sswitch_c
        0x17843 -> :sswitch_b
        0x19883 -> :sswitch_a
        0x1a698 -> :sswitch_9
        0x1a6f0 -> :sswitch_8
        0x1a6f1 -> :sswitch_7
        0x1a721 -> :sswitch_6
        0x1ad8f -> :sswitch_5
        0x2fff68 -> :sswitch_4
        0x317849 -> :sswitch_3
        0x31ece8 -> :sswitch_2
        0x325a49 -> :sswitch_1
        0x379f99 -> :sswitch_0
    .end sparse-switch

    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_9
        :pswitch_8
        :pswitch_a
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_a
        :pswitch_1
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final tmpSize211()Z
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const-string v1, "android.software.leanback"

    .line 6
    .line 7
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-nez v1, :cond_1

    .line 12
    .line 13
    const-string v1, "android.hardware.type.television"

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_0

    .line 20
    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v0, 0x0

    .line 23
    return v0

    .line 24
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 25
    return v0
.end method

.method public final yPN$A_n$()V
    .locals 3

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->Iii:Landroidx/media3/ui/PlayerView;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-boolean v1, p0, Linfo/t4w/vp/view/MainActivity;->gc_$M_w2$:Z

    .line 7
    .line 8
    xor-int/lit8 v2, v1, 0x1

    .line 9
    .line 10
    iput-boolean v2, p0, Linfo/t4w/vp/view/MainActivity;->gc_$M_w2$:Z

    .line 11
    .line 12
    if-nez v1, :cond_1

    .line 13
    .line 14
    const/4 v1, 0x4

    .line 15
    invoke-virtual {v0, v1}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->ChI_KH_:Landroid/widget/ImageView;

    .line 19
    .line 20
    sget v1, LindeQ;->video_scale_zoom:I

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_1
    const/4 v1, 0x0

    .line 27
    invoke-virtual {v0, v1}, Landroidx/media3/ui/PlayerView;->setResizeMode(I)V

    .line 28
    .line 29
    .line 30
    iget-object v0, p0, Linfo/t4w/vp/view/MainActivity;->ChI_KH_:Landroid/widget/ImageView;

    .line 31
    .line 32
    sget v1, LindeQ;->video_scale_fit:I

    .line 33
    .line 34
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageResource(I)V

    .line 35
    .line 36
    .line 37
    return-void
.end method
