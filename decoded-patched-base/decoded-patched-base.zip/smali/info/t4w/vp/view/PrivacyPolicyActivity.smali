.class public Linfo/t4w/vp/view/PrivacyPolicyActivity;
.super LUd$5_1h$;
.source "SourceFile"


# static fields
.field public static final synthetic BCIm:I


# instance fields
.field public Iii:Landroid/widget/TextView;

.field public l1:I

.field public oaX_6_:Landroid/widget/ScrollView;

.field public pQ1Il:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LUd$5_1h$;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->l1:I

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final K0I()Z
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x1

    .line 5
    return v0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, LKùiu;->activity_privacy_policy:I

    .line 5
    .line 6
    invoke-virtual {p0, p1}, LUd$5_1h$;->setContentView(I)V

    .line 7
    .line 8
    .line 9
    sget p1, LRO1QI;->toolbar:I

    .line 10
    .line 11
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Landroidx/appcompat/widget/Toolbar;

    .line 16
    .line 17
    iput-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->pQ1Il:Landroidx/appcompat/widget/Toolbar;

    .line 18
    .line 19
    invoke-virtual {p0, p1}, LUd$5_1h$;->Qp_Hp$i_(Landroidx/appcompat/widget/Toolbar;)V

    .line 20
    .line 21
    .line 22
    sget p1, LRO1QI;->main_layout:I

    .line 23
    .line 24
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    new-instance v0, LI1I;

    .line 29
    .line 30
    const/16 v1, 0x1b

    .line 31
    .line 32
    invoke-direct {v0, v1}, LI1I;-><init>(I)V

    .line 33
    .line 34
    .line 35
    sget-object v1, Ll11Il;->e8$mp_s$:Ljava/util/WeakHashMap;

    .line 36
    .line 37
    invoke-static {p1, v0}, LI11l;->kQy(Landroid/view/View;LvllDQ;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {p0}, LUd$5_1h$;->iOffset934()LdbÙLJ;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    if-eqz p1, :cond_0

    .line 45
    .line 46
    invoke-virtual {p0}, LUd$5_1h$;->iOffset934()LdbÙLJ;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    sget v0, LcJLÌfz;->privacy_policy:I

    .line 51
    .line 52
    invoke-virtual {p1, v0}, LdbÙLJ;->oaX_6_(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p0}, LUd$5_1h$;->iOffset934()LdbÙLJ;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    const/4 v0, 0x1

    .line 60
    invoke-virtual {p1, v0}, LdbÙLJ;->Iii(Z)V

    .line 61
    .line 62
    .line 63
    :cond_0
    sget p1, LRO1QI;->privacy_policy_text:I

    .line 64
    .line 65
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 66
    .line 67
    .line 68
    move-result-object p1

    .line 69
    check-cast p1, Landroid/widget/TextView;

    .line 70
    .line 71
    iput-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->Iii:Landroid/widget/TextView;

    .line 72
    .line 73
    sget p1, LRO1QI;->privacy_scroll:I

    .line 74
    .line 75
    invoke-virtual {p0, p1}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    check-cast p1, Landroid/widget/ScrollView;

    .line 80
    .line 81
    iput-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 82
    .line 83
    iget-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->Iii:Landroid/widget/TextView;

    .line 84
    .line 85
    new-instance v0, LwLEyS;

    .line 86
    .line 87
    const/16 v1, 0x8

    .line 88
    .line 89
    invoke-direct {v0, v1, p0}, LwLEyS;-><init>(ILjava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    const-string v0, "android.software.leanback"

    .line 100
    .line 101
    invoke-virtual {p1, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 102
    .line 103
    .line 104
    move-result v0

    .line 105
    if-nez v0, :cond_2

    .line 106
    .line 107
    const-string v0, "android.hardware.type.television"

    .line 108
    .line 109
    invoke-virtual {p1, v0}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 110
    .line 111
    .line 112
    move-result p1

    .line 113
    if-eqz p1, :cond_1

    .line 114
    .line 115
    goto :goto_0

    .line 116
    :cond_1
    return-void

    .line 117
    :cond_2
    :goto_0
    iget-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 118
    .line 119
    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    .line 120
    .line 121
    .line 122
    iget-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->pQ1Il:Landroidx/appcompat/widget/Toolbar;

    .line 123
    .line 124
    new-instance v0, LvIndex5686;

    .line 125
    .line 126
    const/16 v1, 0x14

    .line 127
    .line 128
    invoke-direct {v0, v1, p0}, LvIndex5686;-><init>(ILjava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {p1, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    .line 132
    .line 133
    .line 134
    return-void
.end method

.method public final onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 4

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 2
    .line 3
    if-eqz v0, :cond_3

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_3

    .line 10
    .line 11
    const/16 v0, 0x14

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    const/4 v2, 0x1

    .line 15
    if-ne p1, v0, :cond_0

    .line 16
    .line 17
    iget-object v0, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 18
    .line 19
    invoke-virtual {v0, v2}, Landroid/view/View;->canScrollVertically(I)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_3

    .line 24
    .line 25
    iget-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 26
    .line 27
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 28
    .line 29
    .line 30
    move-result p2

    .line 31
    div-int/lit8 p2, p2, 0x2

    .line 32
    .line 33
    invoke-virtual {p1, v1, p2}, Landroid/widget/ScrollView;->smoothScrollBy(II)V

    .line 34
    .line 35
    .line 36
    return v2

    .line 37
    :cond_0
    const/16 v0, 0x13

    .line 38
    .line 39
    if-ne p1, v0, :cond_3

    .line 40
    .line 41
    iget-object v0, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 42
    .line 43
    const/4 v3, -0x1

    .line 44
    invoke-virtual {v0, v3}, Landroid/view/View;->canScrollVertically(I)Z

    .line 45
    .line 46
    .line 47
    move-result v0

    .line 48
    if-eqz v0, :cond_1

    .line 49
    .line 50
    iget-object p1, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->oaX_6_:Landroid/widget/ScrollView;

    .line 51
    .line 52
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 53
    .line 54
    .line 55
    move-result p2

    .line 56
    neg-int p2, p2

    .line 57
    div-int/lit8 p2, p2, 0x2

    .line 58
    .line 59
    invoke-virtual {p1, v1, p2}, Landroid/widget/ScrollView;->smoothScrollBy(II)V

    .line 60
    .line 61
    .line 62
    return v2

    .line 63
    :cond_1
    :goto_0
    iget-object v0, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->pQ1Il:Landroidx/appcompat/widget/Toolbar;

    .line 64
    .line 65
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-ge v1, v0, :cond_3

    .line 70
    .line 71
    iget-object v0, p0, Linfo/t4w/vp/view/PrivacyPolicyActivity;->pQ1Il:Landroidx/appcompat/widget/Toolbar;

    .line 72
    .line 73
    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    instance-of v3, v0, Landroid/widget/ImageButton;

    .line 78
    .line 79
    if-eqz v3, :cond_2

    .line 80
    .line 81
    invoke-virtual {v0}, Landroid/view/View;->isFocusable()Z

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    if-eqz v3, :cond_2

    .line 86
    .line 87
    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    .line 88
    .line 89
    .line 90
    return v2

    .line 91
    :cond_2
    add-int/lit8 v1, v1, 0x1

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_3
    invoke-super {p0, p1, p2}, LUd$5_1h$;->onKeyDown(ILandroid/view/KeyEvent;)Z

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    return p1
.end method
