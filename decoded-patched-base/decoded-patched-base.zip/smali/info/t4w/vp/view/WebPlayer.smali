.class public Linfo/t4w/vp/view/WebPlayer;
.super LUd$5_1h$;
.source "SourceFile"

# interfaces
.implements LGl1ID;


# static fields
.field public static final synthetic iSize4906:I


# instance fields
.field public BCIm:Ljava/lang/String;

.field public Iii:Landroid/webkit/WebView;

.field public gSy_FG$D_:Ljava/util/HashMap;

.field public l1:Ljava/lang/String;

.field public oaX_6_:Ljava/lang/String;

.field public pQ1Il:Ljava/lang/String;

.field public zAt$p:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, LUd$5_1h$;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final onBackPressed()V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    invoke-super {p0}, LqboÌWm;->onBackPressed()V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .locals 4

    .line 1
    invoke-super {p0, p1}, LUd$5_1h$;->onCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v0, 0x1a

    .line 7
    .line 8
    const/16 v1, 0x1c

    .line 9
    .line 10
    if-lt p1, v0, :cond_0

    .line 11
    .line 12
    if-lt p1, v1, :cond_0

    .line 13
    .line 14
    :try_start_0
    invoke-static {}, LCA$b_$K$;->tzKù7Ol1()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 15
    .line 16
    .line 17
    goto :goto_0

    .line 18
    :catch_0
    move-exception p1

    .line 19
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    :cond_0
    :goto_0
    sget p1, LKùiu;->activity_web_player:I

    .line 23
    .line 24
    invoke-virtual {p0, p1}, LUd$5_1h$;->setContentView(I)V

    .line 25
    .line 26
    .line 27
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 28
    .line 29
    if-lt p1, v1, :cond_1

    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 32
    .line 33
    .line 34
    move-result-object p1

    .line 35
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 36
    .line 37
    .line 38
    move-result-object p1

    .line 39
    invoke-static {p1}, LCA$b_$K$;->gKey4112(Landroid/view/WindowManager$LayoutParams;)V

    .line 40
    .line 41
    .line 42
    :cond_1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    const/16 v0, 0x600

    .line 47
    .line 48
    invoke-virtual {p1, v0, v0}, Landroid/view/Window;->setFlags(II)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 56
    .line 57
    .line 58
    move-result-object p1

    .line 59
    const/16 v0, 0x1706

    .line 60
    .line 61
    invoke-virtual {p1, v0}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 62
    .line 63
    .line 64
    const/4 p1, 0x0

    .line 65
    invoke-virtual {p0, p1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 66
    .line 67
    .line 68
    sget v0, LRO1QI;->ad_layout:I

    .line 69
    .line 70
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 71
    .line 72
    .line 73
    move-result-object v0

    .line 74
    check-cast v0, Landroid/widget/LinearLayout;

    .line 75
    .line 76
    iput-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->zAt$p:Landroid/widget/LinearLayout;

    .line 77
    .line 78
    sget v0, LcJLÌfz;->admob_ad_id:I

    .line 79
    .line 80
    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    iput-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->BCIm:Ljava/lang/String;

    .line 85
    .line 86
    new-instance v0, LsPos9472;

    .line 87
    .line 88
    const/4 v1, 0x1

    .line 89
    invoke-direct {v0, p0, v1}, LsPos9472;-><init>(LUd$5_1h$;I)V

    .line 90
    .line 91
    .line 92
    invoke-static {p0, v0}, Lcom/google/android/gms/ads/MobileAds;->waiBKÀ(LUd$5_1h$;LZ8_O$y_;)V

    .line 93
    .line 94
    .line 95
    sget v0, LRO1QI;->webView:I

    .line 96
    .line 97
    invoke-virtual {p0, v0}, LUd$5_1h$;->findViewById(I)Landroid/view/View;

    .line 98
    .line 99
    .line 100
    move-result-object v0

    .line 101
    check-cast v0, Landroid/webkit/WebView;

    .line 102
    .line 103
    iput-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 104
    .line 105
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 122
    .line 123
    .line 124
    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    .line 125
    .line 126
    .line 127
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 128
    .line 129
    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->setScrollBarStyle(I)V

    .line 130
    .line 131
    .line 132
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 133
    .line 134
    new-instance v2, Landroid/webkit/WebViewClient;

    .line 135
    .line 136
    invoke-direct {v2}, Landroid/webkit/WebViewClient;-><init>()V

    .line 137
    .line 138
    .line 139
    invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 140
    .line 141
    .line 142
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 143
    .line 144
    new-instance v2, Landroid/webkit/WebChromeClient;

    .line 145
    .line 146
    invoke-direct {v2}, Landroid/webkit/WebChromeClient;-><init>()V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 150
    .line 151
    .line 152
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 153
    .line 154
    new-instance v2, Lioia;

    .line 155
    .line 156
    const/4 v3, 0x0

    .line 157
    invoke-direct {v2, v3, p0}, Lioia;-><init>(ILjava/lang/Object;)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v0, v2}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 161
    .line 162
    .line 163
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 164
    .line 165
    .line 166
    move-result-object v0

    .line 167
    const-string v2, "url"

    .line 168
    .line 169
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v0

    .line 173
    iput-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->l1:Ljava/lang/String;

    .line 174
    .line 175
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    iput-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->pQ1Il:Ljava/lang/String;

    .line 184
    .line 185
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 186
    .line 187
    .line 188
    move-result-object v0

    .line 189
    const-string v2, "agent"

    .line 190
    .line 191
    invoke-virtual {v0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v0

    .line 195
    iput-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->oaX_6_:Ljava/lang/String;

    .line 196
    .line 197
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    const-string v2, "sch"

    .line 209
    .line 210
    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->getBoolean(Ljava/lang/String;Z)Z

    .line 211
    .line 212
    .line 213
    move-result v0

    .line 214
    if-nez v0, :cond_2

    .line 215
    .line 216
    const/4 v0, -0x1

    .line 217
    invoke-virtual {p0, v0}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 218
    .line 219
    .line 220
    :cond_2
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->l1:Ljava/lang/String;

    .line 221
    .line 222
    if-eqz v0, :cond_5

    .line 223
    .line 224
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 225
    .line 226
    .line 227
    move-result v0

    .line 228
    if-nez v0, :cond_5

    .line 229
    .line 230
    :try_start_1
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->l1:Ljava/lang/String;

    .line 231
    .line 232
    const-string v2, "<<R>>"

    .line 233
    .line 234
    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    .line 235
    .line 236
    .line 237
    move-result-object v0

    .line 238
    aget-object p1, v0, p1

    .line 239
    .line 240
    iput-object p1, p0, Linfo/t4w/vp/view/WebPlayer;->l1:Ljava/lang/String;

    .line 241
    .line 242
    aget-object p1, v0, v1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 243
    .line 244
    goto :goto_1

    .line 245
    :catch_1
    iget-object p1, p0, Linfo/t4w/vp/view/WebPlayer;->l1:Ljava/lang/String;

    .line 246
    .line 247
    :goto_1
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->l1:Ljava/lang/String;

    .line 248
    .line 249
    iget-object v1, p0, Linfo/t4w/vp/view/WebPlayer;->oaX_6_:Ljava/lang/String;

    .line 250
    .line 251
    if-eqz v1, :cond_3

    .line 252
    .line 253
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 254
    .line 255
    .line 256
    move-result v2

    .line 257
    if-nez v2, :cond_3

    .line 258
    .line 259
    iget-object v2, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 260
    .line 261
    invoke-virtual {v2}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 262
    .line 263
    .line 264
    move-result-object v2

    .line 265
    invoke-virtual {v2, v1}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    goto :goto_2

    .line 269
    :cond_3
    iget-object v2, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 270
    .line 271
    invoke-virtual {v2}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    .line 272
    .line 273
    .line 274
    move-result-object v2

    .line 275
    const-string v3, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"

    .line 276
    .line 277
    invoke-virtual {v2, v3}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    :goto_2
    new-instance v2, Ljava/util/HashMap;

    .line 281
    .line 282
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 283
    .line 284
    .line 285
    iput-object v2, p0, Linfo/t4w/vp/view/WebPlayer;->gSy_FG$D_:Ljava/util/HashMap;

    .line 286
    .line 287
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    .line 288
    .line 289
    .line 290
    move-result v2

    .line 291
    if-nez v2, :cond_4

    .line 292
    .line 293
    goto :goto_3

    .line 294
    :cond_4
    move-object p1, v0

    .line 295
    :goto_3
    iget-object v2, p0, Linfo/t4w/vp/view/WebPlayer;->gSy_FG$D_:Ljava/util/HashMap;

    .line 296
    .line 297
    const-string v3, "User-Agent"

    .line 298
    .line 299
    invoke-virtual {v2, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 300
    .line 301
    .line 302
    iget-object v1, p0, Linfo/t4w/vp/view/WebPlayer;->gSy_FG$D_:Ljava/util/HashMap;

    .line 303
    .line 304
    const-string v2, "Referer"

    .line 305
    .line 306
    invoke-virtual {v1, v2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    iget-object p1, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 310
    .line 311
    iget-object v1, p0, Linfo/t4w/vp/view/WebPlayer;->gSy_FG$D_:Ljava/util/HashMap;

    .line 312
    .line 313
    invoke-virtual {p1, v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;Ljava/util/Map;)V

    .line 314
    .line 315
    .line 316
    goto :goto_4

    .line 317
    :cond_5
    const-string v0, "No URL provided"

    .line 318
    .line 319
    invoke-static {p0, v0, p1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 320
    .line 321
    .line 322
    move-result-object p1

    .line 323
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 324
    .line 325
    .line 326
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 327
    .line 328
    .line 329
    :goto_4
    return-void
.end method

.method public final onDestroy()V
    .locals 1

    .line 1
    iget-object v0, p0, Linfo/t4w/vp/view/WebPlayer;->Iii:Landroid/webkit/WebView;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V

    .line 6
    .line 7
    .line 8
    :cond_0
    invoke-super {p0}, LUd$5_1h$;->onDestroy()V

    .line 9
    .line 10
    .line 11
    return-void
.end method
