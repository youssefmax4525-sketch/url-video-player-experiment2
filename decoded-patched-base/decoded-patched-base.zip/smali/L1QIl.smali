.class public final LL1QIl;
.super LDKp_q0_;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LIIII;

.field public final waiBKÀ:I


# direct methods
.method public constructor <init>(LIIII;I)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LL1QIl;->e8$mp_s$:LIIII;

    .line 5
    .line 6
    iput p2, p0, LL1QIl;->waiBKÀ:I

    .line 7
    .line 8
    return-void
.end method

.method public static waiBKÀ(LIIII;I)LL1QIl;
    .locals 1

    .line 1
    const/16 v0, 0x8

    .line 2
    .line 3
    if-lt p1, v0, :cond_0

    .line 4
    .line 5
    const/16 v0, 0xc

    .line 6
    .line 7
    if-gt p1, v0, :cond_0

    .line 8
    .line 9
    new-instance v0, LL1QIl;

    .line 10
    .line 11
    invoke-direct {v0, p0, p1}, LL1QIl;-><init>(LIIII;I)V

    .line 12
    .line 13
    .line 14
    return-object v0

    .line 15
    :cond_0
    new-instance p0, Ljava/security/GeneralSecurityException;

    .line 16
    .line 17
    const-string p1, "Salt size must be between 8 and 12 bytes"

    .line 18
    .line 19
    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    throw p0
.end method


# virtual methods
.method public final e8$mp_s$()Z
    .locals 2

    .line 1
    iget-object v0, p0, LL1QIl;->e8$mp_s$:LIIII;

    .line 2
    .line 3
    sget-object v1, LIIII;->sKey7917:LIIII;

    .line 4
    .line 5
    if-eq v0, v1, :cond_0

    .line 6
    .line 7
    const/4 v0, 0x1

    .line 8
    return v0

    .line 9
    :cond_0
    const/4 v0, 0x0

    .line 10
    return v0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    instance-of v0, p1, LL1QIl;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    check-cast p1, LL1QIl;

    .line 8
    .line 9
    iget-object v0, p1, LL1QIl;->e8$mp_s$:LIIII;

    .line 10
    .line 11
    iget-object v2, p0, LL1QIl;->e8$mp_s$:LIIII;

    .line 12
    .line 13
    if-ne v0, v2, :cond_1

    .line 14
    .line 15
    iget p1, p1, LL1QIl;->waiBKÀ:I

    .line 16
    .line 17
    iget v0, p0, LL1QIl;->waiBKÀ:I

    .line 18
    .line 19
    if-ne p1, v0, :cond_1

    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    return p1

    .line 23
    :cond_1
    return v1
.end method

.method public final hashCode()I
    .locals 4

    .line 1
    iget v0, p0, LL1QIl;->waiBKÀ:I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    const/4 v1, 0x3

    .line 8
    new-array v1, v1, [Ljava/lang/Object;

    .line 9
    .line 10
    const-class v2, LL1QIl;

    .line 11
    .line 12
    const/4 v3, 0x0

    .line 13
    aput-object v2, v1, v3

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    iget-object v3, p0, LL1QIl;->e8$mp_s$:LIIII;

    .line 17
    .line 18
    aput-object v3, v1, v2

    .line 19
    .line 20
    const/4 v2, 0x2

    .line 21
    aput-object v0, v1, v2

    .line 22
    .line 23
    invoke-static {v1}, Ljava/util/Objects;->hash([Ljava/lang/Object;)I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget-object v0, p0, LL1QIl;->e8$mp_s$:LIIII;

    .line 2
    .line 3
    iget-object v0, v0, LIIII;->waiBKÀ:Ljava/lang/String;

    .line 4
    .line 5
    const-string v1, "X-AES-GCM Parameters (variant: "

    .line 6
    .line 7
    const-string v2, "salt_size_bytes: "

    .line 8
    .line 9
    invoke-static {v1, v0, v2}, LBRK_m_;->Ialue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iget v1, p0, LL1QIl;->waiBKÀ:I

    .line 14
    .line 15
    const-string v2, ")"

    .line 16
    .line 17
    invoke-static {v0, v1, v2}, LBRK_m_;->jPos3709(Ljava/lang/StringBuilder;ILjava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method
