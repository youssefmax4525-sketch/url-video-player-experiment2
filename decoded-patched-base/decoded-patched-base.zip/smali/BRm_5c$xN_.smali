.class public interface abstract LBRm_5c$xN_;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lk0y;


# virtual methods
.method public abstract isActive()Z
.end method
