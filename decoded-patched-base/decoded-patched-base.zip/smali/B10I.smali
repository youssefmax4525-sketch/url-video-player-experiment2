.class public interface abstract LB10I;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract JKEoÙX()V
.end method
