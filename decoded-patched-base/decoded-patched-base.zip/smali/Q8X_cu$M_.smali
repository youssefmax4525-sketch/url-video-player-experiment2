.class public final LQ8X_cu$M_;
.super LHh_ms_;
.source "SourceFile"


# static fields
.field public static final POOl:LWnÀXqJ5;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LWnÀXqJ5;

    .line 2
    .line 3
    const/16 v1, 0xc

    .line 4
    .line 5
    invoke-direct {v0, v1}, LWnÀXqJ5;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LQ8X_cu$M_;->POOl:LWnÀXqJ5;

    .line 9
    .line 10
    return-void
.end method
