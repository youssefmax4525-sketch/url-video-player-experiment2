.class public interface abstract Ltl$__WZ$;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract tmpData3485(JLYizKm;)V
.end method
