.class public final synthetic Ll1il;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic jPos3709:Ljava/lang/String;

.field public final synthetic vaIue:LisKey7282;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LisKey7282;Ljava/lang/String;I)V
    .locals 0

    .line 1
    iput p3, p0, Ll1il;->yON3x:I

    iput-object p1, p0, Ll1il;->vaIue:LisKey7282;

    iput-object p2, p0, Ll1il;->jPos3709:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget v0, p0, Ll1il;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "UTF-8"

    .line 7
    .line 8
    iget-object v1, p0, Ll1il;->vaIue:LisKey7282;

    .line 9
    .line 10
    iget-object v1, v1, LisKey7282;->yON3x:L_ìdp;

    .line 11
    .line 12
    iget-object v2, p0, Ll1il;->jPos3709:Ljava/lang/String;

    .line 13
    .line 14
    const-string v3, "text/html"

    .line 15
    .line 16
    invoke-interface {v1, v2, v3, v0}, L_ìdp;->loadData(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    return-void

    .line 20
    :pswitch_0
    iget-object v0, p0, Ll1il;->jPos3709:Ljava/lang/String;

    .line 21
    .line 22
    iget-object v1, p0, Ll1il;->vaIue:LisKey7282;

    .line 23
    .line 24
    iget-object v1, v1, LisKey7282;->yON3x:L_ìdp;

    .line 25
    .line 26
    invoke-interface {v1, v0}, L_ìdp;->loadUrl(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
