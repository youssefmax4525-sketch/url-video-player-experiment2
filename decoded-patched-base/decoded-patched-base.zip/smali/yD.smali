.class public final synthetic LyD;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LJl1;


# instance fields
.field public final synthetic e8$mp_s$:LqOIIQD;

.field public final synthetic waiBKÀ:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LqOIIQD;Ljava/lang/Object;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LyD;->e8$mp_s$:LqOIIQD;

    .line 5
    .line 6
    iput-object p2, p0, LyD;->waiBKÀ:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(LisOffset3291;LisItem9853;)V
    .locals 2

    .line 1
    iget-object v0, p0, LyD;->e8$mp_s$:LqOIIQD;

    .line 2
    .line 3
    iget-object v1, p0, LyD;->waiBKÀ:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-virtual {v0, v1, p1, p2}, LqOIIQD;->kO_6X_(Ljava/lang/Object;LisOffset3291;LisItem9853;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method
