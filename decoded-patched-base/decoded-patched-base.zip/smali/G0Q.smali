.class public final LG0Q;
.super LIemp;
.source "SourceFile"


# instance fields
.field public final synthetic $ÒcdS:Ljava/lang/String;

.field public final synthetic Q1_f_:Ljava/lang/String;

.field public final synthetic tmpSize211:LsValue1175;


# direct methods
.method public constructor <init>(LsValue1175;Ljava/lang/String;Ljava/lang/String;)V
    .locals 1

    .line 1
    const/4 v0, 0x7

    .line 2
    invoke-direct {p0, v0}, LPJNypàa;-><init>(I)V

    .line 3
    .line 4
    .line 5
    iput-object p2, p0, LG0Q;->$ÒcdS:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, LG0Q;->Q1_f_:Ljava/lang/String;

    .line 8
    .line 9
    iput-object p1, p0, LG0Q;->tmpSize211:LsValue1175;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final $ÒcdS(LD6$Ff_rK$;)V
    .locals 2

    .line 1
    invoke-static {p1}, LsValue1175;->DìdLm(Ljava/lang/Object;)Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-object v0, p0, LG0Q;->Q1_f_:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v1, p0, LG0Q;->tmpSize211:LsValue1175;

    .line 8
    .line 9
    invoke-virtual {v1, p1, v0}, LsValue1175;->ID(Ljava/lang/String;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final bridge synthetic Q1_f_(Ljava/lang/Object;)V
    .locals 3

    .line 1
    check-cast p1, LRTuÒD5;

    .line 2
    .line 3
    iget-object v0, p0, LG0Q;->tmpSize211:LsValue1175;

    .line 4
    .line 5
    iget-object v1, p0, LG0Q;->$ÒcdS:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, p0, LG0Q;->Q1_f_:Ljava/lang/String;

    .line 8
    .line 9
    invoke-virtual {v0, v1, p1, v2}, LsValue1175;->iSize9261(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method
