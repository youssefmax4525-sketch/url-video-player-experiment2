.class public final LgOffset1953;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LisItem9042;


# instance fields
.field public final POOl:LAO1Q;

.field public final synthetic e8$mp_s$:I

.field public final rz__9J_:Ljava/util/concurrent/Executor;

.field public final waiBKÀ:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;Ljava/util/concurrent/Executor;LAO1Q;I)V
    .locals 0

    .line 1
    iput p4, p0, LgOffset1953;->e8$mp_s$:I

    iput-object p1, p0, LgOffset1953;->waiBKÀ:Landroid/content/Context;

    iput-object p2, p0, LgOffset1953;->rz__9J_:Ljava/util/concurrent/Executor;

    iput-object p3, p0, LgOffset1953;->POOl:LAO1Q;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static final rz__9J_(LmSize8039;LmIndex9894;LdOD;)V
    .locals 1

    .line 1
    :try_start_0
    iget-object v0, p2, LdOD;->waiBKÀ:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LHòbXXM;

    .line 4
    .line 5
    iget-object p0, p0, LmSize8039;->e8$mp_s$:LkGd_Gk_;

    .line 6
    .line 7
    iget-object p0, p0, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p0, LQoXYbY;

    .line 10
    .line 11
    iget-object p0, p0, LQoXYbY;->POOl:LfO0;

    .line 12
    .line 13
    iget-object p1, p1, LmIndex9894;->UC_n_:Lorg/json/JSONObject;

    .line 14
    .line 15
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 19
    :try_start_1
    iget-object v0, v0, LHòbXXM;->e8$mp_s$:LIlli;

    .line 20
    .line 21
    invoke-interface {v0, p1, p0}, LIlli;->o1(Ljava/lang/String;LfO0;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :catchall_0
    move-exception p0

    .line 26
    :try_start_2
    new-instance p1, LiiXwÙ8;

    .line 27
    .line 28
    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 29
    .line 30
    .line 31
    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    .line 32
    :catch_0
    iget-object p0, p2, LdOD;->e8$mp_s$:Ljava/lang/String;

    .line 33
    .line 34
    const-string p1, "Fail to load ad from adapter "

    .line 35
    .line 36
    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(LmSize8039;LmIndex9894;LdOD;)V
    .locals 7

    .line 1
    iget v0, p0, LgOffset1953;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p3, LdOD;->waiBKÀ:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LHòbXXM;

    .line 9
    .line 10
    invoke-virtual {v0}, LHòbXXM;->e8$mp_s$()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    new-instance v1, LtmpCount1613;

    .line 17
    .line 18
    const/16 v6, 0x11

    .line 19
    .line 20
    move-object v2, p0

    .line 21
    move-object v3, p1

    .line 22
    move-object v4, p2

    .line 23
    move-object v5, p3

    .line 24
    invoke-direct/range {v1 .. v6}, LtmpCount1613;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 25
    .line 26
    .line 27
    iget-object p1, v5, LdOD;->rz__9J_:LhasValue4175;

    .line 28
    .line 29
    check-cast p1, LlI1I1;

    .line 30
    .line 31
    monitor-enter p1

    .line 32
    :try_start_0
    iput-object v1, p1, LlI1I1;->jPos3709:LtmpCount1613;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 33
    .line 34
    monitor-exit p1

    .line 35
    iget-object p1, v5, LdOD;->waiBKÀ:Ljava/lang/Object;

    .line 36
    .line 37
    iget-object p2, v2, LgOffset1953;->waiBKÀ:Landroid/content/Context;

    .line 38
    .line 39
    check-cast p1, LHòbXXM;

    .line 40
    .line 41
    iget-object p3, v3, LmSize8039;->e8$mp_s$:LkGd_Gk_;

    .line 42
    .line 43
    iget-object p3, p3, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast p3, LQoXYbY;

    .line 46
    .line 47
    iget-object v0, v5, LdOD;->rz__9J_:LhasValue4175;

    .line 48
    .line 49
    check-cast v0, LrmF_P_;

    .line 50
    .line 51
    iget-object v1, v4, LmIndex9894;->UC_n_:Lorg/json/JSONObject;

    .line 52
    .line 53
    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v1

    .line 57
    iget-object p3, p3, LQoXYbY;->POOl:LfO0;

    .line 58
    .line 59
    :try_start_1
    iget-object p1, p1, LHòbXXM;->e8$mp_s$:LIlli;

    .line 60
    .line 61
    new-instance v3, Lfdo_n_;

    .line 62
    .line 63
    invoke-direct {v3, p2}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-interface {p1, v3, p3, v0, v1}, LIlli;->KBSNU(LKàaq;LfO0;LrmF_P_;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 67
    .line 68
    .line 69
    goto :goto_0

    .line 70
    :catchall_0
    move-exception v0

    .line 71
    move-object p1, v0

    .line 72
    new-instance p2, LiiXwÙ8;

    .line 73
    .line 74
    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 75
    .line 76
    .line 77
    throw p2

    .line 78
    :catchall_1
    move-exception v0

    .line 79
    move-object p2, v0

    .line 80
    :try_start_2
    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 81
    throw p2

    .line 82
    :cond_0
    move-object v2, p0

    .line 83
    move-object v3, p1

    .line 84
    move-object v4, p2

    .line 85
    move-object v5, p3

    .line 86
    invoke-static {v3, v4, v5}, LgOffset1953;->rz__9J_(LmSize8039;LmIndex9894;LdOD;)V

    .line 87
    .line 88
    .line 89
    :goto_0
    return-void

    .line 90
    :pswitch_0
    move-object v2, p0

    .line 91
    move-object v3, p1

    .line 92
    move-object v4, p2

    .line 93
    move-object v5, p3

    .line 94
    iget-object p1, v4, LmIndex9894;->UC_n_:Lorg/json/JSONObject;

    .line 95
    .line 96
    iget-object p2, v5, LdOD;->rz__9J_:LhasValue4175;

    .line 97
    .line 98
    iget-object p3, v5, LdOD;->waiBKÀ:Ljava/lang/Object;

    .line 99
    .line 100
    iget-object v0, v2, LgOffset1953;->waiBKÀ:Landroid/content/Context;

    .line 101
    .line 102
    :try_start_3
    iget-object v1, v3, LmSize8039;->e8$mp_s$:LkGd_Gk_;

    .line 103
    .line 104
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v1, LQoXYbY;

    .line 107
    .line 108
    iget-object v3, v1, LQoXYbY;->valuI:LZlTMJ;

    .line 109
    .line 110
    iget-object v1, v1, LQoXYbY;->POOl:LfO0;

    .line 111
    .line 112
    iget v3, v3, LZlTMJ;->vaIue:I

    .line 113
    .line 114
    const/4 v4, 0x3

    .line 115
    if-ne v3, v4, :cond_1

    .line 116
    .line 117
    check-cast p3, LHòbXXM;

    .line 118
    .line 119
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object p1

    .line 123
    check-cast p2, L_6_r7$K_;
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_0

    .line 124
    .line 125
    :try_start_4
    iget-object p3, p3, LHòbXXM;->e8$mp_s$:LIlli;

    .line 126
    .line 127
    new-instance v3, Lfdo_n_;

    .line 128
    .line 129
    invoke-direct {v3, v0}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 130
    .line 131
    .line 132
    invoke-interface {p3, v3, v1, p1, p2}, LIlli;->gItem9343(LKàaq;LfO0;Ljava/lang/String;L_6_r7$K_;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    .line 133
    .line 134
    .line 135
    goto :goto_1

    .line 136
    :catchall_2
    move-exception v0

    .line 137
    move-object p1, v0

    .line 138
    :try_start_5
    new-instance p2, LiiXwÙ8;

    .line 139
    .line 140
    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 141
    .line 142
    .line 143
    throw p2

    .line 144
    :cond_1
    check-cast p3, LHòbXXM;

    .line 145
    .line 146
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    check-cast p2, L_6_r7$K_;
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_0

    .line 151
    .line 152
    :try_start_6
    iget-object p3, p3, LHòbXXM;->e8$mp_s$:LIlli;

    .line 153
    .line 154
    new-instance v3, Lfdo_n_;

    .line 155
    .line 156
    invoke-direct {v3, v0}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 157
    .line 158
    .line 159
    invoke-interface {p3, v3, v1, p1, p2}, LIlli;->llIiI(LKàaq;LfO0;Ljava/lang/String;L_6_r7$K_;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    .line 160
    .line 161
    .line 162
    goto :goto_1

    .line 163
    :catchall_3
    move-exception v0

    .line 164
    move-object p1, v0

    .line 165
    :try_start_7
    new-instance p2, LiiXwÙ8;

    .line 166
    .line 167
    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 168
    .line 169
    .line 170
    throw p2
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_0

    .line 171
    :catch_0
    iget-object p1, v5, LdOD;->e8$mp_s$:Ljava/lang/String;

    .line 172
    .line 173
    const-string p2, "Fail to load ad from adapter "

    .line 174
    .line 175
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 180
    .line 181
    .line 182
    :goto_1
    return-void

    .line 183
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final waiBKÀ(LmSize8039;LmIndex9894;LdOD;)Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LgOffset1953;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-instance v0, LlACD;

    .line 7
    .line 8
    iget-object v1, p3, LdOD;->e8$mp_s$:Ljava/lang/String;

    .line 9
    .line 10
    invoke-direct {v0, p1, p2, v1}, LlACD;-><init>(LmSize8039;LmIndex9894;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    new-instance p1, LB1Il;

    .line 14
    .line 15
    new-instance p2, Lah_1k$4v_;

    .line 16
    .line 17
    const/4 v1, 0x5

    .line 18
    invoke-direct {p2, v1, p3}, Lah_1k$4v_;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    const/4 v1, 0x0

    .line 22
    const/4 v2, 0x0

    .line 23
    invoke-direct {p1, p2, v1, v2}, LB1Il;-><init>(LeAs;L_ìdp;I)V

    .line 24
    .line 25
    .line 26
    iget-object p2, p0, LgOffset1953;->POOl:LAO1Q;

    .line 27
    .line 28
    new-instance v1, Lp1s;

    .line 29
    .line 30
    iget-object v2, p2, LAO1Q;->rz__9J_:LiKey8287;

    .line 31
    .line 32
    iget-object p2, p2, LAO1Q;->POOl:LAO1Q;

    .line 33
    .line 34
    invoke-direct {v1, v2, p2, v0, p1}, Lp1s;-><init>(LiKey8287;LAO1Q;LlACD;LB1Il;)V

    .line 35
    .line 36
    .line 37
    iget-object p1, v1, Lp1s;->Qp_Hp$i_:LjPos3798;

    .line 38
    .line 39
    invoke-virtual {p1}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    check-cast p1, LnQO;

    .line 44
    .line 45
    new-instance p2, LisCount1918;

    .line 46
    .line 47
    iget-object v0, p3, LdOD;->waiBKÀ:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v0, LHòbXXM;

    .line 50
    .line 51
    const/4 v2, 0x0

    .line 52
    invoke-direct {p2, v2, v0}, LisCount1918;-><init>(ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    iget-object v0, p0, LgOffset1953;->rz__9J_:Ljava/util/concurrent/Executor;

    .line 56
    .line 57
    invoke-virtual {p1, p2, v0}, LHDl0DI;->eQOI(Ljava/lang/Object;Ljava/util/concurrent/Executor;)V

    .line 58
    .line 59
    .line 60
    iget-object p1, v1, Lp1s;->sKey6064:LjPos3798;

    .line 61
    .line 62
    invoke-virtual {p1}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    check-cast p1, Ly1;

    .line 67
    .line 68
    iget-object p2, v1, Lp1s;->tzKù7Ol1:LjPos3798;

    .line 69
    .line 70
    invoke-virtual {p2}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object p2

    .line 74
    check-cast p2, LkItem7394;

    .line 75
    .line 76
    iget-object v0, v1, Lp1s;->Iii:LjPos3798;

    .line 77
    .line 78
    invoke-virtual {v0}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    check-cast v0, LisIndex7822;

    .line 83
    .line 84
    iget-object v2, v1, Lp1s;->gSy_FG$D_:LjPos3798;

    .line 85
    .line 86
    invoke-virtual {v2}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v2

    .line 90
    check-cast v2, LQànSW;

    .line 91
    .line 92
    iget-object p3, p3, LdOD;->rz__9J_:LhasValue4175;

    .line 93
    .line 94
    move-object v3, p3

    .line 95
    check-cast v3, LlI1I1;

    .line 96
    .line 97
    new-instance p3, Ltl0ll;

    .line 98
    .line 99
    invoke-direct {p3, v0, p2, p1, v2}, Ltl0ll;-><init>(LisIndex7822;LkItem7394;Ly1;LQànSW;)V

    .line 100
    .line 101
    .line 102
    monitor-enter v3

    .line 103
    :try_start_0
    iput-object p3, v3, LlI1I1;->yON3x:Ltl0ll;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 104
    .line 105
    monitor-exit v3

    .line 106
    invoke-virtual {v1}, Lp1s;->YOD0()LOWU_k_;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    return-object p1

    .line 111
    :catchall_0
    move-exception p1

    .line 112
    :try_start_1
    monitor-exit v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 113
    throw p1

    .line 114
    :pswitch_0
    new-instance v0, LlACD;

    .line 115
    .line 116
    iget-object v1, p3, LdOD;->e8$mp_s$:Ljava/lang/String;

    .line 117
    .line 118
    invoke-direct {v0, p1, p2, v1}, LlACD;-><init>(LmSize8039;LmIndex9894;Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    new-instance p1, LB1Il;

    .line 122
    .line 123
    new-instance p2, LkGd_Gk_;

    .line 124
    .line 125
    const/4 v1, 0x4

    .line 126
    invoke-direct {p2, v1, p3}, LkGd_Gk_;-><init>(ILjava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    const/4 v1, 0x0

    .line 130
    const/4 v2, 0x0

    .line 131
    invoke-direct {p1, p2, v1, v2}, LB1Il;-><init>(LeAs;L_ìdp;I)V

    .line 132
    .line 133
    .line 134
    iget-object p2, p0, LgOffset1953;->POOl:LAO1Q;

    .line 135
    .line 136
    new-instance v1, Lp1s;

    .line 137
    .line 138
    iget-object v2, p2, LAO1Q;->rz__9J_:LiKey8287;

    .line 139
    .line 140
    iget-object p2, p2, LAO1Q;->POOl:LAO1Q;

    .line 141
    .line 142
    invoke-direct {v1, v2, p2, v0, p1}, Lp1s;-><init>(LiKey8287;LAO1Q;LlACD;LB1Il;)V

    .line 143
    .line 144
    .line 145
    iget-object p1, v1, Lp1s;->Qp_Hp$i_:LjPos3798;

    .line 146
    .line 147
    invoke-virtual {p1}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    check-cast p1, LnQO;

    .line 152
    .line 153
    new-instance p2, LisCount1918;

    .line 154
    .line 155
    iget-object v0, p3, LdOD;->waiBKÀ:Ljava/lang/Object;

    .line 156
    .line 157
    check-cast v0, LHòbXXM;

    .line 158
    .line 159
    const/4 v2, 0x0

    .line 160
    invoke-direct {p2, v2, v0}, LisCount1918;-><init>(ILjava/lang/Object;)V

    .line 161
    .line 162
    .line 163
    iget-object v0, p0, LgOffset1953;->rz__9J_:Ljava/util/concurrent/Executor;

    .line 164
    .line 165
    invoke-virtual {p1, p2, v0}, LHDl0DI;->eQOI(Ljava/lang/Object;Ljava/util/concurrent/Executor;)V

    .line 166
    .line 167
    .line 168
    iget-object p1, p3, LdOD;->rz__9J_:LhasValue4175;

    .line 169
    .line 170
    check-cast p1, LXài2oÙp;

    .line 171
    .line 172
    iget-object p2, v1, Lp1s;->Txy$$d_w$:LjPos3798;

    .line 173
    .line 174
    invoke-virtual {p2}, LjPos3798;->POOl()Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object p2

    .line 178
    check-cast p2, LisItem1109;

    .line 179
    .line 180
    invoke-virtual {p1, p2}, LXài2oÙp;->rYlq$Y(LyO;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v1}, Lp1s;->YOD0()LOWU_k_;

    .line 184
    .line 185
    .line 186
    move-result-object p1

    .line 187
    return-object p1

    .line 188
    nop

    .line 189
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
