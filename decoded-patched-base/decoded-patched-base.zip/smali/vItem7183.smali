.class public interface abstract LvItem7183;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract yàÒZ(Ljava/lang/Object;)Lorg/json/JSONObject;
.end method
