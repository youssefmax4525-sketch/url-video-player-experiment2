.class public interface abstract LwHH$Nh$;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract Qp_Hp$i_(I)V
.end method

.method public abstract waiBKÀ()V
.end method
