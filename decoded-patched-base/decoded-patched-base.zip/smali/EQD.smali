.class public final LEQD;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LcQ;


# instance fields
.field public final e8$mp_s$:Ljava/lang/Object;

.field public waiBKÀ:LisItem9853;


# direct methods
.method public constructor <init>(Ljava/lang/Object;LxCè;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LEQD;->e8$mp_s$:Ljava/lang/Object;

    .line 5
    .line 6
    iget-object p1, p2, LxCè;->valuI:LEma$E_S$;

    .line 7
    .line 8
    iput-object p1, p0, LEQD;->waiBKÀ:LisItem9853;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final POOl()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LEQD;->e8$mp_s$:Ljava/lang/Object;

    .line 2
    .line 3
    return-object v0
.end method

.method public final e8$mp_s$()LisItem9853;
    .locals 1

    .line 1
    iget-object v0, p0, LEQD;->waiBKÀ:LisItem9853;

    .line 2
    .line 3
    return-object v0
.end method
