.class public abstract Llliiiii;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LaZ$O$;
