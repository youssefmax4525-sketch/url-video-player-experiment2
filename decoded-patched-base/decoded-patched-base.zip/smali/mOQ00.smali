.class public final LmOQ00;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public JKEoÙX:I

.field public POOl:J

.field public e8$mp_s$:I

.field public final rz__9J_:Landroid/media/MediaCodec$CryptoInfo;

.field public waiBKÀ:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Landroid/media/MediaCodec$CryptoInfo;

    .line 5
    .line 6
    invoke-direct {v0}, Landroid/media/MediaCodec$CryptoInfo;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LmOQ00;->rz__9J_:Landroid/media/MediaCodec$CryptoInfo;

    .line 10
    .line 11
    return-void
.end method
