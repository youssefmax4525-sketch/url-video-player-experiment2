.class public final LMl;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LhasValue7753;
.implements LvD9$JN$;
.implements LD0l;
.implements Lul0I0;
.implements LnOffset3608;
.implements LlW$N_5$;
.implements LmOffset8880;
.implements LQ4a_k$2_;


# static fields
.field public static volatile Ialue:LMl;

.field public static kQy:I

.field public static pCXDYg:LMl;

.field public static final valuI:Ljava/lang/Object;


# instance fields
.field public iOffset934:Ljava/lang/Object;

.field public jPos3709:Ljava/lang/Object;

.field public vaIue:Ljava/lang/Object;

.field public final synthetic yON3x:I


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, LMl;->valuI:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(I)V
    .locals 0

    iput p1, p0, LMl;->yON3x:I

    sparse-switch p1, :sswitch_data_0

    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 42
    sget-object p1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 43
    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void

    .line 44
    :sswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    sget-object p1, LTa$A4$;->yàÒZ:LTa$A4$;

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void

    .line 45
    :sswitch_1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void

    .line 46
    :sswitch_2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    .line 47
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    .line 48
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void

    .line 49
    :sswitch_3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 50
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    .line 51
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void

    nop

    :sswitch_data_0
    .sparse-switch
        0x11 -> :sswitch_3
        0x13 -> :sswitch_2
        0x1b -> :sswitch_1
        0x1c -> :sswitch_0
    .end sparse-switch
.end method

.method public constructor <init>(LFqVIxJK;LqjA;)V
    .locals 1

    const/16 v0, 0x18

    iput v0, p0, LMl;->yON3x:I

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    new-instance v0, LAq$$_M$;

    invoke-direct {v0, p2}, LAq$$_M$;-><init>(LqjA;)V

    iput-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 9
    iget-object p1, p1, LFqVIxJK;->JKEoÙX:LkO;

    .line 10
    new-instance p2, LUY$5_W$;

    invoke-direct {p2, v0, p1}, LUY$5_W$;-><init>(LAq$$_M$;LkO;)V

    iput-object p2, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LMl;->yON3x:I

    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 22
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 23
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 24
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/app/PendingIntent;)V
    .locals 5

    const/4 v0, 0x0

    iput v0, p0, LMl;->yON3x:I

    .line 54
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 55
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    iput-object v1, p0, LMl;->iOffset934:Ljava/lang/Object;

    if-eqz p1, :cond_a

    .line 56
    const-string v1, "CastMediaSession"

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_9

    const/4 v1, 0x1

    .line 57
    const-string v2, "android.intent.action.MEDIA_BUTTON"

    if-nez p2, :cond_1

    .line 58
    sget p2, LmFS$8$;->waiBKÀ:I

    .line 59
    new-instance p2, Landroid/content/Intent;

    invoke-direct {p2, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 60
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 61
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    .line 62
    invoke-virtual {v3, p2, v0}, Landroid/content/pm/PackageManager;->queryBroadcastReceivers(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p2

    .line 63
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v3

    if-ne v3, v1, :cond_0

    .line 64
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/pm/ResolveInfo;

    .line 65
    new-instance v3, Landroid/content/ComponentName;

    iget-object p2, p2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v4, p2, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object p2, p2, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-direct {v3, v4, p2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    move-object p2, v3

    goto :goto_0

    .line 66
    :cond_0
    invoke-interface {p2}, Ljava/util/List;->size()I

    const/4 p2, 0x0

    :cond_1
    :goto_0
    if-eqz p2, :cond_3

    if-nez p3, :cond_3

    .line 67
    new-instance p3, Landroid/content/Intent;

    invoke-direct {p3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 68
    invoke-virtual {p3, p2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 69
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1f

    if-lt p2, v2, :cond_2

    const/high16 p2, 0x2000000

    goto :goto_1

    :cond_2
    const/4 p2, 0x0

    .line 70
    :goto_1
    invoke-static {p1, v0, p3, p2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object p3

    .line 71
    :cond_3
    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1d

    if-lt p2, v0, :cond_4

    .line 72
    new-instance p2, LtBKz;

    .line 73
    invoke-direct {p2, p1}, LrcDTìq;-><init>(Landroid/content/Context;)V

    .line 74
    iput-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    goto :goto_2

    :cond_4
    const/16 v0, 0x1c

    if-lt p2, v0, :cond_5

    .line 75
    new-instance p2, LvIQDO;

    .line 76
    invoke-direct {p2, p1}, LrcDTìq;-><init>(Landroid/content/Context;)V

    .line 77
    iput-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    goto :goto_2

    :cond_5
    const/16 v0, 0x16

    if-lt p2, v0, :cond_6

    .line 78
    new-instance p2, LvKey1265;

    .line 79
    invoke-direct {p2, p1}, LrcDTìq;-><init>(Landroid/content/Context;)V

    .line 80
    iput-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    goto :goto_2

    .line 81
    :cond_6
    new-instance p2, LrcDTìq;

    invoke-direct {p2, p1}, LrcDTìq;-><init>(Landroid/content/Context;)V

    iput-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 82
    :goto_2
    new-instance p2, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    if-eqz v0, :cond_7

    .line 83
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    goto :goto_3

    :cond_7
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    :goto_3
    invoke-direct {p2, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 84
    new-instance v0, LisIndex9911;

    .line 85
    invoke-direct {v0}, LfÙqYeh;-><init>()V

    .line 86
    invoke-virtual {p0, v0, p2}, LMl;->pCXDYg(LfÙqYeh;Landroid/os/Handler;)V

    .line 87
    iget-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    check-cast p2, LrcDTìq;

    .line 88
    iget-object p2, p2, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    invoke-virtual {p2, p3}, Landroid/media/session/MediaSession;->setMediaButtonReceiver(Landroid/app/PendingIntent;)V

    .line 89
    new-instance p2, LBqOjcA;

    invoke-direct {p2, p1, p0}, LBqOjcA;-><init>(Landroid/content/Context;LMl;)V

    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 90
    sget p2, LMl;->kQy:I

    if-nez p2, :cond_8

    .line 91
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/high16 p2, 0x43a00000    # 320.0f

    .line 92
    invoke-static {v1, p2, p1}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p1

    const/high16 p2, 0x3f000000    # 0.5f

    add-float/2addr p1, p2

    float-to-int p1, p1

    sput p1, LMl;->kQy:I

    :cond_8
    return-void

    .line 93
    :cond_9
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "tag must not be null or empty"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 94
    :cond_a
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string p2, "context must not be null"

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V
    .locals 1

    const/16 v0, 0x9

    iput v0, p0, LMl;->yON3x:I

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 14
    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/location/LocationManager;)V
    .locals 1

    const/16 v0, 0xa

    iput v0, p0, LMl;->yON3x:I

    .line 15
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    new-instance v0, LqYKA;

    .line 17
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 19
    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 20
    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;LxED$DU_3A$;)V
    .locals 1

    const/4 v0, 0x4

    iput v0, p0, LMl;->yON3x:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 4
    iget-object p1, p2, LxED$DU_3A$;->yON3x:Ljava/lang/String;

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lcom/google/android/gms/cast/CastDevice;LQG$A_lg$;)V
    .locals 1

    const/4 v0, 0x3

    iput v0, p0, LMl;->yON3x:I

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "CastDevice parameter cannot be null"

    invoke-static {v0, p1}, Lzl1;->Ialue(Ljava/lang/String;Ljava/lang/Object;)V

    .line 6
    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .locals 0

    .line 1
    iput p4, p0, LMl;->yON3x:I

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    iput-object p3, p0, LMl;->iOffset934:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V
    .locals 0

    .line 2
    iput p4, p0, LMl;->yON3x:I

    iput-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p3, p0, LMl;->jPos3709:Ljava/lang/Object;

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    iput p2, p0, LMl;->yON3x:I

    packed-switch p2, :pswitch_data_0

    .line 31
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 32
    new-instance p2, LBqOjcA;

    const/16 v0, 0x11

    const/4 v1, 0x0

    .line 33
    invoke-direct {p2, v0, v1}, LBqOjcA;-><init>(IZ)V

    .line 34
    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 35
    iput-object p2, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 36
    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    return-void

    .line 37
    :pswitch_0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p2, LtmpOffset9868;

    invoke-direct {p2}, LtmpOffset9868;-><init>()V

    invoke-virtual {p2, p1}, LtmpOffset9868;->rz__9J_(Ljava/lang/String;)V

    .line 38
    new-instance p1, LgItem9321;

    .line 39
    invoke-direct {p1, p2}, LgItem9321;-><init>(LtmpOffset9868;)V

    .line 40
    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    return-void

    :pswitch_data_0
    .packed-switch 0xd
        :pswitch_0
    .end packed-switch
.end method

.method public constructor <init>(Ljava/util/regex/Matcher;)V
    .locals 1

    const/4 v0, 0x6

    iput v0, p0, LMl;->yON3x:I

    .line 52
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 53
    new-instance p1, LqEMPÌzNQ;

    invoke-direct {p1, p0}, LqEMPÌzNQ;-><init>(LMl;)V

    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LsQze;LMl;)V
    .locals 1

    const/4 v0, 0x5

    iput v0, p0, LMl;->yON3x:I

    .line 95
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 96
    iput-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LuK$g8$;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LMl;->yON3x:I

    .line 25
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 26
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 27
    new-instance v0, Ls0ze;

    .line 28
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 29
    iput-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 30
    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LvD9$JN$;LYl7QÙ;)V
    .locals 1

    const/16 v0, 0xc

    iput v0, p0, LMl;->yON3x:I

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    new-instance p1, Landroid/util/SparseArray;

    invoke-direct {p1}, Landroid/util/SparseArray;-><init>()V

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LvSize8002;Ljava/util/List;)V
    .locals 1

    const/16 v0, 0x1a

    iput v0, p0, LMl;->yON3x:I

    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    iput-object p2, p0, LMl;->jPos3709:Ljava/lang/Object;

    sget-object p1, LqOOI;->waiBKÀ:LqOOI;

    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    return-void
.end method

.method public static Ialue(Landroid/content/Context;Landroid/util/AttributeSet;[II)LMl;
    .locals 2

    .line 1
    new-instance v0, LMl;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p0, p1, p2, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-direct {v0, p0, p1}, LMl;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method

.method public static jPos3709(Landroid/content/Context;)LMl;
    .locals 2

    .line 1
    sget-object v0, LMl;->Ialue:LMl;

    .line 2
    .line 3
    if-nez v0, :cond_1

    .line 4
    .line 5
    sget-object v0, LMl;->valuI:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_0
    sget-object v1, LMl;->Ialue:LMl;

    .line 9
    .line 10
    if-nez v1, :cond_0

    .line 11
    .line 12
    new-instance v1, LMl;

    .line 13
    .line 14
    invoke-direct {v1, p0}, LMl;-><init>(Landroid/content/Context;)V

    .line 15
    .line 16
    .line 17
    sput-object v1, LMl;->Ialue:LMl;

    .line 18
    .line 19
    goto :goto_0

    .line 20
    :catchall_0
    move-exception p0

    .line 21
    goto :goto_1

    .line 22
    :cond_0
    :goto_0
    monitor-exit v0

    .line 23
    goto :goto_2

    .line 24
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 25
    throw p0

    .line 26
    :cond_1
    :goto_2
    sget-object p0, LMl;->Ialue:LMl;

    .line 27
    .line 28
    return-object p0
.end method

.method public static final sKey6064(LnPos7306;)LMl;
    .locals 20

    .line 1
    new-instance v0, LlO;

    .line 2
    .line 3
    const/4 v1, 0x7

    .line 4
    invoke-direct {v0, v1}, LlO;-><init>(I)V

    .line 5
    .line 6
    .line 7
    iget-object v1, v0, LlO;->vaIue:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Ljava/util/ArrayList;

    .line 10
    .line 11
    new-instance v2, LtmpKey5795;

    .line 12
    .line 13
    move-object/from16 v3, p0

    .line 14
    .line 15
    invoke-direct {v2, v3}, LtmpKey5795;-><init>(LnPos7306;)V

    .line 16
    .line 17
    .line 18
    sget-object v3, LplQQD0;->gKey4112:LplQQD0;

    .line 19
    .line 20
    iput-object v3, v2, LtmpKey5795;->rz__9J_:LplQQD0;

    .line 21
    .line 22
    const/4 v4, 0x1

    .line 23
    iput-boolean v4, v2, LtmpKey5795;->e8$mp_s$:Z

    .line 24
    .line 25
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    const/4 v6, 0x0

    .line 30
    const/4 v7, 0x0

    .line 31
    :goto_0
    if-ge v7, v5, :cond_0

    .line 32
    .line 33
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v8

    .line 37
    add-int/lit8 v7, v7, 0x1

    .line 38
    .line 39
    check-cast v8, LtmpKey5795;

    .line 40
    .line 41
    iput-boolean v6, v8, LtmpKey5795;->e8$mp_s$:Z

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_0
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    iget-boolean v2, v0, LlO;->yON3x:Z

    .line 48
    .line 49
    if-nez v2, :cond_15

    .line 50
    .line 51
    iput-boolean v4, v0, LlO;->yON3x:Z

    .line 52
    .line 53
    invoke-static {}, LvSize8002;->Q1_f_()LKÙnnPUN;

    .line 54
    .line 55
    .line 56
    move-result-object v2

    .line 57
    new-instance v5, Ljava/util/ArrayList;

    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 60
    .line 61
    .line 62
    move-result v7

    .line 63
    invoke-direct {v5, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 64
    .line 65
    .line 66
    const/4 v7, 0x0

    .line 67
    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 68
    .line 69
    .line 70
    move-result v8

    .line 71
    add-int/lit8 v8, v8, -0x1

    .line 72
    .line 73
    if-ge v7, v8, :cond_3

    .line 74
    .line 75
    add-int/lit8 v8, v7, 0x1

    .line 76
    .line 77
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v7

    .line 81
    check-cast v7, LtmpKey5795;

    .line 82
    .line 83
    iget-object v7, v7, LtmpKey5795;->rz__9J_:LplQQD0;

    .line 84
    .line 85
    if-ne v7, v3, :cond_2

    .line 86
    .line 87
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    check-cast v7, LtmpKey5795;

    .line 92
    .line 93
    iget-object v7, v7, LtmpKey5795;->rz__9J_:LplQQD0;

    .line 94
    .line 95
    if-ne v7, v3, :cond_1

    .line 96
    .line 97
    goto :goto_2

    .line 98
    :cond_1
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 99
    .line 100
    const-string v1, "Entries with \'withRandomId()\' may only be followed by other entries with \'withRandomId()\'."

    .line 101
    .line 102
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    throw v0

    .line 106
    :cond_2
    :goto_2
    move v7, v8

    .line 107
    goto :goto_1

    .line 108
    :cond_3
    new-instance v7, Ljava/util/HashSet;

    .line 109
    .line 110
    invoke-direct {v7}, Ljava/util/HashSet;-><init>()V

    .line 111
    .line 112
    .line 113
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 114
    .line 115
    .line 116
    move-result v8

    .line 117
    const/4 v10, 0x0

    .line 118
    const/4 v11, 0x0

    .line 119
    :goto_3
    if-ge v11, v8, :cond_12

    .line 120
    .line 121
    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v12

    .line 125
    add-int/lit8 v11, v11, 0x1

    .line 126
    .line 127
    check-cast v12, LtmpKey5795;

    .line 128
    .line 129
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    iget-object v13, v12, LtmpKey5795;->waiBKÀ:LnPos7306;

    .line 133
    .line 134
    iget-object v14, v12, LtmpKey5795;->rz__9J_:LplQQD0;

    .line 135
    .line 136
    if-eqz v14, :cond_11

    .line 137
    .line 138
    const/16 p0, 0x0

    .line 139
    .line 140
    const/4 v6, 0x4

    .line 141
    if-ne v14, v3, :cond_7

    .line 142
    .line 143
    const/4 v14, 0x0

    .line 144
    :goto_4
    if-eqz v14, :cond_5

    .line 145
    .line 146
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    .line 148
    .line 149
    move-result-object v9

    .line 150
    invoke-virtual {v7, v9}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v9

    .line 154
    if-eqz v9, :cond_4

    .line 155
    .line 156
    goto :goto_6

    .line 157
    :cond_4
    :goto_5
    move-object/from16 v19, v1

    .line 158
    .line 159
    const/16 v18, 0x3

    .line 160
    .line 161
    goto :goto_8

    .line 162
    :cond_5
    :goto_6
    new-instance v9, Ljava/security/SecureRandom;

    .line 163
    .line 164
    invoke-direct {v9}, Ljava/security/SecureRandom;-><init>()V

    .line 165
    .line 166
    .line 167
    new-array v14, v6, [B

    .line 168
    .line 169
    const/16 v16, 0x0

    .line 170
    .line 171
    :goto_7
    if-nez v16, :cond_6

    .line 172
    .line 173
    invoke-virtual {v9, v14}, Ljava/security/SecureRandom;->nextBytes([B)V

    .line 174
    .line 175
    .line 176
    aget-byte v6, v14, p0

    .line 177
    .line 178
    and-int/lit16 v6, v6, 0xff

    .line 179
    .line 180
    const/16 v18, 0x3

    .line 181
    .line 182
    aget-byte v15, v14, v4

    .line 183
    .line 184
    and-int/lit16 v15, v15, 0xff

    .line 185
    .line 186
    const/16 v16, 0x2

    .line 187
    .line 188
    aget-byte v4, v14, v16

    .line 189
    .line 190
    and-int/lit16 v4, v4, 0xff

    .line 191
    .line 192
    move-object/from16 v19, v1

    .line 193
    .line 194
    aget-byte v1, v14, v18

    .line 195
    .line 196
    and-int/lit16 v1, v1, 0xff

    .line 197
    .line 198
    shl-int/lit8 v6, v6, 0x18

    .line 199
    .line 200
    shl-int/lit8 v15, v15, 0x10

    .line 201
    .line 202
    or-int/2addr v6, v15

    .line 203
    shl-int/lit8 v4, v4, 0x8

    .line 204
    .line 205
    or-int/2addr v4, v6

    .line 206
    or-int v16, v4, v1

    .line 207
    .line 208
    move-object/from16 v1, v19

    .line 209
    .line 210
    const/4 v4, 0x1

    .line 211
    const/4 v6, 0x4

    .line 212
    goto :goto_7

    .line 213
    :cond_6
    move/from16 v14, v16

    .line 214
    .line 215
    goto :goto_4

    .line 216
    :cond_7
    const/4 v14, 0x0

    .line 217
    goto :goto_5

    .line 218
    :goto_8
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 219
    .line 220
    .line 221
    move-result-object v1

    .line 222
    invoke-virtual {v7, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 223
    .line 224
    .line 225
    move-result v4

    .line 226
    if-nez v4, :cond_10

    .line 227
    .line 228
    invoke-virtual {v7, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 229
    .line 230
    .line 231
    invoke-virtual {v13}, LnPos7306;->e8$mp_s$()Z

    .line 232
    .line 233
    .line 234
    move-result v4

    .line 235
    const/4 v6, 0x1

    .line 236
    if-eq v6, v4, :cond_8

    .line 237
    .line 238
    const/4 v4, 0x0

    .line 239
    goto :goto_9

    .line 240
    :cond_8
    move-object v4, v1

    .line 241
    :goto_9
    sget-object v9, Lrne$j_Fu$;->waiBKÀ:Lrne$j_Fu$;

    .line 242
    .line 243
    invoke-virtual {v9, v13, v4}, Lrne$j_Fu$;->e8$mp_s$(LnPos7306;Ljava/lang/Integer;)LvB$7$;

    .line 244
    .line 245
    .line 246
    move-result-object v4

    .line 247
    new-instance v9, LIw$f$;

    .line 248
    .line 249
    sget-object v13, LwYm_BE$mL_;->jPos3709:LwYm_BE$mL_;

    .line 250
    .line 251
    invoke-direct {v9, v4}, LIw$f$;-><init>(LvB$7$;)V

    .line 252
    .line 253
    .line 254
    sget-object v15, LcM$gd_H2$;->waiBKÀ:LcM$gd_H2$;

    .line 255
    .line 256
    invoke-virtual {v15, v4}, LcM$gd_H2$;->rz__9J_(LvB$7$;)LHA9$F1$;

    .line 257
    .line 258
    .line 259
    move-result-object v4

    .line 260
    check-cast v4, LBDO;

    .line 261
    .line 262
    iget-object v15, v4, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 263
    .line 264
    if-eqz v15, :cond_a

    .line 265
    .line 266
    invoke-virtual {v15}, Ljava/lang/Integer;->intValue()I

    .line 267
    .line 268
    .line 269
    move-result v15

    .line 270
    if-ne v15, v14, :cond_9

    .line 271
    .line 272
    goto :goto_a

    .line 273
    :cond_9
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 274
    .line 275
    const-string v1, "Wrong ID set for key with ID requirement"

    .line 276
    .line 277
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 278
    .line 279
    .line 280
    throw v0

    .line 281
    :cond_a
    :goto_a
    invoke-virtual {v13, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 282
    .line 283
    .line 284
    move-result v15

    .line 285
    if-eqz v15, :cond_b

    .line 286
    .line 287
    const/4 v15, 0x3

    .line 288
    goto :goto_b

    .line 289
    :cond_b
    sget-object v15, LwYm_BE$mL_;->iOffset934:LwYm_BE$mL_;

    .line 290
    .line 291
    invoke-virtual {v15, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    move-result v15

    .line 295
    if-eqz v15, :cond_c

    .line 296
    .line 297
    const/4 v15, 0x4

    .line 298
    goto :goto_b

    .line 299
    :cond_c
    sget-object v15, LwYm_BE$mL_;->kQy:LwYm_BE$mL_;

    .line 300
    .line 301
    invoke-virtual {v15, v13}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    move-result v13

    .line 305
    if-eqz v13, :cond_f

    .line 306
    .line 307
    const/4 v15, 0x5

    .line 308
    :goto_b
    invoke-static {}, LG1QDD;->Q1_f_()LnòvmCm;

    .line 309
    .line 310
    .line 311
    move-result-object v13

    .line 312
    invoke-static {}, LcB_9A$V_;->kCount1402()Ld3w_Tj$C_;

    .line 313
    .line 314
    .line 315
    move-result-object v6

    .line 316
    move-object/from16 v16, v1

    .line 317
    .line 318
    iget-object v1, v4, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 319
    .line 320
    invoke-virtual {v6}, Lw1I;->POOl()V

    .line 321
    .line 322
    .line 323
    move-object/from16 v17, v3

    .line 324
    .line 325
    iget-object v3, v6, Lw1I;->vaIue:LHU$B$;

    .line 326
    .line 327
    check-cast v3, LcB_9A$V_;

    .line 328
    .line 329
    invoke-static {v3, v1}, LcB_9A$V_;->ll(LcB_9A$V_;Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    iget-object v1, v4, LBDO;->rz__9J_:Lll11I;

    .line 333
    .line 334
    invoke-virtual {v6}, Lw1I;->POOl()V

    .line 335
    .line 336
    .line 337
    iget-object v3, v6, Lw1I;->vaIue:LHU$B$;

    .line 338
    .line 339
    check-cast v3, LcB_9A$V_;

    .line 340
    .line 341
    invoke-static {v3, v1}, LcB_9A$V_;->oy_R$Xx_(LcB_9A$V_;Lll11I;)V

    .line 342
    .line 343
    .line 344
    iget v1, v4, LBDO;->POOl:I

    .line 345
    .line 346
    invoke-virtual {v6}, Lw1I;->POOl()V

    .line 347
    .line 348
    .line 349
    iget-object v3, v6, Lw1I;->vaIue:LHU$B$;

    .line 350
    .line 351
    check-cast v3, LcB_9A$V_;

    .line 352
    .line 353
    invoke-static {v3, v1}, LcB_9A$V_;->tzKù7Ol1(LcB_9A$V_;I)V

    .line 354
    .line 355
    .line 356
    invoke-virtual {v13}, Lw1I;->POOl()V

    .line 357
    .line 358
    .line 359
    iget-object v1, v13, Lw1I;->vaIue:LHU$B$;

    .line 360
    .line 361
    check-cast v1, LG1QDD;

    .line 362
    .line 363
    invoke-virtual {v6}, Lw1I;->waiBKÀ()LHU$B$;

    .line 364
    .line 365
    .line 366
    move-result-object v3

    .line 367
    check-cast v3, LcB_9A$V_;

    .line 368
    .line 369
    invoke-static {v1, v3}, LG1QDD;->sKey6064(LG1QDD;LcB_9A$V_;)V

    .line 370
    .line 371
    .line 372
    invoke-virtual {v13}, Lw1I;->POOl()V

    .line 373
    .line 374
    .line 375
    iget-object v1, v13, Lw1I;->vaIue:LHU$B$;

    .line 376
    .line 377
    check-cast v1, LG1QDD;

    .line 378
    .line 379
    invoke-static {v1, v15}, LG1QDD;->Oey(LG1QDD;I)V

    .line 380
    .line 381
    .line 382
    invoke-virtual {v13}, Lw1I;->POOl()V

    .line 383
    .line 384
    .line 385
    iget-object v1, v13, Lw1I;->vaIue:LHU$B$;

    .line 386
    .line 387
    check-cast v1, LG1QDD;

    .line 388
    .line 389
    invoke-static {v1, v14}, LG1QDD;->tzKù7Ol1(LG1QDD;I)V

    .line 390
    .line 391
    .line 392
    iget-object v1, v4, LBDO;->JKEoÙX:Lkòè;

    .line 393
    .line 394
    invoke-virtual {v13}, Lw1I;->POOl()V

    .line 395
    .line 396
    .line 397
    iget-object v3, v13, Lw1I;->vaIue:LHU$B$;

    .line 398
    .line 399
    check-cast v3, LG1QDD;

    .line 400
    .line 401
    invoke-static {v3, v1}, LG1QDD;->ll(LG1QDD;Lkòè;)V

    .line 402
    .line 403
    .line 404
    invoke-virtual {v13}, Lw1I;->waiBKÀ()LHU$B$;

    .line 405
    .line 406
    .line 407
    move-result-object v1

    .line 408
    check-cast v1, LG1QDD;

    .line 409
    .line 410
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 411
    .line 412
    .line 413
    iget-object v3, v2, Lw1I;->vaIue:LHU$B$;

    .line 414
    .line 415
    check-cast v3, LvSize8002;

    .line 416
    .line 417
    invoke-static {v3, v1}, LvSize8002;->ll(LvSize8002;LG1QDD;)V

    .line 418
    .line 419
    .line 420
    iget-boolean v1, v12, LtmpKey5795;->e8$mp_s$:Z

    .line 421
    .line 422
    if-eqz v1, :cond_e

    .line 423
    .line 424
    if-nez v10, :cond_d

    .line 425
    .line 426
    move-object/from16 v10, v16

    .line 427
    .line 428
    goto :goto_c

    .line 429
    :cond_d
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 430
    .line 431
    const-string v1, "Two primaries were set"

    .line 432
    .line 433
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 434
    .line 435
    .line 436
    throw v0

    .line 437
    :cond_e
    :goto_c
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 438
    .line 439
    .line 440
    move-object/from16 v3, v17

    .line 441
    .line 442
    move-object/from16 v1, v19

    .line 443
    .line 444
    const/4 v4, 0x1

    .line 445
    const/4 v6, 0x0

    .line 446
    goto/16 :goto_3

    .line 447
    .line 448
    :cond_f
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 449
    .line 450
    const-string v1, "Unknown key status"

    .line 451
    .line 452
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 453
    .line 454
    .line 455
    throw v0

    .line 456
    :cond_10
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 457
    .line 458
    const-string v1, "Id "

    .line 459
    .line 460
    const-string v2, " is used twice in the keyset"

    .line 461
    .line 462
    invoke-static {v1, v14, v2}, LBRK_m_;->sKey7917(Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;

    .line 463
    .line 464
    .line 465
    move-result-object v1

    .line 466
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 467
    .line 468
    .line 469
    throw v0

    .line 470
    :cond_11
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 471
    .line 472
    const-string v1, "No ID was set (with withFixedId or withRandomId)"

    .line 473
    .line 474
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 475
    .line 476
    .line 477
    throw v0

    .line 478
    :cond_12
    if-eqz v10, :cond_14

    .line 479
    .line 480
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 481
    .line 482
    .line 483
    move-result v1

    .line 484
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 485
    .line 486
    .line 487
    iget-object v3, v2, Lw1I;->vaIue:LHU$B$;

    .line 488
    .line 489
    check-cast v3, LvSize8002;

    .line 490
    .line 491
    invoke-static {v3, v1}, LvSize8002;->oy_R$Xx_(LvSize8002;I)V

    .line 492
    .line 493
    .line 494
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    .line 495
    .line 496
    .line 497
    move-result-object v1

    .line 498
    check-cast v1, LvSize8002;

    .line 499
    .line 500
    invoke-virtual {v1}, LvSize8002;->kCount1402()I

    .line 501
    .line 502
    .line 503
    move-result v2

    .line 504
    if-lez v2, :cond_13

    .line 505
    .line 506
    iget-object v0, v0, LlO;->jPos3709:Ljava/lang/Object;

    .line 507
    .line 508
    check-cast v0, LqOOI;

    .line 509
    .line 510
    new-instance v2, LMl;

    .line 511
    .line 512
    const/16 v3, 0x1a

    .line 513
    .line 514
    invoke-direct {v2, v1, v5, v0, v3}, LMl;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 515
    .line 516
    .line 517
    return-object v2

    .line 518
    :cond_13
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 519
    .line 520
    const-string v1, "empty keyset"

    .line 521
    .line 522
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 523
    .line 524
    .line 525
    throw v0

    .line 526
    :cond_14
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 527
    .line 528
    const-string v1, "No primary was set"

    .line 529
    .line 530
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 531
    .line 532
    .line 533
    throw v0

    .line 534
    :cond_15
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 535
    .line 536
    const-string v1, "KeysetHandle.Builder#build must only be called once"

    .line 537
    .line 538
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 539
    .line 540
    .line 541
    throw v0
.end method

.method public static tmpData3485(Landroid/os/Bundle;)V
    .locals 1

    .line 1
    if-eqz p0, :cond_0

    .line 2
    .line 3
    const-class v0, LMl;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p0, v0}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void
.end method


# virtual methods
.method public $ÒcdS(I)V
    .locals 3

    .line 1
    const/16 v0, 0x10

    .line 2
    .line 3
    if-eq p1, v0, :cond_1

    .line 4
    .line 5
    const/16 v0, 0x20

    .line 6
    .line 7
    if-ne p1, v0, :cond_0

    .line 8
    .line 9
    goto :goto_0

    .line 10
    :cond_0
    mul-int/lit8 p1, p1, 0x8

    .line 11
    .line 12
    new-instance v0, Ljava/security/InvalidAlgorithmParameterException;

    .line 13
    .line 14
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    const/4 v1, 0x1

    .line 19
    new-array v1, v1, [Ljava/lang/Object;

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    aput-object p1, v1, v2

    .line 23
    .line 24
    const-string p1, "Invalid key size %d; only 128-bit and 256-bit AES keys are supported"

    .line 25
    .line 26
    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    invoke-direct {v0, p1}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    throw v0

    .line 34
    :cond_1
    :goto_0
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 35
    .line 36
    .line 37
    move-result-object p1

    .line 38
    iput-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 39
    .line 40
    return-void
.end method

.method public DDù8(I)Landroid/graphics/drawable/Drawable;
    .locals 2

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    iget-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p1, Landroid/content/Context;

    .line 21
    .line 22
    invoke-static {p1, v1}, LQ6$k$;->iOffset934(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    return-object p1

    .line 27
    :cond_0
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 28
    .line 29
    .line 30
    move-result-object p1

    .line 31
    return-object p1
.end method

.method public JKEoÙX(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;
    .locals 5

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashMap;

    .line 4
    .line 5
    const-string v1, "Cannot initialize "

    .line 6
    .line 7
    invoke-static {}, Lzl1;->K0I()Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eqz v2, :cond_0

    .line 12
    .line 13
    :try_start_0
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {v2}, Lzl1;->tmpData3485(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :catchall_0
    move-exception p1

    .line 22
    goto/16 :goto_4

    .line 23
    .line 24
    :cond_0
    :goto_0
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-nez v2, :cond_4

    .line 29
    .line 30
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-nez v1, :cond_3

    .line 35
    .line 36
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 37
    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    :try_start_1
    invoke-virtual {p1, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v2, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    check-cast v1, LmIndex4824;

    .line 49
    .line 50
    invoke-interface {v1}, LmIndex4824;->e8$mp_s$()Ljava/util/List;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-nez v3, :cond_2

    .line 59
    .line 60
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    :cond_1
    :goto_1
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-eqz v3, :cond_2

    .line 69
    .line 70
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    check-cast v3, Ljava/lang/Class;

    .line 75
    .line 76
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    if-nez v4, :cond_1

    .line 81
    .line 82
    invoke-virtual {p0, v3, p2}, LMl;->JKEoÙX(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    goto :goto_1

    .line 86
    :catchall_1
    move-exception p1

    .line 87
    goto :goto_2

    .line 88
    :cond_2
    iget-object v2, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 89
    .line 90
    check-cast v2, Landroid/content/Context;

    .line 91
    .line 92
    invoke-interface {v1, v2}, LmIndex4824;->waiBKÀ(Landroid/content/Context;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 100
    .line 101
    .line 102
    goto :goto_3

    .line 103
    :goto_2
    :try_start_2
    new-instance p2, LtemQ;

    .line 104
    .line 105
    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 106
    .line 107
    .line 108
    throw p2

    .line 109
    :cond_3
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 113
    :goto_3
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 114
    .line 115
    .line 116
    return-object v1

    .line 117
    :cond_4
    :try_start_3
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object p1

    .line 121
    new-instance p2, Ljava/lang/StringBuilder;

    .line 122
    .line 123
    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 127
    .line 128
    .line 129
    const-string p1, ". Cycle detected."

    .line 130
    .line 131
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object p1

    .line 138
    new-instance p2, Ljava/lang/IllegalStateException;

    .line 139
    .line 140
    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 141
    .line 142
    .line 143
    throw p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 144
    :goto_4
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 145
    .line 146
    .line 147
    throw p1
.end method

.method public K0I(LuK$g8$;)V
    .locals 9

    .line 1
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 6
    .line 7
    .line 8
    iget-object v1, p1, LuK$g8$;->vSize1911:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    const/4 v2, 0x0

    .line 15
    const/4 v3, 0x0

    .line 16
    :goto_0
    const/4 v4, 0x1

    .line 17
    if-ge v3, v1, :cond_2

    .line 18
    .line 19
    iget-object v5, p1, LuK$g8$;->vSize1911:Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v5

    .line 25
    check-cast v5, LiValue3289;

    .line 26
    .line 27
    iget-object v6, v5, LiValue3289;->IiI1iI:[I

    .line 28
    .line 29
    aget v7, v6, v2

    .line 30
    .line 31
    const/4 v8, 0x3

    .line 32
    if-eq v7, v8, :cond_0

    .line 33
    .line 34
    aget v4, v6, v4

    .line 35
    .line 36
    if-ne v4, v8, :cond_1

    .line 37
    .line 38
    :cond_0
    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_2
    iget-object p1, p1, LuK$g8$;->datI:LpXÙEPtòE;

    .line 45
    .line 46
    iput-boolean v4, p1, LpXÙEPtòE;->e8$mp_s$:Z

    .line 47
    .line 48
    return-void
.end method

.method public Oey()LA_g_b$CS_;
    .locals 4

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/Integer;

    .line 4
    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Ljava/lang/Integer;

    .line 10
    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    new-instance v1, LA_g_b$CS_;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    iget-object v2, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v2, Ljava/lang/Integer;

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    iget-object v3, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast v3, LTa$A4$;

    .line 30
    .line 31
    invoke-direct {v1, v0, v2, v3}, LA_g_b$CS_;-><init>(IILTa$A4$;)V

    .line 32
    .line 33
    .line 34
    return-object v1

    .line 35
    :cond_0
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 36
    .line 37
    const-string v1, "tag size not set"

    .line 38
    .line 39
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v0

    .line 43
    :cond_1
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 44
    .line 45
    const-string v1, "key size not set"

    .line 46
    .line 47
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    throw v0
.end method

.method public POOl(Landroid/os/Bundle;)V
    .locals 6

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashSet;

    .line 4
    .line 5
    iget-object v1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroid/content/Context;

    .line 8
    .line 9
    sget v2, LUòBN2;->androidx_startup:I

    .line 10
    .line 11
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    if-eqz p1, :cond_2

    .line 16
    .line 17
    :try_start_0
    new-instance v2, Ljava/util/HashSet;

    .line 18
    .line 19
    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    :cond_0
    :goto_0
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_1

    .line 35
    .line 36
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    check-cast v4, Ljava/lang/String;

    .line 41
    .line 42
    const/4 v5, 0x0

    .line 43
    invoke-virtual {p1, v4, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 48
    .line 49
    .line 50
    move-result v5

    .line 51
    if-eqz v5, :cond_0

    .line 52
    .line 53
    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    const-class v5, LmIndex4824;

    .line 58
    .line 59
    invoke-virtual {v5, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    if-eqz v5, :cond_0

    .line 64
    .line 65
    invoke-virtual {v0, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 66
    .line 67
    .line 68
    goto :goto_0

    .line 69
    :catch_0
    move-exception p1

    .line 70
    goto :goto_2

    .line 71
    :cond_1
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 72
    .line 73
    .line 74
    move-result-object p1

    .line 75
    :goto_1
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    if-eqz v0, :cond_2

    .line 80
    .line 81
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    check-cast v0, Ljava/lang/Class;

    .line 86
    .line 87
    invoke-virtual {p0, v0, v2}, LMl;->JKEoÙX(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 88
    .line 89
    .line 90
    goto :goto_1

    .line 91
    :goto_2
    new-instance v0, LtemQ;

    .line 92
    .line 93
    invoke-direct {v0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 94
    .line 95
    .line 96
    throw v0

    .line 97
    :cond_2
    return-void
.end method

.method public Q1_f_(LkQQ;)V
    .locals 1

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LvD9$JN$;

    .line 4
    .line 5
    invoke-interface {v0, p1}, LvD9$JN$;->Q1_f_(LkQQ;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public Qp_Hp$i_()V
    .locals 1

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LvD9$JN$;

    .line 4
    .line 5
    invoke-interface {v0}, LvD9$JN$;->Qp_Hp$i_()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public UC_n_(Ljava/lang/Throwable;)V
    .locals 1

    .line 1
    iget-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LMzOj3;

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    invoke-interface {p1, v0}, LMzOj3;->sKey7917(Z)LMzOj3;

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, LsItem5086;

    .line 12
    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, LRuq$DE$;

    .line 18
    .line 19
    iget-object v0, v0, LRuq$DE$;->tmpData3485:LtmpPos3658;

    .line 20
    .line 21
    invoke-interface {p1}, LMzOj3;->valuI()LisPos9932;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    invoke-virtual {v0, p1}, LtmpPos3658;->waiBKÀ(LisPos9932;)V

    .line 26
    .line 27
    .line 28
    return-void

    .line 29
    :cond_0
    invoke-virtual {v0, p1}, LsItem5086;->e8$mp_s$(LMzOj3;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0}, LsItem5086;->DDù8()V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 8

    .line 1
    iget v0, p0, LMl;->yON3x:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    const/4 v2, 0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    packed-switch v0, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v0, Lk0l;

    .line 12
    .line 13
    iget-object v4, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v4, LXÌqIt;

    .line 16
    .line 17
    iget-object v5, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v5, Ljava/lang/String;

    .line 20
    .line 21
    check-cast p1, LJvo$aJ$;

    .line 22
    .line 23
    check-cast p2, LfiCÈÀ5;

    .line 24
    .line 25
    iget v0, v0, Lk0l;->gSy_FG$D_:I

    .line 26
    .line 27
    if-eq v0, v2, :cond_0

    .line 28
    .line 29
    const/4 v0, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const/4 v0, 0x0

    .line 32
    :goto_0
    const-string v6, "Not active connection"

    .line 33
    .line 34
    invoke-static {v6, v0}, Lzl1;->valuI(Ljava/lang/String;Z)V

    .line 35
    .line 36
    .line 37
    if-eqz v4, :cond_1

    .line 38
    .line 39
    iget-object v0, p1, Ly01I0I;->jPos3709:Landroid/content/Context;

    .line 40
    .line 41
    new-instance v0, LlII;

    .line 42
    .line 43
    invoke-direct {v0, v2, v1, v1, v3}, LlII;-><init>(ZIII)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p1}, Ly01I0I;->Qp_Hp$i_()Landroid/os/IInterface;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, LCdKmnà;

    .line 51
    .line 52
    new-instance v1, LllII;

    .line 53
    .line 54
    invoke-direct {v1, v0}, LllII;-><init>(LlII;)V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1}, LrEÈQD;->gc_$M_w2$()Landroid/os/Parcel;

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    invoke-virtual {v0, v5}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    invoke-static {v0, v1}, LWoaOàtYj;->rz__9J_(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    .line 65
    .line 66
    .line 67
    const/16 v1, 0xc

    .line 68
    .line 69
    invoke-virtual {p1, v0, v1}, LrEÈQD;->UEYOU(Landroid/os/Parcel;I)V

    .line 70
    .line 71
    .line 72
    :cond_1
    const/4 p1, 0x0

    .line 73
    invoke-virtual {p2, p1}, LfiCÈÀ5;->waiBKÀ(Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_0
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v0, Lk0l;

    .line 80
    .line 81
    iget-object v4, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 82
    .line 83
    check-cast v4, Ljava/lang/String;

    .line 84
    .line 85
    iget-object v5, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 86
    .line 87
    check-cast v5, LHU$s$;

    .line 88
    .line 89
    check-cast p1, LJvo$aJ$;

    .line 90
    .line 91
    check-cast p2, LfiCÈÀ5;

    .line 92
    .line 93
    sget-object v6, Lk0l;->iSize4906:LhiB_7$0y_;

    .line 94
    .line 95
    iget v6, v0, Lk0l;->gSy_FG$D_:I

    .line 96
    .line 97
    const/4 v7, 0x3

    .line 98
    if-ne v6, v7, :cond_2

    .line 99
    .line 100
    const/4 v6, 0x1

    .line 101
    goto :goto_1

    .line 102
    :cond_2
    const/4 v6, 0x0

    .line 103
    :goto_1
    const-string v7, "Not connected to device"

    .line 104
    .line 105
    invoke-static {v7, v6}, Lzl1;->valuI(Ljava/lang/String;Z)V

    .line 106
    .line 107
    .line 108
    iget-object v6, p1, Ly01I0I;->jPos3709:Landroid/content/Context;

    .line 109
    .line 110
    new-instance v6, LlII;

    .line 111
    .line 112
    invoke-direct {v6, v2, v1, v1, v3}, LlII;-><init>(ZIII)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {p1}, Ly01I0I;->Qp_Hp$i_()Landroid/os/IInterface;

    .line 116
    .line 117
    .line 118
    move-result-object p1

    .line 119
    check-cast p1, LCdKmnà;

    .line 120
    .line 121
    new-instance v1, LllII;

    .line 122
    .line 123
    invoke-direct {v1, v6}, LllII;-><init>(LlII;)V

    .line 124
    .line 125
    .line 126
    invoke-virtual {p1}, LrEÈQD;->gc_$M_w2$()Landroid/os/Parcel;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    invoke-virtual {v2, v4}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-static {v2, v5}, LWoaOàtYj;->rz__9J_(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    .line 134
    .line 135
    .line 136
    invoke-static {v2, v1}, LWoaOàtYj;->rz__9J_(Landroid/os/Parcel;Landroid/os/Parcelable;)V

    .line 137
    .line 138
    .line 139
    const/16 v1, 0xd

    .line 140
    .line 141
    invoke-virtual {p1, v2, v1}, LrEÈQD;->UEYOU(Landroid/os/Parcel;I)V

    .line 142
    .line 143
    .line 144
    iget-object p1, v0, Lk0l;->Q1_f_:Ljava/lang/Object;

    .line 145
    .line 146
    monitor-enter p1

    .line 147
    :try_start_0
    iget-object v1, v0, Lk0l;->UC_n_:LfiCÈÀ5;

    .line 148
    .line 149
    if-eqz v1, :cond_3

    .line 150
    .line 151
    const/16 v1, 0x9ad

    .line 152
    .line 153
    invoke-virtual {v0, v1}, Lk0l;->yON3x(I)V

    .line 154
    .line 155
    .line 156
    goto :goto_2

    .line 157
    :catchall_0
    move-exception p2

    .line 158
    goto :goto_3

    .line 159
    :cond_3
    :goto_2
    iput-object p2, v0, Lk0l;->UC_n_:LfiCÈÀ5;

    .line 160
    .line 161
    monitor-exit p1

    .line 162
    return-void

    .line 163
    :goto_3
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 164
    throw p2

    .line 165
    :pswitch_data_0
    .packed-switch 0xe
        :pswitch_0
    .end packed-switch
.end method

.method public e8$mp_s$()V
    .locals 3

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LMl;

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    iget-object v1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, LsQze;

    .line 10
    .line 11
    iget-object v1, v1, LsQze;->Ialue:LkSize6511;

    .line 12
    .line 13
    iget v1, v1, LkSize6511;->iOffset934:I

    .line 14
    .line 15
    iget-object v0, v0, LMl;->vaIue:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, LrcDTìq;

    .line 18
    .line 19
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    new-instance v2, Landroid/media/AudioAttributes$Builder;

    .line 23
    .line 24
    invoke-direct {v2}, Landroid/media/AudioAttributes$Builder;-><init>()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2, v1}, Landroid/media/AudioAttributes$Builder;->setLegacyStreamType(I)Landroid/media/AudioAttributes$Builder;

    .line 28
    .line 29
    .line 30
    iget-object v0, v0, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    .line 31
    .line 32
    invoke-virtual {v2}, Landroid/media/AudioAttributes$Builder;->build()Landroid/media/AudioAttributes;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    invoke-virtual {v0, v1}, Landroid/media/session/MediaSession;->setPlaybackToLocal(Landroid/media/AudioAttributes;)V

    .line 37
    .line 38
    .line 39
    const/4 v0, 0x0

    .line 40
    iput-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 41
    .line 42
    :cond_0
    return-void
.end method

.method public gKey4112(Landroid/support/v4/media/MediaMetadataCompat;)V
    .locals 3

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LrcDTìq;

    .line 4
    .line 5
    iput-object p1, v0, LrcDTìq;->sKey7917:Landroid/support/v4/media/MediaMetadataCompat;

    .line 6
    .line 7
    iget-object v0, v0, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    .line 8
    .line 9
    iget-object v1, p1, Landroid/support/v4/media/MediaMetadataCompat;->vaIue:Landroid/media/MediaMetadata;

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    const/4 v2, 0x0

    .line 18
    invoke-virtual {p1, v1, v2}, Landroid/support/v4/media/MediaMetadataCompat;->writeToParcel(Landroid/os/Parcel;I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1, v2}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 22
    .line 23
    .line 24
    sget-object v2, Landroid/media/MediaMetadata;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 25
    .line 26
    invoke-interface {v2, v1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    check-cast v2, Landroid/media/MediaMetadata;

    .line 31
    .line 32
    iput-object v2, p1, Landroid/support/v4/media/MediaMetadataCompat;->vaIue:Landroid/media/MediaMetadata;

    .line 33
    .line 34
    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    .line 35
    .line 36
    .line 37
    :cond_0
    iget-object p1, p1, Landroid/support/v4/media/MediaMetadataCompat;->vaIue:Landroid/media/MediaMetadata;

    .line 38
    .line 39
    invoke-virtual {v0, p1}, Landroid/media/session/MediaSession;->setMetadata(Landroid/media/MediaMetadata;)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public gc_$M_w2$(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public get()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LvOffset5624;

    .line 4
    .line 5
    invoke-interface {v0}, LvOffset5624;->get()Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Landroid/content/Context;

    .line 10
    .line 11
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, LvOffset5624;

    .line 14
    .line 15
    invoke-interface {v1}, LvOffset5624;->get()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, LjValue2770;

    .line 20
    .line 21
    iget-object v2, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v2, Lliq$$$;

    .line 24
    .line 25
    invoke-virtual {v2}, Lliq$$$;->get()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v2

    .line 29
    check-cast v2, LmC8$L_yP$;

    .line 30
    .line 31
    new-instance v3, LPX6$F_j$;

    .line 32
    .line 33
    invoke-direct {v3, v0, v1, v2}, LPX6$F_j$;-><init>(Landroid/content/Context;LjValue2770;LmC8$L_yP$;)V

    .line 34
    .line 35
    .line 36
    return-object v3
.end method

.method public iOffset934(ILPùIX;LiValue3289;)Z
    .locals 6

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ls0ze;

    .line 4
    .line 5
    iget-object v1, p3, LiValue3289;->IiI1iI:[I

    .line 6
    .line 7
    iget-object v2, p3, LiValue3289;->K0I:[I

    .line 8
    .line 9
    const/4 v3, 0x0

    .line 10
    aget v4, v1, v3

    .line 11
    .line 12
    iput v4, v0, Ls0ze;->e8$mp_s$:I

    .line 13
    .line 14
    const/4 v4, 0x1

    .line 15
    aget v1, v1, v4

    .line 16
    .line 17
    iput v1, v0, Ls0ze;->waiBKÀ:I

    .line 18
    .line 19
    invoke-virtual {p3}, LiValue3289;->yàÒZ()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    iput v1, v0, Ls0ze;->rz__9J_:I

    .line 24
    .line 25
    invoke-virtual {p3}, LiValue3289;->jPos3709()I

    .line 26
    .line 27
    .line 28
    move-result v1

    .line 29
    iput v1, v0, Ls0ze;->POOl:I

    .line 30
    .line 31
    iput-boolean v3, v0, Ls0ze;->yON3x:Z

    .line 32
    .line 33
    iput p1, v0, Ls0ze;->vaIue:I

    .line 34
    .line 35
    iget p1, v0, Ls0ze;->e8$mp_s$:I

    .line 36
    .line 37
    const/4 v1, 0x3

    .line 38
    if-ne p1, v1, :cond_0

    .line 39
    .line 40
    const/4 p1, 0x1

    .line 41
    goto :goto_0

    .line 42
    :cond_0
    const/4 p1, 0x0

    .line 43
    :goto_0
    iget v5, v0, Ls0ze;->waiBKÀ:I

    .line 44
    .line 45
    if-ne v5, v1, :cond_1

    .line 46
    .line 47
    const/4 v1, 0x1

    .line 48
    goto :goto_1

    .line 49
    :cond_1
    const/4 v1, 0x0

    .line 50
    :goto_1
    const/4 v5, 0x0

    .line 51
    if-eqz p1, :cond_2

    .line 52
    .line 53
    iget p1, p3, LiValue3289;->YOD0:F

    .line 54
    .line 55
    cmpl-float p1, p1, v5

    .line 56
    .line 57
    if-lez p1, :cond_2

    .line 58
    .line 59
    const/4 p1, 0x1

    .line 60
    goto :goto_2

    .line 61
    :cond_2
    const/4 p1, 0x0

    .line 62
    :goto_2
    if-eqz v1, :cond_3

    .line 63
    .line 64
    iget v1, p3, LiValue3289;->YOD0:F

    .line 65
    .line 66
    cmpl-float v1, v1, v5

    .line 67
    .line 68
    if-lez v1, :cond_3

    .line 69
    .line 70
    const/4 v1, 0x1

    .line 71
    goto :goto_3

    .line 72
    :cond_3
    const/4 v1, 0x0

    .line 73
    :goto_3
    const/4 v5, 0x4

    .line 74
    if-eqz p1, :cond_4

    .line 75
    .line 76
    aget p1, v2, v3

    .line 77
    .line 78
    if-ne p1, v5, :cond_4

    .line 79
    .line 80
    iput v4, v0, Ls0ze;->e8$mp_s$:I

    .line 81
    .line 82
    :cond_4
    if-eqz v1, :cond_5

    .line 83
    .line 84
    aget p1, v2, v4

    .line 85
    .line 86
    if-ne p1, v5, :cond_5

    .line 87
    .line 88
    iput v4, v0, Ls0ze;->waiBKÀ:I

    .line 89
    .line 90
    :cond_5
    invoke-virtual {p2, p3, v0}, LPùIX;->waiBKÀ(LiValue3289;Ls0ze;)V

    .line 91
    .line 92
    .line 93
    iget p1, v0, Ls0ze;->JKEoÙX:I

    .line 94
    .line 95
    invoke-virtual {p3, p1}, LiValue3289;->Txy$$d_w$(I)V

    .line 96
    .line 97
    .line 98
    iget p1, v0, Ls0ze;->tmpData3485:I

    .line 99
    .line 100
    invoke-virtual {p3, p1}, LiValue3289;->zAt$p(I)V

    .line 101
    .line 102
    .line 103
    iget-boolean p1, v0, Ls0ze;->DDù8:Z

    .line 104
    .line 105
    iput-boolean p1, p3, LiValue3289;->yPN$A_n$:Z

    .line 106
    .line 107
    iget p1, v0, Ls0ze;->sKey7917:I

    .line 108
    .line 109
    invoke-virtual {p3, p1}, LiValue3289;->pQ1Il(I)V

    .line 110
    .line 111
    .line 112
    iput v3, v0, Ls0ze;->vaIue:I

    .line 113
    .line 114
    iget-boolean p1, v0, Ls0ze;->yON3x:Z

    .line 115
    .line 116
    return p1
.end method

.method public iQ0D(Landroid/os/Bundle;)V
    .locals 8

    .line 1
    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p1, LlO;

    .line 4
    .line 5
    iget-object p1, p1, LlO;->jPos3709:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter p1

    .line 8
    :try_start_0
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LlO;

    .line 11
    .line 12
    iget-boolean v1, v0, LlO;->yON3x:Z

    .line 13
    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    monitor-exit p1

    .line 17
    return-void

    .line 18
    :catchall_0
    move-exception v0

    .line 19
    move-object v2, p0

    .line 20
    goto :goto_0

    .line 21
    :cond_0
    const/4 v1, 0x1

    .line 22
    iput-boolean v1, v0, LlO;->yON3x:Z

    .line 23
    .line 24
    iget-object v0, v0, LlO;->vaIue:Ljava/lang/Object;

    .line 25
    .line 26
    move-object v3, v0

    .line 27
    check-cast v3, LiItem1456;

    .line 28
    .line 29
    if-nez v3, :cond_1

    .line 30
    .line 31
    monitor-exit p1

    .line 32
    return-void

    .line 33
    :cond_1
    sget-object v0, LBòtZ;->e8$mp_s$:LgID0;

    .line 34
    .line 35
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 36
    .line 37
    move-object v4, v1

    .line 38
    check-cast v4, LjKey6026;

    .line 39
    .line 40
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 41
    .line 42
    move-object v5, v1

    .line 43
    check-cast v5, LlwD$W_R$;

    .line 44
    .line 45
    new-instance v1, Lpùà6J;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 46
    .line 47
    const/4 v6, 0x7

    .line 48
    const/4 v7, 0x0

    .line 49
    move-object v2, p0

    .line 50
    :try_start_1
    invoke-direct/range {v1 .. v7}, Lpùà6J;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0, v1}, LgID0;->rz__9J_(Ljava/lang/Runnable;)LeO;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    iget-object v1, v2, LMl;->jPos3709:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v1, LlwD$W_R$;

    .line 60
    .line 61
    new-instance v3, LynztM;

    .line 62
    .line 63
    const/16 v4, 0xd

    .line 64
    .line 65
    const/4 v5, 0x0

    .line 66
    invoke-direct {v3, v4, v1, v0, v5}, LynztM;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 67
    .line 68
    .line 69
    sget-object v0, LBòtZ;->sKey7917:LgID0;

    .line 70
    .line 71
    iget-object v1, v1, LHHH$Qf$;->yON3x:LmItem3213;

    .line 72
    .line 73
    invoke-virtual {v1, v3, v0}, LjPos3706;->e8$mp_s$(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 74
    .line 75
    .line 76
    monitor-exit p1

    .line 77
    return-void

    .line 78
    :catchall_1
    move-exception v0

    .line 79
    :goto_0
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 80
    throw v0
.end method

.method public kCount1402(II)LwÒJK;
    .locals 3

    .line 1
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/util/SparseArray;

    .line 4
    .line 5
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LvD9$JN$;

    .line 8
    .line 9
    const/4 v2, 0x3

    .line 10
    if-eq p2, v2, :cond_0

    .line 11
    .line 12
    invoke-interface {v1, p1, p2}, LvD9$JN$;->kCount1402(II)LwÒJK;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    return-object p1

    .line 17
    :cond_0
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p2

    .line 21
    check-cast p2, LQDDO;

    .line 22
    .line 23
    if-eqz p2, :cond_1

    .line 24
    .line 25
    return-object p2

    .line 26
    :cond_1
    new-instance p2, LQDDO;

    .line 27
    .line 28
    invoke-interface {v1, p1, v2}, LvD9$JN$;->kCount1402(II)LwÒJK;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    iget-object v2, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v2, LYl7QÙ;

    .line 35
    .line 36
    invoke-direct {p2, v1, v2}, LQDDO;-><init>(LwÒJK;LYl7QÙ;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0, p1, p2}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 40
    .line 41
    .line 42
    return-object p2
.end method

.method public kO_6X_(LuK$g8$;III)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget v0, p1, LiValue3289;->WoI_9_:I

    .line 5
    .line 6
    iget v1, p1, LiValue3289;->s$_D_:I

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    iput v2, p1, LiValue3289;->WoI_9_:I

    .line 10
    .line 11
    iput v2, p1, LiValue3289;->s$_D_:I

    .line 12
    .line 13
    invoke-virtual {p1, p3}, LiValue3289;->Txy$$d_w$(I)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1, p4}, LiValue3289;->zAt$p(I)V

    .line 17
    .line 18
    .line 19
    if-gez v0, :cond_0

    .line 20
    .line 21
    iput v2, p1, LiValue3289;->WoI_9_:I

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    iput v0, p1, LiValue3289;->WoI_9_:I

    .line 25
    .line 26
    :goto_0
    if-gez v1, :cond_1

    .line 27
    .line 28
    iput v2, p1, LiValue3289;->s$_D_:I

    .line 29
    .line 30
    goto :goto_1

    .line 31
    :cond_1
    iput v1, p1, LiValue3289;->s$_D_:I

    .line 32
    .line 33
    :goto_1
    iget-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p1, LuK$g8$;

    .line 36
    .line 37
    iput p2, p1, LuK$g8$;->mQQI:I

    .line 38
    .line 39
    invoke-virtual {p1}, LuK$g8$;->valu0()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public kQy(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    check-cast v0, LhasPos5367;

    move-object v2, p1

    check-cast v2, Landroid/database/sqlite/SQLiteDatabase;

    .line 1
    iget-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    move-object v4, p1

    check-cast v4, LgKey2061;

    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    move-object v3, p1

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    new-instance v1, LVW$Lu$;

    const/16 v5, 0x11

    const/4 v6, 0x0

    invoke-direct/range {v1 .. v6}, LVW$Lu$;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V

    iget-object p1, v0, LhasPos5367;->vaIue:LgOffset972;

    invoke-interface {p1, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 p1, 0x0

    return-object p1
.end method

.method public bridge synthetic kQy(Ljava/lang/Object;)V
    .locals 3

    .line 3
    check-cast p1, LisKey7282;

    const-string p1, "loadNewJavascriptEngine (success): Trying to acquire lock"

    .line 4
    invoke-static {p1}, LPJNypàa;->zAt$p(Ljava/lang/String;)V

    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    check-cast p1, LlY_c_;

    .line 5
    iget-object p1, p1, LlY_c_;->waiBKÀ:Ljava/lang/Object;

    .line 6
    monitor-enter p1

    :try_start_0
    const-string v0, "loadNewJavascriptEngine (success): Lock acquired"

    .line 7
    invoke-static {v0}, LPJNypàa;->zAt$p(Ljava/lang/String;)V

    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    check-cast v0, LlY_c_;

    const/4 v1, 0x0

    .line 8
    iput v1, v0, LlY_c_;->sKey7917:I

    .line 9
    iget-object v0, v0, LlY_c_;->tmpData3485:Ljava/lang/Object;

    check-cast v0, LkKey7335;

    if-eqz v0, :cond_0

    .line 10
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    check-cast v1, LkKey7335;

    if-eq v1, v0, :cond_0

    const-string v0, "New JS engine is loaded, marking previous one as destroyable."

    .line 11
    invoke-static {v0}, LPJNypàa;->zAt$p(Ljava/lang/String;)V

    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    check-cast v0, LlY_c_;

    .line 12
    iget-object v0, v0, LlY_c_;->tmpData3485:Ljava/lang/Object;

    check-cast v0, LkKey7335;

    .line 13
    invoke-virtual {v0}, LkKey7335;->K0I()V

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    :goto_0
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    check-cast v0, LlY_c_;

    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    check-cast v1, LkKey7335;

    .line 14
    iput-object v1, v0, LlY_c_;->tmpData3485:Ljava/lang/Object;

    .line 15
    sget-object v0, LeIP;->POOl:LvSize4545;

    invoke-virtual {v0}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    check-cast v0, LlY_c_;

    .line 16
    iget-object v0, v0, LlY_c_;->JKEoÙX:Ljava/lang/Object;

    check-cast v0, LtmpPos3658;

    if-eqz v0, :cond_1

    .line 17
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    check-cast v1, LMzOj3;

    const/4 v2, 0x1

    .line 18
    invoke-interface {v1, v2}, LMzOj3;->sKey7917(Z)LMzOj3;

    invoke-interface {v1}, LMzOj3;->valuI()LisPos9932;

    move-result-object v1

    invoke-virtual {v0, v1}, LtmpPos3658;->waiBKÀ(LisPos9932;)V

    .line 19
    :cond_1
    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-string p1, "loadNewJavascriptEngine (success): Lock released"

    .line 20
    invoke-static {p1}, LPJNypàa;->zAt$p(Ljava/lang/String;)V

    return-void

    .line 21
    :goto_1
    :try_start_1
    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v0
.end method

.method public ll(Ljava/lang/String;ILjava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashMap;

    .line 4
    .line 5
    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Ljava/util/HashMap;

    .line 11
    .line 12
    invoke-virtual {v0, p3, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 16
    .line 17
    .line 18
    move-result-object p2

    .line 19
    iget-object p3, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast p3, Ljava/util/HashMap;

    .line 22
    .line 23
    invoke-virtual {p3, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public oy_R$Xx_()Ljava/lang/Object;
    .locals 16

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    sget v0, LoM_a$AW_;->e8$mp_s$:I

    .line 4
    .line 5
    :try_start_0
    sget-object v2, LMTjJ5b;->waiBKÀ:LMTjJ5b;

    .line 6
    .line 7
    invoke-virtual {v2}, LMTjJ5b;->e8$mp_s$()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    move-result-object v2
    :try_end_0
    .catch Ljava/security/GeneralSecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 11
    goto :goto_0

    .line 12
    :catch_0
    nop

    .line 13
    const/4 v2, 0x0

    .line 14
    :goto_0
    const-class v3, Lfòei;

    .line 15
    .line 16
    const-string v4, "No wrapper found for "

    .line 17
    .line 18
    if-eqz v2, :cond_13

    .line 19
    .line 20
    iget-object v5, v1, LMl;->jPos3709:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v5, Ljava/util/List;

    .line 23
    .line 24
    sget v6, LcC5_XA$2Z_;->e8$mp_s$:I

    .line 25
    .line 26
    iget-object v6, v1, LMl;->vaIue:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v6, LvSize8002;

    .line 29
    .line 30
    invoke-virtual {v6}, LvSize8002;->$ÒcdS()I

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    invoke-virtual {v6}, LvSize8002;->tzKù7Ol1()LII1i;

    .line 35
    .line 36
    .line 37
    move-result-object v8

    .line 38
    invoke-interface {v8}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 39
    .line 40
    .line 41
    move-result-object v8

    .line 42
    const/4 v9, 0x1

    .line 43
    const/4 v10, 0x0

    .line 44
    const/4 v11, 0x0

    .line 45
    const/4 v12, 0x0

    .line 46
    const/4 v13, 0x1

    .line 47
    :cond_0
    :goto_1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 48
    .line 49
    .line 50
    move-result v14

    .line 51
    const/4 v15, 0x3

    .line 52
    if-eqz v14, :cond_7

    .line 53
    .line 54
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object v14

    .line 58
    check-cast v14, LG1QDD;

    .line 59
    .line 60
    invoke-virtual {v14}, LG1QDD;->yPN$A_n$()I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    if-ne v0, v15, :cond_0

    .line 65
    .line 66
    invoke-virtual {v14}, LG1QDD;->oy_R$Xx_()Z

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    if-eqz v0, :cond_6

    .line 71
    .line 72
    invoke-virtual {v14}, LG1QDD;->tmpSize211()Lkòè;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    sget-object v15, Lkòè;->vaIue:Lkòè;

    .line 77
    .line 78
    if-eq v0, v15, :cond_5

    .line 79
    .line 80
    invoke-virtual {v14}, LG1QDD;->yPN$A_n$()I

    .line 81
    .line 82
    .line 83
    move-result v0

    .line 84
    const/4 v15, 0x2

    .line 85
    if-eq v0, v15, :cond_4

    .line 86
    .line 87
    invoke-virtual {v14}, LG1QDD;->kCount1402()I

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    if-ne v0, v7, :cond_2

    .line 92
    .line 93
    if-nez v12, :cond_1

    .line 94
    .line 95
    const/4 v12, 0x1

    .line 96
    goto :goto_2

    .line 97
    :cond_1
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 98
    .line 99
    const-string v2, "keyset contains multiple primary keys"

    .line 100
    .line 101
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 102
    .line 103
    .line 104
    throw v0

    .line 105
    :cond_2
    :goto_2
    invoke-virtual {v14}, LG1QDD;->$ÒcdS()LcB_9A$V_;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    invoke-virtual {v0}, LcB_9A$V_;->$ÒcdS()I

    .line 110
    .line 111
    .line 112
    move-result v0

    .line 113
    const/4 v14, 0x4

    .line 114
    if-eq v0, v14, :cond_3

    .line 115
    .line 116
    const/4 v0, 0x0

    .line 117
    goto :goto_3

    .line 118
    :cond_3
    const/4 v0, 0x1

    .line 119
    :goto_3
    and-int/2addr v13, v0

    .line 120
    add-int/lit8 v11, v11, 0x1

    .line 121
    .line 122
    goto :goto_1

    .line 123
    :cond_4
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 124
    .line 125
    invoke-virtual {v14}, LG1QDD;->kCount1402()I

    .line 126
    .line 127
    .line 128
    move-result v2

    .line 129
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    new-array v3, v9, [Ljava/lang/Object;

    .line 134
    .line 135
    aput-object v2, v3, v10

    .line 136
    .line 137
    const-string v2, "key %d has unknown status"

    .line 138
    .line 139
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 144
    .line 145
    .line 146
    throw v0

    .line 147
    :cond_5
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 148
    .line 149
    invoke-virtual {v14}, LG1QDD;->kCount1402()I

    .line 150
    .line 151
    .line 152
    move-result v2

    .line 153
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    new-array v3, v9, [Ljava/lang/Object;

    .line 158
    .line 159
    aput-object v2, v3, v10

    .line 160
    .line 161
    const-string v2, "key %d has unknown prefix"

    .line 162
    .line 163
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object v2

    .line 167
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    throw v0

    .line 171
    :cond_6
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 172
    .line 173
    invoke-virtual {v14}, LG1QDD;->kCount1402()I

    .line 174
    .line 175
    .line 176
    move-result v2

    .line 177
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 178
    .line 179
    .line 180
    move-result-object v2

    .line 181
    new-array v3, v9, [Ljava/lang/Object;

    .line 182
    .line 183
    aput-object v2, v3, v10

    .line 184
    .line 185
    const-string v2, "key %d has no key data"

    .line 186
    .line 187
    invoke-static {v2, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object v2

    .line 191
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    throw v0

    .line 195
    :cond_7
    if-eqz v11, :cond_12

    .line 196
    .line 197
    if-nez v12, :cond_9

    .line 198
    .line 199
    if-eqz v13, :cond_8

    .line 200
    .line 201
    goto :goto_4

    .line 202
    :cond_8
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 203
    .line 204
    const-string v2, "keyset doesn\'t contain a valid primary key"

    .line 205
    .line 206
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    throw v0

    .line 210
    :cond_9
    :goto_4
    new-instance v0, LKkmORP;

    .line 211
    .line 212
    invoke-direct {v0, v2}, LKkmORP;-><init>(Ljava/lang/Class;)V

    .line 213
    .line 214
    .line 215
    iget-object v7, v1, LMl;->iOffset934:Ljava/lang/Object;

    .line 216
    .line 217
    check-cast v7, LqOOI;

    .line 218
    .line 219
    iget-object v8, v0, LKkmORP;->jPos3709:Ljava/lang/Object;

    .line 220
    .line 221
    check-cast v8, Ljava/util/HashMap;

    .line 222
    .line 223
    if-eqz v8, :cond_11

    .line 224
    .line 225
    iput-object v7, v0, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 226
    .line 227
    const/4 v7, 0x0

    .line 228
    :goto_5
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 229
    .line 230
    .line 231
    move-result v8

    .line 232
    if-ge v7, v8, :cond_d

    .line 233
    .line 234
    invoke-virtual {v6, v7}, LvSize8002;->tmpSize211(I)LG1QDD;

    .line 235
    .line 236
    .line 237
    move-result-object v8

    .line 238
    invoke-virtual {v8}, LG1QDD;->yPN$A_n$()I

    .line 239
    .line 240
    .line 241
    move-result v11

    .line 242
    if-ne v11, v15, :cond_c

    .line 243
    .line 244
    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 245
    .line 246
    .line 247
    move-result-object v11

    .line 248
    check-cast v11, LIw$f$;

    .line 249
    .line 250
    if-eqz v11, :cond_b

    .line 251
    .line 252
    iget-object v11, v11, LIw$f$;->e8$mp_s$:LvB$7$;

    .line 253
    .line 254
    :try_start_1
    sget-object v12, LMTjJ5b;->waiBKÀ:LMTjJ5b;

    .line 255
    .line 256
    invoke-virtual {v12, v11, v2}, LMTjJ5b;->waiBKÀ(LvB$7$;Ljava/lang/Class;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object v11
    :try_end_1
    .catch Ljava/security/GeneralSecurityException; {:try_start_1 .. :try_end_1} :catch_1

    .line 260
    invoke-virtual {v8}, LG1QDD;->kCount1402()I

    .line 261
    .line 262
    .line 263
    move-result v12

    .line 264
    invoke-virtual {v6}, LvSize8002;->$ÒcdS()I

    .line 265
    .line 266
    .line 267
    move-result v13

    .line 268
    if-ne v12, v13, :cond_a

    .line 269
    .line 270
    invoke-virtual {v0, v11, v8, v9}, LKkmORP;->sKey6064(Ljava/lang/Object;LG1QDD;Z)V

    .line 271
    .line 272
    .line 273
    goto :goto_6

    .line 274
    :cond_a
    invoke-virtual {v0, v11, v8, v10}, LKkmORP;->sKey6064(Ljava/lang/Object;LG1QDD;Z)V

    .line 275
    .line 276
    .line 277
    goto :goto_6

    .line 278
    :catch_1
    move-exception v0

    .line 279
    new-instance v3, Ljava/security/GeneralSecurityException;

    .line 280
    .line 281
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 282
    .line 283
    .line 284
    move-result-object v2

    .line 285
    invoke-virtual {v8}, LG1QDD;->$ÒcdS()LcB_9A$V_;

    .line 286
    .line 287
    .line 288
    move-result-object v4

    .line 289
    invoke-virtual {v4}, LcB_9A$V_;->sKey6064()Ljava/lang/String;

    .line 290
    .line 291
    .line 292
    move-result-object v4

    .line 293
    const-string v5, " for key of type "

    .line 294
    .line 295
    const-string v6, ", see https://developers.google.com/tink/faq/registration_errors"

    .line 296
    .line 297
    const-string v7, "Unable to get primitive "

    .line 298
    .line 299
    invoke-static {v7, v2, v5, v4, v6}, LBRK_m_;->vaIue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 300
    .line 301
    .line 302
    move-result-object v2

    .line 303
    invoke-direct {v3, v2, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 304
    .line 305
    .line 306
    throw v3

    .line 307
    :cond_b
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 308
    .line 309
    invoke-virtual {v8}, LG1QDD;->$ÒcdS()LcB_9A$V_;

    .line 310
    .line 311
    .line 312
    move-result-object v2

    .line 313
    invoke-virtual {v2}, LcB_9A$V_;->sKey6064()Ljava/lang/String;

    .line 314
    .line 315
    .line 316
    move-result-object v2

    .line 317
    new-instance v3, Ljava/lang/StringBuilder;

    .line 318
    .line 319
    const-string v4, "Key parsing of key with index "

    .line 320
    .line 321
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 322
    .line 323
    .line 324
    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 325
    .line 326
    .line 327
    const-string v4, " and type_url "

    .line 328
    .line 329
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 330
    .line 331
    .line 332
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 333
    .line 334
    .line 335
    const-string v2, " failed, unable to get primitive"

    .line 336
    .line 337
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 338
    .line 339
    .line 340
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 341
    .line 342
    .line 343
    move-result-object v2

    .line 344
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 345
    .line 346
    .line 347
    throw v0

    .line 348
    :cond_c
    :goto_6
    add-int/lit8 v7, v7, 0x1

    .line 349
    .line 350
    goto :goto_5

    .line 351
    :cond_d
    iget-object v2, v0, LKkmORP;->jPos3709:Ljava/lang/Object;

    .line 352
    .line 353
    check-cast v2, Ljava/util/HashMap;

    .line 354
    .line 355
    if-eqz v2, :cond_10

    .line 356
    .line 357
    new-instance v5, LsIndex9566;

    .line 358
    .line 359
    iget-object v6, v0, LKkmORP;->kQy:Ljava/lang/Object;

    .line 360
    .line 361
    check-cast v6, LEÒwkdìmIY;

    .line 362
    .line 363
    iget-object v7, v0, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 364
    .line 365
    check-cast v7, LqOOI;

    .line 366
    .line 367
    iget-object v8, v0, LKkmORP;->vaIue:Ljava/lang/Object;

    .line 368
    .line 369
    check-cast v8, Ljava/lang/Class;

    .line 370
    .line 371
    invoke-direct {v5, v2, v6, v7, v8}, LsIndex9566;-><init>(Ljava/util/Map;LEÒwkdìmIY;LqOOI;Ljava/lang/Class;)V

    .line 372
    .line 373
    .line 374
    const/4 v2, 0x0

    .line 375
    iput-object v2, v0, LKkmORP;->jPos3709:Ljava/lang/Object;

    .line 376
    .line 377
    sget v0, LoM_a$AW_;->e8$mp_s$:I

    .line 378
    .line 379
    sget-object v0, LMTjJ5b;->waiBKÀ:LMTjJ5b;

    .line 380
    .line 381
    iget-object v0, v0, LMTjJ5b;->e8$mp_s$:Ljava/util/concurrent/atomic/AtomicReference;

    .line 382
    .line 383
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 384
    .line 385
    .line 386
    move-result-object v0

    .line 387
    check-cast v0, LII1IlI;

    .line 388
    .line 389
    iget-object v0, v0, LII1IlI;->waiBKÀ:Ljava/util/HashMap;

    .line 390
    .line 391
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 392
    .line 393
    .line 394
    move-result v2

    .line 395
    if-eqz v2, :cond_f

    .line 396
    .line 397
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    move-result-object v0

    .line 401
    check-cast v0, LgPos7339;

    .line 402
    .line 403
    invoke-interface {v0}, LgPos7339;->e8$mp_s$()Ljava/lang/Class;

    .line 404
    .line 405
    .line 406
    move-result-object v2

    .line 407
    invoke-virtual {v8, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 408
    .line 409
    .line 410
    move-result v2

    .line 411
    if-eqz v2, :cond_e

    .line 412
    .line 413
    invoke-interface {v0}, LgPos7339;->e8$mp_s$()Ljava/lang/Class;

    .line 414
    .line 415
    .line 416
    move-result-object v2

    .line 417
    invoke-virtual {v2, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 418
    .line 419
    .line 420
    move-result v2

    .line 421
    if-eqz v2, :cond_e

    .line 422
    .line 423
    invoke-interface {v0, v5}, LgPos7339;->waiBKÀ(LsIndex9566;)Ljava/lang/Object;

    .line 424
    .line 425
    .line 426
    move-result-object v0

    .line 427
    return-object v0

    .line 428
    :cond_e
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 429
    .line 430
    const-string v2, "Input primitive type of the wrapper doesn\'t match the type of primitives in the provided PrimitiveSet"

    .line 431
    .line 432
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 433
    .line 434
    .line 435
    throw v0

    .line 436
    :cond_f
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 437
    .line 438
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 439
    .line 440
    .line 441
    move-result-object v2

    .line 442
    invoke-virtual {v4, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object v2

    .line 446
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 447
    .line 448
    .line 449
    throw v0

    .line 450
    :cond_10
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 451
    .line 452
    const-string v2, "build cannot be called twice"

    .line 453
    .line 454
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 455
    .line 456
    .line 457
    throw v0

    .line 458
    :cond_11
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 459
    .line 460
    const-string v2, "setAnnotations cannot be called after build"

    .line 461
    .line 462
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 463
    .line 464
    .line 465
    throw v0

    .line 466
    :cond_12
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 467
    .line 468
    const-string v2, "keyset must contain at least one ENABLED key"

    .line 469
    .line 470
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 471
    .line 472
    .line 473
    throw v0

    .line 474
    :cond_13
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 475
    .line 476
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 477
    .line 478
    .line 479
    move-result-object v2

    .line 480
    invoke-virtual {v4, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 481
    .line 482
    .line 483
    move-result-object v2

    .line 484
    invoke-direct {v0, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 485
    .line 486
    .line 487
    throw v0
.end method

.method public pCXDYg(LfÙqYeh;Landroid/os/Handler;)V
    .locals 1

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LrcDTìq;

    .line 4
    .line 5
    if-nez p1, :cond_0

    .line 6
    .line 7
    const/4 p1, 0x0

    .line 8
    invoke-virtual {v0, p1, p1}, LrcDTìq;->JKEoÙX(LfÙqYeh;Landroid/os/Handler;)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_0
    if-eqz p2, :cond_1

    .line 13
    .line 14
    goto :goto_0

    .line 15
    :cond_1
    new-instance p2, Landroid/os/Handler;

    .line 16
    .line 17
    invoke-direct {p2}, Landroid/os/Handler;-><init>()V

    .line 18
    .line 19
    .line 20
    :goto_0
    invoke-virtual {v0, p1, p2}, LrcDTìq;->JKEoÙX(LfÙqYeh;Landroid/os/Handler;)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public rz__9J_(Lq0;LvD9$JN$;LkKey9521;)V
    .locals 0

    .line 1
    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-virtual {p3}, LkKey9521;->e8$mp_s$()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p3}, LkKey9521;->waiBKÀ()V

    .line 7
    .line 8
    .line 9
    iget p1, p3, LkKey9521;->POOl:I

    .line 10
    .line 11
    const/4 p3, 0x5

    .line 12
    invoke-interface {p2, p1, p3}, LvD9$JN$;->kCount1402(II)LwÒJK;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 17
    .line 18
    iget-object p2, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p2, LgItem9321;

    .line 21
    .line 22
    invoke-interface {p1, p2}, LwÒJK;->e8$mp_s$(LgItem9321;)V

    .line 23
    .line 24
    .line 25
    return-void
.end method

.method public sKey7917(I)Landroid/content/res/ColorStateList;
    .locals 3

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_0

    .line 17
    .line 18
    iget-object v2, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v2, Landroid/content/Context;

    .line 21
    .line 22
    invoke-static {v2, v1}, LvData2646;->jPos3709(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 23
    .line 24
    .line 25
    move-result-object v1

    .line 26
    if-eqz v1, :cond_0

    .line 27
    .line 28
    return-object v1

    .line 29
    :cond_0
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    .line 30
    .line 31
    .line 32
    move-result-object p1

    .line 33
    return-object p1
.end method

.method public tmpSize211(Ljava/lang/String;DD)V
    .locals 9

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/ArrayList;

    .line 4
    .line 5
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/util/ArrayList;

    .line 8
    .line 9
    iget-object v2, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Ljava/util/ArrayList;

    .line 12
    .line 13
    const/4 v3, 0x0

    .line 14
    :goto_0
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 15
    .line 16
    .line 17
    move-result v4

    .line 18
    if-ge v3, v4, :cond_2

    .line 19
    .line 20
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    check-cast v4, Ljava/lang/Double;

    .line 25
    .line 26
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 27
    .line 28
    .line 29
    move-result-wide v4

    .line 30
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v6

    .line 34
    check-cast v6, Ljava/lang/Double;

    .line 35
    .line 36
    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    .line 37
    .line 38
    .line 39
    move-result-wide v6

    .line 40
    cmpg-double v8, p2, v4

    .line 41
    .line 42
    if-gez v8, :cond_0

    .line 43
    .line 44
    goto :goto_1

    .line 45
    :cond_0
    cmpl-double v8, v4, p2

    .line 46
    .line 47
    if-nez v8, :cond_1

    .line 48
    .line 49
    cmpg-double v4, p4, v6

    .line 50
    .line 51
    if-ltz v4, :cond_2

    .line 52
    .line 53
    :cond_1
    add-int/lit8 v3, v3, 0x1

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_2
    :goto_1
    invoke-virtual {v2, v3, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    invoke-virtual {v1, v3, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    invoke-static {p4, p5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 67
    .line 68
    .line 69
    move-result-object p1

    .line 70
    invoke-virtual {v0, v3, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 6

    .line 1
    iget v0, p0, LMl;->yON3x:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :sswitch_0
    sget v0, LcC5_XA$2Z_;->e8$mp_s$:I

    .line 12
    .line 13
    invoke-static {}, LQgV_C_;->kCount1402()LhasValue6424;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v1, LvSize8002;

    .line 20
    .line 21
    invoke-virtual {v1}, LvSize8002;->$ÒcdS()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 26
    .line 27
    .line 28
    iget-object v3, v0, Lw1I;->vaIue:LHU$B$;

    .line 29
    .line 30
    check-cast v3, LQgV_C_;

    .line 31
    .line 32
    invoke-static {v3, v2}, LQgV_C_;->Q1_f_(LQgV_C_;I)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {v1}, LvSize8002;->tzKù7Ol1()LII1i;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    :goto_0
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 44
    .line 45
    .line 46
    move-result v2

    .line 47
    if-eqz v2, :cond_0

    .line 48
    .line 49
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    check-cast v2, LG1QDD;

    .line 54
    .line 55
    invoke-static {}, LFF_74_;->kCount1402()LuT_i1_;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    invoke-virtual {v2}, LG1QDD;->$ÒcdS()LcB_9A$V_;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    invoke-virtual {v4}, LcB_9A$V_;->sKey6064()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v4

    .line 67
    invoke-virtual {v3}, Lw1I;->POOl()V

    .line 68
    .line 69
    .line 70
    iget-object v5, v3, Lw1I;->vaIue:LHU$B$;

    .line 71
    .line 72
    check-cast v5, LFF_74_;

    .line 73
    .line 74
    invoke-static {v5, v4}, LFF_74_;->tmpSize211(LFF_74_;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v2}, LG1QDD;->yPN$A_n$()I

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    invoke-virtual {v3}, Lw1I;->POOl()V

    .line 82
    .line 83
    .line 84
    iget-object v5, v3, Lw1I;->vaIue:LHU$B$;

    .line 85
    .line 86
    check-cast v5, LFF_74_;

    .line 87
    .line 88
    invoke-static {v5, v4}, LFF_74_;->sKey6064(LFF_74_;I)V

    .line 89
    .line 90
    .line 91
    invoke-virtual {v2}, LG1QDD;->tmpSize211()Lkòè;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    invoke-virtual {v3}, Lw1I;->POOl()V

    .line 96
    .line 97
    .line 98
    iget-object v5, v3, Lw1I;->vaIue:LHU$B$;

    .line 99
    .line 100
    check-cast v5, LFF_74_;

    .line 101
    .line 102
    invoke-static {v5, v4}, LFF_74_;->Q1_f_(LFF_74_;Lkòè;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v2}, LG1QDD;->kCount1402()I

    .line 106
    .line 107
    .line 108
    move-result v2

    .line 109
    invoke-virtual {v3}, Lw1I;->POOl()V

    .line 110
    .line 111
    .line 112
    iget-object v4, v3, Lw1I;->vaIue:LHU$B$;

    .line 113
    .line 114
    check-cast v4, LFF_74_;

    .line 115
    .line 116
    invoke-static {v4, v2}, LFF_74_;->$ÒcdS(LFF_74_;I)V

    .line 117
    .line 118
    .line 119
    invoke-virtual {v3}, Lw1I;->waiBKÀ()LHU$B$;

    .line 120
    .line 121
    .line 122
    move-result-object v2

    .line 123
    check-cast v2, LFF_74_;

    .line 124
    .line 125
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 126
    .line 127
    .line 128
    iget-object v3, v0, Lw1I;->vaIue:LHU$B$;

    .line 129
    .line 130
    check-cast v3, LQgV_C_;

    .line 131
    .line 132
    invoke-static {v3, v2}, LQgV_C_;->$ÒcdS(LQgV_C_;LFF_74_;)V

    .line 133
    .line 134
    .line 135
    goto :goto_0

    .line 136
    :cond_0
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    check-cast v0, LQgV_C_;

    .line 141
    .line 142
    invoke-virtual {v0}, LHU$B$;->toString()Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    return-object v0

    .line 147
    :sswitch_1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 148
    .line 149
    const/16 v1, 0x20

    .line 150
    .line 151
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 152
    .line 153
    .line 154
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 155
    .line 156
    check-cast v1, Ljava/lang/String;

    .line 157
    .line 158
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 159
    .line 160
    .line 161
    const/16 v1, 0x7b

    .line 162
    .line 163
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 164
    .line 165
    .line 166
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 167
    .line 168
    check-cast v1, LBqOjcA;

    .line 169
    .line 170
    iget-object v1, v1, LBqOjcA;->jPos3709:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast v1, LBqOjcA;

    .line 173
    .line 174
    const-string v2, ""

    .line 175
    .line 176
    :goto_1
    if-eqz v1, :cond_2

    .line 177
    .line 178
    iget-object v3, v1, LBqOjcA;->vaIue:Ljava/lang/Object;

    .line 179
    .line 180
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    if-eqz v3, :cond_1

    .line 184
    .line 185
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 186
    .line 187
    .line 188
    move-result-object v2

    .line 189
    invoke-virtual {v2}, Ljava/lang/Class;->isArray()Z

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    if-eqz v2, :cond_1

    .line 194
    .line 195
    const/4 v2, 0x1

    .line 196
    new-array v4, v2, [Ljava/lang/Object;

    .line 197
    .line 198
    const/4 v5, 0x0

    .line 199
    aput-object v3, v4, v5

    .line 200
    .line 201
    invoke-static {v4}, Ljava/util/Arrays;->deepToString([Ljava/lang/Object;)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object v3

    .line 205
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 206
    .line 207
    .line 208
    move-result v4

    .line 209
    sub-int/2addr v4, v2

    .line 210
    invoke-virtual {v0, v3, v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    .line 211
    .line 212
    .line 213
    goto :goto_2

    .line 214
    :cond_1
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 215
    .line 216
    .line 217
    :goto_2
    iget-object v1, v1, LBqOjcA;->jPos3709:Ljava/lang/Object;

    .line 218
    .line 219
    check-cast v1, LBqOjcA;

    .line 220
    .line 221
    const-string v2, ", "

    .line 222
    .line 223
    goto :goto_1

    .line 224
    :cond_2
    const/16 v1, 0x7d

    .line 225
    .line 226
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 227
    .line 228
    .line 229
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    return-object v0

    .line 234
    nop

    .line 235
    :sswitch_data_0
    .sparse-switch
        0x7 -> :sswitch_1
        0x1a -> :sswitch_0
    .end sparse-switch
.end method

.method public tzKù7Ol1(I)V
    .locals 2

    .line 1
    const/16 v0, 0xa

    .line 2
    .line 3
    if-lt p1, v0, :cond_0

    .line 4
    .line 5
    const/16 v0, 0x10

    .line 6
    .line 7
    if-gt p1, v0, :cond_0

    .line 8
    .line 9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    iput-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 14
    .line 15
    return-void

    .line 16
    :cond_0
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 17
    .line 18
    const-string v1, "Invalid tag size for AesCmacParameters: "

    .line 19
    .line 20
    invoke-static {p1, v1}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    invoke-direct {v0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    throw v0
.end method

.method public vaIue(IILxDJ$X3$;)Landroid/graphics/Typeface;
    .locals 9

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 7
    .line 8
    .line 9
    move-result v3

    .line 10
    if-nez v3, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast p1, Landroid/util/TypedValue;

    .line 16
    .line 17
    if-nez p1, :cond_1

    .line 18
    .line 19
    new-instance p1, Landroid/util/TypedValue;

    .line 20
    .line 21
    invoke-direct {p1}, Landroid/util/TypedValue;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 25
    .line 26
    :cond_1
    iget-object p1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 27
    .line 28
    move-object v2, p1

    .line 29
    check-cast v2, Landroid/content/Context;

    .line 30
    .line 31
    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 32
    .line 33
    move-object v4, p1

    .line 34
    check-cast v4, Landroid/util/TypedValue;

    .line 35
    .line 36
    sget-object p1, Lugq$nh_K$;->e8$mp_s$:Ljava/lang/ThreadLocal;

    .line 37
    .line 38
    invoke-virtual {v2}, Landroid/content/Context;->isRestricted()Z

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_2

    .line 43
    .line 44
    :goto_0
    const/4 p1, 0x0

    .line 45
    return-object p1

    .line 46
    :cond_2
    const/4 v7, 0x1

    .line 47
    const/4 v8, 0x0

    .line 48
    move v5, p2

    .line 49
    move-object v6, p3

    .line 50
    invoke-static/range {v2 .. v8}, Lugq$nh_K$;->waiBKÀ(Landroid/content/Context;ILandroid/util/TypedValue;ILQEHcu;ZZ)Landroid/graphics/Typeface;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    return-object p1
.end method

.method public valuI()V
    .locals 1

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public waiBKÀ(LYizKm;)V
    .locals 13

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lq0;

    .line 4
    .line 5
    invoke-static {v0}, LvItem3158;->po0(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    sget v0, LnPos2706;->e8$mp_s$:I

    .line 9
    .line 10
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 11
    .line 12
    move-object v1, v0

    .line 13
    check-cast v1, Lq0;

    .line 14
    .line 15
    monitor-enter v1

    .line 16
    :try_start_0
    iget-wide v2, v1, Lq0;->rz__9J_:J

    .line 17
    .line 18
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    cmp-long v0, v2, v4

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    iget-wide v6, v1, Lq0;->waiBKÀ:J

    .line 28
    .line 29
    add-long/2addr v2, v6

    .line 30
    :goto_0
    move-wide v7, v2

    .line 31
    goto :goto_1

    .line 32
    :catchall_0
    move-exception v0

    .line 33
    move-object p1, v0

    .line 34
    goto :goto_3

    .line 35
    :cond_0
    invoke-virtual {v1}, Lq0;->POOl()J

    .line 36
    .line 37
    .line 38
    move-result-wide v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    goto :goto_0

    .line 40
    :goto_1
    monitor-exit v1

    .line 41
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Lq0;

    .line 44
    .line 45
    invoke-virtual {v0}, Lq0;->JKEoÙX()J

    .line 46
    .line 47
    .line 48
    move-result-wide v0

    .line 49
    cmp-long v2, v7, v4

    .line 50
    .line 51
    if-eqz v2, :cond_3

    .line 52
    .line 53
    cmp-long v2, v0, v4

    .line 54
    .line 55
    if-nez v2, :cond_1

    .line 56
    .line 57
    goto :goto_2

    .line 58
    :cond_1
    iget-object v2, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 59
    .line 60
    check-cast v2, LgItem9321;

    .line 61
    .line 62
    iget-wide v3, v2, LgItem9321;->gKey4112:J

    .line 63
    .line 64
    cmp-long v5, v0, v3

    .line 65
    .line 66
    if-eqz v5, :cond_2

    .line 67
    .line 68
    new-instance v3, LtmpOffset9868;

    .line 69
    .line 70
    invoke-direct {v3, v2}, LtmpOffset9868;-><init>(LgItem9321;)V

    .line 71
    .line 72
    .line 73
    iput-wide v0, v3, LtmpOffset9868;->yàÒZ:J

    .line 74
    .line 75
    new-instance v0, LgItem9321;

    .line 76
    .line 77
    invoke-direct {v0, v3}, LgItem9321;-><init>(LtmpOffset9868;)V

    .line 78
    .line 79
    .line 80
    iput-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 81
    .line 82
    iget-object v1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 83
    .line 84
    check-cast v1, LwÒJK;

    .line 85
    .line 86
    invoke-interface {v1, v0}, LwÒJK;->e8$mp_s$(LgItem9321;)V

    .line 87
    .line 88
    .line 89
    :cond_2
    invoke-virtual {p1}, LYizKm;->valuI()I

    .line 90
    .line 91
    .line 92
    move-result v10

    .line 93
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 94
    .line 95
    check-cast v0, LwÒJK;

    .line 96
    .line 97
    invoke-interface {v0, v10, p1}, LwÒJK;->JKEoÙX(ILYizKm;)V

    .line 98
    .line 99
    .line 100
    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 101
    .line 102
    move-object v6, p1

    .line 103
    check-cast v6, LwÒJK;

    .line 104
    .line 105
    const/4 v11, 0x0

    .line 106
    const/4 v12, 0x0

    .line 107
    const/4 v9, 0x1

    .line 108
    invoke-interface/range {v6 .. v12}, LwÒJK;->waiBKÀ(JIIILlF_um_;)V

    .line 109
    .line 110
    .line 111
    :cond_3
    :goto_2
    return-void

    .line 112
    :goto_3
    :try_start_1
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 113
    throw p1
.end method

.method public yON3x(I)Landroid/graphics/drawable/Drawable;
    .locals 4

    .line 1
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    iget-object v0, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Landroid/content/res/TypedArray;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    if-eqz p1, :cond_0

    .line 21
    .line 22
    invoke-static {}, LJNg_p_;->e8$mp_s$()LJNg_p_;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, Landroid/content/Context;

    .line 29
    .line 30
    monitor-enter v0

    .line 31
    :try_start_0
    iget-object v2, v0, LJNg_p_;->e8$mp_s$:LqaNsÒB;

    .line 32
    .line 33
    const/4 v3, 0x1

    .line 34
    invoke-virtual {v2, v1, p1, v3}, LqaNsÒB;->sKey7917(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    .line 35
    .line 36
    .line 37
    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 38
    monitor-exit v0

    .line 39
    return-object p1

    .line 40
    :catchall_0
    move-exception p1

    .line 41
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 42
    throw p1

    .line 43
    :cond_0
    const/4 p1, 0x0

    .line 44
    return-object p1
.end method

.method public yPN$A_n$()LCBUP;
    .locals 5

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LhasKey8276;

    .line 4
    .line 5
    if-eqz v0, :cond_8

    .line 6
    .line 7
    iget-object v1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, LkGd_Gk_;

    .line 10
    .line 11
    if-eqz v1, :cond_8

    .line 12
    .line 13
    iget v2, v0, LhasKey8276;->e8$mp_s$:I

    .line 14
    .line 15
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v1, LrlI;

    .line 18
    .line 19
    iget-object v1, v1, LrlI;->e8$mp_s$:[B

    .line 20
    .line 21
    array-length v1, v1

    .line 22
    if-ne v2, v1, :cond_7

    .line 23
    .line 24
    invoke-virtual {v0}, LhasKey8276;->e8$mp_s$()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_1

    .line 29
    .line 30
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 31
    .line 32
    check-cast v0, Ljava/lang/Integer;

    .line 33
    .line 34
    if-eqz v0, :cond_0

    .line 35
    .line 36
    goto :goto_0

    .line 37
    :cond_0
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 38
    .line 39
    const-string v1, "Cannot create key without ID requirement with parameters with ID requirement"

    .line 40
    .line 41
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v0

    .line 45
    :cond_1
    :goto_0
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v0, LhasKey8276;

    .line 48
    .line 49
    invoke-virtual {v0}, LhasKey8276;->e8$mp_s$()Z

    .line 50
    .line 51
    .line 52
    move-result v0

    .line 53
    if-nez v0, :cond_3

    .line 54
    .line 55
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v0, Ljava/lang/Integer;

    .line 58
    .line 59
    if-nez v0, :cond_2

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 63
    .line 64
    const-string v1, "Cannot create key with ID requirement with parameters without ID requirement"

    .line 65
    .line 66
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    throw v0

    .line 70
    :cond_3
    :goto_1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v0, LhasKey8276;

    .line 73
    .line 74
    iget-object v0, v0, LhasKey8276;->waiBKÀ:LTa$A4$;

    .line 75
    .line 76
    sget-object v1, LTa$A4$;->kQy:LTa$A4$;

    .line 77
    .line 78
    if-ne v0, v1, :cond_4

    .line 79
    .line 80
    sget-object v0, Lpm$Dd$;->e8$mp_s$:LrlI;

    .line 81
    .line 82
    goto :goto_2

    .line 83
    :cond_4
    sget-object v1, LTa$A4$;->iOffset934:LTa$A4$;

    .line 84
    .line 85
    if-ne v0, v1, :cond_5

    .line 86
    .line 87
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast v0, Ljava/lang/Integer;

    .line 90
    .line 91
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    invoke-static {v0}, Lpm$Dd$;->e8$mp_s$(I)LrlI;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    goto :goto_2

    .line 100
    :cond_5
    sget-object v1, LTa$A4$;->jPos3709:LTa$A4$;

    .line 101
    .line 102
    if-ne v0, v1, :cond_6

    .line 103
    .line 104
    iget-object v0, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v0, Ljava/lang/Integer;

    .line 107
    .line 108
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result v0

    .line 112
    invoke-static {v0}, Lpm$Dd$;->waiBKÀ(I)LrlI;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    :goto_2
    new-instance v1, LCBUP;

    .line 117
    .line 118
    iget-object v2, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 119
    .line 120
    check-cast v2, LhasKey8276;

    .line 121
    .line 122
    iget-object v3, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 123
    .line 124
    check-cast v3, LkGd_Gk_;

    .line 125
    .line 126
    iget-object v4, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 127
    .line 128
    check-cast v4, Ljava/lang/Integer;

    .line 129
    .line 130
    invoke-direct {v1, v2, v3, v0, v4}, LCBUP;-><init>(LhasKey8276;LkGd_Gk_;LrlI;Ljava/lang/Integer;)V

    .line 131
    .line 132
    .line 133
    return-object v1

    .line 134
    :cond_6
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 135
    .line 136
    iget-object v1, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v1, LhasKey8276;

    .line 139
    .line 140
    iget-object v1, v1, LhasKey8276;->waiBKÀ:LTa$A4$;

    .line 141
    .line 142
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 143
    .line 144
    .line 145
    move-result-object v1

    .line 146
    const-string v2, "Unknown AesGcmSivParameters.Variant: "

    .line 147
    .line 148
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 153
    .line 154
    .line 155
    throw v0

    .line 156
    :cond_7
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 157
    .line 158
    const-string v1, "Key size mismatch"

    .line 159
    .line 160
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    throw v0

    .line 164
    :cond_8
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 165
    .line 166
    const-string v1, "Cannot build without parameters and/or key material"

    .line 167
    .line 168
    invoke-direct {v0, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 169
    .line 170
    .line 171
    throw v0
.end method

.method public bridge synthetic yàÒZ(Ljava/lang/Object;)V
    .locals 2

    .line 1
    iget-object v0, p0, LMl;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, LMzOj3;

    .line 4
    .line 5
    check-cast p1, LqyYXftcJ;

    .line 6
    .line 7
    sget-object v1, LqyYXftcJ;->yON3x:LqyYXftcJ;

    .line 8
    .line 9
    if-ne p1, v1, :cond_0

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    :goto_0
    invoke-interface {v0, p1}, LMzOj3;->sKey7917(Z)LMzOj3;

    .line 15
    .line 16
    .line 17
    iget-object p1, p0, LMl;->jPos3709:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast p1, LsItem5086;

    .line 20
    .line 21
    if-nez p1, :cond_1

    .line 22
    .line 23
    iget-object p1, p0, LMl;->iOffset934:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast p1, LRuq$DE$;

    .line 26
    .line 27
    iget-object p1, p1, LRuq$DE$;->tmpData3485:LtmpPos3658;

    .line 28
    .line 29
    invoke-interface {v0}, LMzOj3;->valuI()LisPos9932;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-virtual {p1, v0}, LtmpPos3658;->waiBKÀ(LisPos9932;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :cond_1
    invoke-virtual {p1, v0}, LsItem5086;->e8$mp_s$(LMzOj3;)V

    .line 38
    .line 39
    .line 40
    invoke-virtual {p1}, LsItem5086;->DDù8()V

    .line 41
    .line 42
    .line 43
    return-void
.end method
