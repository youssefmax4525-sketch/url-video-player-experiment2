.class public final LNlCjcEùr;
.super LIiI1iI;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "LNlCjcE\u00f9r;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final vaIue:Ljava/lang/String;

.field public final yON3x:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LRpS$$j$;

    .line 2
    .line 3
    const/16 v1, 0x11

    .line 4
    .line 5
    invoke-direct {v0, v1}, LRpS$$j$;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LNlCjcEùr;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LNlCjcEùr;->yON3x:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, LNlCjcEùr;->vaIue:Ljava/lang/String;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    .line 1
    const/16 p2, 0x4f45

    .line 2
    .line 3
    invoke-static {p1, p2}, LdQta;->gCount1961(Landroid/os/Parcel;I)I

    .line 4
    .line 5
    .line 6
    move-result p2

    .line 7
    const/4 v0, 0x1

    .line 8
    iget-object v1, p0, LNlCjcEùr;->yON3x:Ljava/lang/String;

    .line 9
    .line 10
    invoke-static {p1, v0, v1}, LdQta;->gSy_FG$D_(Landroid/os/Parcel;ILjava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const/4 v0, 0x2

    .line 14
    iget-object v1, p0, LNlCjcEùr;->vaIue:Ljava/lang/String;

    .line 15
    .line 16
    invoke-static {p1, v0, v1}, LdQta;->gSy_FG$D_(Landroid/os/Parcel;ILjava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-static {p1, p2}, LdQta;->pZDcLvd(Landroid/os/Parcel;I)V

    .line 20
    .line 21
    .line 22
    return-void
.end method
