.class public final LTpPRs5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LgKey862;


# instance fields
.field public final Ialue:F

.field public final iOffset934:I

.field public final jPos3709:I

.field public final kQy:Ljava/lang/String;

.field public final vaIue:Z

.field public final valuI:I

.field public final yON3x:LYizKm;


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .locals 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, LYizKm;

    .line 5
    .line 6
    invoke-direct {v0}, LYizKm;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LTpPRs5;->yON3x:LYizKm;

    .line 10
    .line 11
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 12
    .line 13
    .line 14
    move-result v0

    .line 15
    const v1, 0x3f59999a    # 0.85f

    .line 16
    .line 17
    .line 18
    const-string v2, "sans-serif"

    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    const/4 v4, 0x1

    .line 22
    if-ne v0, v4, :cond_4

    .line 23
    .line 24
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    check-cast v0, [B

    .line 29
    .line 30
    array-length v0, v0

    .line 31
    const/16 v5, 0x30

    .line 32
    .line 33
    if-eq v0, v5, :cond_0

    .line 34
    .line 35
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    check-cast v0, [B

    .line 40
    .line 41
    array-length v0, v0

    .line 42
    const/16 v5, 0x35

    .line 43
    .line 44
    if-ne v0, v5, :cond_4

    .line 45
    .line 46
    :cond_0
    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    check-cast p1, [B

    .line 51
    .line 52
    const/16 v0, 0x18

    .line 53
    .line 54
    aget-byte v5, p1, v0

    .line 55
    .line 56
    iput v5, p0, LTpPRs5;->jPos3709:I

    .line 57
    .line 58
    const/16 v5, 0x1a

    .line 59
    .line 60
    aget-byte v5, p1, v5

    .line 61
    .line 62
    and-int/lit16 v5, v5, 0xff

    .line 63
    .line 64
    const/16 v6, 0x1b

    .line 65
    .line 66
    aget-byte v6, p1, v6

    .line 67
    .line 68
    and-int/lit16 v6, v6, 0xff

    .line 69
    .line 70
    const/16 v7, 0x1c

    .line 71
    .line 72
    aget-byte v7, p1, v7

    .line 73
    .line 74
    and-int/lit16 v7, v7, 0xff

    .line 75
    .line 76
    const/16 v8, 0x1d

    .line 77
    .line 78
    aget-byte v8, p1, v8

    .line 79
    .line 80
    and-int/lit16 v8, v8, 0xff

    .line 81
    .line 82
    shl-int/lit8 v0, v5, 0x18

    .line 83
    .line 84
    shl-int/lit8 v5, v6, 0x10

    .line 85
    .line 86
    or-int/2addr v0, v5

    .line 87
    shl-int/lit8 v5, v7, 0x8

    .line 88
    .line 89
    or-int/2addr v0, v5

    .line 90
    or-int/2addr v0, v8

    .line 91
    iput v0, p0, LTpPRs5;->iOffset934:I

    .line 92
    .line 93
    array-length v0, p1

    .line 94
    add-int/lit8 v0, v0, -0x2b

    .line 95
    .line 96
    new-instance v5, Ljava/lang/String;

    .line 97
    .line 98
    sget-object v6, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 99
    .line 100
    const/16 v7, 0x2b

    .line 101
    .line 102
    invoke-direct {v5, p1, v7, v0, v6}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 103
    .line 104
    .line 105
    const-string v0, "Serif"

    .line 106
    .line 107
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v0

    .line 111
    if-eq v4, v0, :cond_1

    .line 112
    .line 113
    goto :goto_0

    .line 114
    :cond_1
    const-string v2, "serif"

    .line 115
    .line 116
    :goto_0
    iput-object v2, p0, LTpPRs5;->kQy:Ljava/lang/String;

    .line 117
    .line 118
    const/16 v0, 0x19

    .line 119
    .line 120
    aget-byte v0, p1, v0

    .line 121
    .line 122
    mul-int/lit8 v0, v0, 0x14

    .line 123
    .line 124
    iput v0, p0, LTpPRs5;->valuI:I

    .line 125
    .line 126
    aget-byte v2, p1, v3

    .line 127
    .line 128
    and-int/lit8 v2, v2, 0x20

    .line 129
    .line 130
    if-eqz v2, :cond_2

    .line 131
    .line 132
    const/4 v3, 0x1

    .line 133
    :cond_2
    iput-boolean v3, p0, LTpPRs5;->vaIue:Z

    .line 134
    .line 135
    if-eqz v3, :cond_3

    .line 136
    .line 137
    const/16 v1, 0xa

    .line 138
    .line 139
    aget-byte v1, p1, v1

    .line 140
    .line 141
    and-int/lit16 v1, v1, 0xff

    .line 142
    .line 143
    shl-int/lit8 v1, v1, 0x8

    .line 144
    .line 145
    const/16 v2, 0xb

    .line 146
    .line 147
    aget-byte p1, p1, v2

    .line 148
    .line 149
    and-int/lit16 p1, p1, 0xff

    .line 150
    .line 151
    int-to-float v0, v0

    .line 152
    or-int/2addr p1, v1

    .line 153
    int-to-float p1, p1

    .line 154
    div-float/2addr p1, v0

    .line 155
    const v0, 0x3f733333    # 0.95f

    .line 156
    .line 157
    .line 158
    invoke-static {p1, v0}, Ljava/lang/Math;->min(FF)F

    .line 159
    .line 160
    .line 161
    move-result p1

    .line 162
    const/4 v0, 0x0

    .line 163
    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    .line 164
    .line 165
    .line 166
    move-result p1

    .line 167
    iput p1, p0, LTpPRs5;->Ialue:F

    .line 168
    .line 169
    return-void

    .line 170
    :cond_3
    iput v1, p0, LTpPRs5;->Ialue:F

    .line 171
    .line 172
    return-void

    .line 173
    :cond_4
    iput v3, p0, LTpPRs5;->jPos3709:I

    .line 174
    .line 175
    const/4 p1, -0x1

    .line 176
    iput p1, p0, LTpPRs5;->iOffset934:I

    .line 177
    .line 178
    iput-object v2, p0, LTpPRs5;->kQy:Ljava/lang/String;

    .line 179
    .line 180
    iput-boolean v3, p0, LTpPRs5;->vaIue:Z

    .line 181
    .line 182
    iput v1, p0, LTpPRs5;->Ialue:F

    .line 183
    .line 184
    iput p1, p0, LTpPRs5;->valuI:I

    .line 185
    .line 186
    return-void
.end method

.method public static e8$mp_s$(Landroid/text/SpannableStringBuilder;IIIII)V
    .locals 1

    .line 1
    if-eq p1, p2, :cond_0

    .line 2
    .line 3
    and-int/lit16 p2, p1, 0xff

    .line 4
    .line 5
    shl-int/lit8 p2, p2, 0x18

    .line 6
    .line 7
    ushr-int/lit8 p1, p1, 0x8

    .line 8
    .line 9
    new-instance v0, Landroid/text/style/ForegroundColorSpan;

    .line 10
    .line 11
    or-int/2addr p1, p2

    .line 12
    invoke-direct {v0, p1}, Landroid/text/style/ForegroundColorSpan;-><init>(I)V

    .line 13
    .line 14
    .line 15
    or-int/lit8 p1, p5, 0x21

    .line 16
    .line 17
    invoke-virtual {p0, v0, p3, p4, p1}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public static waiBKÀ(Landroid/text/SpannableStringBuilder;IIIII)V
    .locals 4

    .line 1
    if-eq p1, p2, :cond_4

    .line 2
    .line 3
    or-int/lit8 p2, p5, 0x21

    .line 4
    .line 5
    and-int/lit8 p5, p1, 0x1

    .line 6
    .line 7
    and-int/lit8 v0, p1, 0x2

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    const/4 v2, 0x1

    .line 11
    if-eqz p5, :cond_2

    .line 12
    .line 13
    if-eqz v0, :cond_0

    .line 14
    .line 15
    new-instance v0, Landroid/text/style/StyleSpan;

    .line 16
    .line 17
    const/4 v3, 0x3

    .line 18
    invoke-direct {v0, v3}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0, v0, p3, p4, p2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :cond_0
    new-instance v0, Landroid/text/style/StyleSpan;

    .line 26
    .line 27
    invoke-direct {v0, v2}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p0, v0, p3, p4, p2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 31
    .line 32
    .line 33
    :cond_1
    const/4 v2, 0x0

    .line 34
    goto :goto_0

    .line 35
    :cond_2
    if-eqz v0, :cond_1

    .line 36
    .line 37
    new-instance v0, Landroid/text/style/StyleSpan;

    .line 38
    .line 39
    const/4 v3, 0x2

    .line 40
    invoke-direct {v0, v3}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {p0, v0, p3, p4, p2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 44
    .line 45
    .line 46
    :goto_0
    and-int/lit8 p1, p1, 0x4

    .line 47
    .line 48
    if-nez p1, :cond_3

    .line 49
    .line 50
    if-nez p5, :cond_4

    .line 51
    .line 52
    if-nez v2, :cond_4

    .line 53
    .line 54
    new-instance p1, Landroid/text/style/StyleSpan;

    .line 55
    .line 56
    invoke-direct {p1, v1}, Landroid/text/style/StyleSpan;-><init>(I)V

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0, p1, p3, p4, p2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_3
    new-instance p1, Landroid/text/style/UnderlineSpan;

    .line 64
    .line 65
    invoke-direct {p1}, Landroid/text/style/UnderlineSpan;-><init>()V

    .line 66
    .line 67
    .line 68
    invoke-virtual {p0, p1, p3, p4, p2}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 69
    .line 70
    .line 71
    :cond_4
    return-void
.end method


# virtual methods
.method public final Ialue([BIILHnKGeZ;)V
    .locals 25

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p4

    .line 6
    .line 7
    add-int v3, v1, p3

    .line 8
    .line 9
    iget-object v4, v0, LTpPRs5;->yON3x:LYizKm;

    .line 10
    .line 11
    move-object/from16 v5, p1

    .line 12
    .line 13
    invoke-virtual {v4, v3, v5}, LYizKm;->DDù8(I[B)V

    .line 14
    .line 15
    .line 16
    invoke-virtual {v4, v1}, LYizKm;->vaIue(I)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {v4}, LYizKm;->valuI()I

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    const/4 v3, 0x0

    .line 24
    const/4 v5, 0x1

    .line 25
    const/4 v6, 0x2

    .line 26
    if-lt v1, v6, :cond_0

    .line 27
    .line 28
    const/4 v1, 0x1

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    const/4 v1, 0x0

    .line 31
    :goto_0
    invoke-static {v1}, LvItem3158;->jI(Z)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v4}, LYizKm;->tmpSize211()I

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    if-nez v1, :cond_1

    .line 39
    .line 40
    const-string v1, ""

    .line 41
    .line 42
    goto :goto_2

    .line 43
    :cond_1
    iget v7, v4, LYizKm;->waiBKÀ:I

    .line 44
    .line 45
    invoke-virtual {v4}, LYizKm;->rz__9J_()Ljava/nio/charset/Charset;

    .line 46
    .line 47
    .line 48
    move-result-object v8

    .line 49
    iget v9, v4, LYizKm;->waiBKÀ:I

    .line 50
    .line 51
    sub-int/2addr v9, v7

    .line 52
    if-eqz v8, :cond_2

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_2
    sget-object v8, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    .line 56
    .line 57
    :goto_1
    sub-int/2addr v1, v9

    .line 58
    invoke-virtual {v4, v1, v8}, LYizKm;->waiBKÀ(ILjava/nio/charset/Charset;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object v1

    .line 62
    :goto_2
    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    .line 63
    .line 64
    .line 65
    move-result v7

    .line 66
    if-eqz v7, :cond_3

    .line 67
    .line 68
    new-instance v8, L_x$o_t$;

    .line 69
    .line 70
    sget-object v1, LnW_cN_;->vaIue:Ljk_NI_;

    .line 71
    .line 72
    sget-object v9, LlII1II;->kQy:LlII1II;

    .line 73
    .line 74
    const-wide v10, -0x7fffffffffffffffL    # -4.9E-324

    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    move-wide v12, v10

    .line 80
    invoke-direct/range {v8 .. v13}, L_x$o_t$;-><init>(Ljava/util/List;JJ)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2, v8}, LHnKGeZ;->kQy(Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    return-void

    .line 87
    :cond_3
    new-instance v9, Landroid/text/SpannableStringBuilder;

    .line 88
    .line 89
    invoke-direct {v9, v1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    .line 93
    .line 94
    .line 95
    move-result v13

    .line 96
    const/high16 v14, 0xff0000

    .line 97
    .line 98
    iget v10, v0, LTpPRs5;->jPos3709:I

    .line 99
    .line 100
    const/4 v11, 0x0

    .line 101
    const/4 v12, 0x0

    .line 102
    invoke-static/range {v9 .. v14}, LTpPRs5;->waiBKÀ(Landroid/text/SpannableStringBuilder;IIIII)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    .line 106
    .line 107
    .line 108
    move-result v13

    .line 109
    iget v10, v0, LTpPRs5;->iOffset934:I

    .line 110
    .line 111
    const/4 v11, -0x1

    .line 112
    invoke-static/range {v9 .. v14}, LTpPRs5;->e8$mp_s$(Landroid/text/SpannableStringBuilder;IIIII)V

    .line 113
    .line 114
    .line 115
    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    const-string v7, "sans-serif"

    .line 120
    .line 121
    iget-object v8, v0, LTpPRs5;->kQy:Ljava/lang/String;

    .line 122
    .line 123
    if-eq v8, v7, :cond_4

    .line 124
    .line 125
    new-instance v7, Landroid/text/style/TypefaceSpan;

    .line 126
    .line 127
    invoke-direct {v7, v8}, Landroid/text/style/TypefaceSpan;-><init>(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    const v8, 0xff0021

    .line 131
    .line 132
    .line 133
    invoke-virtual {v9, v7, v3, v1, v8}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    .line 134
    .line 135
    .line 136
    :cond_4
    iget v1, v0, LTpPRs5;->Ialue:F

    .line 137
    .line 138
    :goto_3
    invoke-virtual {v4}, LYizKm;->valuI()I

    .line 139
    .line 140
    .line 141
    move-result v7

    .line 142
    const/16 v8, 0x8

    .line 143
    .line 144
    if-lt v7, v8, :cond_c

    .line 145
    .line 146
    iget v7, v4, LYizKm;->waiBKÀ:I

    .line 147
    .line 148
    invoke-virtual {v4}, LYizKm;->yàÒZ()I

    .line 149
    .line 150
    .line 151
    move-result v8

    .line 152
    invoke-virtual {v4}, LYizKm;->yàÒZ()I

    .line 153
    .line 154
    .line 155
    move-result v10

    .line 156
    const v11, 0x7374796c

    .line 157
    .line 158
    .line 159
    if-ne v10, v11, :cond_a

    .line 160
    .line 161
    invoke-virtual {v4}, LYizKm;->valuI()I

    .line 162
    .line 163
    .line 164
    move-result v10

    .line 165
    if-lt v10, v6, :cond_5

    .line 166
    .line 167
    const/4 v10, 0x1

    .line 168
    goto :goto_4

    .line 169
    :cond_5
    const/4 v10, 0x0

    .line 170
    :goto_4
    invoke-static {v10}, LvItem3158;->jI(Z)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v4}, LYizKm;->tmpSize211()I

    .line 174
    .line 175
    .line 176
    move-result v15

    .line 177
    const/4 v10, 0x0

    .line 178
    :goto_5
    if-ge v10, v15, :cond_9

    .line 179
    .line 180
    invoke-virtual {v4}, LYizKm;->valuI()I

    .line 181
    .line 182
    .line 183
    move-result v11

    .line 184
    const/16 v12, 0xc

    .line 185
    .line 186
    if-lt v11, v12, :cond_6

    .line 187
    .line 188
    const/4 v11, 0x1

    .line 189
    goto :goto_6

    .line 190
    :cond_6
    const/4 v11, 0x0

    .line 191
    :goto_6
    invoke-static {v11}, LvItem3158;->jI(Z)V

    .line 192
    .line 193
    .line 194
    invoke-virtual {v4}, LYizKm;->tmpSize211()I

    .line 195
    .line 196
    .line 197
    move-result v12

    .line 198
    invoke-virtual {v4}, LYizKm;->tmpSize211()I

    .line 199
    .line 200
    .line 201
    move-result v11

    .line 202
    invoke-virtual {v4, v6}, LYizKm;->jPos3709(I)V

    .line 203
    .line 204
    .line 205
    move v13, v10

    .line 206
    invoke-virtual {v4}, LYizKm;->UC_n_()I

    .line 207
    .line 208
    .line 209
    move-result v10

    .line 210
    invoke-virtual {v4, v5}, LYizKm;->jPos3709(I)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v4}, LYizKm;->yàÒZ()I

    .line 214
    .line 215
    .line 216
    move-result v16

    .line 217
    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    .line 218
    .line 219
    .line 220
    move-result v14

    .line 221
    const-string v3, ")."

    .line 222
    .line 223
    if-le v11, v14, :cond_7

    .line 224
    .line 225
    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    .line 226
    .line 227
    .line 228
    move-result v14

    .line 229
    new-instance v5, Ljava/lang/StringBuilder;

    .line 230
    .line 231
    const-string v6, "Truncating styl end ("

    .line 232
    .line 233
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 237
    .line 238
    .line 239
    const-string v6, ") to cueText.length() ("

    .line 240
    .line 241
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 242
    .line 243
    .line 244
    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 245
    .line 246
    .line 247
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 248
    .line 249
    .line 250
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 251
    .line 252
    .line 253
    move-result-object v5

    .line 254
    invoke-static {v5}, Lzl1;->RD(Ljava/lang/String;)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {v9}, Landroid/text/SpannableStringBuilder;->length()I

    .line 258
    .line 259
    .line 260
    move-result v11

    .line 261
    :cond_7
    if-lt v12, v11, :cond_8

    .line 262
    .line 263
    new-instance v5, Ljava/lang/StringBuilder;

    .line 264
    .line 265
    const-string v6, "Ignoring styl with start ("

    .line 266
    .line 267
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 268
    .line 269
    .line 270
    invoke-virtual {v5, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 271
    .line 272
    .line 273
    const-string v6, ") >= end ("

    .line 274
    .line 275
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    invoke-virtual {v5, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 279
    .line 280
    .line 281
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 282
    .line 283
    .line 284
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 285
    .line 286
    .line 287
    move-result-object v3

    .line 288
    invoke-static {v3}, Lzl1;->RD(Ljava/lang/String;)V

    .line 289
    .line 290
    .line 291
    move v3, v13

    .line 292
    goto :goto_7

    .line 293
    :cond_8
    move v3, v13

    .line 294
    move v13, v11

    .line 295
    iget v11, v0, LTpPRs5;->jPos3709:I

    .line 296
    .line 297
    const/4 v14, 0x0

    .line 298
    invoke-static/range {v9 .. v14}, LTpPRs5;->waiBKÀ(Landroid/text/SpannableStringBuilder;IIIII)V

    .line 299
    .line 300
    .line 301
    iget v11, v0, LTpPRs5;->iOffset934:I

    .line 302
    .line 303
    move/from16 v10, v16

    .line 304
    .line 305
    invoke-static/range {v9 .. v14}, LTpPRs5;->e8$mp_s$(Landroid/text/SpannableStringBuilder;IIIII)V

    .line 306
    .line 307
    .line 308
    :goto_7
    add-int/lit8 v10, v3, 0x1

    .line 309
    .line 310
    const/4 v3, 0x0

    .line 311
    const/4 v5, 0x1

    .line 312
    const/4 v6, 0x2

    .line 313
    goto/16 :goto_5

    .line 314
    .line 315
    :cond_9
    const/4 v3, 0x2

    .line 316
    goto :goto_9

    .line 317
    :cond_a
    const v3, 0x74626f78

    .line 318
    .line 319
    .line 320
    if-ne v10, v3, :cond_9

    .line 321
    .line 322
    iget-boolean v3, v0, LTpPRs5;->vaIue:Z

    .line 323
    .line 324
    if-eqz v3, :cond_9

    .line 325
    .line 326
    invoke-virtual {v4}, LYizKm;->valuI()I

    .line 327
    .line 328
    .line 329
    move-result v1

    .line 330
    const/4 v3, 0x2

    .line 331
    if-lt v1, v3, :cond_b

    .line 332
    .line 333
    const/4 v1, 0x1

    .line 334
    goto :goto_8

    .line 335
    :cond_b
    const/4 v1, 0x0

    .line 336
    :goto_8
    invoke-static {v1}, LvItem3158;->jI(Z)V

    .line 337
    .line 338
    .line 339
    invoke-virtual {v4}, LYizKm;->tmpSize211()I

    .line 340
    .line 341
    .line 342
    move-result v1

    .line 343
    int-to-float v1, v1

    .line 344
    iget v5, v0, LTpPRs5;->valuI:I

    .line 345
    .line 346
    int-to-float v5, v5

    .line 347
    div-float/2addr v1, v5

    .line 348
    const v5, 0x3f733333    # 0.95f

    .line 349
    .line 350
    .line 351
    invoke-static {v1, v5}, Ljava/lang/Math;->min(FF)F

    .line 352
    .line 353
    .line 354
    move-result v1

    .line 355
    const/4 v5, 0x0

    .line 356
    invoke-static {v5, v1}, Ljava/lang/Math;->max(FF)F

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    :goto_9
    add-int/2addr v7, v8

    .line 361
    invoke-virtual {v4, v7}, LYizKm;->vaIue(I)V

    .line 362
    .line 363
    .line 364
    const/4 v3, 0x0

    .line 365
    const/4 v5, 0x1

    .line 366
    const/4 v6, 0x2

    .line 367
    goto/16 :goto_3

    .line 368
    .line 369
    :cond_c
    new-instance v3, LOS_U_;

    .line 370
    .line 371
    const/4 v11, 0x0

    .line 372
    const/4 v15, 0x0

    .line 373
    const/16 v16, 0x0

    .line 374
    .line 375
    const v17, -0x800001

    .line 376
    .line 377
    .line 378
    const/high16 v18, -0x80000000

    .line 379
    .line 380
    const/16 v24, 0x0

    .line 381
    .line 382
    move-object v12, v11

    .line 383
    move-object v13, v11

    .line 384
    move/from16 v19, v18

    .line 385
    .line 386
    move/from16 v20, v17

    .line 387
    .line 388
    move/from16 v21, v17

    .line 389
    .line 390
    move/from16 v22, v17

    .line 391
    .line 392
    move/from16 v23, v18

    .line 393
    .line 394
    move v14, v1

    .line 395
    move-object v10, v9

    .line 396
    move-object v9, v3

    .line 397
    invoke-direct/range {v9 .. v24}, LOS_U_;-><init>(Ljava/lang/CharSequence;Landroid/text/Layout$Alignment;Landroid/text/Layout$Alignment;Landroid/graphics/Bitmap;FIIFIIFFFIF)V

    .line 398
    .line 399
    .line 400
    new-instance v3, L_x$o_t$;

    .line 401
    .line 402
    invoke-static {v9}, LnW_cN_;->kQy(Ljava/lang/Object;)LlII1II;

    .line 403
    .line 404
    .line 405
    move-result-object v4

    .line 406
    const-wide v5, -0x7fffffffffffffffL    # -4.9E-324

    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    move-wide v7, v5

    .line 412
    invoke-direct/range {v3 .. v8}, L_x$o_t$;-><init>(Ljava/util/List;JJ)V

    .line 413
    .line 414
    .line 415
    invoke-virtual {v2, v3}, LHnKGeZ;->kQy(Ljava/lang/Object;)V

    .line 416
    .line 417
    .line 418
    return-void
.end method
