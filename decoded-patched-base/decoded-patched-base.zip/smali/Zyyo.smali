.class public abstract LZyyo;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final POOl:Ljava/util/List;

.field public final e8$mp_s$:LhiB_7$0y_;

.field public rz__9J_:LlACD;

.field public final waiBKÀ:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, LtmpData2913;->waiBKÀ(Ljava/lang/String;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, LZyyo;->waiBKÀ:Ljava/lang/String;

    .line 8
    .line 9
    new-instance p1, LhiB_7$0y_;

    .line 10
    .line 11
    const-string v0, "MediaControlChannel"

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-direct {p1, v0, v1}, LhiB_7$0y_;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, LZyyo;->e8$mp_s$:LhiB_7$0y_;

    .line 18
    .line 19
    new-instance p1, Ljava/util/ArrayList;

    .line 20
    .line 21
    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    .line 22
    .line 23
    .line 24
    invoke-static {p1}, Ljava/util/Collections;->synchronizedList(Ljava/util/List;)Ljava/util/List;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    iput-object p1, p0, LZyyo;->POOl:Ljava/util/List;

    .line 29
    .line 30
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(L$Q$V$;)V
    .locals 1

    .line 1
    iget-object v0, p0, LZyyo;->POOl:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final rz__9J_(Ljava/lang/String;J)V
    .locals 7

    .line 1
    const/4 v0, 0x2

    .line 2
    new-array v1, v0, [Ljava/lang/Object;

    .line 3
    .line 4
    const/4 v2, 0x0

    .line 5
    aput-object p1, v1, v2

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    const/4 v4, 0x0

    .line 9
    aput-object v4, v1, v3

    .line 10
    .line 11
    iget-object v4, p0, LZyyo;->e8$mp_s$:LhiB_7$0y_;

    .line 12
    .line 13
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    sget-object v5, Landroid/os/Build;->TYPE:Ljava/lang/String;

    .line 17
    .line 18
    const-string v6, "user"

    .line 19
    .line 20
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v5

    .line 24
    if-nez v5, :cond_0

    .line 25
    .line 26
    iget-boolean v5, v4, LhiB_7$0y_;->waiBKÀ:Z

    .line 27
    .line 28
    if-eqz v5, :cond_0

    .line 29
    .line 30
    iget-object v5, v4, LhiB_7$0y_;->e8$mp_s$:Ljava/lang/String;

    .line 31
    .line 32
    invoke-static {v5, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    .line 33
    .line 34
    .line 35
    move-result v0

    .line 36
    if-eqz v0, :cond_0

    .line 37
    .line 38
    const-string v0, "Sending text message: %s to: %s"

    .line 39
    .line 40
    invoke-virtual {v4, v0, v1}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    :cond_0
    iget-object v0, p0, LZyyo;->rz__9J_:LlACD;

    .line 44
    .line 45
    if-nez v0, :cond_1

    .line 46
    .line 47
    new-array p1, v2, [Ljava/lang/Object;

    .line 48
    .line 49
    const-string p2, "Attempt to send text message without a sink"

    .line 50
    .line 51
    invoke-virtual {v4, p2, p1}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_1
    iget-object v1, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 56
    .line 57
    check-cast v1, Lde$GC_mi$;

    .line 58
    .line 59
    if-eqz v1, :cond_4

    .line 60
    .line 61
    check-cast v1, Lk0l;

    .line 62
    .line 63
    iget-object v4, p0, LZyyo;->waiBKÀ:Ljava/lang/String;

    .line 64
    .line 65
    invoke-static {v4}, LtmpData2913;->waiBKÀ(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 69
    .line 70
    .line 71
    move-result v5

    .line 72
    if-nez v5, :cond_3

    .line 73
    .line 74
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 75
    .line 76
    .line 77
    move-result v5

    .line 78
    const/high16 v6, 0x80000

    .line 79
    .line 80
    if-gt v5, v6, :cond_2

    .line 81
    .line 82
    invoke-static {}, LIata;->waiBKÀ()LIata;

    .line 83
    .line 84
    .line 85
    move-result-object v2

    .line 86
    new-instance v5, LlACD;

    .line 87
    .line 88
    const/16 v6, 0x10

    .line 89
    .line 90
    invoke-direct {v5, v1, v4, p1, v6}, LlACD;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 91
    .line 92
    .line 93
    iput-object v5, v2, LIata;->POOl:Ljava/lang/Object;

    .line 94
    .line 95
    const/16 p1, 0x20d5

    .line 96
    .line 97
    iput p1, v2, LIata;->waiBKÀ:I

    .line 98
    .line 99
    invoke-virtual {v2}, LIata;->e8$mp_s$()LIata;

    .line 100
    .line 101
    .line 102
    move-result-object p1

    .line 103
    invoke-virtual {v1, v3, p1}, LC4t_Zg$W_;->POOl(ILIata;)LGIlO;

    .line 104
    .line 105
    .line 106
    move-result-object p1

    .line 107
    new-instance v1, LaLT$WK$;

    .line 108
    .line 109
    const/4 v2, 0x5

    .line 110
    invoke-direct {v1, v0, p2, p3, v2}, LaLT$WK$;-><init>(Ljava/lang/Object;JI)V

    .line 111
    .line 112
    .line 113
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 114
    .line 115
    .line 116
    sget-object p2, LGi$EL$;->e8$mp_s$:Lab_w_;

    .line 117
    .line 118
    new-instance p3, LmData56;

    .line 119
    .line 120
    invoke-direct {p3, p2, v1}, LmData56;-><init>(Ljava/util/concurrent/Executor;LHàWLI;)V

    .line 121
    .line 122
    .line 123
    iget-object p2, p1, LGIlO;->waiBKÀ:LlO;

    .line 124
    .line 125
    invoke-virtual {p2, p3}, LlO;->tmpData3485(LmData56;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {p1}, LGIlO;->jPos3709()V

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :cond_2
    sget-object p1, Lk0l;->iSize4906:LhiB_7$0y_;

    .line 133
    .line 134
    const-string p2, "Message send failed. Message exceeds maximum size"

    .line 135
    .line 136
    new-array p3, v2, [Ljava/lang/Object;

    .line 137
    .line 138
    invoke-virtual {p1, p2, p3}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 139
    .line 140
    .line 141
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 142
    .line 143
    const-string p2, "Message exceeds maximum size524288"

    .line 144
    .line 145
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    throw p1

    .line 149
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 150
    .line 151
    const-string p2, "The message payload cannot be null or empty"

    .line 152
    .line 153
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 154
    .line 155
    .line 156
    throw p1

    .line 157
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 158
    .line 159
    const-string p2, "Device is not connected"

    .line 160
    .line 161
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 162
    .line 163
    .line 164
    throw p1
.end method

.method public final waiBKÀ()J
    .locals 3

    .line 1
    iget-object v0, p0, LZyyo;->rz__9J_:LlACD;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    new-array v0, v0, [Ljava/lang/Object;

    .line 7
    .line 8
    iget-object v1, p0, LZyyo;->e8$mp_s$:LhiB_7$0y_;

    .line 9
    .line 10
    const-string v2, "Attempt to generate requestId without a sink"

    .line 11
    .line 12
    invoke-virtual {v1, v2, v0}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    const-wide/16 v0, 0x0

    .line 16
    .line 17
    return-wide v0

    .line 18
    :cond_0
    iget-object v0, v0, LlACD;->jPos3709:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, Ljava/util/concurrent/atomic/AtomicLong;

    .line 21
    .line 22
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    .line 23
    .line 24
    .line 25
    move-result-wide v0

    .line 26
    return-wide v0
.end method
