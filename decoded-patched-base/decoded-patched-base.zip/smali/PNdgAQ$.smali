.class public final LPNdgAQ$;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final Qp_Hp$i_:LhiB_7$0y_;


# instance fields
.field public final DDù8:J

.field public Ialue:Ltbi;

.field public final JKEoÙX:Landroid/content/ComponentName;

.field public K0I:Ltbi;

.field public final POOl:Landroid/content/ComponentName;

.field public final e8$mp_s$:Landroid/content/Context;

.field public gKey4112:Ltbi;

.field public iOffset934:Lavt$p$;

.field public jPos3709:LgCount1307;

.field public kO_6X_:Ltbi;

.field public kQy:Ltbi;

.field public pCXDYg:Ltbi;

.field public final rz__9J_:LPVN$Zh_Vn$;

.field public sKey7917:[I

.field public tmpData3485:Ljava/util/ArrayList;

.field public final vaIue:Landroid/content/res/Resources;

.field public valuI:Ltbi;

.field public final waiBKÀ:Landroid/app/NotificationManager;

.field public final yON3x:LKkmORP;

.field public yàÒZ:Ltbi;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LhiB_7$0y_;

    .line 2
    .line 3
    const-string v1, "MediaNotificationProxy"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, LhiB_7$0y_;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LPNdgAQ$;->Qp_Hp$i_:LhiB_7$0y_;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LPNdgAQ$;->tmpData3485:Ljava/util/ArrayList;

    .line 10
    .line 11
    iput-object p1, p0, LPNdgAQ$;->e8$mp_s$:Landroid/content/Context;

    .line 12
    .line 13
    const-string v0, "notification"

    .line 14
    .line 15
    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Landroid/app/NotificationManager;

    .line 20
    .line 21
    iput-object v0, p0, LPNdgAQ$;->waiBKÀ:Landroid/app/NotificationManager;

    .line 22
    .line 23
    sget-object v1, LVA_r_;->jPos3709:LhiB_7$0y_;

    .line 24
    .line 25
    const-string v1, "Must be called from the main thread."

    .line 26
    .line 27
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 28
    .line 29
    .line 30
    sget-object v2, LVA_r_;->kQy:LVA_r_;

    .line 31
    .line 32
    invoke-static {v2}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iget-object v1, v2, LVA_r_;->JKEoÙX:LGtVP;

    .line 39
    .line 40
    invoke-static {v1}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    iget-object v1, v1, LGtVP;->Ialue:LUF$r$;

    .line 44
    .line 45
    invoke-static {v1}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    iget-object v2, v1, LUF$r$;->iOffset934:LPVN$Zh_Vn$;

    .line 49
    .line 50
    invoke-static {v2}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    iput-object v2, p0, LPNdgAQ$;->rz__9J_:LPVN$Zh_Vn$;

    .line 54
    .line 55
    invoke-virtual {v1}, LUF$r$;->rz__9J_()V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    iput-object v3, p0, LPNdgAQ$;->vaIue:Landroid/content/res/Resources;

    .line 63
    .line 64
    new-instance v4, Landroid/content/ComponentName;

    .line 65
    .line 66
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 67
    .line 68
    .line 69
    move-result-object v5

    .line 70
    iget-object v1, v1, LUF$r$;->yON3x:Ljava/lang/String;

    .line 71
    .line 72
    invoke-direct {v4, v5, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    iput-object v4, p0, LPNdgAQ$;->POOl:Landroid/content/ComponentName;

    .line 76
    .line 77
    iget-object v1, v2, LPVN$Zh_Vn$;->iOffset934:Ljava/lang/String;

    .line 78
    .line 79
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    if-nez v4, :cond_0

    .line 84
    .line 85
    new-instance v4, Landroid/content/ComponentName;

    .line 86
    .line 87
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    invoke-direct {v4, v5, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 92
    .line 93
    .line 94
    iput-object v4, p0, LPNdgAQ$;->JKEoÙX:Landroid/content/ComponentName;

    .line 95
    .line 96
    goto :goto_0

    .line 97
    :cond_0
    const/4 v1, 0x0

    .line 98
    iput-object v1, p0, LPNdgAQ$;->JKEoÙX:Landroid/content/ComponentName;

    .line 99
    .line 100
    :goto_0
    iget-wide v4, v2, LPVN$Zh_Vn$;->jPos3709:J

    .line 101
    .line 102
    iput-wide v4, p0, LPNdgAQ$;->DDù8:J

    .line 103
    .line 104
    iget v1, v2, LPVN$Zh_Vn$;->tmpSize211:I

    .line 105
    .line 106
    invoke-virtual {v3, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 107
    .line 108
    .line 109
    move-result v1

    .line 110
    new-instance v2, LjxBKYìL;

    .line 111
    .line 112
    const/4 v3, 0x1

    .line 113
    invoke-direct {v2, v3, v1, v1}, LjxBKYìL;-><init>(III)V

    .line 114
    .line 115
    .line 116
    new-instance v1, LKkmORP;

    .line 117
    .line 118
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    invoke-direct {v1, v3, v2}, LKkmORP;-><init>(Landroid/content/Context;LjxBKYìL;)V

    .line 123
    .line 124
    .line 125
    iput-object v1, p0, LPNdgAQ$;->yON3x:LKkmORP;

    .line 126
    .line 127
    invoke-static {}, LI1i1;->kCount1402()Z

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    if-eqz v1, :cond_1

    .line 132
    .line 133
    if-eqz v0, :cond_1

    .line 134
    .line 135
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    sget v1, LbOQ;->media_notification_channel_name:I

    .line 140
    .line 141
    invoke-virtual {p1, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    invoke-static {p1}, LKcÒ2;->waiBKÀ(Ljava/lang/String;)Landroid/app/NotificationChannel;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    invoke-static {p1}, LKcÒ2;->iOffset934(Landroid/app/NotificationChannel;)V

    .line 150
    .line 151
    .line 152
    invoke-static {v0, p1}, LKcÒ2;->Ialue(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    .line 153
    .line 154
    .line 155
    :cond_1
    sget-object p1, LjOffset460;->lelgth:LjOffset460;

    .line 156
    .line 157
    invoke-static {p1}, LZBWÙEP;->e8$mp_s$(LjOffset460;)V

    .line 158
    .line 159
    .line 160
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(Ljava/lang/String;)Ltbi;
    .locals 24

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const/4 v3, 0x1

    .line 10
    const-string v4, "com.google.android.gms.cast.framework.action.REWIND"

    .line 11
    .line 12
    const-string v5, "com.google.android.gms.cast.framework.action.SKIP_NEXT"

    .line 13
    .line 14
    const-string v7, "com.google.android.gms.cast.framework.action.SKIP_PREV"

    .line 15
    .line 16
    const-string v8, "com.google.android.gms.cast.framework.action.STOP_CASTING"

    .line 17
    .line 18
    const-string v9, "com.google.android.gms.cast.framework.action.DISCONNECT"

    .line 19
    .line 20
    const-string v10, "com.google.android.gms.cast.framework.action.FORWARD"

    .line 21
    .line 22
    const-string v11, "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"

    .line 23
    .line 24
    sparse-switch v2, :sswitch_data_0

    .line 25
    .line 26
    .line 27
    goto :goto_0

    .line 28
    :sswitch_0
    invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_0

    .line 33
    .line 34
    const/4 v2, 0x3

    .line 35
    goto :goto_1

    .line 36
    :sswitch_1
    invoke-virtual {v1, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_0

    .line 41
    .line 42
    const/4 v2, 0x0

    .line 43
    goto :goto_1

    .line 44
    :sswitch_2
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_0

    .line 49
    .line 50
    const/4 v2, 0x6

    .line 51
    goto :goto_1

    .line 52
    :sswitch_3
    invoke-virtual {v1, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    if-eqz v2, :cond_0

    .line 57
    .line 58
    const/4 v2, 0x5

    .line 59
    goto :goto_1

    .line 60
    :sswitch_4
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 61
    .line 62
    .line 63
    move-result v2

    .line 64
    if-eqz v2, :cond_0

    .line 65
    .line 66
    const/4 v2, 0x2

    .line 67
    goto :goto_1

    .line 68
    :sswitch_5
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v2

    .line 72
    if-eqz v2, :cond_0

    .line 73
    .line 74
    const/4 v2, 0x1

    .line 75
    goto :goto_1

    .line 76
    :sswitch_6
    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v2

    .line 80
    if-eqz v2, :cond_0

    .line 81
    .line 82
    const/4 v2, 0x4

    .line 83
    goto :goto_1

    .line 84
    :cond_0
    :goto_0
    const/4 v2, -0x1

    .line 85
    :goto_1
    const/high16 v17, 0x8000000

    .line 86
    .line 87
    const-wide/16 v18, 0x2710

    .line 88
    .line 89
    const-string v13, "googlecast-extra_skip_step_ms"

    .line 90
    .line 91
    move-object/from16 v20, v7

    .line 92
    .line 93
    iget-wide v6, v0, LPNdgAQ$;->DDù8:J

    .line 94
    .line 95
    const/16 v21, 0x0

    .line 96
    .line 97
    iget-object v14, v0, LPNdgAQ$;->vaIue:Landroid/content/res/Resources;

    .line 98
    .line 99
    const-wide/16 v22, 0x7530

    .line 100
    .line 101
    iget-object v15, v0, LPNdgAQ$;->e8$mp_s$:Landroid/content/Context;

    .line 102
    .line 103
    const/16 v16, 0x0

    .line 104
    .line 105
    iget-object v12, v0, LPNdgAQ$;->POOl:Landroid/content/ComponentName;

    .line 106
    .line 107
    iget-object v1, v0, LPNdgAQ$;->rz__9J_:LPVN$Zh_Vn$;

    .line 108
    .line 109
    packed-switch v2, :pswitch_data_0

    .line 110
    .line 111
    .line 112
    new-array v1, v3, [Ljava/lang/Object;

    .line 113
    .line 114
    aput-object p1, v1, v16

    .line 115
    .line 116
    const-string v2, "Action: %s is not a pre-defined action."

    .line 117
    .line 118
    sget-object v3, LPNdgAQ$;->Qp_Hp$i_:LhiB_7$0y_;

    .line 119
    .line 120
    invoke-virtual {v3, v2, v1}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 121
    .line 122
    .line 123
    return-object v21

    .line 124
    :pswitch_0
    iget-object v2, v0, LPNdgAQ$;->kO_6X_:Ltbi;

    .line 125
    .line 126
    if-nez v2, :cond_1

    .line 127
    .line 128
    new-instance v2, Landroid/content/Intent;

    .line 129
    .line 130
    invoke-direct {v2, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 131
    .line 132
    .line 133
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 134
    .line 135
    .line 136
    sget v4, LgD1_x$l$_;->e8$mp_s$:I

    .line 137
    .line 138
    const/4 v5, 0x0

    .line 139
    invoke-static {v15, v5, v2, v4}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 140
    .line 141
    .line 142
    move-result-object v2

    .line 143
    new-instance v4, LFÌ1scJWkW;

    .line 144
    .line 145
    iget v6, v1, LPVN$Zh_Vn$;->Q1_f_:I

    .line 146
    .line 147
    iget v1, v1, LPVN$Zh_Vn$;->gSy_FG$D_:I

    .line 148
    .line 149
    new-array v3, v3, [Ljava/lang/Object;

    .line 150
    .line 151
    const-string v7, ""

    .line 152
    .line 153
    aput-object v7, v3, v5

    .line 154
    .line 155
    invoke-virtual {v14, v1, v3}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v1

    .line 159
    invoke-direct {v4, v6, v1, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v4}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    iput-object v1, v0, LPNdgAQ$;->kO_6X_:Ltbi;

    .line 167
    .line 168
    :cond_1
    iget-object v1, v0, LPNdgAQ$;->kO_6X_:Ltbi;

    .line 169
    .line 170
    return-object v1

    .line 171
    :pswitch_1
    iget-object v2, v0, LPNdgAQ$;->K0I:Ltbi;

    .line 172
    .line 173
    if-nez v2, :cond_2

    .line 174
    .line 175
    new-instance v2, Landroid/content/Intent;

    .line 176
    .line 177
    invoke-direct {v2, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 178
    .line 179
    .line 180
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 181
    .line 182
    .line 183
    sget v3, LgD1_x$l$_;->e8$mp_s$:I

    .line 184
    .line 185
    const/4 v5, 0x0

    .line 186
    invoke-static {v15, v5, v2, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 187
    .line 188
    .line 189
    move-result-object v2

    .line 190
    new-instance v3, LFÌ1scJWkW;

    .line 191
    .line 192
    iget v4, v1, LPVN$Zh_Vn$;->Q1_f_:I

    .line 193
    .line 194
    iget v1, v1, LPVN$Zh_Vn$;->gSy_FG$D_:I

    .line 195
    .line 196
    invoke-virtual {v14, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-direct {v3, v4, v1, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v3}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 204
    .line 205
    .line 206
    move-result-object v1

    .line 207
    iput-object v1, v0, LPNdgAQ$;->K0I:Ltbi;

    .line 208
    .line 209
    :cond_2
    iget-object v1, v0, LPNdgAQ$;->K0I:Ltbi;

    .line 210
    .line 211
    return-object v1

    .line 212
    :pswitch_2
    iget-object v2, v0, LPNdgAQ$;->gKey4112:Ltbi;

    .line 213
    .line 214
    if-nez v2, :cond_7

    .line 215
    .line 216
    new-instance v2, Landroid/content/Intent;

    .line 217
    .line 218
    invoke-direct {v2, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 222
    .line 223
    .line 224
    invoke-virtual {v2, v13, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 225
    .line 226
    .line 227
    sget v3, LgD1_x$l$_;->e8$mp_s$:I

    .line 228
    .line 229
    or-int v3, v3, v17

    .line 230
    .line 231
    const/4 v5, 0x0

    .line 232
    invoke-static {v15, v5, v2, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 233
    .line 234
    .line 235
    move-result-object v2

    .line 236
    sget-object v3, LLl$l$;->e8$mp_s$:LhiB_7$0y_;

    .line 237
    .line 238
    cmp-long v3, v6, v18

    .line 239
    .line 240
    iget v4, v1, LPVN$Zh_Vn$;->UC_n_:I

    .line 241
    .line 242
    if-nez v3, :cond_3

    .line 243
    .line 244
    iget v4, v1, LPVN$Zh_Vn$;->kCount1402:I

    .line 245
    .line 246
    goto :goto_2

    .line 247
    :cond_3
    cmp-long v5, v6, v22

    .line 248
    .line 249
    if-eqz v5, :cond_4

    .line 250
    .line 251
    goto :goto_2

    .line 252
    :cond_4
    iget v4, v1, LPVN$Zh_Vn$;->$ÒcdS:I

    .line 253
    .line 254
    :goto_2
    iget v5, v1, LPVN$Zh_Vn$;->oaX_6_:I

    .line 255
    .line 256
    if-nez v3, :cond_5

    .line 257
    .line 258
    iget v5, v1, LPVN$Zh_Vn$;->BCIm:I

    .line 259
    .line 260
    goto :goto_3

    .line 261
    :cond_5
    cmp-long v3, v6, v22

    .line 262
    .line 263
    if-eqz v3, :cond_6

    .line 264
    .line 265
    goto :goto_3

    .line 266
    :cond_6
    iget v5, v1, LPVN$Zh_Vn$;->zAt$p:I

    .line 267
    .line 268
    :goto_3
    new-instance v1, LFÌ1scJWkW;

    .line 269
    .line 270
    invoke-virtual {v14, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 271
    .line 272
    .line 273
    move-result-object v3

    .line 274
    invoke-direct {v1, v4, v3, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {v1}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 278
    .line 279
    .line 280
    move-result-object v1

    .line 281
    iput-object v1, v0, LPNdgAQ$;->gKey4112:Ltbi;

    .line 282
    .line 283
    :cond_7
    iget-object v1, v0, LPNdgAQ$;->gKey4112:Ltbi;

    .line 284
    .line 285
    return-object v1

    .line 286
    :pswitch_3
    iget-object v2, v0, LPNdgAQ$;->yàÒZ:Ltbi;

    .line 287
    .line 288
    if-nez v2, :cond_c

    .line 289
    .line 290
    new-instance v2, Landroid/content/Intent;

    .line 291
    .line 292
    invoke-direct {v2, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 296
    .line 297
    .line 298
    invoke-virtual {v2, v13, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    .line 299
    .line 300
    .line 301
    sget v3, LgD1_x$l$_;->e8$mp_s$:I

    .line 302
    .line 303
    or-int v3, v3, v17

    .line 304
    .line 305
    const/4 v5, 0x0

    .line 306
    invoke-static {v15, v5, v2, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 307
    .line 308
    .line 309
    move-result-object v2

    .line 310
    sget-object v3, LLl$l$;->e8$mp_s$:LhiB_7$0y_;

    .line 311
    .line 312
    cmp-long v3, v6, v18

    .line 313
    .line 314
    iget v4, v1, LPVN$Zh_Vn$;->kO_6X_:I

    .line 315
    .line 316
    if-nez v3, :cond_8

    .line 317
    .line 318
    iget v4, v1, LPVN$Zh_Vn$;->K0I:I

    .line 319
    .line 320
    goto :goto_4

    .line 321
    :cond_8
    cmp-long v5, v6, v22

    .line 322
    .line 323
    if-eqz v5, :cond_9

    .line 324
    .line 325
    goto :goto_4

    .line 326
    :cond_9
    iget v4, v1, LPVN$Zh_Vn$;->Qp_Hp$i_:I

    .line 327
    .line 328
    :goto_4
    iget v5, v1, LPVN$Zh_Vn$;->Iii:I

    .line 329
    .line 330
    if-nez v3, :cond_a

    .line 331
    .line 332
    iget v5, v1, LPVN$Zh_Vn$;->l1:I

    .line 333
    .line 334
    goto :goto_5

    .line 335
    :cond_a
    cmp-long v3, v6, v22

    .line 336
    .line 337
    if-eqz v3, :cond_b

    .line 338
    .line 339
    goto :goto_5

    .line 340
    :cond_b
    iget v5, v1, LPVN$Zh_Vn$;->pQ1Il:I

    .line 341
    .line 342
    :goto_5
    new-instance v1, LFÌ1scJWkW;

    .line 343
    .line 344
    invoke-virtual {v14, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 345
    .line 346
    .line 347
    move-result-object v3

    .line 348
    invoke-direct {v1, v4, v3, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 349
    .line 350
    .line 351
    invoke-virtual {v1}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    iput-object v1, v0, LPNdgAQ$;->yàÒZ:Ltbi;

    .line 356
    .line 357
    :cond_c
    iget-object v1, v0, LPNdgAQ$;->yàÒZ:Ltbi;

    .line 358
    .line 359
    return-object v1

    .line 360
    :pswitch_4
    iget-object v2, v0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 361
    .line 362
    iget-boolean v2, v2, LgCount1307;->sKey7917:Z

    .line 363
    .line 364
    iget-object v3, v0, LPNdgAQ$;->pCXDYg:Ltbi;

    .line 365
    .line 366
    if-nez v3, :cond_e

    .line 367
    .line 368
    if-eqz v2, :cond_d

    .line 369
    .line 370
    new-instance v2, Landroid/content/Intent;

    .line 371
    .line 372
    move-object/from16 v3, v20

    .line 373
    .line 374
    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 375
    .line 376
    .line 377
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 378
    .line 379
    .line 380
    sget v3, LgD1_x$l$_;->e8$mp_s$:I

    .line 381
    .line 382
    const/4 v5, 0x0

    .line 383
    invoke-static {v15, v5, v2, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 384
    .line 385
    .line 386
    move-result-object v21

    .line 387
    :cond_d
    move-object/from16 v2, v21

    .line 388
    .line 389
    new-instance v3, LFÌ1scJWkW;

    .line 390
    .line 391
    iget v4, v1, LPVN$Zh_Vn$;->gKey4112:I

    .line 392
    .line 393
    iget v1, v1, LPVN$Zh_Vn$;->Oey:I

    .line 394
    .line 395
    invoke-virtual {v14, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 396
    .line 397
    .line 398
    move-result-object v1

    .line 399
    invoke-direct {v3, v4, v1, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 400
    .line 401
    .line 402
    invoke-virtual {v3}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 403
    .line 404
    .line 405
    move-result-object v1

    .line 406
    iput-object v1, v0, LPNdgAQ$;->pCXDYg:Ltbi;

    .line 407
    .line 408
    :cond_e
    iget-object v1, v0, LPNdgAQ$;->pCXDYg:Ltbi;

    .line 409
    .line 410
    return-object v1

    .line 411
    :pswitch_5
    iget-object v2, v0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 412
    .line 413
    iget-boolean v2, v2, LgCount1307;->tmpData3485:Z

    .line 414
    .line 415
    iget-object v3, v0, LPNdgAQ$;->valuI:Ltbi;

    .line 416
    .line 417
    if-nez v3, :cond_10

    .line 418
    .line 419
    if-eqz v2, :cond_f

    .line 420
    .line 421
    new-instance v2, Landroid/content/Intent;

    .line 422
    .line 423
    invoke-direct {v2, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 424
    .line 425
    .line 426
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 427
    .line 428
    .line 429
    sget v3, LgD1_x$l$_;->e8$mp_s$:I

    .line 430
    .line 431
    const/4 v5, 0x0

    .line 432
    invoke-static {v15, v5, v2, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 433
    .line 434
    .line 435
    move-result-object v21

    .line 436
    :cond_f
    move-object/from16 v2, v21

    .line 437
    .line 438
    new-instance v3, LFÌ1scJWkW;

    .line 439
    .line 440
    iget v4, v1, LPVN$Zh_Vn$;->yàÒZ:I

    .line 441
    .line 442
    iget v1, v1, LPVN$Zh_Vn$;->yPN$A_n$:I

    .line 443
    .line 444
    invoke-virtual {v14, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 445
    .line 446
    .line 447
    move-result-object v1

    .line 448
    invoke-direct {v3, v4, v1, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 449
    .line 450
    .line 451
    invoke-virtual {v3}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 452
    .line 453
    .line 454
    move-result-object v1

    .line 455
    iput-object v1, v0, LPNdgAQ$;->valuI:Ltbi;

    .line 456
    .line 457
    :cond_10
    iget-object v1, v0, LPNdgAQ$;->valuI:Ltbi;

    .line 458
    .line 459
    return-object v1

    .line 460
    :pswitch_6
    iget-object v2, v0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 461
    .line 462
    iget v3, v2, LgCount1307;->rz__9J_:I

    .line 463
    .line 464
    iget-boolean v2, v2, LgCount1307;->waiBKÀ:Z

    .line 465
    .line 466
    if-eqz v2, :cond_13

    .line 467
    .line 468
    iget-object v2, v0, LPNdgAQ$;->Ialue:Ltbi;

    .line 469
    .line 470
    if-nez v2, :cond_12

    .line 471
    .line 472
    const/4 v2, 0x2

    .line 473
    if-ne v3, v2, :cond_11

    .line 474
    .line 475
    iget v2, v1, LPVN$Zh_Vn$;->Ialue:I

    .line 476
    .line 477
    iget v1, v1, LPVN$Zh_Vn$;->tzKù7Ol1:I

    .line 478
    .line 479
    goto :goto_6

    .line 480
    :cond_11
    iget v2, v1, LPVN$Zh_Vn$;->valuI:I

    .line 481
    .line 482
    iget v1, v1, LPVN$Zh_Vn$;->ll:I

    .line 483
    .line 484
    :goto_6
    new-instance v3, Landroid/content/Intent;

    .line 485
    .line 486
    invoke-direct {v3, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 487
    .line 488
    .line 489
    invoke-virtual {v3, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 490
    .line 491
    .line 492
    sget v4, LgD1_x$l$_;->e8$mp_s$:I

    .line 493
    .line 494
    const/4 v5, 0x0

    .line 495
    invoke-static {v15, v5, v3, v4}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 496
    .line 497
    .line 498
    move-result-object v3

    .line 499
    new-instance v4, LFÌ1scJWkW;

    .line 500
    .line 501
    invoke-virtual {v14, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 502
    .line 503
    .line 504
    move-result-object v1

    .line 505
    invoke-direct {v4, v2, v1, v3}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 506
    .line 507
    .line 508
    invoke-virtual {v4}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 509
    .line 510
    .line 511
    move-result-object v1

    .line 512
    iput-object v1, v0, LPNdgAQ$;->Ialue:Ltbi;

    .line 513
    .line 514
    :cond_12
    iget-object v1, v0, LPNdgAQ$;->Ialue:Ltbi;

    .line 515
    .line 516
    return-object v1

    .line 517
    :cond_13
    iget-object v2, v0, LPNdgAQ$;->kQy:Ltbi;

    .line 518
    .line 519
    if-nez v2, :cond_14

    .line 520
    .line 521
    new-instance v2, Landroid/content/Intent;

    .line 522
    .line 523
    invoke-direct {v2, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 524
    .line 525
    .line 526
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 527
    .line 528
    .line 529
    sget v3, LgD1_x$l$_;->e8$mp_s$:I

    .line 530
    .line 531
    const/4 v5, 0x0

    .line 532
    invoke-static {v15, v5, v2, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 533
    .line 534
    .line 535
    move-result-object v2

    .line 536
    new-instance v3, LFÌ1scJWkW;

    .line 537
    .line 538
    iget v4, v1, LPVN$Zh_Vn$;->pCXDYg:I

    .line 539
    .line 540
    iget v1, v1, LPVN$Zh_Vn$;->oy_R$Xx_:I

    .line 541
    .line 542
    invoke-virtual {v14, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 543
    .line 544
    .line 545
    move-result-object v1

    .line 546
    invoke-direct {v3, v4, v1, v2}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 547
    .line 548
    .line 549
    invoke-virtual {v3}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 550
    .line 551
    .line 552
    move-result-object v1

    .line 553
    iput-object v1, v0, LPNdgAQ$;->kQy:Ltbi;

    .line 554
    .line 555
    :cond_14
    iget-object v1, v0, LPNdgAQ$;->kQy:Ltbi;

    .line 556
    .line 557
    return-object v1

    .line 558
    nop

    .line 559
    :sswitch_data_0
    .sparse-switch
        -0x655132e4 -> :sswitch_6
        -0x3855de4e -> :sswitch_5
        -0x3854c70e -> :sswitch_4
        -0x27d32f79 -> :sswitch_3
        -0x76b6783 -> :sswitch_2
        0xe0a3765 -> :sswitch_1
        0x51303e64 -> :sswitch_0
    .end sparse-switch

    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final waiBKÀ()V
    .locals 13

    .line 1
    iget-object v0, p0, LPNdgAQ$;->waiBKÀ:Landroid/app/NotificationManager;

    .line 2
    .line 3
    if-eqz v0, :cond_15

    .line 4
    .line 5
    iget-object v1, p0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    goto/16 :goto_9

    .line 10
    .line 11
    :cond_0
    iget-object v1, p0, LPNdgAQ$;->iOffset934:Lavt$p$;

    .line 12
    .line 13
    const/4 v2, 0x1

    .line 14
    const/4 v3, 0x0

    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    iget-object v1, v1, Lavt$p$;->waiBKÀ:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v1, Landroid/graphics/Bitmap;

    .line 20
    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    if-le v4, v2, :cond_1

    .line 28
    .line 29
    invoke-virtual {v1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    if-gt v4, v2, :cond_2

    .line 34
    .line 35
    :cond_1
    move-object v1, v3

    .line 36
    :cond_2
    new-instance v4, L$5$e_b$;

    .line 37
    .line 38
    iget-object v5, p0, LPNdgAQ$;->e8$mp_s$:Landroid/content/Context;

    .line 39
    .line 40
    const-string v6, "cast_media_notification"

    .line 41
    .line 42
    invoke-direct {v4, v5, v6}, L$5$e_b$;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v4, v1}, L$5$e_b$;->POOl(Landroid/graphics/Bitmap;)V

    .line 46
    .line 47
    .line 48
    iget-object v1, p0, LPNdgAQ$;->rz__9J_:LPVN$Zh_Vn$;

    .line 49
    .line 50
    iget v6, v1, LPVN$Zh_Vn$;->kQy:I

    .line 51
    .line 52
    iget-object v7, v4, L$5$e_b$;->tzKù7Ol1:Landroid/app/Notification;

    .line 53
    .line 54
    iput v6, v7, Landroid/app/Notification;->icon:I

    .line 55
    .line 56
    iget-object v6, p0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 57
    .line 58
    iget-object v6, v6, LgCount1307;->POOl:Ljava/lang/String;

    .line 59
    .line 60
    invoke-static {v6}, L$5$e_b$;->waiBKÀ(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    iput-object v6, v4, L$5$e_b$;->JKEoÙX:Ljava/lang/CharSequence;

    .line 65
    .line 66
    iget v6, v1, LPVN$Zh_Vn$;->sKey6064:I

    .line 67
    .line 68
    iget-object v7, p0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 69
    .line 70
    iget-object v7, v7, LgCount1307;->JKEoÙX:Ljava/lang/String;

    .line 71
    .line 72
    new-array v8, v2, [Ljava/lang/Object;

    .line 73
    .line 74
    const/4 v9, 0x0

    .line 75
    aput-object v7, v8, v9

    .line 76
    .line 77
    iget-object v7, p0, LPNdgAQ$;->vaIue:Landroid/content/res/Resources;

    .line 78
    .line 79
    invoke-virtual {v7, v6, v8}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v6

    .line 83
    invoke-static {v6}, L$5$e_b$;->waiBKÀ(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    iput-object v6, v4, L$5$e_b$;->tmpData3485:Ljava/lang/CharSequence;

    .line 88
    .line 89
    const/4 v6, 0x2

    .line 90
    invoke-virtual {v4, v6, v2}, L$5$e_b$;->rz__9J_(IZ)V

    .line 91
    .line 92
    .line 93
    iput-boolean v9, v4, L$5$e_b$;->vaIue:Z

    .line 94
    .line 95
    iput v2, v4, L$5$e_b$;->kCount1402:I

    .line 96
    .line 97
    iget-object v6, p0, LPNdgAQ$;->JKEoÙX:Landroid/content/ComponentName;

    .line 98
    .line 99
    if-nez v6, :cond_3

    .line 100
    .line 101
    move-object v6, v3

    .line 102
    goto :goto_1

    .line 103
    :cond_3
    new-instance v7, Landroid/content/Intent;

    .line 104
    .line 105
    invoke-direct {v7}, Landroid/content/Intent;-><init>()V

    .line 106
    .line 107
    .line 108
    const-string v8, "targetActivity"

    .line 109
    .line 110
    invoke-virtual {v7, v8, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v6}, Landroid/content/ComponentName;->flattenToString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v8

    .line 117
    invoke-virtual {v7, v8}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 118
    .line 119
    .line 120
    invoke-virtual {v7, v6}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 121
    .line 122
    .line 123
    new-instance v6, Ljava/util/ArrayList;

    .line 124
    .line 125
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v7}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    .line 129
    .line 130
    .line 131
    move-result-object v8

    .line 132
    if-nez v8, :cond_4

    .line 133
    .line 134
    invoke-virtual {v5}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 135
    .line 136
    .line 137
    move-result-object v8

    .line 138
    invoke-virtual {v7, v8}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    .line 139
    .line 140
    .line 141
    move-result-object v8

    .line 142
    :cond_4
    if-eqz v8, :cond_5

    .line 143
    .line 144
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 145
    .line 146
    .line 147
    move-result v10

    .line 148
    :try_start_0
    invoke-static {v5, v8}, LtmpData593;->Ialue(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 149
    .line 150
    .line 151
    move-result-object v8

    .line 152
    :goto_0
    if-eqz v8, :cond_5

    .line 153
    .line 154
    invoke-virtual {v6, v10, v8}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {v8}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    .line 158
    .line 159
    .line 160
    move-result-object v8

    .line 161
    invoke-static {v5, v8}, LtmpData593;->Ialue(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 162
    .line 163
    .line 164
    move-result-object v8
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    .line 165
    goto :goto_0

    .line 166
    :catch_0
    move-exception v0

    .line 167
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 168
    .line 169
    invoke-direct {v1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    .line 170
    .line 171
    .line 172
    throw v1

    .line 173
    :cond_5
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    sget v7, LgD1_x$l$_;->e8$mp_s$:I

    .line 177
    .line 178
    const/high16 v8, 0x8000000

    .line 179
    .line 180
    or-int/2addr v7, v8

    .line 181
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    .line 182
    .line 183
    .line 184
    move-result v8

    .line 185
    if-nez v8, :cond_14

    .line 186
    .line 187
    new-array v8, v9, [Landroid/content/Intent;

    .line 188
    .line 189
    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    move-result-object v6

    .line 193
    check-cast v6, [Landroid/content/Intent;

    .line 194
    .line 195
    new-instance v8, Landroid/content/Intent;

    .line 196
    .line 197
    aget-object v10, v6, v9

    .line 198
    .line 199
    invoke-direct {v8, v10}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    .line 200
    .line 201
    .line 202
    const v10, 0x1000c000

    .line 203
    .line 204
    .line 205
    invoke-virtual {v8, v10}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 206
    .line 207
    .line 208
    move-result-object v8

    .line 209
    aput-object v8, v6, v9

    .line 210
    .line 211
    invoke-static {v5, v2, v6, v7, v3}, Landroid/app/PendingIntent;->getActivities(Landroid/content/Context;I[Landroid/content/Intent;ILandroid/os/Bundle;)Landroid/app/PendingIntent;

    .line 212
    .line 213
    .line 214
    move-result-object v6

    .line 215
    :goto_1
    if-eqz v6, :cond_6

    .line 216
    .line 217
    iput-object v6, v4, L$5$e_b$;->sKey7917:Landroid/app/PendingIntent;

    .line 218
    .line 219
    :cond_6
    iget-object v6, v1, LPVN$Zh_Vn$;->iSize4906:LolO$6$;

    .line 220
    .line 221
    sget-object v7, LPNdgAQ$;->Qp_Hp$i_:LhiB_7$0y_;

    .line 222
    .line 223
    if-eqz v6, :cond_c

    .line 224
    .line 225
    new-array v1, v9, [Ljava/lang/Object;

    .line 226
    .line 227
    const-string v8, "actionsProvider != null"

    .line 228
    .line 229
    invoke-virtual {v7, v8, v1}, LhiB_7$0y_;->e8$mp_s$(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    invoke-static {v6}, LLl$l$;->waiBKÀ(LolO$6$;)[I

    .line 233
    .line 234
    .line 235
    move-result-object v1

    .line 236
    if-nez v1, :cond_7

    .line 237
    .line 238
    move-object v1, v3

    .line 239
    goto :goto_2

    .line 240
    :cond_7
    invoke-virtual {v1}, [I->clone()Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v1

    .line 244
    check-cast v1, [I

    .line 245
    .line 246
    :goto_2
    iput-object v1, p0, LPNdgAQ$;->sKey7917:[I

    .line 247
    .line 248
    invoke-static {v6}, LLl$l$;->e8$mp_s$(LolO$6$;)Ljava/util/ArrayList;

    .line 249
    .line 250
    .line 251
    move-result-object v1

    .line 252
    new-instance v6, Ljava/util/ArrayList;

    .line 253
    .line 254
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 255
    .line 256
    .line 257
    iput-object v6, p0, LPNdgAQ$;->tmpData3485:Ljava/util/ArrayList;

    .line 258
    .line 259
    if-nez v1, :cond_8

    .line 260
    .line 261
    goto/16 :goto_7

    .line 262
    .line 263
    :cond_8
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 264
    .line 265
    .line 266
    move-result v6

    .line 267
    const/4 v7, 0x0

    .line 268
    :cond_9
    :goto_3
    if-ge v7, v6, :cond_f

    .line 269
    .line 270
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    move-result-object v8

    .line 274
    add-int/lit8 v7, v7, 0x1

    .line 275
    .line 276
    check-cast v8, LldÈL;

    .line 277
    .line 278
    iget-object v10, v8, LldÈL;->yON3x:Ljava/lang/String;

    .line 279
    .line 280
    const-string v11, "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"

    .line 281
    .line 282
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 283
    .line 284
    .line 285
    move-result v11

    .line 286
    if-nez v11, :cond_b

    .line 287
    .line 288
    const-string v11, "com.google.android.gms.cast.framework.action.SKIP_NEXT"

    .line 289
    .line 290
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 291
    .line 292
    .line 293
    move-result v11

    .line 294
    if-nez v11, :cond_b

    .line 295
    .line 296
    const-string v11, "com.google.android.gms.cast.framework.action.SKIP_PREV"

    .line 297
    .line 298
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 299
    .line 300
    .line 301
    move-result v11

    .line 302
    if-nez v11, :cond_b

    .line 303
    .line 304
    const-string v11, "com.google.android.gms.cast.framework.action.FORWARD"

    .line 305
    .line 306
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 307
    .line 308
    .line 309
    move-result v11

    .line 310
    if-nez v11, :cond_b

    .line 311
    .line 312
    const-string v11, "com.google.android.gms.cast.framework.action.REWIND"

    .line 313
    .line 314
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 315
    .line 316
    .line 317
    move-result v11

    .line 318
    if-nez v11, :cond_b

    .line 319
    .line 320
    const-string v11, "com.google.android.gms.cast.framework.action.STOP_CASTING"

    .line 321
    .line 322
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 323
    .line 324
    .line 325
    move-result v11

    .line 326
    if-nez v11, :cond_b

    .line 327
    .line 328
    const-string v11, "com.google.android.gms.cast.framework.action.DISCONNECT"

    .line 329
    .line 330
    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 331
    .line 332
    .line 333
    move-result v11

    .line 334
    if-eqz v11, :cond_a

    .line 335
    .line 336
    goto :goto_4

    .line 337
    :cond_a
    new-instance v11, Landroid/content/Intent;

    .line 338
    .line 339
    invoke-direct {v11, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 340
    .line 341
    .line 342
    iget-object v10, p0, LPNdgAQ$;->POOl:Landroid/content/ComponentName;

    .line 343
    .line 344
    invoke-virtual {v11, v10}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 345
    .line 346
    .line 347
    sget v10, LgD1_x$l$_;->e8$mp_s$:I

    .line 348
    .line 349
    invoke-static {v5, v9, v11, v10}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 350
    .line 351
    .line 352
    move-result-object v10

    .line 353
    new-instance v11, LFÌ1scJWkW;

    .line 354
    .line 355
    iget v12, v8, LldÈL;->vaIue:I

    .line 356
    .line 357
    iget-object v8, v8, LldÈL;->jPos3709:Ljava/lang/String;

    .line 358
    .line 359
    invoke-direct {v11, v12, v8, v10}, LFÌ1scJWkW;-><init>(ILjava/lang/String;Landroid/app/PendingIntent;)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v11}, LFÌ1scJWkW;->e8$mp_s$()Ltbi;

    .line 363
    .line 364
    .line 365
    move-result-object v8

    .line 366
    goto :goto_5

    .line 367
    :cond_b
    :goto_4
    invoke-virtual {p0, v10}, LPNdgAQ$;->e8$mp_s$(Ljava/lang/String;)Ltbi;

    .line 368
    .line 369
    .line 370
    move-result-object v8

    .line 371
    :goto_5
    if-eqz v8, :cond_9

    .line 372
    .line 373
    iget-object v10, p0, LPNdgAQ$;->tmpData3485:Ljava/util/ArrayList;

    .line 374
    .line 375
    invoke-virtual {v10, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 376
    .line 377
    .line 378
    goto :goto_3

    .line 379
    :cond_c
    new-array v5, v9, [Ljava/lang/Object;

    .line 380
    .line 381
    const-string v6, "actionsProvider == null"

    .line 382
    .line 383
    invoke-virtual {v7, v6, v5}, LhiB_7$0y_;->e8$mp_s$(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 384
    .line 385
    .line 386
    new-instance v5, Ljava/util/ArrayList;

    .line 387
    .line 388
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 389
    .line 390
    .line 391
    iput-object v5, p0, LPNdgAQ$;->tmpData3485:Ljava/util/ArrayList;

    .line 392
    .line 393
    iget-object v5, v1, LPVN$Zh_Vn$;->yON3x:Ljava/util/ArrayList;

    .line 394
    .line 395
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 396
    .line 397
    .line 398
    move-result v6

    .line 399
    const/4 v7, 0x0

    .line 400
    :cond_d
    :goto_6
    if-ge v7, v6, :cond_e

    .line 401
    .line 402
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 403
    .line 404
    .line 405
    move-result-object v8

    .line 406
    add-int/lit8 v7, v7, 0x1

    .line 407
    .line 408
    check-cast v8, Ljava/lang/String;

    .line 409
    .line 410
    invoke-virtual {p0, v8}, LPNdgAQ$;->e8$mp_s$(Ljava/lang/String;)Ltbi;

    .line 411
    .line 412
    .line 413
    move-result-object v8

    .line 414
    if-eqz v8, :cond_d

    .line 415
    .line 416
    iget-object v10, p0, LPNdgAQ$;->tmpData3485:Ljava/util/ArrayList;

    .line 417
    .line 418
    invoke-virtual {v10, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 419
    .line 420
    .line 421
    goto :goto_6

    .line 422
    :cond_e
    iget-object v1, v1, LPVN$Zh_Vn$;->vaIue:[I

    .line 423
    .line 424
    array-length v5, v1

    .line 425
    invoke-static {v1, v5}, Ljava/util/Arrays;->copyOf([II)[I

    .line 426
    .line 427
    .line 428
    move-result-object v1

    .line 429
    invoke-virtual {v1}, [I->clone()Ljava/lang/Object;

    .line 430
    .line 431
    .line 432
    move-result-object v1

    .line 433
    check-cast v1, [I

    .line 434
    .line 435
    iput-object v1, p0, LPNdgAQ$;->sKey7917:[I

    .line 436
    .line 437
    :cond_f
    :goto_7
    iget-object v1, p0, LPNdgAQ$;->tmpData3485:Ljava/util/ArrayList;

    .line 438
    .line 439
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 440
    .line 441
    .line 442
    move-result v5

    .line 443
    :cond_10
    :goto_8
    if-ge v9, v5, :cond_11

    .line 444
    .line 445
    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 446
    .line 447
    .line 448
    move-result-object v6

    .line 449
    add-int/lit8 v9, v9, 0x1

    .line 450
    .line 451
    check-cast v6, Ltbi;

    .line 452
    .line 453
    if-eqz v6, :cond_10

    .line 454
    .line 455
    iget-object v7, v4, L$5$e_b$;->waiBKÀ:Ljava/util/ArrayList;

    .line 456
    .line 457
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 458
    .line 459
    .line 460
    goto :goto_8

    .line 461
    :cond_11
    new-instance v1, Ls0l1OQ;

    .line 462
    .line 463
    invoke-direct {v1}, Lv101;-><init>()V

    .line 464
    .line 465
    .line 466
    iput-object v3, v1, Ls0l1OQ;->e8$mp_s$:[I

    .line 467
    .line 468
    iget-object v3, p0, LPNdgAQ$;->sKey7917:[I

    .line 469
    .line 470
    if-eqz v3, :cond_12

    .line 471
    .line 472
    iput-object v3, v1, Ls0l1OQ;->e8$mp_s$:[I

    .line 473
    .line 474
    :cond_12
    iget-object v3, p0, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 475
    .line 476
    iget-object v3, v3, LgCount1307;->e8$mp_s$:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 477
    .line 478
    if-eqz v3, :cond_13

    .line 479
    .line 480
    iput-object v3, v1, Ls0l1OQ;->waiBKÀ:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 481
    .line 482
    :cond_13
    invoke-virtual {v4, v1}, L$5$e_b$;->JKEoÙX(Lv101;)V

    .line 483
    .line 484
    .line 485
    invoke-virtual {v4}, L$5$e_b$;->e8$mp_s$()Landroid/app/Notification;

    .line 486
    .line 487
    .line 488
    move-result-object v1

    .line 489
    const-string v3, "castMediaNotification"

    .line 490
    .line 491
    invoke-virtual {v0, v3, v2, v1}, Landroid/app/NotificationManager;->notify(Ljava/lang/String;ILandroid/app/Notification;)V

    .line 492
    .line 493
    .line 494
    return-void

    .line 495
    :cond_14
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 496
    .line 497
    const-string v1, "No intents added to TaskStackBuilder; cannot getPendingIntent"

    .line 498
    .line 499
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 500
    .line 501
    .line 502
    throw v0

    .line 503
    :cond_15
    :goto_9
    return-void
.end method
