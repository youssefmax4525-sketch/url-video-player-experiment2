.class public interface abstract LVTÈ5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB10I;


# virtual methods
.method public abstract rz__9J_(Ljava/lang/Throwable;)Z
.end method
