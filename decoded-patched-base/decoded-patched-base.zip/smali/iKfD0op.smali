.class public interface abstract LiKfD0op;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract DDù8(LjData6565;)V
.end method
