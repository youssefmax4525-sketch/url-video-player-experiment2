.class public final LhasCount8749;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:Landroid/content/Context;

.field public final rz__9J_:L$d7KXù;

.field public final waiBKÀ:L$d7KXù;


# direct methods
.method public constructor <init>(Landroid/content/Context;L$d7KXù;L$d7KXù;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LhasCount8749;->e8$mp_s$:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p2, p0, LhasCount8749;->waiBKÀ:L$d7KXù;

    .line 7
    .line 8
    iput-object p3, p0, LhasCount8749;->rz__9J_:L$d7KXù;

    .line 9
    .line 10
    return-void
.end method
