.class public final Le2$9Z$;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LPOE_cu_;
.implements LVB8J;


# instance fields
.field public final DDù8:LBqOjcA;

.field public final Ialue:Z

.field public final JKEoÙX:I

.field public K0I:LsIndex9566;

.field public final POOl:I

.field public Qp_Hp$i_:La9$I_FH$;

.field public final e8$mp_s$:LCÒllàY;

.field public gKey4112:Ll00;

.field public final iOffset934:L$1lD;

.field public final jPos3709:Ljava/util/List;

.field public kO_6X_:LWÒò;

.field public final kQy:I

.field public pCXDYg:Ljava/net/Socket;

.field public final rz__9J_:I

.field public final sKey7917:Z

.field public final tmpData3485:I

.field public final vaIue:LGIQ;

.field public volatile valuI:Z

.field public final waiBKÀ:LkOffset7125;

.field public final yON3x:LisOffset9756;

.field public yàÒZ:Ljava/net/Socket;


# direct methods
.method public constructor <init>(LCÒllàY;LkOffset7125;IIIIZLBqOjcA;LisOffset9756;LGIQ;Ljava/util/List;L$1lD;IZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Le2$9Z$;->e8$mp_s$:LCÒllàY;

    .line 5
    .line 6
    iput-object p2, p0, Le2$9Z$;->waiBKÀ:LkOffset7125;

    .line 7
    .line 8
    iput p3, p0, Le2$9Z$;->rz__9J_:I

    .line 9
    .line 10
    iput p4, p0, Le2$9Z$;->POOl:I

    .line 11
    .line 12
    iput p5, p0, Le2$9Z$;->JKEoÙX:I

    .line 13
    .line 14
    iput p6, p0, Le2$9Z$;->tmpData3485:I

    .line 15
    .line 16
    iput-boolean p7, p0, Le2$9Z$;->sKey7917:Z

    .line 17
    .line 18
    iput-object p8, p0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 19
    .line 20
    iput-object p9, p0, Le2$9Z$;->yON3x:LisOffset9756;

    .line 21
    .line 22
    iput-object p10, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 23
    .line 24
    iput-object p11, p0, Le2$9Z$;->jPos3709:Ljava/util/List;

    .line 25
    .line 26
    iput-object p12, p0, Le2$9Z$;->iOffset934:L$1lD;

    .line 27
    .line 28
    iput p13, p0, Le2$9Z$;->kQy:I

    .line 29
    .line 30
    iput-boolean p14, p0, Le2$9Z$;->Ialue:Z

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final DDù8()V
    .locals 4

    .line 1
    iget-object v0, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 2
    .line 3
    iget-object v0, v0, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    const/4 v0, -0x1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    sget-object v1, LG1Dl;->e8$mp_s$:[I

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    aget v0, v1, v0

    .line 20
    .line 21
    :goto_0
    const/4 v1, 0x1

    .line 22
    if-eq v0, v1, :cond_1

    .line 23
    .line 24
    const/4 v1, 0x2

    .line 25
    if-eq v0, v1, :cond_1

    .line 26
    .line 27
    new-instance v0, Ljava/net/Socket;

    .line 28
    .line 29
    iget-object v1, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 30
    .line 31
    iget-object v1, v1, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 32
    .line 33
    invoke-direct {v0, v1}, Ljava/net/Socket;-><init>(Ljava/net/Proxy;)V

    .line 34
    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_1
    iget-object v0, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 38
    .line 39
    iget-object v0, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 40
    .line 41
    iget-object v0, v0, LnValue2624;->waiBKÀ:Ljavax/net/SocketFactory;

    .line 42
    .line 43
    invoke-virtual {v0}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    .line 44
    .line 45
    .line 46
    move-result-object v0

    .line 47
    :goto_1
    iput-object v0, p0, Le2$9Z$;->pCXDYg:Ljava/net/Socket;

    .line 48
    .line 49
    iget-boolean v1, p0, Le2$9Z$;->valuI:Z

    .line 50
    .line 51
    if-nez v1, :cond_3

    .line 52
    .line 53
    iget v1, p0, Le2$9Z$;->tmpData3485:I

    .line 54
    .line 55
    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    .line 56
    .line 57
    .line 58
    :try_start_0
    sget-object v1, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 59
    .line 60
    sget-object v1, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 61
    .line 62
    iget-object v2, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 63
    .line 64
    iget-object v2, v2, LGIQ;->rz__9J_:Ljava/net/InetSocketAddress;

    .line 65
    .line 66
    iget v3, p0, Le2$9Z$;->JKEoÙX:I

    .line 67
    .line 68
    invoke-virtual {v1, v0, v2, v3}, LkValue8207;->tmpData3485(Ljava/net/Socket;Ljava/net/InetSocketAddress;I)V
    :try_end_0
    .catch Ljava/net/ConnectException; {:try_start_0 .. :try_end_0} :catch_1

    .line 69
    .line 70
    .line 71
    :try_start_1
    new-instance v1, LtmpCount1613;

    .line 72
    .line 73
    invoke-direct {v1, v0}, LtmpCount1613;-><init>(Ljava/net/Socket;)V

    .line 74
    .line 75
    .line 76
    new-instance v0, LsIndex9566;

    .line 77
    .line 78
    invoke-direct {v0, v1}, LsIndex9566;-><init>(LtmpCount1613;)V

    .line 79
    .line 80
    .line 81
    iput-object v0, p0, Le2$9Z$;->K0I:LsIndex9566;
    :try_end_1
    .catch Ljava/lang/NullPointerException; {:try_start_1 .. :try_end_1} :catch_0

    .line 82
    .line 83
    return-void

    .line 84
    :catch_0
    move-exception v0

    .line 85
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 86
    .line 87
    .line 88
    move-result-object v1

    .line 89
    const-string v2, "throw with null exception"

    .line 90
    .line 91
    invoke-static {v1, v2}, LdbÙLJ;->rz__9J_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    if-nez v1, :cond_2

    .line 96
    .line 97
    return-void

    .line 98
    :cond_2
    new-instance v1, Ljava/io/IOException;

    .line 99
    .line 100
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    .line 101
    .line 102
    .line 103
    throw v1

    .line 104
    :catch_1
    move-exception v0

    .line 105
    new-instance v1, Ljava/net/ConnectException;

    .line 106
    .line 107
    new-instance v2, Ljava/lang/StringBuilder;

    .line 108
    .line 109
    const-string v3, "Failed to connect to "

    .line 110
    .line 111
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    iget-object v3, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 115
    .line 116
    iget-object v3, v3, LGIQ;->rz__9J_:Ljava/net/InetSocketAddress;

    .line 117
    .line 118
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    invoke-direct {v1, v2}, Ljava/net/ConnectException;-><init>(Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 129
    .line 130
    .line 131
    throw v1

    .line 132
    :cond_3
    new-instance v0, Ljava/io/IOException;

    .line 133
    .line 134
    const-string v1, "canceled"

    .line 135
    .line 136
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 137
    .line 138
    .line 139
    throw v0
.end method

.method public final JKEoÙX(LvKey7702;Ljava/io/IOException;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final POOl()V
    .locals 0

    .line 1
    return-void
.end method

.method public final cancel()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Le2$9Z$;->valuI:Z

    .line 3
    .line 4
    iget-object v0, p0, Le2$9Z$;->pCXDYg:Ljava/net/Socket;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-static {v0}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 9
    .line 10
    .line 11
    :cond_0
    return-void
.end method

.method public final e8$mp_s$()LPOE_cu_;
    .locals 15

    .line 1
    new-instance v0, Le2$9Z$;

    .line 2
    .line 3
    iget v13, p0, Le2$9Z$;->kQy:I

    .line 4
    .line 5
    iget-boolean v14, p0, Le2$9Z$;->Ialue:Z

    .line 6
    .line 7
    iget-object v1, p0, Le2$9Z$;->e8$mp_s$:LCÒllàY;

    .line 8
    .line 9
    iget-object v2, p0, Le2$9Z$;->waiBKÀ:LkOffset7125;

    .line 10
    .line 11
    iget v3, p0, Le2$9Z$;->rz__9J_:I

    .line 12
    .line 13
    iget v4, p0, Le2$9Z$;->POOl:I

    .line 14
    .line 15
    iget v5, p0, Le2$9Z$;->JKEoÙX:I

    .line 16
    .line 17
    iget v6, p0, Le2$9Z$;->tmpData3485:I

    .line 18
    .line 19
    iget-boolean v7, p0, Le2$9Z$;->sKey7917:Z

    .line 20
    .line 21
    iget-object v8, p0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 22
    .line 23
    iget-object v9, p0, Le2$9Z$;->yON3x:LisOffset9756;

    .line 24
    .line 25
    iget-object v10, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 26
    .line 27
    iget-object v11, p0, Le2$9Z$;->jPos3709:Ljava/util/List;

    .line 28
    .line 29
    iget-object v12, p0, Le2$9Z$;->iOffset934:L$1lD;

    .line 30
    .line 31
    invoke-direct/range {v0 .. v14}, Le2$9Z$;-><init>(LCÒllàY;LkOffset7125;IIIIZLBqOjcA;LisOffset9756;LGIQ;Ljava/util/List;L$1lD;IZ)V

    .line 32
    .line 33
    .line 34
    return-object v0
.end method

.method public final iOffset934(Ljava/util/List;Ljavax/net/ssl/SSLSocket;)Le2$9Z$;
    .locals 3

    .line 1
    iget v0, p0, Le2$9Z$;->kQy:I

    .line 2
    .line 3
    const/4 v1, -0x1

    .line 4
    if-eq v0, v1, :cond_0

    .line 5
    .line 6
    return-object p0

    .line 7
    :cond_0
    invoke-virtual {p0, p1, p2}, Le2$9Z$;->jPos3709(Ljava/util/List;Ljavax/net/ssl/SSLSocket;)Le2$9Z$;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    if-eqz v0, :cond_1

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_1
    new-instance v0, Ljava/net/UnknownServiceException;

    .line 15
    .line 16
    new-instance v1, Ljava/lang/StringBuilder;

    .line 17
    .line 18
    const-string v2, "Unable to find acceptable protocols. isFallback="

    .line 19
    .line 20
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    iget-boolean v2, p0, Le2$9Z$;->Ialue:Z

    .line 24
    .line 25
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    const-string v2, ", modes="

    .line 29
    .line 30
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    const-string p1, ", supported protocols="

    .line 37
    .line 38
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 39
    .line 40
    .line 41
    invoke-virtual {p2}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-static {p1}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    const-string p2, "toString(...)"

    .line 50
    .line 51
    invoke-static {p2, p1}, LdbÙLJ;->sKey7917(Ljava/lang/String;Ljava/lang/Object;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    invoke-direct {v0, p1}, Ljava/net/UnknownServiceException;-><init>(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    throw v0
.end method

.method public final isReady()Z
    .locals 1

    .line 1
    iget-object v0, p0, Le2$9Z$;->kO_6X_:LWÒò;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    return v0

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    return v0
.end method

.method public final jPos3709(Ljava/util/List;Ljavax/net/ssl/SSLSocket;)Le2$9Z$;
    .locals 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Le2$9Z$;->kQy:I

    .line 4
    .line 5
    add-int/lit8 v2, v1, 0x1

    .line 6
    .line 7
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    :goto_0
    if-ge v2, v3, :cond_4

    .line 12
    .line 13
    move-object/from16 v4, p1

    .line 14
    .line 15
    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v5

    .line 19
    check-cast v5, LbO;

    .line 20
    .line 21
    iget-boolean v6, v5, LbO;->e8$mp_s$:Z

    .line 22
    .line 23
    if-nez v6, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    iget-object v6, v5, LbO;->POOl:[Ljava/lang/String;

    .line 27
    .line 28
    if-eqz v6, :cond_1

    .line 29
    .line 30
    invoke-virtual/range {p2 .. p2}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v7

    .line 34
    sget-object v8, LZAZ8;->vaIue:LZAZ8;

    .line 35
    .line 36
    invoke-static {v6, v7, v8}, LkOffset2117;->JKEoÙX([Ljava/lang/String;[Ljava/lang/String;Ljava/util/Comparator;)Z

    .line 37
    .line 38
    .line 39
    move-result v6

    .line 40
    if-nez v6, :cond_1

    .line 41
    .line 42
    goto :goto_1

    .line 43
    :cond_1
    iget-object v5, v5, LbO;->rz__9J_:[Ljava/lang/String;

    .line 44
    .line 45
    if-eqz v5, :cond_2

    .line 46
    .line 47
    invoke-virtual/range {p2 .. p2}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v6

    .line 51
    sget-object v7, LIG_7$a_;->rz__9J_:LuqQ$G_rc$;

    .line 52
    .line 53
    invoke-static {v5, v6, v7}, LkOffset2117;->JKEoÙX([Ljava/lang/String;[Ljava/lang/String;Ljava/util/Comparator;)Z

    .line 54
    .line 55
    .line 56
    move-result v5

    .line 57
    if-nez v5, :cond_2

    .line 58
    .line 59
    :goto_1
    add-int/lit8 v2, v2, 0x1

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    const/4 v3, -0x1

    .line 63
    if-eq v1, v3, :cond_3

    .line 64
    .line 65
    const/4 v1, 0x1

    .line 66
    const/16 v18, 0x1

    .line 67
    .line 68
    goto :goto_2

    .line 69
    :cond_3
    const/4 v1, 0x0

    .line 70
    const/16 v18, 0x0

    .line 71
    .line 72
    :goto_2
    new-instance v4, Le2$9Z$;

    .line 73
    .line 74
    iget-object v14, v0, Le2$9Z$;->vaIue:LGIQ;

    .line 75
    .line 76
    iget-object v15, v0, Le2$9Z$;->jPos3709:Ljava/util/List;

    .line 77
    .line 78
    iget-object v5, v0, Le2$9Z$;->e8$mp_s$:LCÒllàY;

    .line 79
    .line 80
    iget-object v6, v0, Le2$9Z$;->waiBKÀ:LkOffset7125;

    .line 81
    .line 82
    iget v7, v0, Le2$9Z$;->rz__9J_:I

    .line 83
    .line 84
    iget v8, v0, Le2$9Z$;->POOl:I

    .line 85
    .line 86
    iget v9, v0, Le2$9Z$;->JKEoÙX:I

    .line 87
    .line 88
    iget v10, v0, Le2$9Z$;->tmpData3485:I

    .line 89
    .line 90
    iget-boolean v11, v0, Le2$9Z$;->sKey7917:Z

    .line 91
    .line 92
    iget-object v12, v0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 93
    .line 94
    iget-object v13, v0, Le2$9Z$;->yON3x:LisOffset9756;

    .line 95
    .line 96
    iget-object v1, v0, Le2$9Z$;->iOffset934:L$1lD;

    .line 97
    .line 98
    move-object/from16 v16, v1

    .line 99
    .line 100
    move/from16 v17, v2

    .line 101
    .line 102
    invoke-direct/range {v4 .. v18}, Le2$9Z$;-><init>(LCÒllàY;LkOffset7125;IIIIZLBqOjcA;LisOffset9756;LGIQ;Ljava/util/List;L$1lD;IZ)V

    .line 103
    .line 104
    .line 105
    return-object v4

    .line 106
    :cond_4
    const/4 v1, 0x0

    .line 107
    return-object v1
.end method

.method public final rz__9J_()LsOffset2123;
    .locals 6

    .line 1
    iget-object v0, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 2
    .line 3
    iget-object v1, p0, Le2$9Z$;->pCXDYg:Ljava/net/Socket;

    .line 4
    .line 5
    if-nez v1, :cond_3

    .line 6
    .line 7
    iget-object v1, p0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 8
    .line 9
    invoke-virtual {v1, p0}, LBqOjcA;->POOl(Le2$9Z$;)V

    .line 10
    .line 11
    .line 12
    const/4 v2, 0x0

    .line 13
    :try_start_0
    invoke-virtual {p0}, Le2$9Z$;->DDù8()V

    .line 14
    .line 15
    .line 16
    const/4 v2, 0x1

    .line 17
    new-instance v3, LsOffset2123;

    .line 18
    .line 19
    const/4 v4, 0x0

    .line 20
    const/4 v5, 0x6

    .line 21
    invoke-direct {v3, p0, v4, v5}, LsOffset2123;-><init>(LPOE_cu_;Ljava/lang/Throwable;I)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 25
    .line 26
    .line 27
    return-object v3

    .line 28
    :catchall_0
    move-exception v0

    .line 29
    goto :goto_0

    .line 30
    :catch_0
    move-exception v3

    .line 31
    :try_start_1
    iget-object v4, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 32
    .line 33
    iget-object v4, v0, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 34
    .line 35
    invoke-virtual {v4}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    .line 36
    .line 37
    .line 38
    move-result-object v4

    .line 39
    sget-object v5, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    .line 40
    .line 41
    if-eq v4, v5, :cond_0

    .line 42
    .line 43
    iget-object v4, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 44
    .line 45
    iget-object v5, v4, LnValue2624;->sKey7917:Ljava/net/ProxySelector;

    .line 46
    .line 47
    iget-object v4, v4, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 48
    .line 49
    invoke-virtual {v4}, LUu_Kn$K_;->sKey7917()Ljava/net/URI;

    .line 50
    .line 51
    .line 52
    move-result-object v4

    .line 53
    iget-object v0, v0, LGIQ;->waiBKÀ:Ljava/net/Proxy;

    .line 54
    .line 55
    invoke-virtual {v0}, Ljava/net/Proxy;->address()Ljava/net/SocketAddress;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {v5, v4, v0, v3}, Ljava/net/ProxySelector;->connectFailed(Ljava/net/URI;Ljava/net/SocketAddress;Ljava/io/IOException;)V

    .line 60
    .line 61
    .line 62
    :cond_0
    new-instance v0, LsOffset2123;

    .line 63
    .line 64
    const/4 v4, 0x2

    .line 65
    invoke-direct {v0, p0, v3, v4}, LsOffset2123;-><init>(LPOE_cu_;Ljava/lang/Throwable;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 69
    .line 70
    .line 71
    if-nez v2, :cond_1

    .line 72
    .line 73
    iget-object v1, p0, Le2$9Z$;->pCXDYg:Ljava/net/Socket;

    .line 74
    .line 75
    if-eqz v1, :cond_1

    .line 76
    .line 77
    invoke-static {v1}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 78
    .line 79
    .line 80
    :cond_1
    return-object v0

    .line 81
    :goto_0
    invoke-virtual {v1, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 82
    .line 83
    .line 84
    if-nez v2, :cond_2

    .line 85
    .line 86
    iget-object v1, p0, Le2$9Z$;->pCXDYg:Ljava/net/Socket;

    .line 87
    .line 88
    if-eqz v1, :cond_2

    .line 89
    .line 90
    invoke-static {v1}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 91
    .line 92
    .line 93
    :cond_2
    throw v0

    .line 94
    :cond_3
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 95
    .line 96
    const-string v1, "TCP already connected"

    .line 97
    .line 98
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    throw v0
.end method

.method public final sKey7917()LGIQ;
    .locals 1

    .line 1
    iget-object v0, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 2
    .line 3
    return-object v0
.end method

.method public final tmpData3485()LsOffset2123;
    .locals 14

    .line 1
    iget-object v4, p0, Le2$9Z$;->pCXDYg:Ljava/net/Socket;

    .line 2
    .line 3
    if-eqz v4, :cond_13

    .line 4
    .line 5
    invoke-virtual {p0}, Le2$9Z$;->isReady()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_12

    .line 10
    .line 11
    iget-object v0, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 12
    .line 13
    iget-object v1, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 14
    .line 15
    iget-object v0, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 16
    .line 17
    iget-object v1, v1, LnValue2624;->vaIue:Ljava/util/List;

    .line 18
    .line 19
    iget-object v9, p0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 20
    .line 21
    invoke-virtual {v9, p0}, LBqOjcA;->POOl(Le2$9Z$;)V

    .line 22
    .line 23
    .line 24
    const/4 v10, 0x0

    .line 25
    const/4 v11, 0x0

    .line 26
    :try_start_0
    iget-object v2, p0, Le2$9Z$;->iOffset934:L$1lD;

    .line 27
    .line 28
    if-eqz v2, :cond_2

    .line 29
    .line 30
    invoke-virtual {p0}, Le2$9Z$;->vaIue()LsOffset2123;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    iget-object v3, v2, LsOffset2123;->waiBKÀ:LPOE_cu_;

    .line 35
    .line 36
    if-nez v3, :cond_0

    .line 37
    .line 38
    iget-object v3, v2, LsOffset2123;->rz__9J_:Ljava/lang/Throwable;
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 39
    .line 40
    if-eqz v3, :cond_2

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :catchall_0
    move-exception v0

    .line 44
    goto/16 :goto_5

    .line 45
    .line 46
    :catch_0
    move-exception v0

    .line 47
    move-object v1, v11

    .line 48
    goto/16 :goto_3

    .line 49
    .line 50
    :cond_0
    :goto_0
    invoke-virtual {v9, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 51
    .line 52
    .line 53
    iget-object v0, p0, Le2$9Z$;->yàÒZ:Ljava/net/Socket;

    .line 54
    .line 55
    if-eqz v0, :cond_1

    .line 56
    .line 57
    invoke-static {v0}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 58
    .line 59
    .line 60
    :cond_1
    invoke-static {v4}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 61
    .line 62
    .line 63
    return-object v2

    .line 64
    :cond_2
    :try_start_1
    iget-object v2, v0, LnValue2624;->rz__9J_:Ljavax/net/ssl/SSLSocketFactory;

    .line 65
    .line 66
    const/4 v12, 0x1

    .line 67
    if-eqz v2, :cond_6

    .line 68
    .line 69
    iget-object v2, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 70
    .line 71
    if-nez v2, :cond_3

    .line 72
    .line 73
    move-object v2, v11

    .line 74
    :cond_3
    iget-object v2, v2, LsIndex9566;->jPos3709:Ljava/lang/Object;

    .line 75
    .line 76
    check-cast v2, LIi11I;

    .line 77
    .line 78
    iget-object v2, v2, LIi11I;->vaIue:Lslze;

    .line 79
    .line 80
    invoke-virtual {v2}, Lslze;->DDù8()Z

    .line 81
    .line 82
    .line 83
    move-result v2

    .line 84
    if-eqz v2, :cond_5

    .line 85
    .line 86
    iget-object v2, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 87
    .line 88
    if-nez v2, :cond_4

    .line 89
    .line 90
    move-object v2, v11

    .line 91
    :cond_4
    iget-object v2, v2, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v2, Lhealot;

    .line 94
    .line 95
    iget-object v2, v2, Lhealot;->vaIue:Lslze;

    .line 96
    .line 97
    invoke-virtual {v2}, Lslze;->DDù8()Z

    .line 98
    .line 99
    .line 100
    move-result v2

    .line 101
    if-eqz v2, :cond_5

    .line 102
    .line 103
    iget-object v2, v0, LnValue2624;->rz__9J_:Ljavax/net/ssl/SSLSocketFactory;

    .line 104
    .line 105
    iget-object v0, v0, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 106
    .line 107
    iget-object v3, v0, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 108
    .line 109
    iget v0, v0, LUu_Kn$K_;->JKEoÙX:I

    .line 110
    .line 111
    invoke-virtual {v2, v4, v3, v0, v12}, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    check-cast v0, Ljavax/net/ssl/SSLSocket;

    .line 116
    .line 117
    invoke-virtual {p0, v1, v0}, Le2$9Z$;->iOffset934(Ljava/util/List;Ljavax/net/ssl/SSLSocket;)Le2$9Z$;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    iget v3, v2, Le2$9Z$;->kQy:I

    .line 122
    .line 123
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object v3

    .line 127
    check-cast v3, LbO;

    .line 128
    .line 129
    invoke-virtual {v2, v1, v0}, Le2$9Z$;->jPos3709(Ljava/util/List;Ljavax/net/ssl/SSLSocket;)Le2$9Z$;

    .line 130
    .line 131
    .line 132
    move-result-object v1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 133
    :try_start_2
    iget-boolean v2, v2, Le2$9Z$;->Ialue:Z

    .line 134
    .line 135
    invoke-virtual {v3, v0, v2}, LbO;->e8$mp_s$(Ljavax/net/ssl/SSLSocket;Z)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {p0, v0, v3}, Le2$9Z$;->yON3x(Ljavax/net/ssl/SSLSocket;LbO;)V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 139
    .line 140
    .line 141
    move-object v13, v1

    .line 142
    goto :goto_2

    .line 143
    :catch_1
    move-exception v0

    .line 144
    goto :goto_3

    .line 145
    :cond_5
    :try_start_3
    new-instance v0, Ljava/io/IOException;

    .line 146
    .line 147
    const-string v1, "TLS tunnel buffered too many bytes!"

    .line 148
    .line 149
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    throw v0

    .line 153
    :cond_6
    iput-object v4, p0, Le2$9Z$;->yàÒZ:Ljava/net/Socket;

    .line 154
    .line 155
    iget-object v0, v0, LnValue2624;->yON3x:Ljava/util/List;

    .line 156
    .line 157
    sget-object v1, LWÒò;->Ialue:LWÒò;

    .line 158
    .line 159
    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    if-eqz v0, :cond_7

    .line 164
    .line 165
    goto :goto_1

    .line 166
    :cond_7
    sget-object v1, LWÒò;->jPos3709:LWÒò;

    .line 167
    .line 168
    :goto_1
    iput-object v1, p0, Le2$9Z$;->kO_6X_:LWÒò;
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 169
    .line 170
    move-object v13, v11

    .line 171
    :goto_2
    :try_start_4
    new-instance v0, La9$I_FH$;

    .line 172
    .line 173
    iget-object v1, p0, Le2$9Z$;->e8$mp_s$:LCÒllàY;

    .line 174
    .line 175
    iget-object v2, p0, Le2$9Z$;->waiBKÀ:LkOffset7125;

    .line 176
    .line 177
    iget-object v3, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 178
    .line 179
    iget-object v5, p0, Le2$9Z$;->yàÒZ:Ljava/net/Socket;

    .line 180
    .line 181
    iget-object v6, p0, Le2$9Z$;->gKey4112:Ll00;

    .line 182
    .line 183
    iget-object v7, p0, Le2$9Z$;->kO_6X_:LWÒò;

    .line 184
    .line 185
    iget-object v8, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 186
    .line 187
    if-nez v8, :cond_8

    .line 188
    .line 189
    move-object v8, v11

    .line 190
    :cond_8
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 191
    .line 192
    .line 193
    invoke-direct/range {v0 .. v8}, La9$I_FH$;-><init>(LCÒllàY;LkOffset7125;LGIQ;Ljava/net/Socket;Ljava/net/Socket;Ll00;LWÒò;LsIndex9566;)V

    .line 194
    .line 195
    .line 196
    iput-object v0, p0, Le2$9Z$;->Qp_Hp$i_:La9$I_FH$;

    .line 197
    .line 198
    invoke-virtual {v0}, La9$I_FH$;->vaIue()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_3
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 199
    .line 200
    .line 201
    :try_start_5
    new-instance v0, LsOffset2123;

    .line 202
    .line 203
    const/4 v1, 0x6

    .line 204
    invoke-direct {v0, p0, v11, v1}, LsOffset2123;-><init>(LPOE_cu_;Ljava/lang/Throwable;I)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_5} :catch_2
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    .line 205
    .line 206
    .line 207
    invoke-virtual {v9, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 208
    .line 209
    .line 210
    return-object v0

    .line 211
    :catchall_1
    move-exception v0

    .line 212
    const/4 v10, 0x1

    .line 213
    goto :goto_5

    .line 214
    :catch_2
    move-exception v0

    .line 215
    move-object v1, v13

    .line 216
    const/4 v10, 0x1

    .line 217
    goto :goto_3

    .line 218
    :catch_3
    move-exception v0

    .line 219
    move-object v1, v13

    .line 220
    :goto_3
    :try_start_6
    iget-boolean v2, p0, Le2$9Z$;->sKey7917:Z

    .line 221
    .line 222
    if-eqz v2, :cond_d

    .line 223
    .line 224
    instance-of v2, v0, Ljava/net/ProtocolException;

    .line 225
    .line 226
    if-eqz v2, :cond_9

    .line 227
    .line 228
    goto :goto_4

    .line 229
    :cond_9
    instance-of v2, v0, Ljava/io/InterruptedIOException;

    .line 230
    .line 231
    if-eqz v2, :cond_a

    .line 232
    .line 233
    goto :goto_4

    .line 234
    :cond_a
    instance-of v2, v0, Ljavax/net/ssl/SSLHandshakeException;

    .line 235
    .line 236
    if-eqz v2, :cond_b

    .line 237
    .line 238
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 239
    .line 240
    .line 241
    move-result-object v2

    .line 242
    instance-of v2, v2, Ljava/security/cert/CertificateException;

    .line 243
    .line 244
    if-eqz v2, :cond_b

    .line 245
    .line 246
    goto :goto_4

    .line 247
    :cond_b
    instance-of v2, v0, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 248
    .line 249
    if-eqz v2, :cond_c

    .line 250
    .line 251
    goto :goto_4

    .line 252
    :cond_c
    instance-of v2, v0, Ljavax/net/ssl/SSLException;

    .line 253
    .line 254
    if-eqz v2, :cond_d

    .line 255
    .line 256
    move-object v11, v1

    .line 257
    :cond_d
    :goto_4
    new-instance v1, LsOffset2123;

    .line 258
    .line 259
    invoke-direct {v1, p0, v11, v0}, LsOffset2123;-><init>(LPOE_cu_;Le2$9Z$;Ljava/lang/Throwable;)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_0

    .line 260
    .line 261
    .line 262
    invoke-virtual {v9, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 263
    .line 264
    .line 265
    if-nez v10, :cond_f

    .line 266
    .line 267
    iget-object v0, p0, Le2$9Z$;->yàÒZ:Ljava/net/Socket;

    .line 268
    .line 269
    if-eqz v0, :cond_e

    .line 270
    .line 271
    invoke-static {v0}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 272
    .line 273
    .line 274
    :cond_e
    invoke-static {v4}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 275
    .line 276
    .line 277
    :cond_f
    return-object v1

    .line 278
    :goto_5
    invoke-virtual {v9, p0}, LBqOjcA;->k1y(Le2$9Z$;)V

    .line 279
    .line 280
    .line 281
    if-nez v10, :cond_11

    .line 282
    .line 283
    iget-object v1, p0, Le2$9Z$;->yàÒZ:Ljava/net/Socket;

    .line 284
    .line 285
    if-eqz v1, :cond_10

    .line 286
    .line 287
    invoke-static {v1}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 288
    .line 289
    .line 290
    :cond_10
    invoke-static {v4}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 291
    .line 292
    .line 293
    :cond_11
    throw v0

    .line 294
    :cond_12
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 295
    .line 296
    const-string v1, "already connected"

    .line 297
    .line 298
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 299
    .line 300
    .line 301
    throw v0

    .line 302
    :cond_13
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 303
    .line 304
    const-string v1, "TCP not connected"

    .line 305
    .line 306
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 307
    .line 308
    .line 309
    throw v0
.end method

.method public final vaIue()LsOffset2123;
    .locals 10

    .line 1
    iget-object v0, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 2
    .line 3
    iget-object v1, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 4
    .line 5
    iget-object v1, v1, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 6
    .line 7
    new-instance v2, Ljava/lang/StringBuilder;

    .line 8
    .line 9
    const-string v3, "CONNECT "

    .line 10
    .line 11
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    const/4 v3, 0x1

    .line 15
    invoke-static {v1, v3}, LyhM_S9$N_;->sKey7917(LUu_Kn$K_;Z)Ljava/lang/String;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 20
    .line 21
    .line 22
    const-string v1, " HTTP/1.1"

    .line 23
    .line 24
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    new-instance v2, LiValue2950;

    .line 32
    .line 33
    iget-object v3, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 34
    .line 35
    const/4 v4, 0x0

    .line 36
    if-nez v3, :cond_0

    .line 37
    .line 38
    move-object v3, v4

    .line 39
    :cond_0
    invoke-direct {v2, v4, p0, v3}, LiValue2950;-><init>(LtmpKey8240;LVB8J;LsIndex9566;)V

    .line 40
    .line 41
    .line 42
    iget-object v3, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 43
    .line 44
    if-nez v3, :cond_1

    .line 45
    .line 46
    move-object v3, v4

    .line 47
    :cond_1
    iget-object v3, v3, LsIndex9566;->jPos3709:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v3, LIi11I;

    .line 50
    .line 51
    iget-object v3, v3, LIi11I;->yON3x:LJTZ_Ka$1W_;

    .line 52
    .line 53
    invoke-interface {v3}, LJTZ_Ka$1W_;->e8$mp_s$()LSÌÙò9;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    iget v5, p0, Le2$9Z$;->rz__9J_:I

    .line 58
    .line 59
    int-to-long v5, v5

    .line 60
    sget-object v7, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 61
    .line 62
    invoke-virtual {v3, v5, v6}, LSÌÙò9;->sKey7917(J)LSÌÙò9;

    .line 63
    .line 64
    .line 65
    iget-object v3, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 66
    .line 67
    if-nez v3, :cond_2

    .line 68
    .line 69
    move-object v3, v4

    .line 70
    :cond_2
    iget-object v3, v3, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 71
    .line 72
    check-cast v3, Lhealot;

    .line 73
    .line 74
    iget-object v3, v3, Lhealot;->yON3x:LXG$Z_M$;

    .line 75
    .line 76
    invoke-interface {v3}, LXG$Z_M$;->e8$mp_s$()LSÌÙò9;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    iget v5, p0, Le2$9Z$;->POOl:I

    .line 81
    .line 82
    int-to-long v5, v5

    .line 83
    invoke-virtual {v3, v5, v6}, LSÌÙò9;->sKey7917(J)LSÌÙò9;

    .line 84
    .line 85
    .line 86
    iget-object v3, p0, Le2$9Z$;->iOffset934:L$1lD;

    .line 87
    .line 88
    iget-object v5, v3, L$1lD;->rz__9J_:LiIùBuO;

    .line 89
    .line 90
    invoke-virtual {v2, v5, v1}, LiValue2950;->iOffset934(LiIùBuO;Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    invoke-virtual {v2}, LiValue2950;->waiBKÀ()V

    .line 94
    .line 95
    .line 96
    const/4 v1, 0x0

    .line 97
    invoke-virtual {v2, v1}, LiValue2950;->tmpData3485(Z)LUX$zx$;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    iput-object v3, v1, LUX$zx$;->e8$mp_s$:L$1lD;

    .line 102
    .line 103
    invoke-virtual {v1}, LUX$zx$;->e8$mp_s$()LQìAQèLa;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    iget v3, v1, LQìAQèLa;->iOffset934:I

    .line 108
    .line 109
    invoke-static {v1}, LyhM_S9$N_;->POOl(LQìAQèLa;)J

    .line 110
    .line 111
    .line 112
    move-result-wide v5

    .line 113
    const-wide/16 v7, -0x1

    .line 114
    .line 115
    cmp-long v9, v5, v7

    .line 116
    .line 117
    if-nez v9, :cond_3

    .line 118
    .line 119
    goto :goto_0

    .line 120
    :cond_3
    iget-object v1, v1, LQìAQèLa;->yON3x:L$1lD;

    .line 121
    .line 122
    iget-object v1, v1, L$1lD;->e8$mp_s$:LUu_Kn$K_;

    .line 123
    .line 124
    invoke-virtual {v2, v1, v5, v6}, LiValue2950;->jPos3709(LUu_Kn$K_;J)LGZnS;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    const v2, 0x7fffffff

    .line 129
    .line 130
    .line 131
    invoke-static {v1, v2}, LyhM_S9$N_;->JKEoÙX(LJTZ_Ka$1W_;I)Z

    .line 132
    .line 133
    .line 134
    invoke-virtual {v1}, LGZnS;->close()V

    .line 135
    .line 136
    .line 137
    :goto_0
    const/16 v1, 0xc8

    .line 138
    .line 139
    if-eq v3, v1, :cond_5

    .line 140
    .line 141
    const/16 v1, 0x197

    .line 142
    .line 143
    if-ne v3, v1, :cond_4

    .line 144
    .line 145
    iget-object v0, v0, LGIQ;->e8$mp_s$:LnValue2624;

    .line 146
    .line 147
    iget-object v0, v0, LnValue2624;->tmpData3485:LLNùD;

    .line 148
    .line 149
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 150
    .line 151
    .line 152
    new-instance v0, Ljava/io/IOException;

    .line 153
    .line 154
    const-string v1, "Failed to authenticate with proxy"

    .line 155
    .line 156
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    throw v0

    .line 160
    :cond_4
    new-instance v0, Ljava/io/IOException;

    .line 161
    .line 162
    const-string v1, "Unexpected response code for CONNECT: "

    .line 163
    .line 164
    invoke-static {v3, v1}, LRQU_K6$Kv_;->jPos3709(ILjava/lang/String;)Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v1

    .line 168
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 169
    .line 170
    .line 171
    throw v0

    .line 172
    :cond_5
    new-instance v0, LsOffset2123;

    .line 173
    .line 174
    const/4 v1, 0x6

    .line 175
    invoke-direct {v0, p0, v4, v1}, LsOffset2123;-><init>(LPOE_cu_;Ljava/lang/Throwable;I)V

    .line 176
    .line 177
    .line 178
    return-object v0
.end method

.method public final waiBKÀ()La9$I_FH$;
    .locals 5

    .line 1
    iget-object v0, p0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 2
    .line 3
    iget-object v1, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 4
    .line 5
    invoke-virtual {v0, v1}, LBqOjcA;->iQ0D(LGIQ;)V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Le2$9Z$;->Qp_Hp$i_:La9$I_FH$;

    .line 9
    .line 10
    iget-object v1, p0, Le2$9Z$;->yON3x:LisOffset9756;

    .line 11
    .line 12
    iget-object v2, p0, Le2$9Z$;->jPos3709:Ljava/util/List;

    .line 13
    .line 14
    invoke-virtual {v1, p0, v2}, LisOffset9756;->DDù8(Le2$9Z$;Ljava/util/List;)LlQngth;

    .line 15
    .line 16
    .line 17
    move-result-object v1

    .line 18
    if-eqz v1, :cond_0

    .line 19
    .line 20
    iget-object v0, v1, LlQngth;->e8$mp_s$:La9$I_FH$;

    .line 21
    .line 22
    return-object v0

    .line 23
    :cond_0
    monitor-enter v0

    .line 24
    :try_start_0
    iget-object v1, p0, Le2$9Z$;->waiBKÀ:LkOffset7125;

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    sget-object v2, LyhM_S9$N_;->e8$mp_s$:Ljava/util/TimeZone;

    .line 30
    .line 31
    iget-object v2, v1, LkOffset7125;->JKEoÙX:Ljava/util/concurrent/ConcurrentLinkedQueue;

    .line 32
    .line 33
    invoke-virtual {v2, v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    iget-object v2, v1, LkOffset7125;->rz__9J_:Lco1nt;

    .line 37
    .line 38
    iget-object v1, v1, LkOffset7125;->POOl:LDni_4_;

    .line 39
    .line 40
    const-wide/16 v3, 0x0

    .line 41
    .line 42
    invoke-virtual {v2, v1, v3, v4}, Lco1nt;->POOl(LvaluO;J)V

    .line 43
    .line 44
    .line 45
    iget-object v1, p0, Le2$9Z$;->DDù8:LBqOjcA;

    .line 46
    .line 47
    invoke-virtual {v1, v0}, LBqOjcA;->e8$mp_s$(La9$I_FH$;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 48
    .line 49
    .line 50
    monitor-exit v0

    .line 51
    return-object v0

    .line 52
    :catchall_0
    move-exception v1

    .line 53
    monitor-exit v0

    .line 54
    throw v1
.end method

.method public final yON3x(Ljavax/net/ssl/SSLSocket;LbO;)V
    .locals 8

    .line 1
    const-string v0, "Hostname "

    .line 2
    .line 3
    const-string v1, "\n            |Hostname "

    .line 4
    .line 5
    iget-object v2, p0, Le2$9Z$;->vaIue:LGIQ;

    .line 6
    .line 7
    iget-object v2, v2, LGIQ;->e8$mp_s$:LnValue2624;

    .line 8
    .line 9
    :try_start_0
    iget-boolean v3, p2, LbO;->waiBKÀ:Z

    .line 10
    .line 11
    if-eqz v3, :cond_0

    .line 12
    .line 13
    sget-object v3, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 14
    .line 15
    sget-object v3, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 16
    .line 17
    iget-object v4, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 18
    .line 19
    iget-object v4, v4, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v5, v2, LnValue2624;->yON3x:Ljava/util/List;

    .line 22
    .line 23
    invoke-virtual {v3, p1, v4, v5}, LkValue8207;->JKEoÙX(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V

    .line 24
    .line 25
    .line 26
    goto :goto_0

    .line 27
    :catchall_0
    move-exception p2

    .line 28
    goto/16 :goto_2

    .line 29
    .line 30
    :cond_0
    :goto_0
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->startHandshake()V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getSession()Ljavax/net/ssl/SSLSession;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    invoke-static {v3}, LvB$7$;->sKey7917(Ljavax/net/ssl/SSLSession;)Ll00;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    iget-object v5, v2, LnValue2624;->POOl:Ljavax/net/ssl/HostnameVerifier;

    .line 42
    .line 43
    iget-object v6, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 44
    .line 45
    iget-object v6, v6, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 46
    .line 47
    invoke-interface {v5, v6, v3}, Ljavax/net/ssl/HostnameVerifier;->verify(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z

    .line 48
    .line 49
    .line 50
    move-result v3

    .line 51
    if-nez v3, :cond_2

    .line 52
    .line 53
    invoke-virtual {v4}, Ll00;->e8$mp_s$()Ljava/util/List;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    invoke-interface {p2}, Ljava/util/Collection;->isEmpty()Z

    .line 58
    .line 59
    .line 60
    move-result v3

    .line 61
    if-nez v3, :cond_1

    .line 62
    .line 63
    const/4 v0, 0x0

    .line 64
    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    check-cast p2, Ljava/security/cert/X509Certificate;

    .line 69
    .line 70
    new-instance v0, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 71
    .line 72
    new-instance v3, Ljava/lang/StringBuilder;

    .line 73
    .line 74
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    iget-object v1, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 78
    .line 79
    iget-object v1, v1, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 80
    .line 81
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    const-string v1, " not verified:\n            |    certificate: "

    .line 85
    .line 86
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    sget-object v1, LiOffset4404;->rz__9J_:LiOffset4404;

    .line 90
    .line 91
    invoke-static {p2}, LPJNypàa;->tzKù7Ol1(Ljava/security/cert/X509Certificate;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v1

    .line 95
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    const-string v1, "\n            |    DN: "

    .line 99
    .line 100
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    invoke-virtual {p2}, Ljava/security/cert/X509Certificate;->getSubjectDN()Ljava/security/Principal;

    .line 104
    .line 105
    .line 106
    move-result-object v1

    .line 107
    invoke-interface {v1}, Ljava/security/Principal;->getName()Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    const-string v1, "\n            |    subjectAltNames: "

    .line 115
    .line 116
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 117
    .line 118
    .line 119
    const/4 v1, 0x7

    .line 120
    invoke-static {p2, v1}, Lr0QD0O;->e8$mp_s$(Ljava/security/cert/X509Certificate;I)Ljava/util/List;

    .line 121
    .line 122
    .line 123
    move-result-object v1

    .line 124
    const/4 v2, 0x2

    .line 125
    invoke-static {p2, v2}, Lr0QD0O;->e8$mp_s$(Ljava/security/cert/X509Certificate;I)Ljava/util/List;

    .line 126
    .line 127
    .line 128
    move-result-object p2

    .line 129
    new-instance v2, Ljava/util/ArrayList;

    .line 130
    .line 131
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 132
    .line 133
    .line 134
    move-result v4

    .line 135
    invoke-interface {p2}, Ljava/util/Collection;->size()I

    .line 136
    .line 137
    .line 138
    move-result v5

    .line 139
    add-int/2addr v5, v4

    .line 140
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 141
    .line 142
    .line 143
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 144
    .line 145
    .line 146
    invoke-virtual {v2, p2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 147
    .line 148
    .line 149
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 150
    .line 151
    .line 152
    const-string p2, "\n            "

    .line 153
    .line 154
    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    invoke-static {p2}, LJTk;->valu0(Ljava/lang/String;)Ljava/lang/String;

    .line 162
    .line 163
    .line 164
    move-result-object p2

    .line 165
    invoke-direct {v0, p2}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    .line 166
    .line 167
    .line 168
    throw v0

    .line 169
    :cond_1
    new-instance p2, Ljavax/net/ssl/SSLPeerUnverifiedException;

    .line 170
    .line 171
    new-instance v1, Ljava/lang/StringBuilder;

    .line 172
    .line 173
    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    iget-object v0, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 177
    .line 178
    iget-object v0, v0, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 179
    .line 180
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 181
    .line 182
    .line 183
    const-string v0, " not verified (no certificates)"

    .line 184
    .line 185
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 186
    .line 187
    .line 188
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v0

    .line 192
    invoke-direct {p2, v0}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    .line 193
    .line 194
    .line 195
    throw p2

    .line 196
    :cond_2
    iget-object v0, v2, LnValue2624;->JKEoÙX:LiOffset4404;

    .line 197
    .line 198
    new-instance v1, Ll00;

    .line 199
    .line 200
    iget-object v3, v4, Ll00;->e8$mp_s$:LIi1IIi;

    .line 201
    .line 202
    iget-object v5, v4, Ll00;->waiBKÀ:LIG_7$a_;

    .line 203
    .line 204
    iget-object v6, v4, Ll00;->rz__9J_:Ljava/util/List;

    .line 205
    .line 206
    new-instance v7, Lm9_av_;

    .line 207
    .line 208
    invoke-direct {v7, v0, v4, v2}, Lm9_av_;-><init>(LiOffset4404;Ll00;LnValue2624;)V

    .line 209
    .line 210
    .line 211
    invoke-direct {v1, v3, v5, v6, v7}, Ll00;-><init>(LIi1IIi;LIG_7$a_;Ljava/util/List;LH2h_go_;)V

    .line 212
    .line 213
    .line 214
    iput-object v1, p0, Le2$9Z$;->gKey4112:Ll00;

    .line 215
    .line 216
    iget-object v1, v2, LnValue2624;->DDù8:LUu_Kn$K_;

    .line 217
    .line 218
    iget-object v1, v1, LUu_Kn$K_;->POOl:Ljava/lang/String;

    .line 219
    .line 220
    iget-object v0, v0, LiOffset4404;->e8$mp_s$:Ljava/util/Set;

    .line 221
    .line 222
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 227
    .line 228
    .line 229
    move-result v1

    .line 230
    const/4 v2, 0x0

    .line 231
    if-nez v1, :cond_5

    .line 232
    .line 233
    iget-boolean p2, p2, LbO;->waiBKÀ:Z

    .line 234
    .line 235
    if-eqz p2, :cond_3

    .line 236
    .line 237
    sget-object p2, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 238
    .line 239
    sget-object p2, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 240
    .line 241
    invoke-virtual {p2, p1}, LkValue8207;->sKey7917(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;

    .line 242
    .line 243
    .line 244
    move-result-object v2

    .line 245
    :cond_3
    iput-object p1, p0, Le2$9Z$;->yàÒZ:Ljava/net/Socket;

    .line 246
    .line 247
    new-instance p2, LtmpCount1613;

    .line 248
    .line 249
    invoke-direct {p2, p1}, LtmpCount1613;-><init>(Ljava/net/Socket;)V

    .line 250
    .line 251
    .line 252
    new-instance v0, LsIndex9566;

    .line 253
    .line 254
    invoke-direct {v0, p2}, LsIndex9566;-><init>(LtmpCount1613;)V

    .line 255
    .line 256
    .line 257
    iput-object v0, p0, Le2$9Z$;->K0I:LsIndex9566;

    .line 258
    .line 259
    if-eqz v2, :cond_4

    .line 260
    .line 261
    invoke-static {v2}, LmKB;->yàÒZ(Ljava/lang/String;)LWÒò;

    .line 262
    .line 263
    .line 264
    move-result-object p2

    .line 265
    goto :goto_1

    .line 266
    :cond_4
    sget-object p2, LWÒò;->jPos3709:LWÒò;

    .line 267
    .line 268
    :goto_1
    iput-object p2, p0, Le2$9Z$;->kO_6X_:LWÒò;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 269
    .line 270
    sget-object p1, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 271
    .line 272
    sget-object p1, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 273
    .line 274
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 275
    .line 276
    .line 277
    return-void

    .line 278
    :cond_5
    :try_start_1
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object p2

    .line 282
    invoke-static {p2}, LRQU_K6$Kv_;->Qp_Hp$i_(Ljava/lang/Object;)V

    .line 283
    .line 284
    .line 285
    throw v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 286
    :goto_2
    sget-object v0, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 287
    .line 288
    sget-object v0, LkValue8207;->e8$mp_s$:LkValue8207;

    .line 289
    .line 290
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 291
    .line 292
    .line 293
    invoke-static {p1}, LyhM_S9$N_;->waiBKÀ(Ljava/net/Socket;)V

    .line 294
    .line 295
    .line 296
    throw p2
.end method
