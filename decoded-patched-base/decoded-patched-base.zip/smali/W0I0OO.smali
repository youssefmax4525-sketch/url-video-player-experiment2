.class public final synthetic LW0I0OO;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic Ialue:Ljava/lang/Object;

.field public final synthetic iOffset934:Ljava/lang/String;

.field public final synthetic jPos3709:Ljava/lang/String;

.field public final synthetic kQy:Ljava/lang/Object;

.field public final synthetic vaIue:Ljava/lang/String;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 0

    .line 1
    iput p6, p0, LW0I0OO;->yON3x:I

    iput-object p1, p0, LW0I0OO;->kQy:Ljava/lang/Object;

    iput-object p2, p0, LW0I0OO;->Ialue:Ljava/lang/Object;

    iput-object p3, p0, LW0I0OO;->vaIue:Ljava/lang/String;

    iput-object p4, p0, LW0I0OO;->jPos3709:Ljava/lang/String;

    iput-object p5, p0, LW0I0OO;->iOffset934:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 17

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    iget v0, v1, LW0I0OO;->yON3x:I

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object v0, v1, LW0I0OO;->kQy:Ljava/lang/Object;

    .line 9
    .line 10
    move-object v2, v0

    .line 11
    check-cast v2, LUBK;

    .line 12
    .line 13
    iget-object v0, v1, LW0I0OO;->Ialue:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v0, Lorg/cybergarage/upnp/Device;

    .line 16
    .line 17
    iget-object v3, v1, LW0I0OO;->vaIue:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v4, v2, LUBK;->waiBKÀ:Landroid/os/Handler;

    .line 20
    .line 21
    const-string v5, "0"

    .line 22
    .line 23
    const-string v6, "InstanceID"

    .line 24
    .line 25
    const-string v7, "Error formatting metadata: "

    .line 26
    .line 27
    const-string v8, "Network error during URI setup: "

    .line 28
    .line 29
    const-string v9, "Error during play command: "

    .line 30
    .line 31
    const-string v10, "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\"><item id=\"1\" parentID=\"0\" restricted=\"0\"><dc:title>"

    .line 32
    .line 33
    const-string v11, "http-get:*:video/mp4:DLNA.ORG_PN=MP4_P;DLNA.ORG_OP=01;DLNA.ORG_FLAGS=01700000000000000000000000000000;DLNA.ORG_CI=0;DLNA.ORG_UA="

    .line 34
    .line 35
    :try_start_0
    const-string v12, "urn:schemas-upnp-org:service:AVTransport:1"

    .line 36
    .line 37
    invoke-virtual {v0, v12}, Lorg/cybergarage/upnp/Device;->getService(Ljava/lang/String;)Lorg/cybergarage/upnp/Service;

    .line 38
    .line 39
    .line 40
    move-result-object v12

    .line 41
    const-string v13, "SetAVTransportURI"

    .line 42
    .line 43
    invoke-virtual {v12, v13}, Lorg/cybergarage/upnp/Service;->getAction(Ljava/lang/String;)Lorg/cybergarage/upnp/Action;

    .line 44
    .line 45
    .line 46
    move-result-object v13

    .line 47
    invoke-virtual {v13, v6, v5}, Lorg/cybergarage/upnp/Action;->setArgumentValue(Ljava/lang/String;Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    const-string v14, "CurrentURI"

    .line 51
    .line 52
    invoke-virtual {v13, v14, v3}, Lorg/cybergarage/upnp/Action;->setArgumentValue(Ljava/lang/String;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    const-string v14, "http-get:*:video/mp4:*"
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 56
    .line 57
    iget-object v15, v1, LW0I0OO;->jPos3709:Ljava/lang/String;

    .line 58
    .line 59
    if-eqz v15, :cond_0

    .line 60
    .line 61
    :try_start_1
    invoke-virtual {v15}, Ljava/lang/String;->isEmpty()Z

    .line 62
    .line 63
    .line 64
    move-result v16

    .line 65
    if-nez v16, :cond_0

    .line 66
    .line 67
    invoke-virtual {v11, v15}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v14
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    .line 71
    goto :goto_0

    .line 72
    :catch_0
    move-exception v0

    .line 73
    goto/16 :goto_3

    .line 74
    .line 75
    :cond_0
    :goto_0
    :try_start_2
    const-string v11, "CurrentURIMetaData"

    .line 76
    .line 77
    new-instance v15, Ljava/lang/StringBuilder;

    .line 78
    .line 79
    invoke-direct {v15, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3

    .line 80
    .line 81
    .line 82
    iget-object v10, v1, LW0I0OO;->iOffset934:Ljava/lang/String;

    .line 83
    .line 84
    if-eqz v10, :cond_1

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_1
    :try_start_3
    const-string v10, "Video"

    .line 88
    .line 89
    :goto_1
    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string v10, "</dc:title><res protocolInfo=\""

    .line 93
    .line 94
    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    const-string v10, "\">"

    .line 101
    .line 102
    invoke-virtual {v15, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 103
    .line 104
    .line 105
    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    const-string v3, "</res><upnp:class>object.item.videoItem</upnp:class></item></DIDL-Lite>"

    .line 109
    .line 110
    invoke-virtual {v15, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v3

    .line 117
    invoke-virtual {v13, v11, v3}, Lorg/cybergarage/upnp/Action;->setArgumentValue(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 118
    .line 119
    .line 120
    :try_start_4
    invoke-virtual {v13}, Lorg/cybergarage/upnp/Action;->postControlAction()Z

    .line 121
    .line 122
    .line 123
    move-result v3
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    .line 124
    if-eqz v3, :cond_3

    .line 125
    .line 126
    :try_start_5
    const-string v3, "Play"

    .line 127
    .line 128
    invoke-virtual {v12, v3}, Lorg/cybergarage/upnp/Service;->getAction(Ljava/lang/String;)Lorg/cybergarage/upnp/Action;

    .line 129
    .line 130
    .line 131
    move-result-object v3

    .line 132
    if-eqz v3, :cond_2

    .line 133
    .line 134
    invoke-virtual {v3, v6, v5}, Lorg/cybergarage/upnp/Action;->setArgumentValue(Ljava/lang/String;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    const-string v5, "Speed"

    .line 138
    .line 139
    const-string v6, "1"

    .line 140
    .line 141
    invoke-virtual {v3, v5, v6}, Lorg/cybergarage/upnp/Action;->setArgumentValue(Ljava/lang/String;Ljava/lang/String;)V

    .line 142
    .line 143
    .line 144
    invoke-virtual {v3}, Lorg/cybergarage/upnp/Action;->postControlAction()Z

    .line 145
    .line 146
    .line 147
    move-result v3
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_1

    .line 148
    :try_start_6
    new-instance v5, Ltu$8c$;

    .line 149
    .line 150
    const/4 v6, 0x1

    .line 151
    invoke-direct {v5, v6, v2, v0, v3}, Ltu$8c$;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_0

    .line 155
    .line 156
    .line 157
    goto :goto_4

    .line 158
    :catch_1
    move-exception v0

    .line 159
    goto :goto_2

    .line 160
    :cond_2
    :try_start_7
    new-instance v0, Ljava/lang/Exception;

    .line 161
    .line 162
    const-string v3, "Play action not found"

    .line 163
    .line 164
    invoke-direct {v0, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 165
    .line 166
    .line 167
    throw v0
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_7} :catch_1

    .line 168
    :goto_2
    :try_start_8
    new-instance v3, Ljava/lang/Exception;

    .line 169
    .line 170
    new-instance v5, Ljava/lang/StringBuilder;

    .line 171
    .line 172
    invoke-direct {v5, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 176
    .line 177
    .line 178
    move-result-object v0

    .line 179
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 183
    .line 184
    .line 185
    move-result-object v0

    .line 186
    invoke-direct {v3, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 187
    .line 188
    .line 189
    throw v3
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_0

    .line 190
    :cond_3
    :try_start_9
    new-instance v0, Ljava/lang/Exception;

    .line 191
    .line 192
    const-string v3, "Failed to set transport URI"

    .line 193
    .line 194
    invoke-direct {v0, v3}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    throw v0
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_2

    .line 198
    :catch_2
    move-exception v0

    .line 199
    :try_start_a
    new-instance v3, Ljava/lang/Exception;

    .line 200
    .line 201
    new-instance v5, Ljava/lang/StringBuilder;

    .line 202
    .line 203
    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 211
    .line 212
    .line 213
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 214
    .line 215
    .line 216
    move-result-object v0

    .line 217
    invoke-direct {v3, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    throw v3

    .line 221
    :catch_3
    move-exception v0

    .line 222
    new-instance v3, Ljava/lang/Exception;

    .line 223
    .line 224
    new-instance v5, Ljava/lang/StringBuilder;

    .line 225
    .line 226
    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 230
    .line 231
    .line 232
    move-result-object v0

    .line 233
    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 234
    .line 235
    .line 236
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 237
    .line 238
    .line 239
    move-result-object v0

    .line 240
    invoke-direct {v3, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    throw v3
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_a} :catch_0

    .line 244
    :goto_3
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object v0

    .line 248
    new-instance v3, L_ag$q$;

    .line 249
    .line 250
    const/4 v5, 0x0

    .line 251
    invoke-direct {v3, v2, v0, v5}, L_ag$q$;-><init>(LUBK;Ljava/lang/String;I)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v4, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 255
    .line 256
    .line 257
    :goto_4
    return-void

    .line 258
    :pswitch_0
    iget-object v0, v1, LW0I0OO;->kQy:Ljava/lang/Object;

    .line 259
    .line 260
    move-object v2, v0

    .line 261
    check-cast v2, LjData4941;

    .line 262
    .line 263
    iget-object v0, v1, LW0I0OO;->Ialue:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast v0, Linfo/t4w/vp/airplay/AirPlayDevice;

    .line 266
    .line 267
    iget-object v3, v1, LW0I0OO;->jPos3709:Ljava/lang/String;

    .line 268
    .line 269
    iget-object v4, v1, LW0I0OO;->iOffset934:Ljava/lang/String;

    .line 270
    .line 271
    iget-object v5, v2, LjData4941;->waiBKÀ:Landroid/os/Handler;

    .line 272
    .line 273
    :try_start_b
    new-instance v6, Linfo/t4w/vp/airplay/AirPlayClient;

    .line 274
    .line 275
    invoke-direct {v6, v0}, Linfo/t4w/vp/airplay/AirPlayClient;-><init>(Linfo/t4w/vp/airplay/AirPlayDevice;)V
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_4

    .line 276
    .line 277
    .line 278
    iget-object v7, v1, LW0I0OO;->vaIue:Ljava/lang/String;

    .line 279
    .line 280
    if-eqz v7, :cond_4

    .line 281
    .line 282
    :try_start_c
    invoke-virtual {v7}, Ljava/lang/String;->isEmpty()Z

    .line 283
    .line 284
    .line 285
    move-result v8

    .line 286
    if-nez v8, :cond_4

    .line 287
    .line 288
    invoke-virtual {v6, v7}, Linfo/t4w/vp/airplay/AirPlayClient;->setUserAgent(Ljava/lang/String;)V
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_c} :catch_4

    .line 289
    .line 290
    .line 291
    goto :goto_5

    .line 292
    :catch_4
    move-exception v0

    .line 293
    goto :goto_7

    .line 294
    :cond_4
    :goto_5
    const/4 v7, 0x0

    .line 295
    const/4 v8, 0x0

    .line 296
    :goto_6
    const/4 v9, 0x2

    .line 297
    if-ge v7, v9, :cond_6

    .line 298
    .line 299
    if-nez v8, :cond_6

    .line 300
    .line 301
    if-lez v7, :cond_5

    .line 302
    .line 303
    const-wide/16 v8, 0x1f4

    .line 304
    .line 305
    :try_start_d
    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_d
    .catch Ljava/lang/InterruptedException; {:try_start_d .. :try_end_d} :catch_5
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_4

    .line 306
    .line 307
    .line 308
    :catch_5
    :cond_5
    :try_start_e
    invoke-virtual {v6, v3, v4}, Linfo/t4w/vp/airplay/AirPlayClient;->playVideo(Ljava/lang/String;Ljava/lang/String;)Z

    .line 309
    .line 310
    .line 311
    move-result v8

    .line 312
    add-int/lit8 v7, v7, 0x1

    .line 313
    .line 314
    goto :goto_6

    .line 315
    :cond_6
    new-instance v3, Ltu$8c$;

    .line 316
    .line 317
    const/4 v4, 0x0

    .line 318
    invoke-direct {v3, v4, v2, v0, v8}, Ltu$8c$;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 319
    .line 320
    .line 321
    invoke-virtual {v5, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_e} :catch_4

    .line 322
    .line 323
    .line 324
    goto :goto_8

    .line 325
    :goto_7
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 326
    .line 327
    .line 328
    move-result-object v0

    .line 329
    new-instance v3, LyaI1ì;

    .line 330
    .line 331
    const/4 v4, 0x0

    .line 332
    invoke-direct {v3, v2, v0, v4}, LyaI1ì;-><init>(LjData4941;Ljava/lang/String;I)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v5, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 336
    .line 337
    .line 338
    :goto_8
    return-void

    .line 339
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
