.class public final LKDlQl;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LisSize8185;


# instance fields
.field public DDù8:J

.field public Ialue:J

.field public JKEoÙX:I

.field public final POOl:LWnÀXqJ5;

.field public final e8$mp_s$:LYizKm;

.field public iOffset934:I

.field public jPos3709:LlIll11;

.field public kQy:J

.field public pCXDYg:Z

.field public final rz__9J_:Z

.field public sKey7917:LXRi$A5_0$;

.field public tmpData3485:LvD9$JN$;

.field public vaIue:J

.field public valuI:I

.field public final waiBKÀ:LHlMPQ;

.field public yON3x:[LlIll11;


# direct methods
.method public constructor <init>(LWnÀXqJ5;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LKDlQl;->POOl:LWnÀXqJ5;

    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, LKDlQl;->rz__9J_:Z

    .line 8
    .line 9
    new-instance p1, LYizKm;

    .line 10
    .line 11
    const/16 v0, 0xc

    .line 12
    .line 13
    invoke-direct {p1, v0}, LYizKm;-><init>(I)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, LKDlQl;->e8$mp_s$:LYizKm;

    .line 17
    .line 18
    new-instance p1, LHlMPQ;

    .line 19
    .line 20
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, LKDlQl;->waiBKÀ:LHlMPQ;

    .line 24
    .line 25
    new-instance p1, LWnÀXqJ5;

    .line 26
    .line 27
    const/16 v0, 0x1a

    .line 28
    .line 29
    invoke-direct {p1, v0}, LWnÀXqJ5;-><init>(I)V

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, LKDlQl;->tmpData3485:LvD9$JN$;

    .line 33
    .line 34
    const/4 p1, 0x0

    .line 35
    new-array p1, p1, [LlIll11;

    .line 36
    .line 37
    iput-object p1, p0, LKDlQl;->yON3x:[LlIll11;

    .line 38
    .line 39
    const-wide/16 v0, -0x1

    .line 40
    .line 41
    iput-wide v0, p0, LKDlQl;->kQy:J

    .line 42
    .line 43
    iput-wide v0, p0, LKDlQl;->Ialue:J

    .line 44
    .line 45
    const/4 p1, -0x1

    .line 46
    iput p1, p0, LKDlQl;->iOffset934:I

    .line 47
    .line 48
    const-wide v0, -0x7fffffffffffffffL    # -4.9E-324

    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    iput-wide v0, p0, LKDlQl;->DDù8:J

    .line 54
    .line 55
    return-void
.end method


# virtual methods
.method public final Ialue(JJ)V
    .locals 5

    .line 1
    const-wide/16 p3, -0x1

    .line 2
    .line 3
    iput-wide p3, p0, LKDlQl;->vaIue:J

    .line 4
    .line 5
    const/4 p3, 0x0

    .line 6
    iput-object p3, p0, LKDlQl;->jPos3709:LlIll11;

    .line 7
    .line 8
    iget-object p3, p0, LKDlQl;->yON3x:[LlIll11;

    .line 9
    .line 10
    array-length p4, p3

    .line 11
    const/4 v0, 0x0

    .line 12
    const/4 v1, 0x0

    .line 13
    :goto_0
    if-ge v1, p4, :cond_1

    .line 14
    .line 15
    aget-object v2, p3, v1

    .line 16
    .line 17
    iget v3, v2, LlIll11;->vaIue:I

    .line 18
    .line 19
    if-nez v3, :cond_0

    .line 20
    .line 21
    iput v0, v2, LlIll11;->DDù8:I

    .line 22
    .line 23
    goto :goto_1

    .line 24
    :cond_0
    iget-object v3, v2, LlIll11;->iOffset934:[J

    .line 25
    .line 26
    const/4 v4, 0x1

    .line 27
    invoke-static {v3, p1, p2, v4}, LnPos2706;->vaIue([JJZ)I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    iget-object v4, v2, LlIll11;->kQy:[I

    .line 32
    .line 33
    aget v3, v4, v3

    .line 34
    .line 35
    iput v3, v2, LlIll11;->DDù8:I

    .line 36
    .line 37
    :goto_1
    add-int/lit8 v1, v1, 0x1

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_1
    const-wide/16 p3, 0x0

    .line 41
    .line 42
    cmp-long v1, p1, p3

    .line 43
    .line 44
    if-nez v1, :cond_3

    .line 45
    .line 46
    iget-object p1, p0, LKDlQl;->yON3x:[LlIll11;

    .line 47
    .line 48
    array-length p1, p1

    .line 49
    if-nez p1, :cond_2

    .line 50
    .line 51
    goto :goto_2

    .line 52
    :cond_2
    const/4 v0, 0x3

    .line 53
    :goto_2
    iput v0, p0, LKDlQl;->JKEoÙX:I

    .line 54
    .line 55
    return-void

    .line 56
    :cond_3
    const/4 p1, 0x6

    .line 57
    iput p1, p0, LKDlQl;->JKEoÙX:I

    .line 58
    .line 59
    return-void
.end method

.method public final iOffset934(LxPsMK;)Z
    .locals 4

    .line 1
    iget-object v0, p0, LKDlQl;->e8$mp_s$:LYizKm;

    .line 2
    .line 3
    iget-object v1, v0, LYizKm;->e8$mp_s$:[B

    .line 4
    .line 5
    const/16 v2, 0xc

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-interface {p1, v1, v3, v2}, LxPsMK;->BCIm([BII)V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0, v3}, LYizKm;->vaIue(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, LYizKm;->gKey4112()I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    const v1, 0x46464952

    .line 19
    .line 20
    .line 21
    if-eq p1, v1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const/4 p1, 0x4

    .line 25
    invoke-virtual {v0, p1}, LYizKm;->jPos3709(I)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, LYizKm;->gKey4112()I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    const v0, 0x20495641

    .line 33
    .line 34
    .line 35
    if-ne p1, v0, :cond_1

    .line 36
    .line 37
    const/4 p1, 0x1

    .line 38
    return p1

    .line 39
    :cond_1
    :goto_0
    return v3
.end method

.method public final jPos3709(LxPsMK;LgUx$H8_De$;)I
    .locals 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget-wide v2, v0, LKDlQl;->vaIue:J

    .line 6
    .line 7
    const/4 v4, 0x1

    .line 8
    const/4 v5, 0x0

    .line 9
    const-wide/16 v6, -0x1

    .line 10
    .line 11
    cmp-long v8, v2, v6

    .line 12
    .line 13
    if-eqz v8, :cond_2

    .line 14
    .line 15
    move-object v8, v1

    .line 16
    check-cast v8, LoYxmSde;

    .line 17
    .line 18
    iget-wide v8, v8, LoYxmSde;->iOffset934:J

    .line 19
    .line 20
    cmp-long v10, v2, v8

    .line 21
    .line 22
    if-ltz v10, :cond_0

    .line 23
    .line 24
    const-wide/32 v10, 0x40000

    .line 25
    .line 26
    .line 27
    add-long/2addr v10, v8

    .line 28
    cmp-long v12, v2, v10

    .line 29
    .line 30
    if-lez v12, :cond_1

    .line 31
    .line 32
    :cond_0
    move-object/from16 v8, p2

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    sub-long/2addr v2, v8

    .line 36
    long-to-int v3, v2

    .line 37
    move-object v2, v1

    .line 38
    check-cast v2, LoYxmSde;

    .line 39
    .line 40
    invoke-virtual {v2, v3}, LoYxmSde;->sKey7917(I)V

    .line 41
    .line 42
    .line 43
    :cond_2
    const/4 v2, 0x0

    .line 44
    goto :goto_1

    .line 45
    :goto_0
    iput-wide v2, v8, LgUx$H8_De$;->e8$mp_s$:J

    .line 46
    .line 47
    const/4 v2, 0x1

    .line 48
    :goto_1
    iput-wide v6, v0, LKDlQl;->vaIue:J

    .line 49
    .line 50
    if-eqz v2, :cond_3

    .line 51
    .line 52
    return v4

    .line 53
    :cond_3
    iget v2, v0, LKDlQl;->JKEoÙX:I

    .line 54
    .line 55
    const/16 v3, 0xc

    .line 56
    .line 57
    const/4 v8, 0x0

    .line 58
    if-eqz v2, :cond_39

    .line 59
    .line 60
    const v9, 0x6c726468

    .line 61
    .line 62
    .line 63
    const v10, 0x5453494c

    .line 64
    .line 65
    .line 66
    const/4 v11, 0x2

    .line 67
    iget-object v12, v0, LKDlQl;->waiBKÀ:LHlMPQ;

    .line 68
    .line 69
    iget-object v13, v0, LKDlQl;->e8$mp_s$:LYizKm;

    .line 70
    .line 71
    if-eq v2, v4, :cond_36

    .line 72
    .line 73
    const/4 v14, 0x3

    .line 74
    if-eq v2, v11, :cond_2a

    .line 75
    .line 76
    const v9, 0x69766f6d

    .line 77
    .line 78
    .line 79
    const/4 v15, 0x6

    .line 80
    move-wide/from16 v16, v6

    .line 81
    .line 82
    const/4 v6, 0x4

    .line 83
    move-object v7, v12

    .line 84
    const/16 p2, 0x2

    .line 85
    .line 86
    const-wide/16 v18, 0x8

    .line 87
    .line 88
    const/16 v11, 0x10

    .line 89
    .line 90
    if-eq v2, v14, :cond_22

    .line 91
    .line 92
    const/4 v7, 0x5

    .line 93
    const/16 v12, 0x8

    .line 94
    .line 95
    if-eq v2, v6, :cond_20

    .line 96
    .line 97
    if-eq v2, v7, :cond_13

    .line 98
    .line 99
    move-object v2, v1

    .line 100
    check-cast v2, LoYxmSde;

    .line 101
    .line 102
    iget-wide v6, v2, LoYxmSde;->iOffset934:J

    .line 103
    .line 104
    iget-wide v14, v0, LKDlQl;->Ialue:J

    .line 105
    .line 106
    cmp-long v2, v6, v14

    .line 107
    .line 108
    if-ltz v2, :cond_4

    .line 109
    .line 110
    const/4 v1, -0x1

    .line 111
    return v1

    .line 112
    :cond_4
    iget-object v2, v0, LKDlQl;->jPos3709:LlIll11;

    .line 113
    .line 114
    if-eqz v2, :cond_a

    .line 115
    .line 116
    iget-object v3, v2, LlIll11;->e8$mp_s$:LwÒJK;

    .line 117
    .line 118
    iget v6, v2, LlIll11;->sKey7917:I

    .line 119
    .line 120
    invoke-interface {v3, v1, v6, v5}, LwÒJK;->rz__9J_(LSQ1I;IZ)I

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    sub-int/2addr v6, v1

    .line 125
    iput v6, v2, LlIll11;->sKey7917:I

    .line 126
    .line 127
    if-nez v6, :cond_5

    .line 128
    .line 129
    const/4 v1, 0x1

    .line 130
    goto :goto_2

    .line 131
    :cond_5
    const/4 v1, 0x0

    .line 132
    :goto_2
    if-eqz v1, :cond_8

    .line 133
    .line 134
    iget v6, v2, LlIll11;->tmpData3485:I

    .line 135
    .line 136
    if-lez v6, :cond_7

    .line 137
    .line 138
    iget v6, v2, LlIll11;->DDù8:I

    .line 139
    .line 140
    iget v7, v2, LlIll11;->JKEoÙX:I

    .line 141
    .line 142
    iget-wide v9, v2, LlIll11;->POOl:J

    .line 143
    .line 144
    int-to-long v11, v6

    .line 145
    mul-long v9, v9, v11

    .line 146
    .line 147
    int-to-long v11, v7

    .line 148
    div-long v21, v9, v11

    .line 149
    .line 150
    iget-object v7, v2, LlIll11;->kQy:[I

    .line 151
    .line 152
    invoke-static {v7, v6}, Ljava/util/Arrays;->binarySearch([II)I

    .line 153
    .line 154
    .line 155
    move-result v6

    .line 156
    if-ltz v6, :cond_6

    .line 157
    .line 158
    const/16 v23, 0x1

    .line 159
    .line 160
    goto :goto_3

    .line 161
    :cond_6
    const/16 v23, 0x0

    .line 162
    .line 163
    :goto_3
    iget v6, v2, LlIll11;->tmpData3485:I

    .line 164
    .line 165
    const/16 v25, 0x0

    .line 166
    .line 167
    const/16 v26, 0x0

    .line 168
    .line 169
    move-object/from16 v20, v3

    .line 170
    .line 171
    move/from16 v24, v6

    .line 172
    .line 173
    invoke-interface/range {v20 .. v26}, LwÒJK;->waiBKÀ(JIIILlF_um_;)V

    .line 174
    .line 175
    .line 176
    :cond_7
    iget v3, v2, LlIll11;->DDù8:I

    .line 177
    .line 178
    add-int/2addr v3, v4

    .line 179
    iput v3, v2, LlIll11;->DDù8:I

    .line 180
    .line 181
    :cond_8
    if-nez v1, :cond_9

    .line 182
    .line 183
    return v5

    .line 184
    :cond_9
    iput-object v8, v0, LKDlQl;->jPos3709:LlIll11;

    .line 185
    .line 186
    return v5

    .line 187
    :cond_a
    check-cast v1, LoYxmSde;

    .line 188
    .line 189
    iget-wide v6, v1, LoYxmSde;->iOffset934:J

    .line 190
    .line 191
    const-wide/16 v14, 0x1

    .line 192
    .line 193
    and-long/2addr v6, v14

    .line 194
    cmp-long v2, v6, v14

    .line 195
    .line 196
    if-nez v2, :cond_b

    .line 197
    .line 198
    invoke-virtual {v1, v4}, LoYxmSde;->sKey7917(I)V

    .line 199
    .line 200
    .line 201
    :cond_b
    iget-object v2, v13, LYizKm;->e8$mp_s$:[B

    .line 202
    .line 203
    invoke-virtual {v1, v2, v5, v3, v5}, LoYxmSde;->pQ1Il([BIIZ)Z

    .line 204
    .line 205
    .line 206
    invoke-virtual {v13, v5}, LYizKm;->vaIue(I)V

    .line 207
    .line 208
    .line 209
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 210
    .line 211
    .line 212
    move-result v2

    .line 213
    if-ne v2, v10, :cond_d

    .line 214
    .line 215
    invoke-virtual {v13, v12}, LYizKm;->vaIue(I)V

    .line 216
    .line 217
    .line 218
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 219
    .line 220
    .line 221
    move-result v2

    .line 222
    if-ne v2, v9, :cond_c

    .line 223
    .line 224
    goto :goto_4

    .line 225
    :cond_c
    const/16 v3, 0x8

    .line 226
    .line 227
    :goto_4
    invoke-virtual {v1, v3}, LoYxmSde;->sKey7917(I)V

    .line 228
    .line 229
    .line 230
    iput v5, v1, LoYxmSde;->Ialue:I

    .line 231
    .line 232
    return v5

    .line 233
    :cond_d
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 234
    .line 235
    .line 236
    move-result v3

    .line 237
    const v4, 0x4b4e554a    # 1.352225E7f

    .line 238
    .line 239
    .line 240
    if-ne v2, v4, :cond_e

    .line 241
    .line 242
    int-to-long v2, v3

    .line 243
    iget-wide v6, v1, LoYxmSde;->iOffset934:J

    .line 244
    .line 245
    add-long/2addr v6, v2

    .line 246
    add-long v6, v6, v18

    .line 247
    .line 248
    iput-wide v6, v0, LKDlQl;->vaIue:J

    .line 249
    .line 250
    return v5

    .line 251
    :cond_e
    invoke-virtual {v1, v12}, LoYxmSde;->sKey7917(I)V

    .line 252
    .line 253
    .line 254
    iput v5, v1, LoYxmSde;->Ialue:I

    .line 255
    .line 256
    iget-object v4, v0, LKDlQl;->yON3x:[LlIll11;

    .line 257
    .line 258
    array-length v6, v4

    .line 259
    const/4 v7, 0x0

    .line 260
    :goto_5
    if-ge v7, v6, :cond_11

    .line 261
    .line 262
    aget-object v9, v4, v7

    .line 263
    .line 264
    iget v10, v9, LlIll11;->waiBKÀ:I

    .line 265
    .line 266
    if-eq v10, v2, :cond_10

    .line 267
    .line 268
    iget v10, v9, LlIll11;->rz__9J_:I

    .line 269
    .line 270
    if-ne v10, v2, :cond_f

    .line 271
    .line 272
    goto :goto_6

    .line 273
    :cond_f
    add-int/lit8 v7, v7, 0x1

    .line 274
    .line 275
    goto :goto_5

    .line 276
    :cond_10
    :goto_6
    move-object v8, v9

    .line 277
    :cond_11
    if-nez v8, :cond_12

    .line 278
    .line 279
    int-to-long v2, v3

    .line 280
    iget-wide v6, v1, LoYxmSde;->iOffset934:J

    .line 281
    .line 282
    add-long/2addr v6, v2

    .line 283
    iput-wide v6, v0, LKDlQl;->vaIue:J

    .line 284
    .line 285
    return v5

    .line 286
    :cond_12
    iput v3, v8, LlIll11;->tmpData3485:I

    .line 287
    .line 288
    iput v3, v8, LlIll11;->sKey7917:I

    .line 289
    .line 290
    iput-object v8, v0, LKDlQl;->jPos3709:LlIll11;

    .line 291
    .line 292
    return v5

    .line 293
    :cond_13
    new-instance v2, LYizKm;

    .line 294
    .line 295
    iget v3, v0, LKDlQl;->valuI:I

    .line 296
    .line 297
    invoke-direct {v2, v3}, LYizKm;-><init>(I)V

    .line 298
    .line 299
    .line 300
    iget-object v3, v2, LYizKm;->e8$mp_s$:[B

    .line 301
    .line 302
    iget v6, v0, LKDlQl;->valuI:I

    .line 303
    .line 304
    check-cast v1, LoYxmSde;

    .line 305
    .line 306
    invoke-virtual {v1, v3, v5, v6, v5}, LoYxmSde;->Iii([BIIZ)Z

    .line 307
    .line 308
    .line 309
    invoke-virtual {v2}, LYizKm;->valuI()I

    .line 310
    .line 311
    .line 312
    move-result v1

    .line 313
    if-ge v1, v11, :cond_14

    .line 314
    .line 315
    const-wide/16 v20, 0x0

    .line 316
    .line 317
    goto :goto_8

    .line 318
    :cond_14
    iget v1, v2, LYizKm;->waiBKÀ:I

    .line 319
    .line 320
    invoke-virtual {v2, v12}, LYizKm;->jPos3709(I)V

    .line 321
    .line 322
    .line 323
    invoke-virtual {v2}, LYizKm;->gKey4112()I

    .line 324
    .line 325
    .line 326
    move-result v3

    .line 327
    int-to-long v6, v3

    .line 328
    iget-wide v9, v0, LKDlQl;->kQy:J

    .line 329
    .line 330
    cmp-long v3, v6, v9

    .line 331
    .line 332
    if-lez v3, :cond_15

    .line 333
    .line 334
    const-wide/16 v20, 0x0

    .line 335
    .line 336
    goto :goto_7

    .line 337
    :cond_15
    add-long v6, v9, v18

    .line 338
    .line 339
    move-wide/from16 v20, v6

    .line 340
    .line 341
    :goto_7
    invoke-virtual {v2, v1}, LYizKm;->vaIue(I)V

    .line 342
    .line 343
    .line 344
    :goto_8
    invoke-virtual {v2}, LYizKm;->valuI()I

    .line 345
    .line 346
    .line 347
    move-result v1

    .line 348
    if-lt v1, v11, :cond_1e

    .line 349
    .line 350
    invoke-virtual {v2}, LYizKm;->gKey4112()I

    .line 351
    .line 352
    .line 353
    move-result v1

    .line 354
    invoke-virtual {v2}, LYizKm;->gKey4112()I

    .line 355
    .line 356
    .line 357
    move-result v3

    .line 358
    invoke-virtual {v2}, LYizKm;->gKey4112()I

    .line 359
    .line 360
    .line 361
    move-result v6

    .line 362
    int-to-long v6, v6

    .line 363
    add-long v6, v6, v20

    .line 364
    .line 365
    invoke-virtual {v2}, LYizKm;->gKey4112()I

    .line 366
    .line 367
    .line 368
    iget-object v9, v0, LKDlQl;->yON3x:[LlIll11;

    .line 369
    .line 370
    array-length v10, v9

    .line 371
    const/4 v12, 0x0

    .line 372
    :goto_9
    if-ge v12, v10, :cond_17

    .line 373
    .line 374
    aget-object v13, v9, v12

    .line 375
    .line 376
    iget v8, v13, LlIll11;->waiBKÀ:I

    .line 377
    .line 378
    if-eq v8, v1, :cond_18

    .line 379
    .line 380
    iget v8, v13, LlIll11;->rz__9J_:I

    .line 381
    .line 382
    if-ne v8, v1, :cond_16

    .line 383
    .line 384
    goto :goto_a

    .line 385
    :cond_16
    add-int/lit8 v12, v12, 0x1

    .line 386
    .line 387
    const/4 v8, 0x0

    .line 388
    goto :goto_9

    .line 389
    :cond_17
    const/4 v13, 0x0

    .line 390
    :cond_18
    :goto_a
    if-eqz v13, :cond_1d

    .line 391
    .line 392
    and-int/lit8 v1, v3, 0x10

    .line 393
    .line 394
    if-ne v1, v11, :cond_19

    .line 395
    .line 396
    const/4 v1, 0x1

    .line 397
    goto :goto_b

    .line 398
    :cond_19
    const/4 v1, 0x0

    .line 399
    :goto_b
    iget-wide v8, v13, LlIll11;->jPos3709:J

    .line 400
    .line 401
    cmp-long v3, v8, v16

    .line 402
    .line 403
    if-nez v3, :cond_1a

    .line 404
    .line 405
    iput-wide v6, v13, LlIll11;->jPos3709:J

    .line 406
    .line 407
    :cond_1a
    if-eqz v1, :cond_1c

    .line 408
    .line 409
    iget v1, v13, LlIll11;->vaIue:I

    .line 410
    .line 411
    iget-object v3, v13, LlIll11;->kQy:[I

    .line 412
    .line 413
    array-length v3, v3

    .line 414
    if-ne v1, v3, :cond_1b

    .line 415
    .line 416
    iget-object v1, v13, LlIll11;->iOffset934:[J

    .line 417
    .line 418
    array-length v3, v1

    .line 419
    mul-int/lit8 v3, v3, 0x3

    .line 420
    .line 421
    div-int/lit8 v3, v3, 0x2

    .line 422
    .line 423
    invoke-static {v1, v3}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 424
    .line 425
    .line 426
    move-result-object v1

    .line 427
    iput-object v1, v13, LlIll11;->iOffset934:[J

    .line 428
    .line 429
    iget-object v1, v13, LlIll11;->kQy:[I

    .line 430
    .line 431
    array-length v3, v1

    .line 432
    mul-int/lit8 v3, v3, 0x3

    .line 433
    .line 434
    div-int/lit8 v3, v3, 0x2

    .line 435
    .line 436
    invoke-static {v1, v3}, Ljava/util/Arrays;->copyOf([II)[I

    .line 437
    .line 438
    .line 439
    move-result-object v1

    .line 440
    iput-object v1, v13, LlIll11;->kQy:[I

    .line 441
    .line 442
    :cond_1b
    iget-object v1, v13, LlIll11;->iOffset934:[J

    .line 443
    .line 444
    iget v3, v13, LlIll11;->vaIue:I

    .line 445
    .line 446
    aput-wide v6, v1, v3

    .line 447
    .line 448
    iget-object v1, v13, LlIll11;->kQy:[I

    .line 449
    .line 450
    iget v6, v13, LlIll11;->yON3x:I

    .line 451
    .line 452
    aput v6, v1, v3

    .line 453
    .line 454
    add-int/2addr v3, v4

    .line 455
    iput v3, v13, LlIll11;->vaIue:I

    .line 456
    .line 457
    :cond_1c
    iget v1, v13, LlIll11;->yON3x:I

    .line 458
    .line 459
    add-int/2addr v1, v4

    .line 460
    iput v1, v13, LlIll11;->yON3x:I

    .line 461
    .line 462
    :cond_1d
    const/4 v8, 0x0

    .line 463
    goto :goto_8

    .line 464
    :cond_1e
    iget-object v1, v0, LKDlQl;->yON3x:[LlIll11;

    .line 465
    .line 466
    array-length v2, v1

    .line 467
    const/4 v3, 0x0

    .line 468
    :goto_c
    if-ge v3, v2, :cond_1f

    .line 469
    .line 470
    aget-object v6, v1, v3

    .line 471
    .line 472
    iget-object v7, v6, LlIll11;->iOffset934:[J

    .line 473
    .line 474
    iget v8, v6, LlIll11;->vaIue:I

    .line 475
    .line 476
    invoke-static {v7, v8}, Ljava/util/Arrays;->copyOf([JI)[J

    .line 477
    .line 478
    .line 479
    move-result-object v7

    .line 480
    iput-object v7, v6, LlIll11;->iOffset934:[J

    .line 481
    .line 482
    iget-object v7, v6, LlIll11;->kQy:[I

    .line 483
    .line 484
    iget v8, v6, LlIll11;->vaIue:I

    .line 485
    .line 486
    invoke-static {v7, v8}, Ljava/util/Arrays;->copyOf([II)[I

    .line 487
    .line 488
    .line 489
    move-result-object v7

    .line 490
    iput-object v7, v6, LlIll11;->kQy:[I

    .line 491
    .line 492
    add-int/lit8 v3, v3, 0x1

    .line 493
    .line 494
    goto :goto_c

    .line 495
    :cond_1f
    iput-boolean v4, v0, LKDlQl;->pCXDYg:Z

    .line 496
    .line 497
    iget-object v1, v0, LKDlQl;->tmpData3485:LvD9$JN$;

    .line 498
    .line 499
    new-instance v2, LisData7872;

    .line 500
    .line 501
    iget-wide v3, v0, LKDlQl;->DDù8:J

    .line 502
    .line 503
    const/4 v6, 0x2

    .line 504
    invoke-direct {v2, v0, v3, v4, v6}, LisData7872;-><init>(Ljava/lang/Object;JI)V

    .line 505
    .line 506
    .line 507
    invoke-interface {v1, v2}, LvD9$JN$;->Q1_f_(LkQQ;)V

    .line 508
    .line 509
    .line 510
    iput v15, v0, LKDlQl;->JKEoÙX:I

    .line 511
    .line 512
    iget-wide v1, v0, LKDlQl;->kQy:J

    .line 513
    .line 514
    iput-wide v1, v0, LKDlQl;->vaIue:J

    .line 515
    .line 516
    return v5

    .line 517
    :cond_20
    iget-object v2, v13, LYizKm;->e8$mp_s$:[B

    .line 518
    .line 519
    move-object v3, v1

    .line 520
    check-cast v3, LoYxmSde;

    .line 521
    .line 522
    invoke-virtual {v3, v2, v5, v12, v5}, LoYxmSde;->Iii([BIIZ)Z

    .line 523
    .line 524
    .line 525
    invoke-virtual {v13, v5}, LYizKm;->vaIue(I)V

    .line 526
    .line 527
    .line 528
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 529
    .line 530
    .line 531
    move-result v2

    .line 532
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 533
    .line 534
    .line 535
    move-result v3

    .line 536
    const v4, 0x31786469

    .line 537
    .line 538
    .line 539
    if-ne v2, v4, :cond_21

    .line 540
    .line 541
    iput v7, v0, LKDlQl;->JKEoÙX:I

    .line 542
    .line 543
    iput v3, v0, LKDlQl;->valuI:I

    .line 544
    .line 545
    return v5

    .line 546
    :cond_21
    check-cast v1, LoYxmSde;

    .line 547
    .line 548
    iget-wide v1, v1, LoYxmSde;->iOffset934:J

    .line 549
    .line 550
    int-to-long v3, v3

    .line 551
    add-long/2addr v1, v3

    .line 552
    iput-wide v1, v0, LKDlQl;->vaIue:J

    .line 553
    .line 554
    return v5

    .line 555
    :cond_22
    move-object v2, v7

    .line 556
    iget-wide v6, v0, LKDlQl;->kQy:J

    .line 557
    .line 558
    cmp-long v12, v6, v16

    .line 559
    .line 560
    if-eqz v12, :cond_24

    .line 561
    .line 562
    move-object v12, v1

    .line 563
    check-cast v12, LoYxmSde;

    .line 564
    .line 565
    const/16 v16, 0x10

    .line 566
    .line 567
    iget-wide v11, v12, LoYxmSde;->iOffset934:J

    .line 568
    .line 569
    cmp-long v14, v11, v6

    .line 570
    .line 571
    if-nez v14, :cond_23

    .line 572
    .line 573
    goto :goto_d

    .line 574
    :cond_23
    iput-wide v6, v0, LKDlQl;->vaIue:J

    .line 575
    .line 576
    return v5

    .line 577
    :cond_24
    const/16 v16, 0x10

    .line 578
    .line 579
    :goto_d
    iget-object v6, v13, LYizKm;->e8$mp_s$:[B

    .line 580
    .line 581
    move-object v7, v1

    .line 582
    check-cast v7, LoYxmSde;

    .line 583
    .line 584
    invoke-virtual {v7, v6, v5, v3, v5}, LoYxmSde;->pQ1Il([BIIZ)Z

    .line 585
    .line 586
    .line 587
    check-cast v1, LoYxmSde;

    .line 588
    .line 589
    iput v5, v1, LoYxmSde;->Ialue:I

    .line 590
    .line 591
    invoke-virtual {v13, v5}, LYizKm;->vaIue(I)V

    .line 592
    .line 593
    .line 594
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 595
    .line 596
    .line 597
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 598
    .line 599
    .line 600
    move-result v6

    .line 601
    iput v6, v2, LHlMPQ;->e8$mp_s$:I

    .line 602
    .line 603
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 604
    .line 605
    .line 606
    move-result v6

    .line 607
    iput v6, v2, LHlMPQ;->waiBKÀ:I

    .line 608
    .line 609
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 610
    .line 611
    .line 612
    move-result v6

    .line 613
    iget v7, v2, LHlMPQ;->e8$mp_s$:I

    .line 614
    .line 615
    const v11, 0x46464952

    .line 616
    .line 617
    .line 618
    if-ne v7, v11, :cond_25

    .line 619
    .line 620
    invoke-virtual {v1, v3}, LoYxmSde;->sKey7917(I)V

    .line 621
    .line 622
    .line 623
    return v5

    .line 624
    :cond_25
    if-ne v7, v10, :cond_29

    .line 625
    .line 626
    if-eq v6, v9, :cond_26

    .line 627
    .line 628
    goto :goto_f

    .line 629
    :cond_26
    iget-wide v6, v1, LoYxmSde;->iOffset934:J

    .line 630
    .line 631
    iput-wide v6, v0, LKDlQl;->kQy:J

    .line 632
    .line 633
    iget v2, v2, LHlMPQ;->waiBKÀ:I

    .line 634
    .line 635
    int-to-long v2, v2

    .line 636
    add-long/2addr v6, v2

    .line 637
    add-long v6, v6, v18

    .line 638
    .line 639
    iput-wide v6, v0, LKDlQl;->Ialue:J

    .line 640
    .line 641
    iget-boolean v2, v0, LKDlQl;->pCXDYg:Z

    .line 642
    .line 643
    if-nez v2, :cond_28

    .line 644
    .line 645
    iget-object v2, v0, LKDlQl;->sKey7917:LXRi$A5_0$;

    .line 646
    .line 647
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 648
    .line 649
    .line 650
    iget v2, v2, LXRi$A5_0$;->waiBKÀ:I

    .line 651
    .line 652
    and-int/lit8 v2, v2, 0x10

    .line 653
    .line 654
    const/16 v3, 0x10

    .line 655
    .line 656
    if-eq v2, v3, :cond_27

    .line 657
    .line 658
    iget-object v2, v0, LKDlQl;->tmpData3485:LvD9$JN$;

    .line 659
    .line 660
    new-instance v3, LisData7872;

    .line 661
    .line 662
    iget-wide v6, v0, LKDlQl;->DDù8:J

    .line 663
    .line 664
    const-wide/16 v8, 0x0

    .line 665
    .line 666
    invoke-direct {v3, v6, v7, v8, v9}, LisData7872;-><init>(JJ)V

    .line 667
    .line 668
    .line 669
    invoke-interface {v2, v3}, LvD9$JN$;->Q1_f_(LkQQ;)V

    .line 670
    .line 671
    .line 672
    iput-boolean v4, v0, LKDlQl;->pCXDYg:Z

    .line 673
    .line 674
    goto :goto_e

    .line 675
    :cond_27
    const/4 v8, 0x4

    .line 676
    iput v8, v0, LKDlQl;->JKEoÙX:I

    .line 677
    .line 678
    iput-wide v6, v0, LKDlQl;->vaIue:J

    .line 679
    .line 680
    return v5

    .line 681
    :cond_28
    :goto_e
    iget-wide v1, v1, LoYxmSde;->iOffset934:J

    .line 682
    .line 683
    const-wide/16 v3, 0xc

    .line 684
    .line 685
    add-long/2addr v1, v3

    .line 686
    iput-wide v1, v0, LKDlQl;->vaIue:J

    .line 687
    .line 688
    iput v15, v0, LKDlQl;->JKEoÙX:I

    .line 689
    .line 690
    return v5

    .line 691
    :cond_29
    :goto_f
    iget-wide v3, v1, LoYxmSde;->iOffset934:J

    .line 692
    .line 693
    iget v1, v2, LHlMPQ;->waiBKÀ:I

    .line 694
    .line 695
    int-to-long v1, v1

    .line 696
    add-long/2addr v3, v1

    .line 697
    add-long v3, v3, v18

    .line 698
    .line 699
    iput-wide v3, v0, LKDlQl;->vaIue:J

    .line 700
    .line 701
    return v5

    .line 702
    :cond_2a
    const/16 p2, 0x2

    .line 703
    .line 704
    iget v2, v0, LKDlQl;->iOffset934:I

    .line 705
    .line 706
    add-int/lit8 v2, v2, -0x4

    .line 707
    .line 708
    new-instance v3, LYizKm;

    .line 709
    .line 710
    invoke-direct {v3, v2}, LYizKm;-><init>(I)V

    .line 711
    .line 712
    .line 713
    iget-object v6, v3, LYizKm;->e8$mp_s$:[B

    .line 714
    .line 715
    check-cast v1, LoYxmSde;

    .line 716
    .line 717
    invoke-virtual {v1, v6, v5, v2, v5}, LoYxmSde;->Iii([BIIZ)Z

    .line 718
    .line 719
    .line 720
    invoke-static {v9, v3}, LgCount4526;->rz__9J_(ILYizKm;)LgCount4526;

    .line 721
    .line 722
    .line 723
    move-result-object v1

    .line 724
    iget v2, v1, LgCount4526;->waiBKÀ:I

    .line 725
    .line 726
    if-ne v2, v9, :cond_35

    .line 727
    .line 728
    const-class v2, LXRi$A5_0$;

    .line 729
    .line 730
    invoke-virtual {v1, v2}, LgCount4526;->waiBKÀ(Ljava/lang/Class;)Lenb;

    .line 731
    .line 732
    .line 733
    move-result-object v2

    .line 734
    check-cast v2, LXRi$A5_0$;

    .line 735
    .line 736
    if-eqz v2, :cond_34

    .line 737
    .line 738
    iput-object v2, v0, LKDlQl;->sKey7917:LXRi$A5_0$;

    .line 739
    .line 740
    iget v3, v2, LXRi$A5_0$;->rz__9J_:I

    .line 741
    .line 742
    iget v2, v2, LXRi$A5_0$;->e8$mp_s$:I

    .line 743
    .line 744
    int-to-long v6, v3

    .line 745
    int-to-long v2, v2

    .line 746
    mul-long v6, v6, v2

    .line 747
    .line 748
    iput-wide v6, v0, LKDlQl;->DDù8:J

    .line 749
    .line 750
    new-instance v2, Ljava/util/ArrayList;

    .line 751
    .line 752
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 753
    .line 754
    .line 755
    iget-object v1, v1, LgCount4526;->e8$mp_s$:LnW_cN_;

    .line 756
    .line 757
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 758
    .line 759
    .line 760
    move-result v3

    .line 761
    const/4 v6, 0x0

    .line 762
    const/4 v8, 0x0

    .line 763
    :goto_10
    if-ge v6, v3, :cond_33

    .line 764
    .line 765
    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 766
    .line 767
    .line 768
    move-result-object v7

    .line 769
    check-cast v7, Lenb;

    .line 770
    .line 771
    invoke-interface {v7}, Lenb;->e8$mp_s$()I

    .line 772
    .line 773
    .line 774
    move-result v9

    .line 775
    const v10, 0x6c727473

    .line 776
    .line 777
    .line 778
    if-ne v9, v10, :cond_32

    .line 779
    .line 780
    check-cast v7, LgCount4526;

    .line 781
    .line 782
    add-int/lit8 v15, v8, 0x1

    .line 783
    .line 784
    const-class v9, LUwV$b_h$;

    .line 785
    .line 786
    invoke-virtual {v7, v9}, LgCount4526;->waiBKÀ(Ljava/lang/Class;)Lenb;

    .line 787
    .line 788
    .line 789
    move-result-object v9

    .line 790
    check-cast v9, LUwV$b_h$;

    .line 791
    .line 792
    const-class v10, LIIlllI;

    .line 793
    .line 794
    invoke-virtual {v7, v10}, LgCount4526;->waiBKÀ(Ljava/lang/Class;)Lenb;

    .line 795
    .line 796
    .line 797
    move-result-object v10

    .line 798
    check-cast v10, LIIlllI;

    .line 799
    .line 800
    if-nez v9, :cond_2c

    .line 801
    .line 802
    const-string v7, "Missing Stream Header"

    .line 803
    .line 804
    invoke-static {v7}, Lzl1;->RD(Ljava/lang/String;)V

    .line 805
    .line 806
    .line 807
    :goto_11
    move/from16 p1, v15

    .line 808
    .line 809
    :cond_2b
    const/4 v7, 0x0

    .line 810
    goto/16 :goto_12

    .line 811
    .line 812
    :cond_2c
    if-nez v10, :cond_2d

    .line 813
    .line 814
    const-string v7, "Missing Stream Format"

    .line 815
    .line 816
    invoke-static {v7}, Lzl1;->RD(Ljava/lang/String;)V

    .line 817
    .line 818
    .line 819
    goto :goto_11

    .line 820
    :cond_2d
    iget v11, v9, LUwV$b_h$;->POOl:I

    .line 821
    .line 822
    iget v12, v9, LUwV$b_h$;->waiBKÀ:I

    .line 823
    .line 824
    iget v13, v9, LUwV$b_h$;->rz__9J_:I

    .line 825
    .line 826
    iget-object v10, v10, LIIlllI;->e8$mp_s$:LgItem9321;

    .line 827
    .line 828
    move/from16 p1, v15

    .line 829
    .line 830
    int-to-long v14, v12

    .line 831
    const-wide/32 v17, 0xf4240

    .line 832
    .line 833
    .line 834
    mul-long v25, v14, v17

    .line 835
    .line 836
    int-to-long v12, v13

    .line 837
    sget-object v29, Ljava/math/RoundingMode;->DOWN:Ljava/math/RoundingMode;

    .line 838
    .line 839
    int-to-long v14, v11

    .line 840
    move-wide/from16 v27, v12

    .line 841
    .line 842
    move-wide/from16 v23, v14

    .line 843
    .line 844
    invoke-static/range {v23 .. v29}, LnPos2706;->Qp_Hp$i_(JJJLjava/math/RoundingMode;)J

    .line 845
    .line 846
    .line 847
    move-result-wide v11

    .line 848
    new-instance v13, LtmpOffset9868;

    .line 849
    .line 850
    invoke-direct {v13, v10}, LtmpOffset9868;-><init>(LgItem9321;)V

    .line 851
    .line 852
    .line 853
    invoke-virtual {v13, v8}, LtmpOffset9868;->waiBKÀ(I)V

    .line 854
    .line 855
    .line 856
    iget v14, v9, LUwV$b_h$;->JKEoÙX:I

    .line 857
    .line 858
    if-eqz v14, :cond_2e

    .line 859
    .line 860
    iput v14, v13, LtmpOffset9868;->kQy:I

    .line 861
    .line 862
    :cond_2e
    const-class v14, LH_l_v$j_;

    .line 863
    .line 864
    invoke-virtual {v7, v14}, LgCount4526;->waiBKÀ(Ljava/lang/Class;)Lenb;

    .line 865
    .line 866
    .line 867
    move-result-object v7

    .line 868
    check-cast v7, LH_l_v$j_;

    .line 869
    .line 870
    if-eqz v7, :cond_2f

    .line 871
    .line 872
    iget-object v7, v7, LH_l_v$j_;->e8$mp_s$:Ljava/lang/String;

    .line 873
    .line 874
    iput-object v7, v13, LtmpOffset9868;->waiBKÀ:Ljava/lang/String;

    .line 875
    .line 876
    :cond_2f
    iget-object v7, v10, LgItem9321;->kQy:Ljava/lang/String;

    .line 877
    .line 878
    invoke-static {v7}, LCfA_L8$Og_;->waiBKÀ(Ljava/lang/String;)I

    .line 879
    .line 880
    .line 881
    move-result v7

    .line 882
    if-eq v7, v4, :cond_30

    .line 883
    .line 884
    const/4 v10, 0x2

    .line 885
    if-ne v7, v10, :cond_2b

    .line 886
    .line 887
    const/4 v7, 0x2

    .line 888
    :cond_30
    iget-object v10, v0, LKDlQl;->tmpData3485:LvD9$JN$;

    .line 889
    .line 890
    invoke-interface {v10, v8, v7}, LvD9$JN$;->kCount1402(II)LwÒJK;

    .line 891
    .line 892
    .line 893
    move-result-object v10

    .line 894
    new-instance v14, LgItem9321;

    .line 895
    .line 896
    invoke-direct {v14, v13}, LgItem9321;-><init>(LtmpOffset9868;)V

    .line 897
    .line 898
    .line 899
    invoke-interface {v10, v14}, LwÒJK;->e8$mp_s$(LgItem9321;)V

    .line 900
    .line 901
    .line 902
    iget v9, v9, LUwV$b_h$;->POOl:I

    .line 903
    .line 904
    move-object v13, v10

    .line 905
    move-wide v10, v11

    .line 906
    move v12, v9

    .line 907
    move v9, v7

    .line 908
    new-instance v7, LlIll11;

    .line 909
    .line 910
    invoke-direct/range {v7 .. v13}, LlIll11;-><init>(IIJILwÒJK;)V

    .line 911
    .line 912
    .line 913
    iget-wide v8, v0, LKDlQl;->DDù8:J

    .line 914
    .line 915
    invoke-static {v8, v9, v10, v11}, Ljava/lang/Math;->max(JJ)J

    .line 916
    .line 917
    .line 918
    move-result-wide v8

    .line 919
    iput-wide v8, v0, LKDlQl;->DDù8:J

    .line 920
    .line 921
    :goto_12
    if-eqz v7, :cond_31

    .line 922
    .line 923
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 924
    .line 925
    .line 926
    :cond_31
    move/from16 v8, p1

    .line 927
    .line 928
    :cond_32
    add-int/lit8 v6, v6, 0x1

    .line 929
    .line 930
    const/16 p2, 0x2

    .line 931
    .line 932
    const/4 v14, 0x3

    .line 933
    goto/16 :goto_10

    .line 934
    .line 935
    :cond_33
    new-array v1, v5, [LlIll11;

    .line 936
    .line 937
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 938
    .line 939
    .line 940
    move-result-object v1

    .line 941
    check-cast v1, [LlIll11;

    .line 942
    .line 943
    iput-object v1, v0, LKDlQl;->yON3x:[LlIll11;

    .line 944
    .line 945
    iget-object v1, v0, LKDlQl;->tmpData3485:LvD9$JN$;

    .line 946
    .line 947
    invoke-interface {v1}, LvD9$JN$;->Qp_Hp$i_()V

    .line 948
    .line 949
    .line 950
    const/4 v1, 0x3

    .line 951
    iput v1, v0, LKDlQl;->JKEoÙX:I

    .line 952
    .line 953
    return v5

    .line 954
    :cond_34
    const-string v1, "AviHeader not found"

    .line 955
    .line 956
    const/4 v3, 0x0

    .line 957
    invoke-static {v3, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 958
    .line 959
    .line 960
    move-result-object v1

    .line 961
    throw v1

    .line 962
    :cond_35
    const/4 v3, 0x0

    .line 963
    new-instance v1, Ljava/lang/StringBuilder;

    .line 964
    .line 965
    const-string v4, "Unexpected header list type "

    .line 966
    .line 967
    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 968
    .line 969
    .line 970
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 971
    .line 972
    .line 973
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 974
    .line 975
    .line 976
    move-result-object v1

    .line 977
    invoke-static {v3, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 978
    .line 979
    .line 980
    move-result-object v1

    .line 981
    throw v1

    .line 982
    :cond_36
    move-object v2, v12

    .line 983
    iget-object v4, v13, LYizKm;->e8$mp_s$:[B

    .line 984
    .line 985
    check-cast v1, LoYxmSde;

    .line 986
    .line 987
    invoke-virtual {v1, v4, v5, v3, v5}, LoYxmSde;->Iii([BIIZ)Z

    .line 988
    .line 989
    .line 990
    invoke-virtual {v13, v5}, LYizKm;->vaIue(I)V

    .line 991
    .line 992
    .line 993
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 994
    .line 995
    .line 996
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 997
    .line 998
    .line 999
    move-result v1

    .line 1000
    iput v1, v2, LHlMPQ;->e8$mp_s$:I

    .line 1001
    .line 1002
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 1003
    .line 1004
    .line 1005
    move-result v1

    .line 1006
    iput v1, v2, LHlMPQ;->waiBKÀ:I

    .line 1007
    .line 1008
    iget v1, v2, LHlMPQ;->e8$mp_s$:I

    .line 1009
    .line 1010
    if-ne v1, v10, :cond_38

    .line 1011
    .line 1012
    invoke-virtual {v13}, LYizKm;->gKey4112()I

    .line 1013
    .line 1014
    .line 1015
    move-result v1

    .line 1016
    if-ne v1, v9, :cond_37

    .line 1017
    .line 1018
    iget v1, v2, LHlMPQ;->waiBKÀ:I

    .line 1019
    .line 1020
    iput v1, v0, LKDlQl;->iOffset934:I

    .line 1021
    .line 1022
    const/4 v10, 0x2

    .line 1023
    iput v10, v0, LKDlQl;->JKEoÙX:I

    .line 1024
    .line 1025
    return v5

    .line 1026
    :cond_37
    new-instance v2, Ljava/lang/StringBuilder;

    .line 1027
    .line 1028
    const-string v3, "hdrl expected, found: "

    .line 1029
    .line 1030
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1031
    .line 1032
    .line 1033
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1034
    .line 1035
    .line 1036
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1037
    .line 1038
    .line 1039
    move-result-object v1

    .line 1040
    const/4 v2, 0x0

    .line 1041
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v1

    .line 1045
    throw v1

    .line 1046
    :cond_38
    const/4 v2, 0x0

    .line 1047
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1048
    .line 1049
    const-string v4, "LIST expected, found: "

    .line 1050
    .line 1051
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1052
    .line 1053
    .line 1054
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1055
    .line 1056
    .line 1057
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v1

    .line 1061
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v1

    .line 1065
    throw v1

    .line 1066
    :cond_39
    move-object v2, v8

    .line 1067
    invoke-virtual/range {p0 .. p1}, LKDlQl;->iOffset934(LxPsMK;)Z

    .line 1068
    .line 1069
    .line 1070
    move-result v6

    .line 1071
    if-eqz v6, :cond_3a

    .line 1072
    .line 1073
    check-cast v1, LoYxmSde;

    .line 1074
    .line 1075
    invoke-virtual {v1, v3}, LoYxmSde;->sKey7917(I)V

    .line 1076
    .line 1077
    .line 1078
    iput v4, v0, LKDlQl;->JKEoÙX:I

    .line 1079
    .line 1080
    return v5

    .line 1081
    :cond_3a
    const-string v1, "AVI Header List not found"

    .line 1082
    .line 1083
    invoke-static {v2, v1}, LhasIndex1902;->e8$mp_s$(Ljava/lang/RuntimeException;Ljava/lang/String;)LhasIndex1902;

    .line 1084
    .line 1085
    .line 1086
    move-result-object v1

    .line 1087
    throw v1
.end method

.method public final kQy(LvD9$JN$;)V
    .locals 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, LKDlQl;->JKEoÙX:I

    .line 3
    .line 4
    iget-boolean v0, p0, LKDlQl;->rz__9J_:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    new-instance v0, LMl;

    .line 9
    .line 10
    iget-object v1, p0, LKDlQl;->POOl:LWnÀXqJ5;

    .line 11
    .line 12
    invoke-direct {v0, p1, v1}, LMl;-><init>(LvD9$JN$;LYl7QÙ;)V

    .line 13
    .line 14
    .line 15
    move-object p1, v0

    .line 16
    :cond_0
    iput-object p1, p0, LKDlQl;->tmpData3485:LvD9$JN$;

    .line 17
    .line 18
    const-wide/16 v0, -0x1

    .line 19
    .line 20
    iput-wide v0, p0, LKDlQl;->vaIue:J

    .line 21
    .line 22
    return-void
.end method

.method public final vaIue()Ljava/util/List;
    .locals 1

    .line 1
    sget-object v0, LnW_cN_;->vaIue:Ljk_NI_;

    .line 2
    .line 3
    sget-object v0, LlII1II;->kQy:LlII1II;

    .line 4
    .line 5
    return-object v0
.end method
