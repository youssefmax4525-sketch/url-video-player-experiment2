.class public final LtmpKey5795;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public e8$mp_s$:Z

.field public rz__9J_:LplQQD0;

.field public final waiBKÀ:LnPos7306;


# direct methods
.method public synthetic constructor <init>(LnPos7306;)V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, LtmpKey5795;->rz__9J_:LplQQD0;

    .line 6
    .line 7
    iput-object p1, p0, LtmpKey5795;->waiBKÀ:LnPos7306;

    .line 8
    .line 9
    return-void
.end method
