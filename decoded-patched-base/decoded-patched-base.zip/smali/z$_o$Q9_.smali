.class public final synthetic Lz$_o$Q9_;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic jPos3709:I

.field public final synthetic vaIue:LzA$Tt$;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LzA$Tt$;II)V
    .locals 0

    .line 1
    iput p3, p0, Lz$_o$Q9_;->yON3x:I

    iput-object p1, p0, Lz$_o$Q9_;->vaIue:LzA$Tt$;

    iput p2, p0, Lz$_o$Q9_;->jPos3709:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 2

    .line 1
    iget v0, p0, Lz$_o$Q9_;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lz$_o$Q9_;->vaIue:LzA$Tt$;

    .line 7
    .line 8
    iget-object v0, v0, LzA$Tt$;->tmpData3485:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LMl;

    .line 11
    .line 12
    iget-object v0, v0, LMl;->iOffset934:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, LsQze;

    .line 15
    .line 16
    iget-object v0, v0, LsQze;->POOl:LRo_Zk$ML_;

    .line 17
    .line 18
    if-eqz v0, :cond_0

    .line 19
    .line 20
    iget v1, p0, Lz$_o$Q9_;->jPos3709:I

    .line 21
    .line 22
    invoke-virtual {v0, v1}, LRo_Zk$ML_;->jPos3709(I)V

    .line 23
    .line 24
    .line 25
    :cond_0
    return-void

    .line 26
    :pswitch_0
    iget-object v0, p0, Lz$_o$Q9_;->vaIue:LzA$Tt$;

    .line 27
    .line 28
    iget-object v0, v0, LzA$Tt$;->tmpData3485:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, LMl;

    .line 31
    .line 32
    iget-object v0, v0, LMl;->iOffset934:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, LsQze;

    .line 35
    .line 36
    iget-object v0, v0, LsQze;->POOl:LRo_Zk$ML_;

    .line 37
    .line 38
    if-eqz v0, :cond_1

    .line 39
    .line 40
    iget v1, p0, Lz$_o$Q9_;->jPos3709:I

    .line 41
    .line 42
    invoke-virtual {v0, v1}, LRo_Zk$ML_;->vaIue(I)V

    .line 43
    .line 44
    .line 45
    :cond_1
    return-void

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
