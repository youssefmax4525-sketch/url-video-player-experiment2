.class public final LqI;
.super LsA8$j$;


# instance fields
.field public final synthetic iOffset934:I

.field public kQy:Ljava/util/Stack;


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LqI;->iOffset934:I

    invoke-direct {p0}, LIQ;-><init>()V

    return-void
.end method

.method private final iOffset934(LvKey4670;Ljava/lang/String;Lorg/xml/sax/Attributes;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final DDù8(LvKey4670;Ljava/lang/String;Lorg/xml/sax/Attributes;)V
    .locals 9

    .line 1
    iget v0, p0, LqI;->iOffset934:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string v0, "]"

    .line 7
    .line 8
    const-string v1, "Assuming default type ["

    .line 9
    .line 10
    const-string v2, "Could not find an appropriate class for property ["

    .line 11
    .line 12
    iget-object v3, p0, LqI;->kQy:Ljava/util/Stack;

    .line 13
    .line 14
    invoke-virtual {v3}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    check-cast v3, LBID1;

    .line 19
    .line 20
    const-string v4, "class"

    .line 21
    .line 22
    invoke-interface {p3, v4}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object p3

    .line 26
    invoke-virtual {p1, p3}, LvKey4670;->jPos3709(Ljava/lang/String;)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p3

    .line 30
    const/4 v4, 0x1

    .line 31
    :try_start_0
    invoke-static {p3}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    if-nez v5, :cond_0

    .line 36
    .line 37
    iget-object v5, p0, LIQ;->vaIue:LZN$P$;

    .line 38
    .line 39
    invoke-static {v5}, LyV_s$L_;->e8$mp_s$(Ljava/lang/Object;)Ljava/lang/ClassLoader;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    invoke-virtual {v5, p3}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    goto :goto_0

    .line 48
    :catch_0
    move-exception p1

    .line 49
    goto :goto_1

    .line 50
    :cond_0
    iget-object v5, v3, LBID1;->e8$mp_s$:LBDd_Zm;

    .line 51
    .line 52
    iget-object v6, v3, LBID1;->rz__9J_:Ljava/lang/String;

    .line 53
    .line 54
    iget v7, v3, LBID1;->waiBKÀ:I

    .line 55
    .line 56
    iget-object v8, p1, LvKey4670;->yàÒZ:LJw_Mi$Hk_;

    .line 57
    .line 58
    invoke-virtual {v5, v6, v7, v8}, LBDd_Zm;->iOffset934(Ljava/lang/String;ILJw_Mi$Hk_;)Ljava/lang/Class;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    :goto_0
    if-nez v5, :cond_1

    .line 63
    .line 64
    iput-boolean v4, v3, LBID1;->JKEoÙX:Z

    .line 65
    .line 66
    new-instance p1, Ljava/lang/StringBuilder;

    .line 67
    .line 68
    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    invoke-virtual {p0, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    goto :goto_2

    .line 85
    :cond_1
    invoke-static {p3}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 86
    .line 87
    .line 88
    move-result v2

    .line 89
    if-eqz v2, :cond_2

    .line 90
    .line 91
    new-instance v2, Ljava/lang/StringBuilder;

    .line 92
    .line 93
    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v1

    .line 100
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    .line 102
    .line 103
    const-string v1, "] for ["

    .line 104
    .line 105
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 106
    .line 107
    .line 108
    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    .line 110
    .line 111
    const-string v1, "] property"

    .line 112
    .line 113
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    .line 115
    .line 116
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object v1

    .line 120
    invoke-virtual {p0, v1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    :cond_2
    const/4 v1, 0x0

    .line 124
    invoke-virtual {v5, v1}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    invoke-virtual {v2, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v1

    .line 132
    iput-object v1, v3, LBID1;->POOl:Ljava/lang/Object;

    .line 133
    .line 134
    instance-of v2, v1, LVNPÌmw;

    .line 135
    .line 136
    if-eqz v2, :cond_3

    .line 137
    .line 138
    check-cast v1, LVNPÌmw;

    .line 139
    .line 140
    iget-object v2, p0, LIQ;->vaIue:LZN$P$;

    .line 141
    .line 142
    invoke-interface {v1, v2}, LVNPÌmw;->waiBKÀ(LZN$P$;)V

    .line 143
    .line 144
    .line 145
    :cond_3
    iget-object v1, v3, LBID1;->POOl:Ljava/lang/Object;

    .line 146
    .line 147
    invoke-virtual {p1, v1}, LvKey4670;->vaIue(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    .line 148
    .line 149
    .line 150
    goto :goto_2

    .line 151
    :goto_1
    iput-boolean v4, v3, LBID1;->JKEoÙX:Z

    .line 152
    .line 153
    const-string v1, "Could not create component ["

    .line 154
    .line 155
    const-string v2, "] of type ["

    .line 156
    .line 157
    invoke-static {v1, p2, v2, p3, v0}, LBRK_m_;->vaIue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    invoke-virtual {p0, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 162
    .line 163
    .line 164
    :goto_2
    :pswitch_0
    return-void

    .line 165
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final vaIue(LvKey4670;Ljava/lang/String;)V
    .locals 7

    .line 1
    iget v0, p0, LqI;->iOffset934:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LqI;->kQy:Ljava/util/Stack;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/Stack;->pop()Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, LBID1;

    .line 13
    .line 14
    iget-boolean v1, v0, LBID1;->JKEoÙX:Z

    .line 15
    .line 16
    iget v2, v0, LBID1;->waiBKÀ:I

    .line 17
    .line 18
    iget-object v3, v0, LBID1;->e8$mp_s$:LBDd_Zm;

    .line 19
    .line 20
    if-eqz v1, :cond_0

    .line 21
    .line 22
    goto/16 :goto_2

    .line 23
    .line 24
    :cond_0
    new-instance v1, LBDd_Zm;

    .line 25
    .line 26
    iget-object v4, v0, LBID1;->POOl:Ljava/lang/Object;

    .line 27
    .line 28
    invoke-direct {v1, v4}, LBDd_Zm;-><init>(Ljava/lang/Object;)V

    .line 29
    .line 30
    .line 31
    iget-object v4, p0, LIQ;->vaIue:LZN$P$;

    .line 32
    .line 33
    invoke-virtual {v1, v4}, LIQ;->waiBKÀ(LZN$P$;)V

    .line 34
    .line 35
    .line 36
    const-string v4, "parent"

    .line 37
    .line 38
    invoke-virtual {v1, v4}, LBDd_Zm;->yON3x(Ljava/lang/String;)I

    .line 39
    .line 40
    .line 41
    move-result v5

    .line 42
    const/4 v6, 0x3

    .line 43
    if-ne v5, v6, :cond_1

    .line 44
    .line 45
    iget-object v5, v3, LBDd_Zm;->iOffset934:Ljava/lang/Object;

    .line 46
    .line 47
    invoke-virtual {v1, v4, v5}, LBDd_Zm;->yàÒZ(Ljava/lang/String;Ljava/lang/Object;)V

    .line 48
    .line 49
    .line 50
    :cond_1
    iget-object v1, v0, LBID1;->POOl:Ljava/lang/Object;

    .line 51
    .line 52
    instance-of v4, v1, LOUy_0_;

    .line 53
    .line 54
    if-eqz v4, :cond_3

    .line 55
    .line 56
    if-nez v1, :cond_2

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_2
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    const-class v5, LKFd_w_;

    .line 64
    .line 65
    invoke-virtual {v4, v5}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    .line 66
    .line 67
    .line 68
    move-result-object v4

    .line 69
    check-cast v4, LKFd_w_;

    .line 70
    .line 71
    if-nez v4, :cond_3

    .line 72
    .line 73
    check-cast v1, LOUy_0_;

    .line 74
    .line 75
    invoke-interface {v1}, LOUy_0_;->start()V

    .line 76
    .line 77
    .line 78
    :cond_3
    :goto_0
    iget-object v1, p1, LvKey4670;->iOffset934:Ljava/util/Stack;

    .line 79
    .line 80
    invoke-virtual {v1}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    iget-object v4, v0, LBID1;->POOl:Ljava/lang/Object;

    .line 85
    .line 86
    if-eq v1, v4, :cond_4

    .line 87
    .line 88
    const-string p1, "The object on the top the of the stack is not the component pushed earlier."

    .line 89
    .line 90
    :goto_1
    invoke-virtual {p0, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 91
    .line 92
    .line 93
    goto :goto_2

    .line 94
    :cond_4
    invoke-virtual {p1}, LvKey4670;->yON3x()V

    .line 95
    .line 96
    .line 97
    invoke-static {v2}, LBRK_m_;->UC_n_(I)I

    .line 98
    .line 99
    .line 100
    move-result p1

    .line 101
    const/4 v1, 0x2

    .line 102
    if-eq p1, v1, :cond_8

    .line 103
    .line 104
    const/4 v1, 0x4

    .line 105
    if-eq p1, v1, :cond_5

    .line 106
    .line 107
    invoke-static {v2}, LBRK_m_;->kCount1402(I)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object p1

    .line 111
    const-string p2, "Unexpected aggregationType "

    .line 112
    .line 113
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    goto :goto_1

    .line 118
    :cond_5
    iget-object p1, v0, LBID1;->POOl:Ljava/lang/Object;

    .line 119
    .line 120
    invoke-virtual {v3, p2}, LBDd_Zm;->jPos3709(Ljava/lang/String;)Ljava/lang/reflect/Method;

    .line 121
    .line 122
    .line 123
    move-result-object v0

    .line 124
    if-eqz v0, :cond_7

    .line 125
    .line 126
    invoke-virtual {v0}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    .line 127
    .line 128
    .line 129
    move-result-object v1

    .line 130
    invoke-virtual {v3, p2, v1, p1}, LBDd_Zm;->pCXDYg(Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result p2

    .line 134
    if-nez p2, :cond_6

    .line 135
    .line 136
    goto :goto_2

    .line 137
    :cond_6
    invoke-virtual {v3, v0, p1}, LBDd_Zm;->valuI(Ljava/lang/reflect/Method;Ljava/lang/Object;)V

    .line 138
    .line 139
    .line 140
    goto :goto_2

    .line 141
    :cond_7
    const-string p1, "Could not find method [add"

    .line 142
    .line 143
    const-string v0, "] in class ["

    .line 144
    .line 145
    invoke-static {p1, p2, v0}, LBRK_m_;->Ialue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    iget-object p2, v3, LBDd_Zm;->kQy:Ljava/lang/Class;

    .line 150
    .line 151
    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 152
    .line 153
    .line 154
    move-result-object p2

    .line 155
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 156
    .line 157
    .line 158
    const-string p2, "]."

    .line 159
    .line 160
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 161
    .line 162
    .line 163
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    invoke-virtual {v3, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 168
    .line 169
    .line 170
    goto :goto_2

    .line 171
    :cond_8
    iget-object p1, v0, LBID1;->POOl:Ljava/lang/Object;

    .line 172
    .line 173
    invoke-virtual {v3, p2, p1}, LBDd_Zm;->yàÒZ(Ljava/lang/String;Ljava/lang/Object;)V

    .line 174
    .line 175
    .line 176
    :goto_2
    return-void

    .line 177
    :pswitch_0
    iget-object p1, p0, LqI;->kQy:Ljava/util/Stack;

    .line 178
    .line 179
    invoke-virtual {p1}, Ljava/util/Stack;->pop()Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    return-void

    .line 183
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public yON3x(LvKey4670;Ljava/lang/String;)V
    .locals 4

    .line 1
    iget v0, p0, LqI;->iOffset934:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    invoke-virtual {p1, p2}, LvKey4670;->jPos3709(Ljava/lang/String;)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    iget-object p2, p0, LqI;->kQy:Ljava/util/Stack;

    .line 12
    .line 13
    invoke-virtual {p2}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p2

    .line 17
    check-cast p2, LQ0D;

    .line 18
    .line 19
    iget v0, p2, LQ0D;->waiBKÀ:I

    .line 20
    .line 21
    iget-object v1, p2, LQ0D;->rz__9J_:Ljava/lang/String;

    .line 22
    .line 23
    iget-object v2, p2, LQ0D;->e8$mp_s$:LBDd_Zm;

    .line 24
    .line 25
    invoke-static {v0}, LBRK_m_;->UC_n_(I)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    const/4 v3, 0x1

    .line 30
    if-eq v0, v3, :cond_3

    .line 31
    .line 32
    const/4 v3, 0x3

    .line 33
    if-eq v0, v3, :cond_0

    .line 34
    .line 35
    iget p1, p2, LQ0D;->waiBKÀ:I

    .line 36
    .line 37
    invoke-static {p1}, LBRK_m_;->kCount1402(I)Ljava/lang/String;

    .line 38
    .line 39
    .line 40
    move-result-object p1

    .line 41
    const-string p2, "Unexpected aggregationType "

    .line 42
    .line 43
    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 44
    .line 45
    .line 46
    move-result-object p1

    .line 47
    invoke-virtual {p0, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 48
    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_0
    if-nez p1, :cond_1

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_1
    invoke-static {v1}, LBDd_Zm;->DDù8(Ljava/lang/String;)Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p2

    .line 58
    invoke-virtual {v2, p2}, LBDd_Zm;->jPos3709(Ljava/lang/String;)Ljava/lang/reflect/Method;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    if-nez v0, :cond_2

    .line 63
    .line 64
    new-instance p1, Ljava/lang/StringBuilder;

    .line 65
    .line 66
    const-string v0, "No adder for property ["

    .line 67
    .line 68
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 72
    .line 73
    .line 74
    const-string p2, "]."

    .line 75
    .line 76
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 77
    .line 78
    .line 79
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    invoke-virtual {v2, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    goto :goto_0

    .line 87
    :cond_2
    invoke-virtual {v0}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    invoke-virtual {v2, p2, v1, p1}, LBDd_Zm;->pCXDYg(Ljava/lang/String;[Ljava/lang/Class;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    const/4 p2, 0x0

    .line 95
    :try_start_0
    aget-object v3, v1, p2

    .line 96
    .line 97
    invoke-static {v2, p1, v3}, LI1i1;->sKey7917(LBDd_Zm;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 101
    if-eqz p2, :cond_4

    .line 102
    .line 103
    invoke-virtual {v2, v0, p1}, LBDd_Zm;->valuI(Ljava/lang/reflect/Method;Ljava/lang/Object;)V

    .line 104
    .line 105
    .line 106
    goto :goto_0

    .line 107
    :catchall_0
    move-exception p1

    .line 108
    new-instance v0, Ljava/lang/StringBuilder;

    .line 109
    .line 110
    const-string v3, "Conversion to type ["

    .line 111
    .line 112
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    aget-object p2, v1, p2

    .line 116
    .line 117
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 118
    .line 119
    .line 120
    const-string p2, "] failed. "

    .line 121
    .line 122
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object p2

    .line 129
    invoke-virtual {v2, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 130
    .line 131
    .line 132
    goto :goto_0

    .line 133
    :cond_3
    invoke-virtual {v2, v1, p1}, LBDd_Zm;->kO_6X_(Ljava/lang/String;Ljava/lang/String;)V

    .line 134
    .line 135
    .line 136
    :cond_4
    :goto_0
    return-void

    .line 137
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
