.class public final LnW_Z_;
.super LwQX$Ml$;
.source "SourceFile"


# instance fields
.field public final pCXDYg:Ljava/lang/Thread;


# direct methods
.method public constructor <init>(Ljava/lang/Thread;)V
    .locals 0

    .line 1
    invoke-direct {p0}, LwQX$Ml$;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LnW_Z_;->pCXDYg:Ljava/lang/Thread;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final yàÒZ()Ljava/lang/Thread;
    .locals 1

    .line 1
    iget-object v0, p0, LnW_Z_;->pCXDYg:Ljava/lang/Thread;

    .line 2
    .line 3
    return-object v0
.end method
