.class public interface abstract LlW$N_5$;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract kQy(Ljava/lang/Object;)V
.end method
