.class public final LrQ;
.super LK_S_kQ$8_;
.source "SourceFile"


# static fields
.field public static final BCIm:I

.field public static final Iii:I

.field public static final l1:[I

.field public static final oaX_6_:[[I

.field public static final pQ1Il:[I


# instance fields
.field public $ÒcdS:Landroid/content/res/ColorStateList;

.field public final Ialue:Ljava/util/LinkedHashSet;

.field public K0I:Landroid/graphics/drawable/Drawable;

.field public final Oey:LjPos1170;

.field public Q1_f_:Landroid/graphics/PorterDuff$Mode;

.field public Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

.field public UC_n_:Z

.field public gKey4112:Z

.field public kCount1402:Landroid/content/res/ColorStateList;

.field public kO_6X_:Ljava/lang/CharSequence;

.field public final kQy:Ljava/util/LinkedHashSet;

.field public ll:Ljava/lang/CharSequence;

.field public oy_R$Xx_:Landroid/widget/CompoundButton$OnCheckedChangeListener;

.field public pCXDYg:Z

.field public sKey6064:[I

.field public tmpSize211:I

.field public tzKù7Ol1:Z

.field public valuI:Landroid/content/res/ColorStateList;

.field public final yPN$A_n$:Lbokmka;

.field public yàÒZ:Z


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    sget v0, LHQD0l;->Widget_MaterialComponents_CompoundButton_CheckBox:I

    .line 2
    .line 3
    sput v0, LrQ;->Iii:I

    .line 4
    .line 5
    sget v0, LvaOue;->state_indeterminate:I

    .line 6
    .line 7
    filled-new-array {v0}, [I

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    sput-object v0, LrQ;->l1:[I

    .line 12
    .line 13
    sget v0, LvaOue;->state_error:I

    .line 14
    .line 15
    filled-new-array {v0}, [I

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    sput-object v1, LrQ;->pQ1Il:[I

    .line 20
    .line 21
    const v1, 0x101009e

    .line 22
    .line 23
    .line 24
    filled-new-array {v1, v0}, [I

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    const/4 v2, 0x5

    .line 29
    new-array v2, v2, [[I

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    aput-object v0, v2, v3

    .line 33
    .line 34
    const v0, 0x10100a0

    .line 35
    .line 36
    .line 37
    filled-new-array {v1, v0}, [I

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    const/4 v4, 0x1

    .line 42
    aput-object v3, v2, v4

    .line 43
    .line 44
    const v3, -0x10100a0

    .line 45
    .line 46
    .line 47
    filled-new-array {v1, v3}, [I

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    const/4 v4, 0x2

    .line 52
    aput-object v1, v2, v4

    .line 53
    .line 54
    const v1, -0x101009e

    .line 55
    .line 56
    .line 57
    filled-new-array {v1, v0}, [I

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    const/4 v4, 0x3

    .line 62
    aput-object v0, v2, v4

    .line 63
    .line 64
    filled-new-array {v1, v3}, [I

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    const/4 v1, 0x4

    .line 69
    aput-object v0, v2, v1

    .line 70
    .line 71
    sput-object v2, LrQ;->oaX_6_:[[I

    .line 72
    .line 73
    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    const-string v1, "drawable"

    .line 78
    .line 79
    const-string v2, "android"

    .line 80
    .line 81
    const-string v3, "btn_check_material_anim"

    .line 82
    .line 83
    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    sput v0, LrQ;->BCIm:I

    .line 88
    .line 89
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 9

    .line 1
    sget v3, LvaOue;->checkboxStyle:I

    .line 2
    .line 3
    sget v0, LrQ;->Iii:I

    .line 4
    .line 5
    invoke-static {p1, p2, v3, v0}, LED;->e8$mp_s$(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroid/content/Context;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-direct {p0, p1, p2, v3}, LK_S_kQ$8_;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 10
    .line 11
    .line 12
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 13
    .line 14
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, LrQ;->kQy:Ljava/util/LinkedHashSet;

    .line 18
    .line 19
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 20
    .line 21
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, LrQ;->Ialue:Ljava/util/LinkedHashSet;

    .line 25
    .line 26
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    sget v0, LD0;->mtrl_checkbox_button_checked_unchecked:I

    .line 31
    .line 32
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 33
    .line 34
    const/16 v2, 0x18

    .line 35
    .line 36
    const/4 v6, 0x1

    .line 37
    const/4 v7, 0x0

    .line 38
    const/4 v8, 0x0

    .line 39
    if-lt v1, v2, :cond_0

    .line 40
    .line 41
    new-instance v1, Lbokmka;

    .line 42
    .line 43
    invoke-direct {v1, p1, v7}, Lbokmka;-><init>(Landroid/content/Context;I)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    sget-object v4, Lugq$nh_K$;->e8$mp_s$:Ljava/lang/ThreadLocal;

    .line 55
    .line 56
    invoke-virtual {v2, v0, p1}, Landroid/content/res/Resources;->getDrawable(ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    iput-object p1, v1, LcQO$W$;->yON3x:Landroid/graphics/drawable/Drawable;

    .line 61
    .line 62
    iget-object v0, v1, Lbokmka;->Ialue:LCSuIèy;

    .line 63
    .line 64
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 65
    .line 66
    .line 67
    new-instance p1, Ltem0;

    .line 68
    .line 69
    iget-object v0, v1, LcQO$W$;->yON3x:Landroid/graphics/drawable/Drawable;

    .line 70
    .line 71
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    .line 72
    .line 73
    .line 74
    move-result-object v0

    .line 75
    invoke-direct {p1, v0}, Ltem0;-><init>(Landroid/graphics/drawable/Drawable$ConstantState;)V

    .line 76
    .line 77
    .line 78
    goto :goto_2

    .line 79
    :cond_0
    sget v1, Lbokmka;->valuI:I

    .line 80
    .line 81
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    :try_start_0
    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-static {v0}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    .line 90
    .line 91
    .line 92
    move-result-object v1

    .line 93
    :goto_0
    invoke-interface {v0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    .line 94
    .line 95
    .line 96
    move-result v2

    .line 97
    const/4 v4, 0x2

    .line 98
    if-eq v2, v4, :cond_1

    .line 99
    .line 100
    if-eq v2, v6, :cond_1

    .line 101
    .line 102
    goto :goto_0

    .line 103
    :cond_1
    if-ne v2, v4, :cond_2

    .line 104
    .line 105
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 106
    .line 107
    .line 108
    move-result-object v2

    .line 109
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 110
    .line 111
    .line 112
    move-result-object v4

    .line 113
    new-instance v5, Lbokmka;

    .line 114
    .line 115
    invoke-direct {v5, p1, v7}, Lbokmka;-><init>(Landroid/content/Context;I)V

    .line 116
    .line 117
    .line 118
    invoke-virtual {v5, v2, v0, v1, v4}, Lbokmka;->inflate(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    .line 119
    .line 120
    .line 121
    move-object v1, v5

    .line 122
    goto :goto_2

    .line 123
    :catch_0
    nop

    .line 124
    goto :goto_1

    .line 125
    :cond_2
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    .line 126
    .line 127
    const-string v0, "No start tag found"

    .line 128
    .line 129
    invoke-direct {p1, v0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    .line 130
    .line 131
    .line 132
    throw p1
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 133
    :goto_1
    move-object v1, v8

    .line 134
    :goto_2
    iput-object v1, p0, LrQ;->yPN$A_n$:Lbokmka;

    .line 135
    .line 136
    new-instance p1, LjPos1170;

    .line 137
    .line 138
    invoke-direct {p1, p0}, LjPos1170;-><init>(LrQ;)V

    .line 139
    .line 140
    .line 141
    iput-object p1, p0, LrQ;->Oey:LjPos1170;

    .line 142
    .line 143
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    invoke-static {p0}, LQ6$k$;->vaIue(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    .line 148
    .line 149
    .line 150
    move-result-object p1

    .line 151
    iput-object p1, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 152
    .line 153
    invoke-direct {p0}, LrQ;->getSuperButtonTintList()Landroid/content/res/ColorStateList;

    .line 154
    .line 155
    .line 156
    move-result-object p1

    .line 157
    iput-object p1, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 158
    .line 159
    invoke-interface {p0, v8}, LQkcatè;->setSupportButtonTintList(Landroid/content/res/ColorStateList;)V

    .line 160
    .line 161
    .line 162
    sget-object v2, LUIlD;->MaterialCheckBox:[I

    .line 163
    .line 164
    new-array v5, v7, [I

    .line 165
    .line 166
    sget v4, LrQ;->Iii:I

    .line 167
    .line 168
    invoke-static {v0, p2, v3, v4}, LVQ__k_;->e8$mp_s$(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    .line 169
    .line 170
    .line 171
    move-object v1, p2

    .line 172
    invoke-static/range {v0 .. v5}, LVQ__k_;->waiBKÀ(Landroid/content/Context;Landroid/util/AttributeSet;[III[I)V

    .line 173
    .line 174
    .line 175
    new-instance p1, LMl;

    .line 176
    .line 177
    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 178
    .line 179
    .line 180
    move-result-object p2

    .line 181
    invoke-direct {p1, v0, p2}, LMl;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 182
    .line 183
    .line 184
    sget v1, LUIlD;->MaterialCheckBox_buttonIcon:I

    .line 185
    .line 186
    invoke-virtual {p1, v1}, LMl;->DDù8(I)Landroid/graphics/drawable/Drawable;

    .line 187
    .line 188
    .line 189
    move-result-object v1

    .line 190
    iput-object v1, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 191
    .line 192
    iget-object v1, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 193
    .line 194
    if-eqz v1, :cond_3

    .line 195
    .line 196
    sget v1, LvaOue;->isMaterial3Theme:I

    .line 197
    .line 198
    invoke-static {v0, v1, v7}, LQEHcu;->iOffset934(Landroid/content/Context;IZ)Z

    .line 199
    .line 200
    .line 201
    move-result v1

    .line 202
    if-eqz v1, :cond_3

    .line 203
    .line 204
    sget v1, LUIlD;->MaterialCheckBox_android_button:I

    .line 205
    .line 206
    invoke-virtual {p2, v1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    sget v2, LUIlD;->MaterialCheckBox_buttonCompat:I

    .line 211
    .line 212
    invoke-virtual {p2, v2, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 213
    .line 214
    .line 215
    move-result v2

    .line 216
    sget v3, LrQ;->BCIm:I

    .line 217
    .line 218
    if-ne v1, v3, :cond_3

    .line 219
    .line 220
    if-nez v2, :cond_3

    .line 221
    .line 222
    invoke-super {p0, v8}, LK_S_kQ$8_;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 223
    .line 224
    .line 225
    sget v1, LD0;->mtrl_checkbox_button:I

    .line 226
    .line 227
    invoke-static {v0, v1}, LQ6$k$;->iOffset934(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 228
    .line 229
    .line 230
    move-result-object v1

    .line 231
    iput-object v1, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 232
    .line 233
    iput-boolean v6, p0, LrQ;->UC_n_:Z

    .line 234
    .line 235
    iget-object v1, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 236
    .line 237
    if-nez v1, :cond_3

    .line 238
    .line 239
    sget v1, LD0;->mtrl_checkbox_button_icon:I

    .line 240
    .line 241
    invoke-static {v0, v1}, LQ6$k$;->iOffset934(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    iput-object v1, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 246
    .line 247
    :cond_3
    sget v1, LUIlD;->MaterialCheckBox_buttonIconTint:I

    .line 248
    .line 249
    invoke-static {v0, p1, v1}, LqaqSBo;->JKEoÙX(Landroid/content/Context;LMl;I)Landroid/content/res/ColorStateList;

    .line 250
    .line 251
    .line 252
    move-result-object v0

    .line 253
    iput-object v0, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 254
    .line 255
    sget v0, LUIlD;->MaterialCheckBox_buttonIconTintMode:I

    .line 256
    .line 257
    const/4 v1, -0x1

    .line 258
    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 259
    .line 260
    .line 261
    move-result v0

    .line 262
    sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    .line 263
    .line 264
    invoke-static {v0, v1}, LdQta;->pCXDYg(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    .line 265
    .line 266
    .line 267
    move-result-object v0

    .line 268
    iput-object v0, p0, LrQ;->Q1_f_:Landroid/graphics/PorterDuff$Mode;

    .line 269
    .line 270
    sget v0, LUIlD;->MaterialCheckBox_useMaterialThemeColors:I

    .line 271
    .line 272
    invoke-virtual {p2, v0, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 273
    .line 274
    .line 275
    move-result v0

    .line 276
    iput-boolean v0, p0, LrQ;->pCXDYg:Z

    .line 277
    .line 278
    sget v0, LUIlD;->MaterialCheckBox_centerIfNoTextEnabled:I

    .line 279
    .line 280
    invoke-virtual {p2, v0, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 281
    .line 282
    .line 283
    move-result v0

    .line 284
    iput-boolean v0, p0, LrQ;->yàÒZ:Z

    .line 285
    .line 286
    sget v0, LUIlD;->MaterialCheckBox_errorShown:I

    .line 287
    .line 288
    invoke-virtual {p2, v0, v7}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 289
    .line 290
    .line 291
    move-result v0

    .line 292
    iput-boolean v0, p0, LrQ;->gKey4112:Z

    .line 293
    .line 294
    sget v0, LUIlD;->MaterialCheckBox_errorAccessibilityLabel:I

    .line 295
    .line 296
    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    .line 297
    .line 298
    .line 299
    move-result-object v0

    .line 300
    iput-object v0, p0, LrQ;->kO_6X_:Ljava/lang/CharSequence;

    .line 301
    .line 302
    sget v0, LUIlD;->MaterialCheckBox_checkedState:I

    .line 303
    .line 304
    invoke-virtual {p2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 305
    .line 306
    .line 307
    move-result v0

    .line 308
    if-eqz v0, :cond_4

    .line 309
    .line 310
    sget v0, LUIlD;->MaterialCheckBox_checkedState:I

    .line 311
    .line 312
    invoke-virtual {p2, v0, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 313
    .line 314
    .line 315
    move-result p2

    .line 316
    invoke-virtual {p0, p2}, LrQ;->setCheckedState(I)V

    .line 317
    .line 318
    .line 319
    :cond_4
    invoke-virtual {p1}, LMl;->valuI()V

    .line 320
    .line 321
    .line 322
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    .line 323
    .line 324
    .line 325
    return-void
.end method

.method private getButtonStateDescription()Ljava/lang/String;
    .locals 2

    .line 1
    iget v0, p0, LrQ;->tmpSize211:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sget v1, LGzjEt;->mtrl_checkbox_state_description_checked:I

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0

    .line 17
    :cond_0
    if-nez v0, :cond_1

    .line 18
    .line 19
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    sget v1, LGzjEt;->mtrl_checkbox_state_description_unchecked:I

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    return-object v0

    .line 30
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    sget v1, LGzjEt;->mtrl_checkbox_state_description_indeterminate:I

    .line 35
    .line 36
    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    return-object v0
.end method

.method private getMaterialThemeColorsTintList()Landroid/content/res/ColorStateList;
    .locals 7

    .line 1
    iget-object v0, p0, LrQ;->valuI:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    sget v0, LvaOue;->colorControlActivated:I

    .line 6
    .line 7
    invoke-static {v0, p0}, Lwo2_P$S_;->vaIue(ILandroid/view/View;)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    sget v1, LvaOue;->colorError:I

    .line 12
    .line 13
    invoke-static {v1, p0}, Lwo2_P$S_;->vaIue(ILandroid/view/View;)I

    .line 14
    .line 15
    .line 16
    move-result v1

    .line 17
    sget v2, LvaOue;->colorSurface:I

    .line 18
    .line 19
    invoke-static {v2, p0}, Lwo2_P$S_;->vaIue(ILandroid/view/View;)I

    .line 20
    .line 21
    .line 22
    move-result v2

    .line 23
    sget v3, LvaOue;->colorOnSurface:I

    .line 24
    .line 25
    invoke-static {v3, p0}, Lwo2_P$S_;->vaIue(ILandroid/view/View;)I

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    const/high16 v4, 0x3f800000    # 1.0f

    .line 30
    .line 31
    invoke-static {v4, v2, v1}, Lwo2_P$S_;->valuI(FII)I

    .line 32
    .line 33
    .line 34
    move-result v1

    .line 35
    invoke-static {v4, v2, v0}, Lwo2_P$S_;->valuI(FII)I

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    const v4, 0x3f0a3d71    # 0.54f

    .line 40
    .line 41
    .line 42
    invoke-static {v4, v2, v3}, Lwo2_P$S_;->valuI(FII)I

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    const v5, 0x3ec28f5c    # 0.38f

    .line 47
    .line 48
    .line 49
    invoke-static {v5, v2, v3}, Lwo2_P$S_;->valuI(FII)I

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    invoke-static {v5, v2, v3}, Lwo2_P$S_;->valuI(FII)I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    filled-new-array {v1, v0, v4, v6, v2}, [I

    .line 58
    .line 59
    .line 60
    move-result-object v0

    .line 61
    new-instance v1, Landroid/content/res/ColorStateList;

    .line 62
    .line 63
    sget-object v2, LrQ;->oaX_6_:[[I

    .line 64
    .line 65
    invoke-direct {v1, v2, v0}, Landroid/content/res/ColorStateList;-><init>([[I[I)V

    .line 66
    .line 67
    .line 68
    iput-object v1, p0, LrQ;->valuI:Landroid/content/res/ColorStateList;

    .line 69
    .line 70
    :cond_0
    iget-object v0, p0, LrQ;->valuI:Landroid/content/res/ColorStateList;

    .line 71
    .line 72
    return-object v0
.end method

.method private getSuperButtonTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-object v0

    .line 6
    :cond_0
    invoke-super {p0}, Landroid/widget/CheckBox;->getButtonTintList()Landroid/content/res/ColorStateList;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    invoke-super {p0}, Landroid/widget/CheckBox;->getButtonTintList()Landroid/content/res/ColorStateList;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    return-object v0

    .line 17
    :cond_1
    invoke-interface {p0}, LQkcatè;->getSupportButtonTintList()Landroid/content/res/ColorStateList;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    return-object v0
.end method


# virtual methods
.method public final e8$mp_s$()V
    .locals 14

    .line 1
    iget-object v0, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    iget-object v1, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/widget/CompoundButton;->getButtonTintMode()Landroid/graphics/PorterDuff$Mode;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    invoke-static {v0, v1, v2}, Lzl1;->yàÒZ(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Drawable;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    iput-object v0, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 14
    .line 15
    iget-object v0, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 16
    .line 17
    iget-object v1, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 18
    .line 19
    iget-object v2, p0, LrQ;->Q1_f_:Landroid/graphics/PorterDuff$Mode;

    .line 20
    .line 21
    invoke-static {v0, v1, v2}, Lzl1;->yàÒZ(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;Landroid/graphics/PorterDuff$Mode;)Landroid/graphics/drawable/Drawable;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    iput-object v0, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 26
    .line 27
    iget-boolean v0, p0, LrQ;->UC_n_:Z

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    const/4 v2, 0x0

    .line 31
    if-nez v0, :cond_0

    .line 32
    .line 33
    goto/16 :goto_2

    .line 34
    .line 35
    :cond_0
    iget-object v0, p0, LrQ;->yPN$A_n$:Lbokmka;

    .line 36
    .line 37
    if-eqz v0, :cond_b

    .line 38
    .line 39
    iget-object v3, v0, Lbokmka;->vaIue:Lu1D1;

    .line 40
    .line 41
    iget-object v4, v0, LcQO$W$;->yON3x:Landroid/graphics/drawable/Drawable;

    .line 42
    .line 43
    iget-object v5, p0, LrQ;->Oey:LjPos1170;

    .line 44
    .line 45
    if-eqz v4, :cond_2

    .line 46
    .line 47
    check-cast v4, Landroid/graphics/drawable/AnimatedVectorDrawable;

    .line 48
    .line 49
    iget-object v6, v5, LjPos1170;->e8$mp_s$:LIIll1I;

    .line 50
    .line 51
    if-nez v6, :cond_1

    .line 52
    .line 53
    new-instance v6, LIIll1I;

    .line 54
    .line 55
    invoke-direct {v6, v5}, LIIll1I;-><init>(LjPos1170;)V

    .line 56
    .line 57
    .line 58
    iput-object v6, v5, LjPos1170;->e8$mp_s$:LIIll1I;

    .line 59
    .line 60
    :cond_1
    iget-object v6, v5, LjPos1170;->e8$mp_s$:LIIll1I;

    .line 61
    .line 62
    invoke-static {v4, v6}, Ldatl;->yàÒZ(Landroid/graphics/drawable/AnimatedVectorDrawable;Landroid/graphics/drawable/Animatable2$AnimationCallback;)Z

    .line 63
    .line 64
    .line 65
    :cond_2
    iget-object v4, v0, Lbokmka;->kQy:Ljava/util/ArrayList;

    .line 66
    .line 67
    if-eqz v4, :cond_4

    .line 68
    .line 69
    if-nez v5, :cond_3

    .line 70
    .line 71
    goto :goto_0

    .line 72
    :cond_3
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    iget-object v4, v0, Lbokmka;->kQy:Ljava/util/ArrayList;

    .line 76
    .line 77
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 78
    .line 79
    .line 80
    move-result v4

    .line 81
    if-nez v4, :cond_4

    .line 82
    .line 83
    iget-object v4, v0, Lbokmka;->iOffset934:LQÒTlaXA;

    .line 84
    .line 85
    if-eqz v4, :cond_4

    .line 86
    .line 87
    iget-object v6, v3, Lu1D1;->waiBKÀ:Landroid/animation/AnimatorSet;

    .line 88
    .line 89
    invoke-virtual {v6, v4}, Landroid/animation/Animator;->removeListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 90
    .line 91
    .line 92
    const/4 v4, 0x0

    .line 93
    iput-object v4, v0, Lbokmka;->iOffset934:LQÒTlaXA;

    .line 94
    .line 95
    :cond_4
    :goto_0
    iget-object v4, v0, LcQO$W$;->yON3x:Landroid/graphics/drawable/Drawable;

    .line 96
    .line 97
    if-eqz v4, :cond_6

    .line 98
    .line 99
    check-cast v4, Landroid/graphics/drawable/AnimatedVectorDrawable;

    .line 100
    .line 101
    iget-object v3, v5, LjPos1170;->e8$mp_s$:LIIll1I;

    .line 102
    .line 103
    if-nez v3, :cond_5

    .line 104
    .line 105
    new-instance v3, LIIll1I;

    .line 106
    .line 107
    invoke-direct {v3, v5}, LIIll1I;-><init>(LjPos1170;)V

    .line 108
    .line 109
    .line 110
    iput-object v3, v5, LjPos1170;->e8$mp_s$:LIIll1I;

    .line 111
    .line 112
    :cond_5
    iget-object v3, v5, LjPos1170;->e8$mp_s$:LIIll1I;

    .line 113
    .line 114
    invoke-static {v4, v3}, Ldatl;->jPos3709(Landroid/graphics/drawable/AnimatedVectorDrawable;Landroid/graphics/drawable/Animatable2$AnimationCallback;)V

    .line 115
    .line 116
    .line 117
    goto :goto_1

    .line 118
    :cond_6
    if-nez v5, :cond_7

    .line 119
    .line 120
    goto :goto_1

    .line 121
    :cond_7
    iget-object v4, v0, Lbokmka;->kQy:Ljava/util/ArrayList;

    .line 122
    .line 123
    if-nez v4, :cond_8

    .line 124
    .line 125
    new-instance v4, Ljava/util/ArrayList;

    .line 126
    .line 127
    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    .line 128
    .line 129
    .line 130
    iput-object v4, v0, Lbokmka;->kQy:Ljava/util/ArrayList;

    .line 131
    .line 132
    :cond_8
    iget-object v4, v0, Lbokmka;->kQy:Ljava/util/ArrayList;

    .line 133
    .line 134
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v4

    .line 138
    if-eqz v4, :cond_9

    .line 139
    .line 140
    goto :goto_1

    .line 141
    :cond_9
    iget-object v4, v0, Lbokmka;->kQy:Ljava/util/ArrayList;

    .line 142
    .line 143
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    iget-object v4, v0, Lbokmka;->iOffset934:LQÒTlaXA;

    .line 147
    .line 148
    if-nez v4, :cond_a

    .line 149
    .line 150
    new-instance v4, LQÒTlaXA;

    .line 151
    .line 152
    invoke-direct {v4, v1, v0}, LQÒTlaXA;-><init>(ILjava/lang/Object;)V

    .line 153
    .line 154
    .line 155
    iput-object v4, v0, Lbokmka;->iOffset934:LQÒTlaXA;

    .line 156
    .line 157
    :cond_a
    iget-object v3, v3, Lu1D1;->waiBKÀ:Landroid/animation/AnimatorSet;

    .line 158
    .line 159
    iget-object v4, v0, Lbokmka;->iOffset934:LQÒTlaXA;

    .line 160
    .line 161
    invoke-virtual {v3, v4}, Landroid/animation/Animator;->addListener(Landroid/animation/Animator$AnimatorListener;)V

    .line 162
    .line 163
    .line 164
    :cond_b
    :goto_1
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 165
    .line 166
    const/16 v4, 0x18

    .line 167
    .line 168
    if-lt v3, v4, :cond_c

    .line 169
    .line 170
    iget-object v3, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 171
    .line 172
    instance-of v4, v3, Landroid/graphics/drawable/AnimatedStateListDrawable;

    .line 173
    .line 174
    if-eqz v4, :cond_c

    .line 175
    .line 176
    if-eqz v0, :cond_c

    .line 177
    .line 178
    check-cast v3, Landroid/graphics/drawable/AnimatedStateListDrawable;

    .line 179
    .line 180
    sget v4, LisIndex5467;->checked:I

    .line 181
    .line 182
    sget v5, LisIndex5467;->unchecked:I

    .line 183
    .line 184
    invoke-virtual {v3, v4, v5, v0, v2}, Landroid/graphics/drawable/AnimatedStateListDrawable;->addTransition(IILandroid/graphics/drawable/Drawable;Z)V

    .line 185
    .line 186
    .line 187
    iget-object v3, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 188
    .line 189
    check-cast v3, Landroid/graphics/drawable/AnimatedStateListDrawable;

    .line 190
    .line 191
    sget v4, LisIndex5467;->indeterminate:I

    .line 192
    .line 193
    sget v5, LisIndex5467;->unchecked:I

    .line 194
    .line 195
    invoke-virtual {v3, v4, v5, v0, v2}, Landroid/graphics/drawable/AnimatedStateListDrawable;->addTransition(IILandroid/graphics/drawable/Drawable;Z)V

    .line 196
    .line 197
    .line 198
    :cond_c
    :goto_2
    iget-object v0, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 199
    .line 200
    if-eqz v0, :cond_d

    .line 201
    .line 202
    iget-object v3, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 203
    .line 204
    if-eqz v3, :cond_d

    .line 205
    .line 206
    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    .line 207
    .line 208
    .line 209
    :cond_d
    iget-object v0, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 210
    .line 211
    if-eqz v0, :cond_e

    .line 212
    .line 213
    iget-object v3, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 214
    .line 215
    if-eqz v3, :cond_e

    .line 216
    .line 217
    invoke-virtual {v0, v3}, Landroid/graphics/drawable/Drawable;->setTintList(Landroid/content/res/ColorStateList;)V

    .line 218
    .line 219
    .line 220
    :cond_e
    iget-object v0, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 221
    .line 222
    iget-object v3, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 223
    .line 224
    if-nez v0, :cond_f

    .line 225
    .line 226
    move-object v0, v3

    .line 227
    goto/16 :goto_6

    .line 228
    .line 229
    :cond_f
    if-nez v3, :cond_10

    .line 230
    .line 231
    goto/16 :goto_6

    .line 232
    .line 233
    :cond_10
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 234
    .line 235
    .line 236
    move-result v4

    .line 237
    const/4 v5, -0x1

    .line 238
    if-eq v4, v5, :cond_11

    .line 239
    .line 240
    goto :goto_3

    .line 241
    :cond_11
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 242
    .line 243
    .line 244
    move-result v4

    .line 245
    :goto_3
    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 246
    .line 247
    .line 248
    move-result v6

    .line 249
    if-eq v6, v5, :cond_12

    .line 250
    .line 251
    goto :goto_4

    .line 252
    :cond_12
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 253
    .line 254
    .line 255
    move-result v6

    .line 256
    :goto_4
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 257
    .line 258
    .line 259
    move-result v5

    .line 260
    if-gt v4, v5, :cond_13

    .line 261
    .line 262
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 263
    .line 264
    .line 265
    move-result v5

    .line 266
    if-gt v6, v5, :cond_13

    .line 267
    .line 268
    goto :goto_5

    .line 269
    :cond_13
    int-to-float v4, v4

    .line 270
    int-to-float v5, v6

    .line 271
    div-float/2addr v4, v5

    .line 272
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 273
    .line 274
    .line 275
    move-result v5

    .line 276
    int-to-float v5, v5

    .line 277
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 278
    .line 279
    .line 280
    move-result v6

    .line 281
    int-to-float v6, v6

    .line 282
    div-float/2addr v5, v6

    .line 283
    cmpl-float v5, v4, v5

    .line 284
    .line 285
    if-ltz v5, :cond_14

    .line 286
    .line 287
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 288
    .line 289
    .line 290
    move-result v5

    .line 291
    int-to-float v6, v5

    .line 292
    div-float/2addr v6, v4

    .line 293
    float-to-int v6, v6

    .line 294
    move v4, v5

    .line 295
    goto :goto_5

    .line 296
    :cond_14
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 297
    .line 298
    .line 299
    move-result v6

    .line 300
    int-to-float v5, v6

    .line 301
    mul-float v4, v4, v5

    .line 302
    .line 303
    float-to-int v4, v4

    .line 304
    :goto_5
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 305
    .line 306
    const/16 v7, 0x17

    .line 307
    .line 308
    const/4 v8, 0x2

    .line 309
    if-lt v5, v7, :cond_15

    .line 310
    .line 311
    new-instance v5, Landroid/graphics/drawable/LayerDrawable;

    .line 312
    .line 313
    new-array v7, v8, [Landroid/graphics/drawable/Drawable;

    .line 314
    .line 315
    aput-object v0, v7, v2

    .line 316
    .line 317
    aput-object v3, v7, v1

    .line 318
    .line 319
    invoke-direct {v5, v7}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 320
    .line 321
    .line 322
    invoke-static {v5, v4, v6}, Ljc4_8W$K_;->K0I(Landroid/graphics/drawable/LayerDrawable;II)V

    .line 323
    .line 324
    .line 325
    invoke-static {v5}, Ljc4_8W$K_;->kO_6X_(Landroid/graphics/drawable/LayerDrawable;)V

    .line 326
    .line 327
    .line 328
    move-object v0, v5

    .line 329
    goto :goto_6

    .line 330
    :cond_15
    const/4 v5, 0x2

    .line 331
    new-instance v8, Landroid/graphics/drawable/LayerDrawable;

    .line 332
    .line 333
    new-array v7, v5, [Landroid/graphics/drawable/Drawable;

    .line 334
    .line 335
    aput-object v0, v7, v2

    .line 336
    .line 337
    aput-object v3, v7, v1

    .line 338
    .line 339
    invoke-direct {v8, v7}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 343
    .line 344
    .line 345
    move-result v1

    .line 346
    sub-int/2addr v1, v4

    .line 347
    div-int/2addr v1, v5

    .line 348
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    .line 349
    .line 350
    .line 351
    move-result v10

    .line 352
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    .line 353
    .line 354
    .line 355
    move-result v0

    .line 356
    sub-int/2addr v0, v6

    .line 357
    div-int/2addr v0, v5

    .line 358
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    .line 359
    .line 360
    .line 361
    move-result v11

    .line 362
    const/4 v9, 0x1

    .line 363
    move v12, v10

    .line 364
    move v13, v11

    .line 365
    invoke-virtual/range {v8 .. v13}, Landroid/graphics/drawable/LayerDrawable;->setLayerInset(IIIII)V

    .line 366
    .line 367
    .line 368
    move-object v0, v8

    .line 369
    :goto_6
    invoke-super {p0, v0}, LK_S_kQ$8_;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 370
    .line 371
    .line 372
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 373
    .line 374
    .line 375
    return-void
.end method

.method public getButtonDrawable()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    return-object v0
.end method

.method public getButtonIconDrawable()Landroid/graphics/drawable/Drawable;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    return-object v0
.end method

.method public getButtonIconTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    return-object v0
.end method

.method public getButtonIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->Q1_f_:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    return-object v0
.end method

.method public getButtonTintList()Landroid/content/res/ColorStateList;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    return-object v0
.end method

.method public getCheckedState()I
    .locals 1

    .line 1
    iget v0, p0, LrQ;->tmpSize211:I

    .line 2
    .line 3
    return v0
.end method

.method public getErrorAccessibilityLabel()Ljava/lang/CharSequence;
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->kO_6X_:Ljava/lang/CharSequence;

    .line 2
    .line 3
    return-object v0
.end method

.method public final isChecked()Z
    .locals 2

    .line 1
    iget v0, p0, LrQ;->tmpSize211:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    return v0
.end method

.method public final onAttachedToWindow()V
    .locals 1

    .line 1
    invoke-super {p0}, Landroid/widget/CheckBox;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    iget-boolean v0, p0, LrQ;->pCXDYg:Z

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    iget-object v0, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 13
    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    invoke-virtual {p0, v0}, LrQ;->setUseMaterialThemeColors(Z)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void
.end method

.method public final onCreateDrawableState(I)[I
    .locals 3

    .line 1
    const/4 v0, 0x2

    .line 2
    add-int/2addr p1, v0

    .line 3
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onCreateDrawableState(I)[I

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-virtual {p0}, LrQ;->getCheckedState()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-ne v1, v0, :cond_0

    .line 12
    .line 13
    sget-object v0, LrQ;->l1:[I

    .line 14
    .line 15
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 16
    .line 17
    .line 18
    :cond_0
    iget-boolean v0, p0, LrQ;->gKey4112:Z

    .line 19
    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    sget-object v0, LrQ;->pQ1Il:[I

    .line 23
    .line 24
    invoke-static {p1, v0}, Landroid/view/View;->mergeDrawableStates([I[I)[I

    .line 25
    .line 26
    .line 27
    :cond_1
    const/4 v0, 0x0

    .line 28
    :goto_0
    array-length v1, p1

    .line 29
    const v2, 0x10100a0

    .line 30
    .line 31
    .line 32
    if-ge v0, v1, :cond_4

    .line 33
    .line 34
    aget v1, p1, v0

    .line 35
    .line 36
    if-ne v1, v2, :cond_2

    .line 37
    .line 38
    move-object v1, p1

    .line 39
    goto :goto_1

    .line 40
    :cond_2
    if-nez v1, :cond_3

    .line 41
    .line 42
    invoke-virtual {p1}, [I->clone()Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    check-cast v1, [I

    .line 47
    .line 48
    aput v2, v1, v0

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_3
    add-int/lit8 v0, v0, 0x1

    .line 52
    .line 53
    goto :goto_0

    .line 54
    :cond_4
    array-length v0, p1

    .line 55
    add-int/lit8 v0, v0, 0x1

    .line 56
    .line 57
    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    array-length v0, p1

    .line 62
    aput v2, v1, v0

    .line 63
    .line 64
    :goto_1
    iput-object v1, p0, LrQ;->sKey6064:[I

    .line 65
    .line 66
    return-object p1
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 5

    .line 1
    iget-boolean v0, p0, LrQ;->yàÒZ:Z

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_2

    .line 14
    .line 15
    invoke-static {p0}, LQ6$k$;->vaIue(Landroid/widget/CompoundButton;)Landroid/graphics/drawable/Drawable;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    if-eqz v0, :cond_2

    .line 20
    .line 21
    invoke-static {p0}, LdQta;->Ialue(Landroid/view/View;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_0

    .line 26
    .line 27
    const/4 v1, -0x1

    .line 28
    goto :goto_0

    .line 29
    :cond_0
    const/4 v1, 0x1

    .line 30
    :goto_0
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    .line 35
    .line 36
    .line 37
    move-result v3

    .line 38
    sub-int/2addr v2, v3

    .line 39
    div-int/lit8 v2, v2, 0x2

    .line 40
    .line 41
    mul-int v2, v2, v1

    .line 42
    .line 43
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 44
    .line 45
    .line 46
    move-result v1

    .line 47
    int-to-float v3, v2

    .line 48
    const/4 v4, 0x0

    .line 49
    invoke-virtual {p1, v3, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 50
    .line 51
    .line 52
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onDraw(Landroid/graphics/Canvas;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 59
    .line 60
    .line 61
    move-result-object p1

    .line 62
    if-eqz p1, :cond_1

    .line 63
    .line 64
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    .line 65
    .line 66
    .line 67
    move-result-object p1

    .line 68
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iget v1, p1, Landroid/graphics/Rect;->left:I

    .line 73
    .line 74
    add-int/2addr v1, v2

    .line 75
    iget v3, p1, Landroid/graphics/Rect;->top:I

    .line 76
    .line 77
    iget v4, p1, Landroid/graphics/Rect;->right:I

    .line 78
    .line 79
    add-int/2addr v4, v2

    .line 80
    iget p1, p1, Landroid/graphics/Rect;->bottom:I

    .line 81
    .line 82
    invoke-virtual {v0, v1, v3, v4, p1}, Landroid/graphics/drawable/Drawable;->setHotspotBounds(IIII)V

    .line 83
    .line 84
    .line 85
    :cond_1
    return-void

    .line 86
    :cond_2
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onDraw(Landroid/graphics/Canvas;)V

    .line 87
    .line 88
    .line 89
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 2

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_0

    .line 5
    .line 6
    goto :goto_0

    .line 7
    :cond_0
    iget-boolean v0, p0, LrQ;->gKey4112:Z

    .line 8
    .line 9
    if-eqz v0, :cond_1

    .line 10
    .line 11
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", "

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-object v1, p0, LrQ;->kO_6X_:Ljava/lang/CharSequence;

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setText(Ljava/lang/CharSequence;)V

    .line 38
    .line 39
    .line 40
    :cond_1
    :goto_0
    return-void
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 1

    .line 1
    instance-of v0, p1, Ll1ill;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, Ll1ill;

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/AbsSavedState;->getSuperState()Landroid/os/Parcelable;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-super {p0, v0}, Landroid/widget/CheckBox;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 16
    .line 17
    .line 18
    iget p1, p1, Ll1ill;->yON3x:I

    .line 19
    .line 20
    invoke-virtual {p0, p1}, LrQ;->setCheckedState(I)V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    invoke-super {p0}, Landroid/widget/CheckBox;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Ll1ill;

    .line 6
    .line 7
    invoke-direct {v1, v0}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0}, LrQ;->getCheckedState()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    iput v0, v1, Ll1ill;->yON3x:I

    .line 15
    .line 16
    return-object v1
.end method

.method public setButtonDrawable(I)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, p1}, LQ6$k$;->iOffset934(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    invoke-virtual {p0, p1}, LrQ;->setButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    return-void
.end method

.method public setButtonDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 2
    iput-object p1, p0, LrQ;->K0I:Landroid/graphics/drawable/Drawable;

    const/4 p1, 0x0

    .line 3
    iput-boolean p1, p0, LrQ;->UC_n_:Z

    .line 4
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    return-void
.end method

.method public setButtonIconDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 0

    .line 1
    iput-object p1, p0, LrQ;->Qp_Hp$i_:Landroid/graphics/drawable/Drawable;

    .line 2
    .line 3
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setButtonIconDrawableResource(I)V
    .locals 1

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-static {v0, p1}, LQ6$k$;->iOffset934(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LrQ;->setButtonIconDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public setButtonIconTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iput-object p1, p0, LrQ;->$ÒcdS:Landroid/content/res/ColorStateList;

    .line 7
    .line 8
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setButtonIconTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->Q1_f_:Landroid/graphics/PorterDuff$Mode;

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iput-object p1, p0, LrQ;->Q1_f_:Landroid/graphics/PorterDuff$Mode;

    .line 7
    .line 8
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setButtonTintList(Landroid/content/res/ColorStateList;)V
    .locals 1

    .line 1
    iget-object v0, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iput-object p1, p0, LrQ;->kCount1402:Landroid/content/res/ColorStateList;

    .line 7
    .line 8
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setButtonTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 0

    .line 1
    invoke-interface {p0, p1}, LQkcatè;->setSupportButtonTintMode(Landroid/graphics/PorterDuff$Mode;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, LrQ;->e8$mp_s$()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public setCenterIfNoTextEnabled(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, LrQ;->yàÒZ:Z

    .line 2
    .line 3
    return-void
.end method

.method public setChecked(Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, LrQ;->setCheckedState(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public setCheckedState(I)V
    .locals 3

    .line 1
    iget v0, p0, LrQ;->tmpSize211:I

    .line 2
    .line 3
    if-eq v0, p1, :cond_7

    .line 4
    .line 5
    iput p1, p0, LrQ;->tmpSize211:I

    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    const/4 v1, 0x1

    .line 9
    if-ne p1, v1, :cond_0

    .line 10
    .line 11
    const/4 p1, 0x1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    :goto_0
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 18
    .line 19
    .line 20
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 21
    .line 22
    const/16 v2, 0x1e

    .line 23
    .line 24
    if-lt p1, v2, :cond_1

    .line 25
    .line 26
    iget-object v2, p0, LrQ;->ll:Ljava/lang/CharSequence;

    .line 27
    .line 28
    if-nez v2, :cond_1

    .line 29
    .line 30
    invoke-direct {p0}, LrQ;->getButtonStateDescription()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v2

    .line 34
    invoke-super {p0, v2}, Landroid/widget/CheckBox;->setStateDescription(Ljava/lang/CharSequence;)V

    .line 35
    .line 36
    .line 37
    :cond_1
    iget-boolean v2, p0, LrQ;->tzKù7Ol1:Z

    .line 38
    .line 39
    if-eqz v2, :cond_2

    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_2
    iput-boolean v1, p0, LrQ;->tzKù7Ol1:Z

    .line 43
    .line 44
    iget-object v1, p0, LrQ;->Ialue:Ljava/util/LinkedHashSet;

    .line 45
    .line 46
    if-eqz v1, :cond_4

    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    if-nez v2, :cond_3

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_3
    invoke-static {v1}, LRQU_K6$Kv_;->vaIue(Ljava/util/Iterator;)Ljava/lang/ClassCastException;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    throw p1

    .line 64
    :cond_4
    :goto_1
    iget v1, p0, LrQ;->tmpSize211:I

    .line 65
    .line 66
    const/4 v2, 0x2

    .line 67
    if-eq v1, v2, :cond_5

    .line 68
    .line 69
    iget-object v1, p0, LrQ;->oy_R$Xx_:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 70
    .line 71
    if-eqz v1, :cond_5

    .line 72
    .line 73
    invoke-virtual {p0}, LrQ;->isChecked()Z

    .line 74
    .line 75
    .line 76
    move-result v2

    .line 77
    invoke-interface {v1, p0, v2}, Landroid/widget/CompoundButton$OnCheckedChangeListener;->onCheckedChanged(Landroid/widget/CompoundButton;Z)V

    .line 78
    .line 79
    .line 80
    :cond_5
    const/16 v1, 0x1a

    .line 81
    .line 82
    if-lt p1, v1, :cond_6

    .line 83
    .line 84
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    const-class v1, Landroid/view/autofill/AutofillManager;

    .line 89
    .line 90
    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p1

    .line 94
    check-cast p1, Landroid/view/autofill/AutofillManager;

    .line 95
    .line 96
    if-eqz p1, :cond_6

    .line 97
    .line 98
    invoke-virtual {p1, p0}, Landroid/view/autofill/AutofillManager;->notifyValueChanged(Landroid/view/View;)V

    .line 99
    .line 100
    .line 101
    :cond_6
    iput-boolean v0, p0, LrQ;->tzKù7Ol1:Z

    .line 102
    .line 103
    :cond_7
    :goto_2
    return-void
.end method

.method public setEnabled(Z)V
    .locals 0

    .line 1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setEnabled(Z)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public setErrorAccessibilityLabel(Ljava/lang/CharSequence;)V
    .locals 0

    .line 1
    iput-object p1, p0, LrQ;->kO_6X_:Ljava/lang/CharSequence;

    .line 2
    .line 3
    return-void
.end method

.method public setErrorAccessibilityLabelResource(I)V
    .locals 1

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    .line 8
    .line 9
    .line 10
    move-result-object p1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 p1, 0x0

    .line 13
    :goto_0
    invoke-virtual {p0, p1}, LrQ;->setErrorAccessibilityLabel(Ljava/lang/CharSequence;)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public setErrorShown(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, LrQ;->gKey4112:Z

    .line 2
    .line 3
    if-ne v0, p1, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iput-boolean p1, p0, LrQ;->gKey4112:Z

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/view/View;->refreshDrawableState()V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LrQ;->kQy:Ljava/util/LinkedHashSet;

    .line 12
    .line 13
    invoke-virtual {p1}, Ljava/util/AbstractCollection;->iterator()Ljava/util/Iterator;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    if-nez v0, :cond_1

    .line 22
    .line 23
    :goto_0
    return-void

    .line 24
    :cond_1
    invoke-static {p1}, LRQU_K6$Kv_;->vaIue(Ljava/util/Iterator;)Ljava/lang/ClassCastException;

    .line 25
    .line 26
    .line 27
    move-result-object p1

    .line 28
    throw p1
.end method

.method public setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V
    .locals 0

    .line 1
    iput-object p1, p0, LrQ;->oy_R$Xx_:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    .line 2
    .line 3
    return-void
.end method

.method public setStateDescription(Ljava/lang/CharSequence;)V
    .locals 2

    .line 1
    iput-object p1, p0, LrQ;->ll:Ljava/lang/CharSequence;

    .line 2
    .line 3
    if-nez p1, :cond_1

    .line 4
    .line 5
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    .line 7
    const/16 v1, 0x1e

    .line 8
    .line 9
    if-lt v0, v1, :cond_0

    .line 10
    .line 11
    if-nez p1, :cond_0

    .line 12
    .line 13
    invoke-direct {p0}, LrQ;->getButtonStateDescription()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setStateDescription(Ljava/lang/CharSequence;)V

    .line 18
    .line 19
    .line 20
    :cond_0
    return-void

    .line 21
    :cond_1
    invoke-super {p0, p1}, Landroid/widget/CheckBox;->setStateDescription(Ljava/lang/CharSequence;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method

.method public setUseMaterialThemeColors(Z)V
    .locals 0

    .line 1
    iput-boolean p1, p0, LrQ;->pCXDYg:Z

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    invoke-direct {p0}, LrQ;->getMaterialThemeColorsTintList()Landroid/content/res/ColorStateList;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-virtual {p0, p1}, LrQ;->setButtonTintList(Landroid/content/res/ColorStateList;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    const/4 p1, 0x0

    .line 14
    invoke-virtual {p0, p1}, LrQ;->setButtonTintList(Landroid/content/res/ColorStateList;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final toggle()V
    .locals 1

    .line 1
    invoke-virtual {p0}, LrQ;->isChecked()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    xor-int/lit8 v0, v0, 0x1

    .line 6
    .line 7
    invoke-virtual {p0, v0}, LrQ;->setChecked(Z)V

    .line 8
    .line 9
    .line 10
    return-void
.end method
