.class public final Lke1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public e8$mp_s$:I

.field public rz__9J_:I

.field public waiBKÀ:I


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lke1;->e8$mp_s$:I

    iput v0, p0, Lke1;->waiBKÀ:I

    iput v0, p0, Lke1;->rz__9J_:I

    return-void
.end method

.method public constructor <init>(III)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lke1;->e8$mp_s$:I

    iput p2, p0, Lke1;->rz__9J_:I

    iput p3, p0, Lke1;->waiBKÀ:I

    return-void
.end method

.method public synthetic constructor <init>(ZIII)V
    .locals 0

    .line 3
    iput p2, p0, Lke1;->e8$mp_s$:I

    iput p3, p0, Lke1;->waiBKÀ:I

    iput p4, p0, Lke1;->rz__9J_:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static e8$mp_s$(Lmh_p$kn_;)Lke1;
    .locals 3

    .line 1
    iget-boolean v0, p0, Lmh_p$kn_;->iOffset934:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    new-instance p0, Lke1;

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    invoke-direct {p0, v0, v1, v1}, Lke1;-><init>(III)V

    .line 10
    .line 11
    .line 12
    return-object p0

    .line 13
    :cond_0
    iget-boolean v0, p0, Lmh_p$kn_;->yàÒZ:Z

    .line 14
    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    new-instance p0, Lke1;

    .line 18
    .line 19
    const/4 v0, 0x2

    .line 20
    invoke-direct {p0, v0, v1, v1}, Lke1;-><init>(III)V

    .line 21
    .line 22
    .line 23
    return-object p0

    .line 24
    :cond_1
    iget-boolean v0, p0, Lmh_p$kn_;->pCXDYg:Z

    .line 25
    .line 26
    if-eqz v0, :cond_2

    .line 27
    .line 28
    new-instance p0, Lke1;

    .line 29
    .line 30
    invoke-direct {p0, v1, v1, v1}, Lke1;-><init>(III)V

    .line 31
    .line 32
    .line 33
    return-object p0

    .line 34
    :cond_2
    iget v0, p0, Lmh_p$kn_;->Ialue:I

    .line 35
    .line 36
    iget p0, p0, Lmh_p$kn_;->jPos3709:I

    .line 37
    .line 38
    new-instance v1, Lke1;

    .line 39
    .line 40
    const/4 v2, 0x1

    .line 41
    invoke-direct {v1, v2, v0, p0}, Lke1;-><init>(III)V

    .line 42
    .line 43
    .line 44
    return-object v1
.end method


# virtual methods
.method public waiBKÀ()Z
    .locals 2

    .line 1
    iget v0, p0, Lke1;->e8$mp_s$:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    if-ne v0, v1, :cond_0

    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    return v0

    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    return v0
.end method
