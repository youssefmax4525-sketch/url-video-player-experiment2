.class public abstract LiDmiEkt;
.super Ljava/lang/Object;


# static fields
.field public static compat_button_inset_horizontal_material:I = 0x7f07007c

.field public static compat_button_inset_vertical_material:I = 0x7f07007d

.field public static compat_button_padding_horizontal_material:I = 0x7f07007e

.field public static compat_button_padding_vertical_material:I = 0x7f07007f

.field public static compat_control_corner_material:I = 0x7f070080

.field public static compat_notification_large_icon_max_height:I = 0x7f070081

.field public static compat_notification_large_icon_max_width:I = 0x7f070082

.field public static notification_action_icon_size:I = 0x7f070457

.field public static notification_action_text_size:I = 0x7f070458

.field public static notification_big_circle_margin:I = 0x7f070459

.field public static notification_content_margin_start:I = 0x7f07045a

.field public static notification_large_icon_height:I = 0x7f07045b

.field public static notification_large_icon_width:I = 0x7f07045c

.field public static notification_main_column_padding_top:I = 0x7f07045d

.field public static notification_media_narrow_margin:I = 0x7f07045e

.field public static notification_right_icon_size:I = 0x7f07045f

.field public static notification_right_side_padding_top:I = 0x7f070460

.field public static notification_small_icon_background_padding:I = 0x7f070461

.field public static notification_small_icon_size_as_large:I = 0x7f070462

.field public static notification_subtext_size:I = 0x7f070463

.field public static notification_top_pad:I = 0x7f070464

.field public static notification_top_pad_large_text:I = 0x7f070465
