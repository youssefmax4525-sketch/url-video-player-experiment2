.class public final LDx_Ac_;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:I

.field public final rz__9J_:Z

.field public final waiBKÀ:[B


# direct methods
.method public constructor <init>([BIZ)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p2, p0, LDx_Ac_;->e8$mp_s$:I

    .line 5
    .line 6
    iput-object p1, p0, LDx_Ac_;->waiBKÀ:[B

    .line 7
    .line 8
    iput-boolean p3, p0, LDx_Ac_;->rz__9J_:Z

    .line 9
    .line 10
    return-void
.end method
