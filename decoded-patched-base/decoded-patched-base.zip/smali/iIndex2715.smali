.class public abstract LiIndex2715;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e8$mp_s$:LvSize5689;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LvSize5689;

    .line 2
    .line 3
    const/16 v1, 0x8

    .line 4
    .line 5
    invoke-direct {v0, v1}, LvSize5689;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sput-object v0, LiIndex2715;->e8$mp_s$:LvSize5689;

    .line 9
    .line 10
    return-void
.end method
