.class public abstract Ly0D;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static e8$mp_s$(Landroid/app/ActivityOptions;Z)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroid/app/ActivityOptions;->setShareIdentityEnabled(Z)Landroid/app/ActivityOptions;

    .line 2
    .line 3
    .line 4
    return-void
.end method
