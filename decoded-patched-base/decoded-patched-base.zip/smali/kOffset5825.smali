.class public final LkOffset5825;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# static fields
.field public static final waiBKÀ:LkOffset5825;


# instance fields
.field public final synthetic e8$mp_s$:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LkOffset5825;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, LkOffset5825;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LkOffset5825;->waiBKÀ:LkOffset5825;

    .line 8
    .line 9
    return-void
.end method

.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LkOffset5825;->e8$mp_s$:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 9

    .line 1
    iget v0, p0, LkOffset5825;->e8$mp_s$:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x1

    .line 6
    const/4 v4, 0x0

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    invoke-static {p1}, LvItem3158;->ChI_KH_(Landroid/os/Parcel;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    move-object v5, v4

    .line 15
    const/4 v4, 0x0

    .line 16
    :goto_0
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    .line 17
    .line 18
    .line 19
    move-result v6

    .line 20
    if-ge v6, v0, :cond_3

    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 23
    .line 24
    .line 25
    move-result v6

    .line 26
    int-to-char v7, v6

    .line 27
    if-eq v7, v3, :cond_2

    .line 28
    .line 29
    if-eq v7, v1, :cond_1

    .line 30
    .line 31
    const/4 v8, 0x3

    .line 32
    if-eq v7, v8, :cond_0

    .line 33
    .line 34
    invoke-static {p1, v6}, LvItem3158;->BCIm(Landroid/os/Parcel;I)V

    .line 35
    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_0
    sget-object v5, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 39
    .line 40
    invoke-static {p1, v6, v5}, LvItem3158;->kQy(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 41
    .line 42
    .line 43
    move-result-object v5

    .line 44
    check-cast v5, Landroid/content/Intent;

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_1
    invoke-static {p1, v6}, LvItem3158;->Oey(Landroid/os/Parcel;I)I

    .line 48
    .line 49
    .line 50
    move-result v4

    .line 51
    goto :goto_0

    .line 52
    :cond_2
    invoke-static {p1, v6}, LvItem3158;->Oey(Landroid/os/Parcel;I)I

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    goto :goto_0

    .line 57
    :cond_3
    invoke-static {p1, v0}, LvItem3158;->kO_6X_(Landroid/os/Parcel;I)V

    .line 58
    .line 59
    .line 60
    new-instance p1, LLsa$df_W$;

    .line 61
    .line 62
    invoke-direct {p1, v2, v4, v5}, LLsa$df_W$;-><init>(IILandroid/content/Intent;)V

    .line 63
    .line 64
    .line 65
    return-object p1

    .line 66
    :pswitch_0
    invoke-static {p1}, LvItem3158;->ChI_KH_(Landroid/os/Parcel;)I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    :goto_1
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    if-ge v5, v0, :cond_6

    .line 75
    .line 76
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 77
    .line 78
    .line 79
    move-result v5

    .line 80
    int-to-char v6, v5

    .line 81
    if-eq v6, v3, :cond_5

    .line 82
    .line 83
    if-eq v6, v1, :cond_4

    .line 84
    .line 85
    invoke-static {p1, v5}, LvItem3158;->BCIm(Landroid/os/Parcel;I)V

    .line 86
    .line 87
    .line 88
    goto :goto_1

    .line 89
    :cond_4
    sget-object v4, Lco0nt;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 90
    .line 91
    invoke-static {p1, v5, v4}, LvItem3158;->gKey4112(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    goto :goto_1

    .line 96
    :cond_5
    invoke-static {p1, v5}, LvItem3158;->Oey(Landroid/os/Parcel;I)I

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    goto :goto_1

    .line 101
    :cond_6
    invoke-static {p1, v0}, LvItem3158;->kO_6X_(Landroid/os/Parcel;I)V

    .line 102
    .line 103
    .line 104
    new-instance p1, LsnzàSw;

    .line 105
    .line 106
    invoke-direct {p1, v2, v4}, LsnzàSw;-><init>(ILjava/util/List;)V

    .line 107
    .line 108
    .line 109
    return-object p1

    .line 110
    :pswitch_1
    new-instance v0, LhasOffset6417;

    .line 111
    .line 112
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 113
    .line 114
    .line 115
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    iput v1, v0, LhasOffset6417;->yON3x:I

    .line 120
    .line 121
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 122
    .line 123
    .line 124
    move-result v1

    .line 125
    iput v1, v0, LhasOffset6417;->vaIue:I

    .line 126
    .line 127
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    iput v1, v0, LhasOffset6417;->jPos3709:I

    .line 132
    .line 133
    if-lez v1, :cond_7

    .line 134
    .line 135
    new-array v1, v1, [I

    .line 136
    .line 137
    iput-object v1, v0, LhasOffset6417;->iOffset934:[I

    .line 138
    .line 139
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    .line 140
    .line 141
    .line 142
    :cond_7
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    iput v1, v0, LhasOffset6417;->kQy:I

    .line 147
    .line 148
    if-lez v1, :cond_8

    .line 149
    .line 150
    new-array v1, v1, [I

    .line 151
    .line 152
    iput-object v1, v0, LhasOffset6417;->Ialue:[I

    .line 153
    .line 154
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    .line 155
    .line 156
    .line 157
    :cond_8
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 158
    .line 159
    .line 160
    move-result v1

    .line 161
    if-ne v1, v3, :cond_9

    .line 162
    .line 163
    const/4 v1, 0x1

    .line 164
    goto :goto_2

    .line 165
    :cond_9
    const/4 v1, 0x0

    .line 166
    :goto_2
    iput-boolean v1, v0, LhasOffset6417;->pCXDYg:Z

    .line 167
    .line 168
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 169
    .line 170
    .line 171
    move-result v1

    .line 172
    if-ne v1, v3, :cond_a

    .line 173
    .line 174
    const/4 v1, 0x1

    .line 175
    goto :goto_3

    .line 176
    :cond_a
    const/4 v1, 0x0

    .line 177
    :goto_3
    iput-boolean v1, v0, LhasOffset6417;->yàÒZ:Z

    .line 178
    .line 179
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 180
    .line 181
    .line 182
    move-result v1

    .line 183
    if-ne v1, v3, :cond_b

    .line 184
    .line 185
    const/4 v2, 0x1

    .line 186
    :cond_b
    iput-boolean v2, v0, LhasOffset6417;->gKey4112:Z

    .line 187
    .line 188
    const-class v1, LFDl1O0;

    .line 189
    .line 190
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 191
    .line 192
    .line 193
    move-result-object v1

    .line 194
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readArrayList(Ljava/lang/ClassLoader;)Ljava/util/ArrayList;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    iput-object p1, v0, LhasOffset6417;->valuI:Ljava/util/ArrayList;

    .line 199
    .line 200
    return-object v0

    .line 201
    :pswitch_2
    new-instance v0, LFDl1O0;

    .line 202
    .line 203
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 204
    .line 205
    .line 206
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 207
    .line 208
    .line 209
    move-result v1

    .line 210
    iput v1, v0, LFDl1O0;->yON3x:I

    .line 211
    .line 212
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 213
    .line 214
    .line 215
    move-result v1

    .line 216
    iput v1, v0, LFDl1O0;->vaIue:I

    .line 217
    .line 218
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    if-ne v1, v3, :cond_c

    .line 223
    .line 224
    const/4 v2, 0x1

    .line 225
    :cond_c
    iput-boolean v2, v0, LFDl1O0;->iOffset934:Z

    .line 226
    .line 227
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 228
    .line 229
    .line 230
    move-result v1

    .line 231
    if-lez v1, :cond_d

    .line 232
    .line 233
    new-array v1, v1, [I

    .line 234
    .line 235
    iput-object v1, v0, LFDl1O0;->jPos3709:[I

    .line 236
    .line 237
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readIntArray([I)V

    .line 238
    .line 239
    .line 240
    :cond_d
    return-object v0

    .line 241
    :pswitch_3
    new-instance v0, LkItem3038;

    .line 242
    .line 243
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 244
    .line 245
    .line 246
    invoke-virtual {p1}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    .line 247
    .line 248
    .line 249
    move-result-object p1

    .line 250
    sget v1, LiQ;->vaIue:I

    .line 251
    .line 252
    if-nez p1, :cond_e

    .line 253
    .line 254
    goto :goto_4

    .line 255
    :cond_e
    sget-object v1, LjSize5839;->POOl:Ljava/lang/String;

    .line 256
    .line 257
    invoke-interface {p1, v1}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    .line 258
    .line 259
    .line 260
    move-result-object v1

    .line 261
    if-eqz v1, :cond_f

    .line 262
    .line 263
    instance-of v2, v1, LjSize5839;

    .line 264
    .line 265
    if-eqz v2, :cond_f

    .line 266
    .line 267
    move-object v4, v1

    .line 268
    check-cast v4, LjSize5839;

    .line 269
    .line 270
    goto :goto_4

    .line 271
    :cond_f
    new-instance v4, Lclunt;

    .line 272
    .line 273
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 274
    .line 275
    .line 276
    iput-object p1, v4, Lclunt;->yON3x:Landroid/os/IBinder;

    .line 277
    .line 278
    :goto_4
    iput-object v4, v0, LkItem3038;->yON3x:LjSize5839;

    .line 279
    .line 280
    return-object v0

    .line 281
    :pswitch_4
    new-instance v0, Landroid/support/v4/media/RatingCompat;

    .line 282
    .line 283
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 284
    .line 285
    .line 286
    move-result v1

    .line 287
    invoke-virtual {p1}, Landroid/os/Parcel;->readFloat()F

    .line 288
    .line 289
    .line 290
    move-result p1

    .line 291
    invoke-direct {v0, v1, p1}, Landroid/support/v4/media/RatingCompat;-><init>(IF)V

    .line 292
    .line 293
    .line 294
    return-object v0

    .line 295
    :pswitch_5
    new-instance v0, Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 296
    .line 297
    invoke-direct {v0, p1}, Landroid/support/v4/media/session/PlaybackStateCompat;-><init>(Landroid/os/Parcel;)V

    .line 298
    .line 299
    .line 300
    return-object v0

    .line 301
    :pswitch_6
    new-instance v0, Landroid/support/v4/media/session/ParcelableVolumeInfo;

    .line 302
    .line 303
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 304
    .line 305
    .line 306
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 307
    .line 308
    .line 309
    move-result v1

    .line 310
    iput v1, v0, Landroid/support/v4/media/session/ParcelableVolumeInfo;->yON3x:I

    .line 311
    .line 312
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 313
    .line 314
    .line 315
    move-result v1

    .line 316
    iput v1, v0, Landroid/support/v4/media/session/ParcelableVolumeInfo;->jPos3709:I

    .line 317
    .line 318
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 319
    .line 320
    .line 321
    move-result v1

    .line 322
    iput v1, v0, Landroid/support/v4/media/session/ParcelableVolumeInfo;->iOffset934:I

    .line 323
    .line 324
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 325
    .line 326
    .line 327
    move-result v1

    .line 328
    iput v1, v0, Landroid/support/v4/media/session/ParcelableVolumeInfo;->kQy:I

    .line 329
    .line 330
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 331
    .line 332
    .line 333
    move-result p1

    .line 334
    iput p1, v0, Landroid/support/v4/media/session/ParcelableVolumeInfo;->vaIue:I

    .line 335
    .line 336
    return-object v0

    .line 337
    :pswitch_7
    new-instance v0, Landroidx/versionedparcelable/ParcelImpl;

    .line 338
    .line 339
    invoke-direct {v0, p1}, Landroidx/versionedparcelable/ParcelImpl;-><init>(Landroid/os/Parcel;)V

    .line 340
    .line 341
    .line 342
    return-object v0

    .line 343
    :pswitch_8
    new-instance v0, LnOO;

    .line 344
    .line 345
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 346
    .line 347
    .line 348
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 349
    .line 350
    .line 351
    move-result p1

    .line 352
    iput p1, v0, LnOO;->yON3x:I

    .line 353
    .line 354
    return-object v0

    .line 355
    :pswitch_9
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 356
    .line 357
    .line 358
    move-result v0

    .line 359
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 360
    .line 361
    .line 362
    move-result p1

    .line 363
    invoke-static {v0, p1}, LiIndex6820;->waiBKÀ(II)LiIndex6820;

    .line 364
    .line 365
    .line 366
    move-result-object p1

    .line 367
    return-object p1

    .line 368
    :pswitch_a
    invoke-virtual {p1, v4}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 369
    .line 370
    .line 371
    move-result-object p1

    .line 372
    new-instance v0, Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 373
    .line 374
    invoke-direct {v0, p1, v4}, Landroid/support/v4/media/session/MediaSessionCompat$Token;-><init>(Ljava/lang/Object;Landroid/support/v4/media/session/JKEoÙX;)V

    .line 375
    .line 376
    .line 377
    return-object v0

    .line 378
    :pswitch_b
    new-instance v0, Landroid/support/v4/media/session/MediaSessionCompat$QueueItem;

    .line 379
    .line 380
    invoke-direct {v0, p1}, Landroid/support/v4/media/session/MediaSessionCompat$QueueItem;-><init>(Landroid/os/Parcel;)V

    .line 381
    .line 382
    .line 383
    return-object v0

    .line 384
    :pswitch_c
    new-instance v0, Landroid/support/v4/media/MediaMetadataCompat;

    .line 385
    .line 386
    invoke-direct {v0, p1}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Parcel;)V

    .line 387
    .line 388
    .line 389
    return-object v0

    .line 390
    :pswitch_d
    sget-object v0, Landroid/media/MediaDescription;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 391
    .line 392
    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 393
    .line 394
    .line 395
    move-result-object p1

    .line 396
    invoke-static {p1}, Landroid/support/v4/media/MediaDescriptionCompat;->waiBKÀ(Ljava/lang/Object;)Landroid/support/v4/media/MediaDescriptionCompat;

    .line 397
    .line 398
    .line 399
    move-result-object p1

    .line 400
    return-object p1

    .line 401
    :pswitch_e
    new-instance v0, Landroid/support/v4/media/MediaBrowserCompat$MediaItem;

    .line 402
    .line 403
    invoke-direct {v0, p1}, Landroid/support/v4/media/MediaBrowserCompat$MediaItem;-><init>(Landroid/os/Parcel;)V

    .line 404
    .line 405
    .line 406
    return-object v0

    .line 407
    :pswitch_f
    new-instance v0, Ll1ill;

    .line 408
    .line 409
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 410
    .line 411
    .line 412
    const-class v1, Ll1ill;

    .line 413
    .line 414
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 415
    .line 416
    .line 417
    move-result-object v1

    .line 418
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readValue(Ljava/lang/ClassLoader;)Ljava/lang/Object;

    .line 419
    .line 420
    .line 421
    move-result-object p1

    .line 422
    check-cast p1, Ljava/lang/Integer;

    .line 423
    .line 424
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 425
    .line 426
    .line 427
    move-result p1

    .line 428
    iput p1, v0, Ll1ill;->yON3x:I

    .line 429
    .line 430
    return-object v0

    .line 431
    :pswitch_10
    new-instance v0, LkUu_T_;

    .line 432
    .line 433
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 434
    .line 435
    .line 436
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 437
    .line 438
    .line 439
    move-result v1

    .line 440
    iput v1, v0, LkUu_T_;->yON3x:I

    .line 441
    .line 442
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 443
    .line 444
    .line 445
    move-result v1

    .line 446
    iput v1, v0, LkUu_T_;->vaIue:I

    .line 447
    .line 448
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 449
    .line 450
    .line 451
    move-result p1

    .line 452
    if-ne p1, v3, :cond_10

    .line 453
    .line 454
    const/4 v2, 0x1

    .line 455
    :cond_10
    iput-boolean v2, v0, LkUu_T_;->jPos3709:Z

    .line 456
    .line 457
    return-object v0

    .line 458
    :pswitch_11
    new-instance v0, LOÀfPscCj;

    .line 459
    .line 460
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 461
    .line 462
    .line 463
    sget-object v1, Landroid/os/Bundle;->EMPTY:Landroid/os/Bundle;

    .line 464
    .line 465
    iput-object v1, v0, LOÀfPscCj;->vaIue:Landroid/os/Bundle;

    .line 466
    .line 467
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 468
    .line 469
    .line 470
    move-result v1

    .line 471
    iput v1, v0, LOÀfPscCj;->yON3x:I

    .line 472
    .line 473
    const-class v1, Landroidx/leanback/widget/GridLayoutManager;

    .line 474
    .line 475
    invoke-virtual {v1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 476
    .line 477
    .line 478
    move-result-object v1

    .line 479
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readBundle(Ljava/lang/ClassLoader;)Landroid/os/Bundle;

    .line 480
    .line 481
    .line 482
    move-result-object p1

    .line 483
    iput-object p1, v0, LOÀfPscCj;->vaIue:Landroid/os/Bundle;

    .line 484
    .line 485
    return-object v0

    .line 486
    :pswitch_12
    new-instance v0, LOo_A$F_;

    .line 487
    .line 488
    invoke-direct {v0, p1}, LOo_A$F_;-><init>(Landroid/os/Parcel;)V

    .line 489
    .line 490
    .line 491
    return-object v0

    .line 492
    :pswitch_13
    new-instance v0, LJU_R_;

    .line 493
    .line 494
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 495
    .line 496
    .line 497
    iput-object v4, v0, LJU_R_;->kQy:Ljava/lang/String;

    .line 498
    .line 499
    new-instance v1, Ljava/util/ArrayList;

    .line 500
    .line 501
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 502
    .line 503
    .line 504
    iput-object v1, v0, LJU_R_;->Ialue:Ljava/util/ArrayList;

    .line 505
    .line 506
    new-instance v1, Ljava/util/ArrayList;

    .line 507
    .line 508
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 509
    .line 510
    .line 511
    iput-object v1, v0, LJU_R_;->valuI:Ljava/util/ArrayList;

    .line 512
    .line 513
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 514
    .line 515
    .line 516
    move-result-object v1

    .line 517
    iput-object v1, v0, LJU_R_;->yON3x:Ljava/util/ArrayList;

    .line 518
    .line 519
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 520
    .line 521
    .line 522
    move-result-object v1

    .line 523
    iput-object v1, v0, LJU_R_;->vaIue:Ljava/util/ArrayList;

    .line 524
    .line 525
    sget-object v1, LjH0_ah_;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 526
    .line 527
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;

    .line 528
    .line 529
    .line 530
    move-result-object v1

    .line 531
    check-cast v1, [LjH0_ah_;

    .line 532
    .line 533
    iput-object v1, v0, LJU_R_;->jPos3709:[LjH0_ah_;

    .line 534
    .line 535
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 536
    .line 537
    .line 538
    move-result v1

    .line 539
    iput v1, v0, LJU_R_;->iOffset934:I

    .line 540
    .line 541
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 542
    .line 543
    .line 544
    move-result-object v1

    .line 545
    iput-object v1, v0, LJU_R_;->kQy:Ljava/lang/String;

    .line 546
    .line 547
    invoke-virtual {p1}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    .line 548
    .line 549
    .line 550
    move-result-object v1

    .line 551
    iput-object v1, v0, LJU_R_;->Ialue:Ljava/util/ArrayList;

    .line 552
    .line 553
    sget-object v1, LnKey3134;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 554
    .line 555
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 556
    .line 557
    .line 558
    move-result-object v1

    .line 559
    iput-object v1, v0, LJU_R_;->valuI:Ljava/util/ArrayList;

    .line 560
    .line 561
    sget-object v1, LI1lI;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 562
    .line 563
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    .line 564
    .line 565
    .line 566
    move-result-object p1

    .line 567
    iput-object p1, v0, LJU_R_;->pCXDYg:Ljava/util/ArrayList;

    .line 568
    .line 569
    return-object v0

    .line 570
    :pswitch_14
    new-instance v0, LI1lI;

    .line 571
    .line 572
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 573
    .line 574
    .line 575
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 576
    .line 577
    .line 578
    move-result-object v1

    .line 579
    iput-object v1, v0, LI1lI;->yON3x:Ljava/lang/String;

    .line 580
    .line 581
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 582
    .line 583
    .line 584
    move-result p1

    .line 585
    iput p1, v0, LI1lI;->vaIue:I

    .line 586
    .line 587
    return-object v0

    .line 588
    :pswitch_15
    new-instance v0, Lyl;

    .line 589
    .line 590
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    .line 591
    .line 592
    .line 593
    move-result-wide v1

    .line 594
    invoke-direct {v0, v1, v2}, Lyl;-><init>(J)V

    .line 595
    .line 596
    .line 597
    return-object v0

    .line 598
    :pswitch_16
    const-class v0, LiIndex6820;

    .line 599
    .line 600
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 601
    .line 602
    .line 603
    move-result-object v1

    .line 604
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 605
    .line 606
    .line 607
    move-result-object v1

    .line 608
    move-object v3, v1

    .line 609
    check-cast v3, LiIndex6820;

    .line 610
    .line 611
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 612
    .line 613
    .line 614
    move-result-object v1

    .line 615
    invoke-virtual {p1, v1}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 616
    .line 617
    .line 618
    move-result-object v1

    .line 619
    move-object v4, v1

    .line 620
    check-cast v4, LiIndex6820;

    .line 621
    .line 622
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 623
    .line 624
    .line 625
    move-result-object v0

    .line 626
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 627
    .line 628
    .line 629
    move-result-object v0

    .line 630
    move-object v6, v0

    .line 631
    check-cast v6, LiIndex6820;

    .line 632
    .line 633
    const-class v0, Lyl;

    .line 634
    .line 635
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 636
    .line 637
    .line 638
    move-result-object v0

    .line 639
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    .line 640
    .line 641
    .line 642
    move-result-object v0

    .line 643
    move-object v5, v0

    .line 644
    check-cast v5, Lyl;

    .line 645
    .line 646
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 647
    .line 648
    .line 649
    move-result v7

    .line 650
    new-instance v2, LtJ_p$__;

    .line 651
    .line 652
    invoke-direct/range {v2 .. v7}, LtJ_p$__;-><init>(LiIndex6820;LiIndex6820;Lyl;LiIndex6820;I)V

    .line 653
    .line 654
    .line 655
    return-object v2

    .line 656
    :pswitch_17
    new-instance v0, LYx6$9$;

    .line 657
    .line 658
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 659
    .line 660
    .line 661
    const/16 v1, 0xff

    .line 662
    .line 663
    iput v1, v0, LYx6$9$;->yàÒZ:I

    .line 664
    .line 665
    const/4 v1, -0x2

    .line 666
    iput v1, v0, LYx6$9$;->kO_6X_:I

    .line 667
    .line 668
    iput v1, v0, LYx6$9$;->K0I:I

    .line 669
    .line 670
    iput v1, v0, LYx6$9$;->Qp_Hp$i_:I

    .line 671
    .line 672
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 673
    .line 674
    iput-object v1, v0, LYx6$9$;->tzKù7Ol1:Ljava/lang/Boolean;

    .line 675
    .line 676
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 677
    .line 678
    .line 679
    move-result v1

    .line 680
    iput v1, v0, LYx6$9$;->yON3x:I

    .line 681
    .line 682
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 683
    .line 684
    .line 685
    move-result-object v1

    .line 686
    check-cast v1, Ljava/lang/Integer;

    .line 687
    .line 688
    iput-object v1, v0, LYx6$9$;->vaIue:Ljava/lang/Integer;

    .line 689
    .line 690
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 691
    .line 692
    .line 693
    move-result-object v1

    .line 694
    check-cast v1, Ljava/lang/Integer;

    .line 695
    .line 696
    iput-object v1, v0, LYx6$9$;->jPos3709:Ljava/lang/Integer;

    .line 697
    .line 698
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 699
    .line 700
    .line 701
    move-result-object v1

    .line 702
    check-cast v1, Ljava/lang/Integer;

    .line 703
    .line 704
    iput-object v1, v0, LYx6$9$;->iOffset934:Ljava/lang/Integer;

    .line 705
    .line 706
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 707
    .line 708
    .line 709
    move-result-object v1

    .line 710
    check-cast v1, Ljava/lang/Integer;

    .line 711
    .line 712
    iput-object v1, v0, LYx6$9$;->kQy:Ljava/lang/Integer;

    .line 713
    .line 714
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 715
    .line 716
    .line 717
    move-result-object v1

    .line 718
    check-cast v1, Ljava/lang/Integer;

    .line 719
    .line 720
    iput-object v1, v0, LYx6$9$;->Ialue:Ljava/lang/Integer;

    .line 721
    .line 722
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 723
    .line 724
    .line 725
    move-result-object v1

    .line 726
    check-cast v1, Ljava/lang/Integer;

    .line 727
    .line 728
    iput-object v1, v0, LYx6$9$;->valuI:Ljava/lang/Integer;

    .line 729
    .line 730
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 731
    .line 732
    .line 733
    move-result-object v1

    .line 734
    check-cast v1, Ljava/lang/Integer;

    .line 735
    .line 736
    iput-object v1, v0, LYx6$9$;->pCXDYg:Ljava/lang/Integer;

    .line 737
    .line 738
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 739
    .line 740
    .line 741
    move-result v1

    .line 742
    iput v1, v0, LYx6$9$;->yàÒZ:I

    .line 743
    .line 744
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 745
    .line 746
    .line 747
    move-result-object v1

    .line 748
    iput-object v1, v0, LYx6$9$;->gKey4112:Ljava/lang/String;

    .line 749
    .line 750
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 751
    .line 752
    .line 753
    move-result v1

    .line 754
    iput v1, v0, LYx6$9$;->kO_6X_:I

    .line 755
    .line 756
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 757
    .line 758
    .line 759
    move-result v1

    .line 760
    iput v1, v0, LYx6$9$;->K0I:I

    .line 761
    .line 762
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 763
    .line 764
    .line 765
    move-result v1

    .line 766
    iput v1, v0, LYx6$9$;->Qp_Hp$i_:I

    .line 767
    .line 768
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 769
    .line 770
    .line 771
    move-result-object v1

    .line 772
    iput-object v1, v0, LYx6$9$;->kCount1402:Ljava/lang/CharSequence;

    .line 773
    .line 774
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    .line 775
    .line 776
    .line 777
    move-result-object v1

    .line 778
    iput-object v1, v0, LYx6$9$;->$ÒcdS:Ljava/lang/CharSequence;

    .line 779
    .line 780
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 781
    .line 782
    .line 783
    move-result v1

    .line 784
    iput v1, v0, LYx6$9$;->Q1_f_:I

    .line 785
    .line 786
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 787
    .line 788
    .line 789
    move-result-object v1

    .line 790
    check-cast v1, Ljava/lang/Integer;

    .line 791
    .line 792
    iput-object v1, v0, LYx6$9$;->sKey6064:Ljava/lang/Integer;

    .line 793
    .line 794
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 795
    .line 796
    .line 797
    move-result-object v1

    .line 798
    check-cast v1, Ljava/lang/Integer;

    .line 799
    .line 800
    iput-object v1, v0, LYx6$9$;->ll:Ljava/lang/Integer;

    .line 801
    .line 802
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 803
    .line 804
    .line 805
    move-result-object v1

    .line 806
    check-cast v1, Ljava/lang/Integer;

    .line 807
    .line 808
    iput-object v1, v0, LYx6$9$;->oy_R$Xx_:Ljava/lang/Integer;

    .line 809
    .line 810
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 811
    .line 812
    .line 813
    move-result-object v1

    .line 814
    check-cast v1, Ljava/lang/Integer;

    .line 815
    .line 816
    iput-object v1, v0, LYx6$9$;->yPN$A_n$:Ljava/lang/Integer;

    .line 817
    .line 818
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 819
    .line 820
    .line 821
    move-result-object v1

    .line 822
    check-cast v1, Ljava/lang/Integer;

    .line 823
    .line 824
    iput-object v1, v0, LYx6$9$;->Oey:Ljava/lang/Integer;

    .line 825
    .line 826
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 827
    .line 828
    .line 829
    move-result-object v1

    .line 830
    check-cast v1, Ljava/lang/Integer;

    .line 831
    .line 832
    iput-object v1, v0, LYx6$9$;->Iii:Ljava/lang/Integer;

    .line 833
    .line 834
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 835
    .line 836
    .line 837
    move-result-object v1

    .line 838
    check-cast v1, Ljava/lang/Integer;

    .line 839
    .line 840
    iput-object v1, v0, LYx6$9$;->l1:Ljava/lang/Integer;

    .line 841
    .line 842
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 843
    .line 844
    .line 845
    move-result-object v1

    .line 846
    check-cast v1, Ljava/lang/Integer;

    .line 847
    .line 848
    iput-object v1, v0, LYx6$9$;->BCIm:Ljava/lang/Integer;

    .line 849
    .line 850
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 851
    .line 852
    .line 853
    move-result-object v1

    .line 854
    check-cast v1, Ljava/lang/Integer;

    .line 855
    .line 856
    iput-object v1, v0, LYx6$9$;->pQ1Il:Ljava/lang/Integer;

    .line 857
    .line 858
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 859
    .line 860
    .line 861
    move-result-object v1

    .line 862
    check-cast v1, Ljava/lang/Integer;

    .line 863
    .line 864
    iput-object v1, v0, LYx6$9$;->oaX_6_:Ljava/lang/Integer;

    .line 865
    .line 866
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 867
    .line 868
    .line 869
    move-result-object v1

    .line 870
    check-cast v1, Ljava/lang/Boolean;

    .line 871
    .line 872
    iput-object v1, v0, LYx6$9$;->tzKù7Ol1:Ljava/lang/Boolean;

    .line 873
    .line 874
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 875
    .line 876
    .line 877
    move-result-object v1

    .line 878
    check-cast v1, Ljava/util/Locale;

    .line 879
    .line 880
    iput-object v1, v0, LYx6$9$;->UC_n_:Ljava/util/Locale;

    .line 881
    .line 882
    invoke-virtual {p1}, Landroid/os/Parcel;->readSerializable()Ljava/io/Serializable;

    .line 883
    .line 884
    .line 885
    move-result-object p1

    .line 886
    check-cast p1, Ljava/lang/Boolean;

    .line 887
    .line 888
    iput-object p1, v0, LYx6$9$;->zAt$p:Ljava/lang/Boolean;

    .line 889
    .line 890
    return-object v0

    .line 891
    :pswitch_18
    new-instance v0, LnKey3134;

    .line 892
    .line 893
    invoke-direct {v0, p1}, LnKey3134;-><init>(Landroid/os/Parcel;)V

    .line 894
    .line 895
    .line 896
    return-object v0

    .line 897
    :pswitch_19
    new-instance v0, LjH0_ah_;

    .line 898
    .line 899
    invoke-direct {v0, p1}, LjH0_ah_;-><init>(Landroid/os/Parcel;)V

    .line 900
    .line 901
    .line 902
    return-object v0

    .line 903
    :pswitch_1a
    new-instance v0, LisPos9173;

    .line 904
    .line 905
    invoke-direct {v0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 906
    .line 907
    .line 908
    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    .line 909
    .line 910
    .line 911
    move-result p1

    .line 912
    if-eqz p1, :cond_11

    .line 913
    .line 914
    const/4 v2, 0x1

    .line 915
    :cond_11
    iput-boolean v2, v0, LisPos9173;->yON3x:Z

    .line 916
    .line 917
    return-object v0

    .line 918
    :pswitch_1b
    new-instance v0, LgKey1542;

    .line 919
    .line 920
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 921
    .line 922
    .line 923
    move-result v1

    .line 924
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 925
    .line 926
    .line 927
    move-result v2

    .line 928
    if-nez v2, :cond_12

    .line 929
    .line 930
    goto :goto_5

    .line 931
    :cond_12
    sget-object v2, Landroid/content/Intent;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 932
    .line 933
    invoke-interface {v2, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 934
    .line 935
    .line 936
    move-result-object p1

    .line 937
    move-object v4, p1

    .line 938
    check-cast v4, Landroid/content/Intent;

    .line 939
    .line 940
    :goto_5
    invoke-direct {v0, v1, v4}, LgKey1542;-><init>(ILandroid/content/Intent;)V

    .line 941
    .line 942
    .line 943
    return-object v0

    .line 944
    :pswitch_1c
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    .line 945
    .line 946
    .line 947
    move-result v0

    .line 948
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 949
    .line 950
    .line 951
    move-result v1

    .line 952
    const v2, -0xc2a5d3a

    .line 953
    .line 954
    .line 955
    if-ne v1, v2, :cond_15

    .line 956
    .line 957
    invoke-static {p1}, LvItem3158;->ChI_KH_(Landroid/os/Parcel;)I

    .line 958
    .line 959
    .line 960
    move-result v0

    .line 961
    :goto_6
    invoke-virtual {p1}, Landroid/os/Parcel;->dataPosition()I

    .line 962
    .line 963
    .line 964
    move-result v1

    .line 965
    if-ge v1, v0, :cond_14

    .line 966
    .line 967
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    .line 968
    .line 969
    .line 970
    move-result v1

    .line 971
    int-to-char v2, v1

    .line 972
    if-eq v2, v3, :cond_13

    .line 973
    .line 974
    invoke-static {p1, v1}, LvItem3158;->BCIm(Landroid/os/Parcel;I)V

    .line 975
    .line 976
    .line 977
    goto :goto_6

    .line 978
    :cond_13
    sget-object v2, LlII;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 979
    .line 980
    invoke-static {p1, v1, v2}, LvItem3158;->kQy(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;

    .line 981
    .line 982
    .line 983
    move-result-object v1

    .line 984
    move-object v4, v1

    .line 985
    check-cast v4, LlII;

    .line 986
    .line 987
    goto :goto_6

    .line 988
    :cond_14
    invoke-static {p1, v0}, LvItem3158;->kO_6X_(Landroid/os/Parcel;I)V

    .line 989
    .line 990
    .line 991
    new-instance p1, LllII;

    .line 992
    .line 993
    invoke-direct {p1, v4}, LllII;-><init>(LlII;)V

    .line 994
    .line 995
    .line 996
    goto :goto_7

    .line 997
    :cond_15
    add-int/lit8 v0, v0, -0x4

    .line 998
    .line 999
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 1000
    .line 1001
    .line 1002
    sget-object p1, LllII;->vaIue:LllII;

    .line 1003
    .line 1004
    :goto_7
    return-object p1

    .line 1005
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LkOffset5825;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    new-array p1, p1, [LLsa$df_W$;

    .line 7
    .line 8
    return-object p1

    .line 9
    :pswitch_0
    new-array p1, p1, [LsnzàSw;

    .line 10
    .line 11
    return-object p1

    .line 12
    :pswitch_1
    new-array p1, p1, [LhasOffset6417;

    .line 13
    .line 14
    return-object p1

    .line 15
    :pswitch_2
    new-array p1, p1, [LFDl1O0;

    .line 16
    .line 17
    return-object p1

    .line 18
    :pswitch_3
    new-array p1, p1, [LkItem3038;

    .line 19
    .line 20
    return-object p1

    .line 21
    :pswitch_4
    new-array p1, p1, [Landroid/support/v4/media/RatingCompat;

    .line 22
    .line 23
    return-object p1

    .line 24
    :pswitch_5
    new-array p1, p1, [Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 25
    .line 26
    return-object p1

    .line 27
    :pswitch_6
    new-array p1, p1, [Landroid/support/v4/media/session/ParcelableVolumeInfo;

    .line 28
    .line 29
    return-object p1

    .line 30
    :pswitch_7
    new-array p1, p1, [Landroidx/versionedparcelable/ParcelImpl;

    .line 31
    .line 32
    return-object p1

    .line 33
    :pswitch_8
    new-array p1, p1, [LnOO;

    .line 34
    .line 35
    return-object p1

    .line 36
    :pswitch_9
    new-array p1, p1, [LiIndex6820;

    .line 37
    .line 38
    return-object p1

    .line 39
    :pswitch_a
    new-array p1, p1, [Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 40
    .line 41
    return-object p1

    .line 42
    :pswitch_b
    new-array p1, p1, [Landroid/support/v4/media/session/MediaSessionCompat$QueueItem;

    .line 43
    .line 44
    return-object p1

    .line 45
    :pswitch_c
    new-array p1, p1, [Landroid/support/v4/media/MediaMetadataCompat;

    .line 46
    .line 47
    return-object p1

    .line 48
    :pswitch_d
    new-array p1, p1, [Landroid/support/v4/media/MediaDescriptionCompat;

    .line 49
    .line 50
    return-object p1

    .line 51
    :pswitch_e
    new-array p1, p1, [Landroid/support/v4/media/MediaBrowserCompat$MediaItem;

    .line 52
    .line 53
    return-object p1

    .line 54
    :pswitch_f
    new-array p1, p1, [Ll1ill;

    .line 55
    .line 56
    return-object p1

    .line 57
    :pswitch_10
    new-array p1, p1, [LkUu_T_;

    .line 58
    .line 59
    return-object p1

    .line 60
    :pswitch_11
    new-array p1, p1, [LOÀfPscCj;

    .line 61
    .line 62
    return-object p1

    .line 63
    :pswitch_12
    new-array p1, p1, [LOo_A$F_;

    .line 64
    .line 65
    return-object p1

    .line 66
    :pswitch_13
    new-array p1, p1, [LJU_R_;

    .line 67
    .line 68
    return-object p1

    .line 69
    :pswitch_14
    new-array p1, p1, [LI1lI;

    .line 70
    .line 71
    return-object p1

    .line 72
    :pswitch_15
    new-array p1, p1, [Lyl;

    .line 73
    .line 74
    return-object p1

    .line 75
    :pswitch_16
    new-array p1, p1, [LtJ_p$__;

    .line 76
    .line 77
    return-object p1

    .line 78
    :pswitch_17
    new-array p1, p1, [LYx6$9$;

    .line 79
    .line 80
    return-object p1

    .line 81
    :pswitch_18
    new-array p1, p1, [LnKey3134;

    .line 82
    .line 83
    return-object p1

    .line 84
    :pswitch_19
    new-array p1, p1, [LjH0_ah_;

    .line 85
    .line 86
    return-object p1

    .line 87
    :pswitch_1a
    new-array p1, p1, [LisPos9173;

    .line 88
    .line 89
    return-object p1

    .line 90
    :pswitch_1b
    new-array p1, p1, [LgKey1542;

    .line 91
    .line 92
    return-object p1

    .line 93
    :pswitch_1c
    new-array p1, p1, [LllII;

    .line 94
    .line 95
    return-object p1

    .line 96
    nop

    .line 97
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_19
        :pswitch_18
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
