.class public final Lqp8_Pg$JX_;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:Ljava/lang/Long;

.field public final rz__9J_:Ljava/util/HashSet;

.field public final waiBKÀ:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/Long;Ljava/lang/String;Ljava/util/HashSet;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lqp8_Pg$JX_;->e8$mp_s$:Ljava/lang/Long;

    .line 5
    .line 6
    iput-object p2, p0, Lqp8_Pg$JX_;->waiBKÀ:Ljava/lang/String;

    .line 7
    .line 8
    iput-object p3, p0, Lqp8_Pg$JX_;->rz__9J_:Ljava/util/HashSet;

    .line 9
    .line 10
    return-void
.end method
