.class public abstract LTW$mG_5$;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final JKEoÙX:Lyll0O0;

.field public static final POOl:LIIiIlIl;

.field public static final e8$mp_s$:LVF$4t_2$;

.field public static final rz__9J_:LiIndex1200;

.field public static final tmpData3485:LgIndex153;

.field public static final waiBKÀ:LVF$4t_2$;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    .line 1
    const-string v0, "type.googleapis.com/google.crypto.tink.HmacKey"

    .line 2
    .line 3
    invoke-static {v0}, LLM$ly_a$;->waiBKÀ(Ljava/lang/String;)LrlI;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    new-instance v1, Ljava/util/HashMap;

    .line 8
    .line 9
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 10
    .line 11
    .line 12
    new-instance v2, Ljava/util/HashMap;

    .line 13
    .line 14
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 15
    .line 16
    .line 17
    sget-object v3, Lkòè;->kQy:Lkòè;

    .line 18
    .line 19
    sget-object v4, LxsQmI;->JKEoÙX:LxsQmI;

    .line 20
    .line 21
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    sget-object v3, Lkòè;->jPos3709:Lkòè;

    .line 28
    .line 29
    sget-object v4, LxsQmI;->waiBKÀ:LxsQmI;

    .line 30
    .line 31
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    .line 36
    .line 37
    sget-object v3, Lkòè;->iOffset934:Lkòè;

    .line 38
    .line 39
    sget-object v4, LxsQmI;->POOl:LxsQmI;

    .line 40
    .line 41
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    sget-object v3, Lkòè;->Ialue:Lkòè;

    .line 48
    .line 49
    sget-object v4, LxsQmI;->rz__9J_:LxsQmI;

    .line 50
    .line 51
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    new-instance v3, LVF$4t_2$;

    .line 58
    .line 59
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 60
    .line 61
    .line 62
    move-result-object v1

    .line 63
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-direct {v3, v1, v2}, LVF$4t_2$;-><init>(Ljava/util/Map;Ljava/util/Map;)V

    .line 68
    .line 69
    .line 70
    sput-object v3, LTW$mG_5$;->e8$mp_s$:LVF$4t_2$;

    .line 71
    .line 72
    new-instance v1, Ljava/util/HashMap;

    .line 73
    .line 74
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 75
    .line 76
    .line 77
    new-instance v2, Ljava/util/HashMap;

    .line 78
    .line 79
    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    .line 80
    .line 81
    .line 82
    sget-object v3, LhasIndex1121;->jPos3709:LhasIndex1121;

    .line 83
    .line 84
    sget-object v4, LFER_Ag$V_;->waiBKÀ:LFER_Ag$V_;

    .line 85
    .line 86
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    sget-object v3, LhasIndex1121;->valuI:LhasIndex1121;

    .line 93
    .line 94
    sget-object v4, LFER_Ag$V_;->rz__9J_:LFER_Ag$V_;

    .line 95
    .line 96
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    sget-object v3, LhasIndex1121;->kQy:LhasIndex1121;

    .line 103
    .line 104
    sget-object v4, LFER_Ag$V_;->POOl:LFER_Ag$V_;

    .line 105
    .line 106
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    sget-object v3, LhasIndex1121;->iOffset934:LhasIndex1121;

    .line 113
    .line 114
    sget-object v4, LFER_Ag$V_;->JKEoÙX:LFER_Ag$V_;

    .line 115
    .line 116
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    sget-object v3, LhasIndex1121;->Ialue:LhasIndex1121;

    .line 123
    .line 124
    sget-object v4, LFER_Ag$V_;->tmpData3485:LFER_Ag$V_;

    .line 125
    .line 126
    invoke-virtual {v1, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    invoke-virtual {v2, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    new-instance v3, LVF$4t_2$;

    .line 133
    .line 134
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 139
    .line 140
    .line 141
    move-result-object v2

    .line 142
    invoke-direct {v3, v1, v2}, LVF$4t_2$;-><init>(Ljava/util/Map;Ljava/util/Map;)V

    .line 143
    .line 144
    .line 145
    sput-object v3, LTW$mG_5$;->waiBKÀ:LVF$4t_2$;

    .line 146
    .line 147
    new-instance v1, LtmpPos8530;

    .line 148
    .line 149
    const/16 v2, 0x1a

    .line 150
    .line 151
    const/4 v3, 0x0

    .line 152
    invoke-direct {v1, v2, v3}, LtmpPos8530;-><init>(IB)V

    .line 153
    .line 154
    .line 155
    new-instance v2, LiIndex1200;

    .line 156
    .line 157
    const-class v3, L_lQ0D;

    .line 158
    .line 159
    invoke-direct {v2, v3, v1}, LiIndex1200;-><init>(Ljava/lang/Class;LsData8261;)V

    .line 160
    .line 161
    .line 162
    sput-object v2, LTW$mG_5$;->rz__9J_:LiIndex1200;

    .line 163
    .line 164
    new-instance v1, LuXVÌJÒ;

    .line 165
    .line 166
    const/16 v2, 0x1b

    .line 167
    .line 168
    invoke-direct {v1, v2}, LuXVÌJÒ;-><init>(I)V

    .line 169
    .line 170
    .line 171
    new-instance v2, LIIiIlIl;

    .line 172
    .line 173
    invoke-direct {v2, v0, v1}, LIIiIlIl;-><init>(LrlI;LhasKey5903;)V

    .line 174
    .line 175
    .line 176
    sput-object v2, LTW$mG_5$;->POOl:LIIiIlIl;

    .line 177
    .line 178
    new-instance v1, LJ11D;

    .line 179
    .line 180
    const/16 v2, 0x1b

    .line 181
    .line 182
    invoke-direct {v1, v2}, LJ11D;-><init>(I)V

    .line 183
    .line 184
    .line 185
    new-instance v2, Lyll0O0;

    .line 186
    .line 187
    const-class v3, LCicqEZY;

    .line 188
    .line 189
    invoke-direct {v2, v3, v1}, Lyll0O0;-><init>(Ljava/lang/Class;LbesqìA;)V

    .line 190
    .line 191
    .line 192
    sput-object v2, LTW$mG_5$;->JKEoÙX:Lyll0O0;

    .line 193
    .line 194
    new-instance v1, LtmpPos8530;

    .line 195
    .line 196
    const/16 v2, 0x1b

    .line 197
    .line 198
    const/4 v3, 0x0

    .line 199
    invoke-direct {v1, v2, v3}, LtmpPos8530;-><init>(IB)V

    .line 200
    .line 201
    .line 202
    new-instance v2, LgIndex153;

    .line 203
    .line 204
    invoke-direct {v2, v0, v1}, LgIndex153;-><init>(LrlI;LtmpOffset2707;)V

    .line 205
    .line 206
    .line 207
    sput-object v2, LTW$mG_5$;->tmpData3485:LgIndex153;

    .line 208
    .line 209
    return-void
.end method
