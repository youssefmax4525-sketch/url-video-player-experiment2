.class public final Lmm1ÈsbiO;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LvItem7183;


# instance fields
.field public final jPos3709:Landroid/os/PowerManager;

.field public final vaIue:LiValue7354;

.field public final yON3x:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;LiValue7354;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lmm1ÈsbiO;->yON3x:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p2, p0, Lmm1ÈsbiO;->vaIue:LiValue7354;

    .line 7
    .line 8
    const-string p2, "power"

    .line 9
    .line 10
    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, Landroid/os/PowerManager;

    .line 15
    .line 16
    iput-object p1, p0, Lmm1ÈsbiO;->jPos3709:Landroid/os/PowerManager;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(LElK0;)Lorg/json/JSONObject;
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    new-instance v2, Lorg/json/JSONArray;

    .line 6
    .line 7
    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    .line 8
    .line 9
    .line 10
    new-instance v3, Lorg/json/JSONObject;

    .line 11
    .line 12
    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v4, v1, LElK0;->JKEoÙX:LnSize1148;

    .line 16
    .line 17
    if-nez v4, :cond_0

    .line 18
    .line 19
    new-instance v1, Lorg/json/JSONObject;

    .line 20
    .line 21
    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 22
    .line 23
    .line 24
    move-object/from16 v16, v3

    .line 25
    .line 26
    goto/16 :goto_3

    .line 27
    .line 28
    :cond_0
    iget-object v5, v4, LnSize1148;->yON3x:Landroid/graphics/Rect;

    .line 29
    .line 30
    iget-object v6, v4, LnSize1148;->sKey7917:Landroid/graphics/Rect;

    .line 31
    .line 32
    iget-object v7, v4, LnSize1148;->JKEoÙX:Landroid/graphics/Rect;

    .line 33
    .line 34
    iget-object v8, v4, LnSize1148;->POOl:Landroid/graphics/Rect;

    .line 35
    .line 36
    iget-object v9, v4, LnSize1148;->rz__9J_:Landroid/graphics/Rect;

    .line 37
    .line 38
    iget-object v10, v0, Lmm1ÈsbiO;->vaIue:LiValue7354;

    .line 39
    .line 40
    iget-object v11, v10, LiValue7354;->waiBKÀ:Lorg/json/JSONObject;

    .line 41
    .line 42
    if-eqz v11, :cond_6

    .line 43
    .line 44
    iget-boolean v11, v4, LnSize1148;->e8$mp_s$:Z

    .line 45
    .line 46
    new-instance v12, Lorg/json/JSONObject;

    .line 47
    .line 48
    invoke-direct {v12}, Lorg/json/JSONObject;-><init>()V

    .line 49
    .line 50
    .line 51
    const-string v13, "afmaVersion"

    .line 52
    .line 53
    iget-object v14, v10, LiValue7354;->POOl:Ljava/lang/String;

    .line 54
    .line 55
    invoke-virtual {v12, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 56
    .line 57
    .line 58
    move-result-object v13

    .line 59
    const-string v14, "activeViewJSON"

    .line 60
    .line 61
    iget-object v15, v10, LiValue7354;->waiBKÀ:Lorg/json/JSONObject;

    .line 62
    .line 63
    invoke-virtual {v13, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 64
    .line 65
    .line 66
    move-result-object v13

    .line 67
    iget-wide v14, v1, LElK0;->rz__9J_:J

    .line 68
    .line 69
    move-object/from16 v16, v3

    .line 70
    .line 71
    const-string v3, "timestamp"

    .line 72
    .line 73
    invoke-virtual {v13, v3, v14, v15}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 74
    .line 75
    .line 76
    move-result-object v3

    .line 77
    const-string v13, "adFormat"

    .line 78
    .line 79
    iget-object v14, v10, LiValue7354;->e8$mp_s$:Ljava/lang/String;

    .line 80
    .line 81
    invoke-virtual {v3, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 82
    .line 83
    .line 84
    move-result-object v3

    .line 85
    const-string v13, "hashCode"

    .line 86
    .line 87
    iget-object v14, v10, LiValue7354;->rz__9J_:Ljava/lang/String;

    .line 88
    .line 89
    invoke-virtual {v3, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    const-string v13, "isMraid"

    .line 94
    .line 95
    const/4 v14, 0x0

    .line 96
    invoke-virtual {v3, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 97
    .line 98
    .line 99
    move-result-object v3

    .line 100
    const-string v13, "isStopped"

    .line 101
    .line 102
    invoke-virtual {v3, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 103
    .line 104
    .line 105
    move-result-object v3

    .line 106
    iget-boolean v13, v1, LElK0;->waiBKÀ:Z

    .line 107
    .line 108
    const-string v14, "isPaused"

    .line 109
    .line 110
    invoke-virtual {v3, v14, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 111
    .line 112
    .line 113
    move-result-object v3

    .line 114
    const-string v13, "isNative"

    .line 115
    .line 116
    iget-boolean v10, v10, LiValue7354;->JKEoÙX:Z

    .line 117
    .line 118
    invoke-virtual {v3, v13, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 119
    .line 120
    .line 121
    move-result-object v3

    .line 122
    const-string v10, "isScreenOn"

    .line 123
    .line 124
    iget-object v13, v0, Lmm1ÈsbiO;->jPos3709:Landroid/os/PowerManager;

    .line 125
    .line 126
    invoke-virtual {v13}, Landroid/os/PowerManager;->isInteractive()Z

    .line 127
    .line 128
    .line 129
    move-result v13

    .line 130
    invoke-virtual {v3, v10, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 131
    .line 132
    .line 133
    move-result-object v3

    .line 134
    sget-object v10, LvItem598;->tzKù7Ol1:LvItem598;

    .line 135
    .line 136
    iget-object v13, v10, LvItem598;->DDù8:LgKey7050;

    .line 137
    .line 138
    invoke-virtual {v13}, LgKey7050;->POOl()Z

    .line 139
    .line 140
    .line 141
    move-result v13

    .line 142
    const-string v14, "appMuted"

    .line 143
    .line 144
    invoke-virtual {v3, v14, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    iget-object v10, v10, LvItem598;->DDù8:LgKey7050;

    .line 149
    .line 150
    invoke-virtual {v10}, LgKey7050;->e8$mp_s$()F

    .line 151
    .line 152
    .line 153
    move-result v10

    .line 154
    float-to-double v13, v10

    .line 155
    const-string v10, "appVolume"

    .line 156
    .line 157
    invoke-virtual {v3, v10, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 158
    .line 159
    .line 160
    move-result-object v3

    .line 161
    iget-object v10, v0, Lmm1ÈsbiO;->yON3x:Landroid/content/Context;

    .line 162
    .line 163
    invoke-virtual {v10}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 164
    .line 165
    .line 166
    move-result-object v13

    .line 167
    const-string v14, "audio"

    .line 168
    .line 169
    invoke-virtual {v13, v14}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v13

    .line 173
    check-cast v13, Landroid/media/AudioManager;

    .line 174
    .line 175
    if-nez v13, :cond_1

    .line 176
    .line 177
    goto :goto_0

    .line 178
    :cond_1
    const/4 v14, 0x3

    .line 179
    invoke-virtual {v13, v14}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    .line 180
    .line 181
    .line 182
    move-result v15

    .line 183
    invoke-virtual {v13, v14}, Landroid/media/AudioManager;->getStreamVolume(I)I

    .line 184
    .line 185
    .line 186
    move-result v13

    .line 187
    if-eqz v15, :cond_2

    .line 188
    .line 189
    int-to-float v13, v13

    .line 190
    int-to-float v14, v15

    .line 191
    div-float/2addr v13, v14

    .line 192
    goto :goto_1

    .line 193
    :cond_2
    :goto_0
    const/4 v13, 0x0

    .line 194
    :goto_1
    float-to-double v13, v13

    .line 195
    const-string v15, "deviceVolume"

    .line 196
    .line 197
    invoke-virtual {v3, v15, v13, v14}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 198
    .line 199
    .line 200
    new-instance v3, Landroid/graphics/Rect;

    .line 201
    .line 202
    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    .line 203
    .line 204
    .line 205
    const-string v13, "window"

    .line 206
    .line 207
    invoke-virtual {v10, v13}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    move-result-object v13

    .line 211
    check-cast v13, Landroid/view/WindowManager;

    .line 212
    .line 213
    invoke-interface {v13}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 214
    .line 215
    .line 216
    move-result-object v13

    .line 217
    invoke-virtual {v13}, Landroid/view/Display;->getWidth()I

    .line 218
    .line 219
    .line 220
    move-result v14

    .line 221
    iput v14, v3, Landroid/graphics/Rect;->right:I

    .line 222
    .line 223
    invoke-virtual {v13}, Landroid/view/Display;->getHeight()I

    .line 224
    .line 225
    .line 226
    move-result v13

    .line 227
    iput v13, v3, Landroid/graphics/Rect;->bottom:I

    .line 228
    .line 229
    invoke-virtual {v10}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 230
    .line 231
    .line 232
    move-result-object v3

    .line 233
    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 234
    .line 235
    .line 236
    move-result-object v3

    .line 237
    iget v10, v4, LnSize1148;->waiBKÀ:I

    .line 238
    .line 239
    const-string v13, "windowVisibility"

    .line 240
    .line 241
    invoke-virtual {v12, v13, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 242
    .line 243
    .line 244
    move-result-object v10

    .line 245
    const-string v13, "isAttachedToWindow"

    .line 246
    .line 247
    invoke-virtual {v10, v13, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 248
    .line 249
    .line 250
    move-result-object v10

    .line 251
    new-instance v11, Lorg/json/JSONObject;

    .line 252
    .line 253
    invoke-direct {v11}, Lorg/json/JSONObject;-><init>()V

    .line 254
    .line 255
    .line 256
    iget v13, v9, Landroid/graphics/Rect;->top:I

    .line 257
    .line 258
    const-string v14, "top"

    .line 259
    .line 260
    invoke-virtual {v11, v14, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 261
    .line 262
    .line 263
    move-result-object v11

    .line 264
    iget v13, v9, Landroid/graphics/Rect;->bottom:I

    .line 265
    .line 266
    const-string v15, "bottom"

    .line 267
    .line 268
    invoke-virtual {v11, v15, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 269
    .line 270
    .line 271
    move-result-object v11

    .line 272
    iget v13, v9, Landroid/graphics/Rect;->left:I

    .line 273
    .line 274
    const-string v0, "left"

    .line 275
    .line 276
    invoke-virtual {v11, v0, v13}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 277
    .line 278
    .line 279
    move-result-object v11

    .line 280
    iget v9, v9, Landroid/graphics/Rect;->right:I

    .line 281
    .line 282
    const-string v13, "right"

    .line 283
    .line 284
    invoke-virtual {v11, v13, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 285
    .line 286
    .line 287
    move-result-object v9

    .line 288
    const-string v11, "viewBox"

    .line 289
    .line 290
    invoke-virtual {v10, v11, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 291
    .line 292
    .line 293
    move-result-object v9

    .line 294
    new-instance v10, Lorg/json/JSONObject;

    .line 295
    .line 296
    invoke-direct {v10}, Lorg/json/JSONObject;-><init>()V

    .line 297
    .line 298
    .line 299
    iget v11, v8, Landroid/graphics/Rect;->top:I

    .line 300
    .line 301
    invoke-virtual {v10, v14, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 302
    .line 303
    .line 304
    move-result-object v10

    .line 305
    iget v11, v8, Landroid/graphics/Rect;->bottom:I

    .line 306
    .line 307
    invoke-virtual {v10, v15, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 308
    .line 309
    .line 310
    move-result-object v10

    .line 311
    iget v11, v8, Landroid/graphics/Rect;->left:I

    .line 312
    .line 313
    invoke-virtual {v10, v0, v11}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 314
    .line 315
    .line 316
    move-result-object v10

    .line 317
    iget v8, v8, Landroid/graphics/Rect;->right:I

    .line 318
    .line 319
    invoke-virtual {v10, v13, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 320
    .line 321
    .line 322
    move-result-object v8

    .line 323
    const-string v10, "adBox"

    .line 324
    .line 325
    invoke-virtual {v9, v10, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 326
    .line 327
    .line 328
    move-result-object v8

    .line 329
    new-instance v9, Lorg/json/JSONObject;

    .line 330
    .line 331
    invoke-direct {v9}, Lorg/json/JSONObject;-><init>()V

    .line 332
    .line 333
    .line 334
    iget v10, v7, Landroid/graphics/Rect;->top:I

    .line 335
    .line 336
    invoke-virtual {v9, v14, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 337
    .line 338
    .line 339
    move-result-object v9

    .line 340
    iget v10, v7, Landroid/graphics/Rect;->bottom:I

    .line 341
    .line 342
    invoke-virtual {v9, v15, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 343
    .line 344
    .line 345
    move-result-object v9

    .line 346
    iget v10, v7, Landroid/graphics/Rect;->left:I

    .line 347
    .line 348
    invoke-virtual {v9, v0, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 349
    .line 350
    .line 351
    move-result-object v9

    .line 352
    iget v7, v7, Landroid/graphics/Rect;->right:I

    .line 353
    .line 354
    invoke-virtual {v9, v13, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 355
    .line 356
    .line 357
    move-result-object v7

    .line 358
    const-string v9, "globalVisibleBox"

    .line 359
    .line 360
    invoke-virtual {v8, v9, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 361
    .line 362
    .line 363
    move-result-object v7

    .line 364
    iget-boolean v8, v4, LnSize1148;->tmpData3485:Z

    .line 365
    .line 366
    const-string v9, "globalVisibleBoxVisible"

    .line 367
    .line 368
    invoke-virtual {v7, v9, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 369
    .line 370
    .line 371
    move-result-object v7

    .line 372
    new-instance v8, Lorg/json/JSONObject;

    .line 373
    .line 374
    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    .line 375
    .line 376
    .line 377
    iget v9, v6, Landroid/graphics/Rect;->top:I

    .line 378
    .line 379
    invoke-virtual {v8, v14, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 380
    .line 381
    .line 382
    move-result-object v8

    .line 383
    iget v9, v6, Landroid/graphics/Rect;->bottom:I

    .line 384
    .line 385
    invoke-virtual {v8, v15, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 386
    .line 387
    .line 388
    move-result-object v8

    .line 389
    iget v9, v6, Landroid/graphics/Rect;->left:I

    .line 390
    .line 391
    invoke-virtual {v8, v0, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 392
    .line 393
    .line 394
    move-result-object v8

    .line 395
    iget v6, v6, Landroid/graphics/Rect;->right:I

    .line 396
    .line 397
    invoke-virtual {v8, v13, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 398
    .line 399
    .line 400
    move-result-object v6

    .line 401
    const-string v8, "localVisibleBox"

    .line 402
    .line 403
    invoke-virtual {v7, v8, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 404
    .line 405
    .line 406
    move-result-object v6

    .line 407
    iget-boolean v7, v4, LnSize1148;->DDù8:Z

    .line 408
    .line 409
    const-string v8, "localVisibleBoxVisible"

    .line 410
    .line 411
    invoke-virtual {v6, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 412
    .line 413
    .line 414
    move-result-object v6

    .line 415
    new-instance v7, Lorg/json/JSONObject;

    .line 416
    .line 417
    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    .line 418
    .line 419
    .line 420
    iget v8, v5, Landroid/graphics/Rect;->top:I

    .line 421
    .line 422
    invoke-virtual {v7, v14, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 423
    .line 424
    .line 425
    move-result-object v7

    .line 426
    iget v8, v5, Landroid/graphics/Rect;->bottom:I

    .line 427
    .line 428
    invoke-virtual {v7, v15, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 429
    .line 430
    .line 431
    move-result-object v7

    .line 432
    iget v8, v5, Landroid/graphics/Rect;->left:I

    .line 433
    .line 434
    invoke-virtual {v7, v0, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 435
    .line 436
    .line 437
    move-result-object v7

    .line 438
    iget v5, v5, Landroid/graphics/Rect;->right:I

    .line 439
    .line 440
    invoke-virtual {v7, v13, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 441
    .line 442
    .line 443
    move-result-object v5

    .line 444
    const-string v7, "hitBox"

    .line 445
    .line 446
    invoke-virtual {v6, v7, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 447
    .line 448
    .line 449
    move-result-object v5

    .line 450
    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    .line 451
    .line 452
    float-to-double v6, v3

    .line 453
    const-string v3, "screenDensity"

    .line 454
    .line 455
    invoke-virtual {v5, v3, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;D)Lorg/json/JSONObject;

    .line 456
    .line 457
    .line 458
    iget-boolean v3, v1, LElK0;->e8$mp_s$:Z

    .line 459
    .line 460
    const-string v5, "isVisible"

    .line 461
    .line 462
    invoke-virtual {v12, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 463
    .line 464
    .line 465
    sget-object v3, LisIndex2415;->eQOI:LSdE$n$;

    .line 466
    .line 467
    sget-object v5, LIl1il;->POOl:LIl1il;

    .line 468
    .line 469
    iget-object v5, v5, LIl1il;->rz__9J_:LnCount1076;

    .line 470
    .line 471
    invoke-virtual {v5, v3}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 472
    .line 473
    .line 474
    move-result-object v3

    .line 475
    check-cast v3, Ljava/lang/Boolean;

    .line 476
    .line 477
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 478
    .line 479
    .line 480
    move-result v3

    .line 481
    if-eqz v3, :cond_4

    .line 482
    .line 483
    new-instance v3, Lorg/json/JSONArray;

    .line 484
    .line 485
    invoke-direct {v3}, Lorg/json/JSONArray;-><init>()V

    .line 486
    .line 487
    .line 488
    iget-object v4, v4, LnSize1148;->jPos3709:Ljava/util/List;

    .line 489
    .line 490
    if-eqz v4, :cond_3

    .line 491
    .line 492
    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 493
    .line 494
    .line 495
    move-result-object v4

    .line 496
    :goto_2
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 497
    .line 498
    .line 499
    move-result v5

    .line 500
    if-eqz v5, :cond_3

    .line 501
    .line 502
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 503
    .line 504
    .line 505
    move-result-object v5

    .line 506
    check-cast v5, Landroid/graphics/Rect;

    .line 507
    .line 508
    new-instance v6, Lorg/json/JSONObject;

    .line 509
    .line 510
    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    .line 511
    .line 512
    .line 513
    iget v7, v5, Landroid/graphics/Rect;->top:I

    .line 514
    .line 515
    invoke-virtual {v6, v14, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 516
    .line 517
    .line 518
    move-result-object v6

    .line 519
    iget v7, v5, Landroid/graphics/Rect;->bottom:I

    .line 520
    .line 521
    invoke-virtual {v6, v15, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 522
    .line 523
    .line 524
    move-result-object v6

    .line 525
    iget v7, v5, Landroid/graphics/Rect;->left:I

    .line 526
    .line 527
    invoke-virtual {v6, v0, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 528
    .line 529
    .line 530
    move-result-object v6

    .line 531
    iget v5, v5, Landroid/graphics/Rect;->right:I

    .line 532
    .line 533
    invoke-virtual {v6, v13, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 534
    .line 535
    .line 536
    move-result-object v5

    .line 537
    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 538
    .line 539
    .line 540
    goto :goto_2

    .line 541
    :cond_3
    const-string v0, "scrollableContainerBoxes"

    .line 542
    .line 543
    invoke-virtual {v12, v0, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 544
    .line 545
    .line 546
    :cond_4
    iget-object v0, v1, LElK0;->POOl:Ljava/lang/String;

    .line 547
    .line 548
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 549
    .line 550
    .line 551
    move-result v0

    .line 552
    if-nez v0, :cond_5

    .line 553
    .line 554
    const-string v0, "doneReasonCode"

    .line 555
    .line 556
    const-string v1, "u"

    .line 557
    .line 558
    invoke-virtual {v12, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 559
    .line 560
    .line 561
    :cond_5
    move-object v1, v12

    .line 562
    :goto_3
    invoke-virtual {v2, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    .line 563
    .line 564
    .line 565
    const-string v0, "units"

    .line 566
    .line 567
    move-object/from16 v1, v16

    .line 568
    .line 569
    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 570
    .line 571
    .line 572
    return-object v1

    .line 573
    :cond_6
    new-instance v0, Lorg/json/JSONException;

    .line 574
    .line 575
    const-string v1, "Active view Info cannot be null."

    .line 576
    .line 577
    invoke-direct {v0, v1}, Lorg/json/JSONException;-><init>(Ljava/lang/String;)V

    .line 578
    .line 579
    .line 580
    throw v0
.end method

.method public final bridge synthetic yàÒZ(Ljava/lang/Object;)Lorg/json/JSONObject;
    .locals 0

    .line 1
    check-cast p1, LElK0;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lmm1ÈsbiO;->e8$mp_s$(LElK0;)Lorg/json/JSONObject;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    return-object p1
.end method
