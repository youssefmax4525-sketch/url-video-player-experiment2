.class public interface abstract LmValue599;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract mCount3824(LnSize1148;)V
.end method
