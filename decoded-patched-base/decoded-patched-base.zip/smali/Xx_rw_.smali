.class public final LXx_rw_;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final waiBKÀ:LXx_rw_;


# instance fields
.field public final e8$mp_s$:Ljava/lang/Throwable;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LXx_rw_;

    .line 2
    .line 3
    new-instance v1, LIalue;

    .line 4
    .line 5
    const-string v2, "Failure occurred while trying to finish a future."

    .line 6
    .line 7
    const/4 v3, 0x4

    .line 8
    invoke-direct {v1, v2, v3}, LIalue;-><init>(Ljava/lang/String;I)V

    .line 9
    .line 10
    .line 11
    invoke-direct {v0, v1}, LXx_rw_;-><init>(Ljava/lang/Throwable;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, LXx_rw_;->waiBKÀ:LXx_rw_;

    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, LXx_rw_;->e8$mp_s$:Ljava/lang/Throwable;

    .line 8
    .line 9
    return-void
.end method
