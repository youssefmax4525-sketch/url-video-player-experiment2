.class public interface abstract LikMna;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract rz__9J_(ILjava/lang/Object;)V
.end method
