.class public final L_QI1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public DDù8:Z

.field public JKEoÙX:J

.field public POOl:I

.field public final e8$mp_s$:LwÒJK;

.field public iOffset934:J

.field public jPos3709:J

.field public kQy:Z

.field public rz__9J_:Z

.field public sKey7917:Z

.field public tmpData3485:Z

.field public vaIue:Z

.field public waiBKÀ:J

.field public yON3x:Z


# direct methods
.method public constructor <init>(LwÒJK;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, L_QI1;->e8$mp_s$:LwÒJK;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final e8$mp_s$(I)V
    .locals 8

    .line 1
    iget-wide v1, p0, L_QI1;->iOffset934:J

    .line 2
    .line 3
    const-wide v3, -0x7fffffffffffffffL    # -4.9E-324

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    cmp-long v0, v1, v3

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-boolean v3, p0, L_QI1;->kQy:Z

    .line 14
    .line 15
    iget-wide v4, p0, L_QI1;->waiBKÀ:J

    .line 16
    .line 17
    iget-wide v6, p0, L_QI1;->jPos3709:J

    .line 18
    .line 19
    sub-long/2addr v4, v6

    .line 20
    long-to-int v4, v4

    .line 21
    const/4 v6, 0x0

    .line 22
    iget-object v0, p0, L_QI1;->e8$mp_s$:LwÒJK;

    .line 23
    .line 24
    move v5, p1

    .line 25
    invoke-interface/range {v0 .. v6}, LwÒJK;->waiBKÀ(JIIILlF_um_;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method
