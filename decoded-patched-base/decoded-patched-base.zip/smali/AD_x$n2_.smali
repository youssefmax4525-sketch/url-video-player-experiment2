.class public final LAD_x$n2_;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final UC_n_:LhiB_7$0y_;


# instance fields
.field public final DDù8:LKkmORP;

.field public Ialue:Lol01D;

.field public final JKEoÙX:LPVN$Zh_Vn$;

.field public K0I:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

.field public final POOl:LIll1iI;

.field public Qp_Hp$i_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

.field public final e8$mp_s$:Landroid/content/Context;

.field public gKey4112:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

.field public final iOffset934:LqàÙ;

.field public final jPos3709:LlI111l;

.field public kO_6X_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

.field public final kQy:LXDOQID;

.field public pCXDYg:LMl;

.field public final rz__9J_:LsqùAA;

.field public final sKey7917:Landroid/content/ComponentName;

.field public final tmpData3485:Landroid/content/ComponentName;

.field public final vaIue:LPNdgAQ$;

.field public valuI:Lcom/google/android/gms/cast/CastDevice;

.field public final waiBKÀ:LGtVP;

.field public final yON3x:LKkmORP;

.field public yàÒZ:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    .line 1
    new-instance v0, LhiB_7$0y_;

    .line 2
    .line 3
    const-string v1, "MediaSessionManager"

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, LhiB_7$0y_;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 7
    .line 8
    .line 9
    sput-object v0, LAD_x$n2_;->UC_n_:LhiB_7$0y_;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;LGtVP;LsqùAA;)V
    .locals 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LAD_x$n2_;->e8$mp_s$:Landroid/content/Context;

    .line 5
    .line 6
    iput-object p2, p0, LAD_x$n2_;->waiBKÀ:LGtVP;

    .line 7
    .line 8
    iput-object p3, p0, LAD_x$n2_;->rz__9J_:LsqùAA;

    .line 9
    .line 10
    sget-object p3, LVA_r_;->jPos3709:LhiB_7$0y_;

    .line 11
    .line 12
    const-string p3, "Must be called from the main thread."

    .line 13
    .line 14
    invoke-static {p3}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    sget-object p3, LVA_r_;->kQy:LVA_r_;

    .line 18
    .line 19
    const/4 v0, 0x0

    .line 20
    if-eqz p3, :cond_0

    .line 21
    .line 22
    invoke-virtual {p3}, LVA_r_;->POOl()LIll1iI;

    .line 23
    .line 24
    .line 25
    move-result-object p3

    .line 26
    goto :goto_0

    .line 27
    :cond_0
    move-object p3, v0

    .line 28
    :goto_0
    iput-object p3, p0, LAD_x$n2_;->POOl:LIll1iI;

    .line 29
    .line 30
    iget-object p3, p2, LGtVP;->Ialue:LUF$r$;

    .line 31
    .line 32
    if-nez p3, :cond_1

    .line 33
    .line 34
    move-object v1, v0

    .line 35
    goto :goto_1

    .line 36
    :cond_1
    iget-object v1, p3, LUF$r$;->iOffset934:LPVN$Zh_Vn$;

    .line 37
    .line 38
    :goto_1
    iput-object v1, p0, LAD_x$n2_;->JKEoÙX:LPVN$Zh_Vn$;

    .line 39
    .line 40
    new-instance v1, LXDOQID;

    .line 41
    .line 42
    const/4 v2, 0x1

    .line 43
    invoke-direct {v1, v2, p0}, LXDOQID;-><init>(ILjava/lang/Object;)V

    .line 44
    .line 45
    .line 46
    iput-object v1, p0, LAD_x$n2_;->kQy:LXDOQID;

    .line 47
    .line 48
    if-nez p3, :cond_2

    .line 49
    .line 50
    move-object v1, v0

    .line 51
    goto :goto_2

    .line 52
    :cond_2
    iget-object v1, p3, LUF$r$;->vaIue:Ljava/lang/String;

    .line 53
    .line 54
    :goto_2
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 55
    .line 56
    .line 57
    move-result v2

    .line 58
    if-nez v2, :cond_3

    .line 59
    .line 60
    new-instance v2, Landroid/content/ComponentName;

    .line 61
    .line 62
    invoke-direct {v2, p1, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    goto :goto_3

    .line 66
    :cond_3
    move-object v2, v0

    .line 67
    :goto_3
    iput-object v2, p0, LAD_x$n2_;->tmpData3485:Landroid/content/ComponentName;

    .line 68
    .line 69
    if-nez p3, :cond_4

    .line 70
    .line 71
    move-object p3, v0

    .line 72
    goto :goto_4

    .line 73
    :cond_4
    iget-object p3, p3, LUF$r$;->yON3x:Ljava/lang/String;

    .line 74
    .line 75
    :goto_4
    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    if-nez v1, :cond_5

    .line 80
    .line 81
    new-instance v1, Landroid/content/ComponentName;

    .line 82
    .line 83
    invoke-direct {v1, p1, p3}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    goto :goto_5

    .line 87
    :cond_5
    move-object v1, v0

    .line 88
    :goto_5
    iput-object v1, p0, LAD_x$n2_;->sKey7917:Landroid/content/ComponentName;

    .line 89
    .line 90
    new-instance p3, LKkmORP;

    .line 91
    .line 92
    invoke-direct {p3, p1}, LKkmORP;-><init>(Landroid/content/Context;)V

    .line 93
    .line 94
    .line 95
    iput-object p3, p0, LAD_x$n2_;->DDù8:LKkmORP;

    .line 96
    .line 97
    new-instance v1, LkGd_Gk_;

    .line 98
    .line 99
    const/16 v2, 0x10

    .line 100
    .line 101
    invoke-direct {v1, v2, p0}, LkGd_Gk_;-><init>(ILjava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    iput-object v1, p3, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 105
    .line 106
    new-instance p3, LKkmORP;

    .line 107
    .line 108
    invoke-direct {p3, p1}, LKkmORP;-><init>(Landroid/content/Context;)V

    .line 109
    .line 110
    .line 111
    iput-object p3, p0, LAD_x$n2_;->yON3x:LKkmORP;

    .line 112
    .line 113
    new-instance v1, LindQx;

    .line 114
    .line 115
    const/16 v2, 0xa

    .line 116
    .line 117
    invoke-direct {v1, v2, p0}, LindQx;-><init>(ILjava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    iput-object v1, p3, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 121
    .line 122
    new-instance p3, LlI111l;

    .line 123
    .line 124
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    const/4 v2, 0x3

    .line 129
    invoke-direct {p3, v1, v2}, LlI111l;-><init>(Landroid/os/Looper;I)V

    .line 130
    .line 131
    .line 132
    iput-object p3, p0, LAD_x$n2_;->jPos3709:LlI111l;

    .line 133
    .line 134
    sget-object p3, LPNdgAQ$;->Qp_Hp$i_:LhiB_7$0y_;

    .line 135
    .line 136
    iget-object p2, p2, LGtVP;->Ialue:LUF$r$;

    .line 137
    .line 138
    if-nez p2, :cond_6

    .line 139
    .line 140
    goto/16 :goto_c

    .line 141
    .line 142
    :cond_6
    iget-object p2, p2, LUF$r$;->iOffset934:LPVN$Zh_Vn$;

    .line 143
    .line 144
    if-nez p2, :cond_7

    .line 145
    .line 146
    goto/16 :goto_c

    .line 147
    .line 148
    :cond_7
    iget-object p2, p2, LPVN$Zh_Vn$;->iSize4906:LolO$6$;

    .line 149
    .line 150
    if-nez p2, :cond_8

    .line 151
    .line 152
    goto :goto_9

    .line 153
    :cond_8
    invoke-static {p2}, LLl$l$;->e8$mp_s$(LolO$6$;)Ljava/util/ArrayList;

    .line 154
    .line 155
    .line 156
    move-result-object v1

    .line 157
    invoke-static {p2}, LLl$l$;->waiBKÀ(LolO$6$;)[I

    .line 158
    .line 159
    .line 160
    move-result-object p2

    .line 161
    const/4 v2, 0x0

    .line 162
    if-nez v1, :cond_9

    .line 163
    .line 164
    const/4 v3, 0x0

    .line 165
    goto :goto_6

    .line 166
    :cond_9
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 167
    .line 168
    .line 169
    move-result v3

    .line 170
    :goto_6
    const-class v4, LPJNypàa;

    .line 171
    .line 172
    if-eqz v1, :cond_11

    .line 173
    .line 174
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 175
    .line 176
    .line 177
    move-result v5

    .line 178
    if-eqz v5, :cond_a

    .line 179
    .line 180
    goto :goto_b

    .line 181
    :cond_a
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 182
    .line 183
    .line 184
    move-result v1

    .line 185
    const/4 v5, 0x5

    .line 186
    if-le v1, v5, :cond_b

    .line 187
    .line 188
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object p1

    .line 192
    new-array p2, v2, [Ljava/lang/Object;

    .line 193
    .line 194
    const-string v1, " provides more than 5 actions."

    .line 195
    .line 196
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 197
    .line 198
    .line 199
    move-result-object p1

    .line 200
    invoke-virtual {p3, p1, p2}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 201
    .line 202
    .line 203
    goto :goto_c

    .line 204
    :cond_b
    if-eqz p2, :cond_10

    .line 205
    .line 206
    array-length v1, p2

    .line 207
    if-nez v1, :cond_c

    .line 208
    .line 209
    goto :goto_a

    .line 210
    :cond_c
    const/4 v5, 0x0

    .line 211
    :goto_7
    if-ge v5, v1, :cond_f

    .line 212
    .line 213
    aget v6, p2, v5

    .line 214
    .line 215
    if-ltz v6, :cond_e

    .line 216
    .line 217
    if-lt v6, v3, :cond_d

    .line 218
    .line 219
    goto :goto_8

    .line 220
    :cond_d
    add-int/lit8 v5, v5, 0x1

    .line 221
    .line 222
    goto :goto_7

    .line 223
    :cond_e
    :goto_8
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    new-array p2, v2, [Ljava/lang/Object;

    .line 228
    .line 229
    const-string v1, "provides a compact view action whose index is out of bounds."

    .line 230
    .line 231
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object p1

    .line 235
    invoke-virtual {p3, p1, p2}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 236
    .line 237
    .line 238
    goto :goto_c

    .line 239
    :cond_f
    :goto_9
    new-instance v0, LPNdgAQ$;

    .line 240
    .line 241
    invoke-direct {v0, p1}, LPNdgAQ$;-><init>(Landroid/content/Context;)V

    .line 242
    .line 243
    .line 244
    goto :goto_c

    .line 245
    :cond_10
    :goto_a
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 246
    .line 247
    .line 248
    move-result-object p1

    .line 249
    new-array p2, v2, [Ljava/lang/Object;

    .line 250
    .line 251
    const-string v1, " doesn\'t provide any actions for compact view."

    .line 252
    .line 253
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 254
    .line 255
    .line 256
    move-result-object p1

    .line 257
    invoke-virtual {p3, p1, p2}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 258
    .line 259
    .line 260
    goto :goto_c

    .line 261
    :cond_11
    :goto_b
    invoke-virtual {v4}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 262
    .line 263
    .line 264
    move-result-object p1

    .line 265
    new-array p2, v2, [Ljava/lang/Object;

    .line 266
    .line 267
    const-string v1, " doesn\'t provide any action."

    .line 268
    .line 269
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 270
    .line 271
    .line 272
    move-result-object p1

    .line 273
    invoke-virtual {p3, p1, p2}, LhiB_7$0y_;->rz__9J_(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 274
    .line 275
    .line 276
    :goto_c
    iput-object v0, p0, LAD_x$n2_;->vaIue:LPNdgAQ$;

    .line 277
    .line 278
    new-instance p1, LqàÙ;

    .line 279
    .line 280
    const/4 p2, 0x7

    .line 281
    invoke-direct {p1, p2, p0}, LqàÙ;-><init>(ILjava/lang/Object;)V

    .line 282
    .line 283
    .line 284
    iput-object p1, p0, LAD_x$n2_;->iOffset934:LqàÙ;

    .line 285
    .line 286
    return-void
.end method


# virtual methods
.method public final DDù8()V
    .locals 4

    .line 1
    iget-object v0, p0, LAD_x$n2_;->vaIue:LPNdgAQ$;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    new-array v1, v1, [Ljava/lang/Object;

    .line 7
    .line 8
    sget-object v2, LAD_x$n2_;->UC_n_:LhiB_7$0y_;

    .line 9
    .line 10
    const-string v3, "Stopping media notification."

    .line 11
    .line 12
    invoke-virtual {v2, v3, v1}, LhiB_7$0y_;->e8$mp_s$(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-object v1, v0, LPNdgAQ$;->yON3x:LKkmORP;

    .line 16
    .line 17
    invoke-virtual {v1}, LKkmORP;->Q1_f_()V

    .line 18
    .line 19
    .line 20
    const/4 v2, 0x0

    .line 21
    iput-object v2, v1, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 22
    .line 23
    iget-object v0, v0, LPNdgAQ$;->waiBKÀ:Landroid/app/NotificationManager;

    .line 24
    .line 25
    if-eqz v0, :cond_0

    .line 26
    .line 27
    const-string v1, "castMediaNotification"

    .line 28
    .line 29
    const/4 v2, 0x1

    .line 30
    invoke-virtual {v0, v1, v2}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    .line 31
    .line 32
    .line 33
    :cond_0
    return-void
.end method

.method public final JKEoÙX(LlI1I;)Landroid/net/Uri;
    .locals 2

    .line 1
    iget-object v0, p0, LAD_x$n2_;->waiBKÀ:LGtVP;

    .line 2
    .line 3
    iget-object v0, v0, LGtVP;->Ialue:LUF$r$;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    invoke-virtual {v0}, LUF$r$;->rz__9J_()V

    .line 9
    .line 10
    .line 11
    :goto_0
    iget-object v0, p1, LlI1I;->yON3x:Ljava/util/List;

    .line 12
    .line 13
    const/4 v1, 0x0

    .line 14
    if-eqz v0, :cond_1

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_1

    .line 21
    .line 22
    iget-object p1, p1, LlI1I;->yON3x:Ljava/util/List;

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-interface {p1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    check-cast p1, LHDlI;

    .line 30
    .line 31
    goto :goto_1

    .line 32
    :cond_1
    move-object p1, v1

    .line 33
    :goto_1
    if-nez p1, :cond_2

    .line 34
    .line 35
    return-object v1

    .line 36
    :cond_2
    iget-object p1, p1, LHDlI;->vaIue:Landroid/net/Uri;

    .line 37
    .line 38
    return-object p1
.end method

.method public final POOl(Ljava/lang/String;ILandroid/os/Bundle;)J
    .locals 9

    .line 1
    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, -0x3855de4e

    .line 6
    .line 7
    .line 8
    const/4 v2, -0x1

    .line 9
    const/4 v3, 0x2

    .line 10
    const/4 v4, 0x1

    .line 11
    if-eq v0, v1, :cond_2

    .line 12
    .line 13
    const v1, -0x3854c70e

    .line 14
    .line 15
    .line 16
    if-eq v0, v1, :cond_1

    .line 17
    .line 18
    const v1, 0xe0a3765

    .line 19
    .line 20
    .line 21
    if-eq v0, v1, :cond_0

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_0
    const-string v0, "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"

    .line 25
    .line 26
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    if-eqz p1, :cond_3

    .line 31
    .line 32
    const/4 p1, 0x0

    .line 33
    goto :goto_1

    .line 34
    :cond_1
    const-string v0, "com.google.android.gms.cast.framework.action.SKIP_PREV"

    .line 35
    .line 36
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result p1

    .line 40
    if-eqz p1, :cond_3

    .line 41
    .line 42
    const/4 p1, 0x1

    .line 43
    goto :goto_1

    .line 44
    :cond_2
    const-string v0, "com.google.android.gms.cast.framework.action.SKIP_NEXT"

    .line 45
    .line 46
    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    if-eqz p1, :cond_3

    .line 51
    .line 52
    const/4 p1, 0x2

    .line 53
    goto :goto_1

    .line 54
    :cond_3
    :goto_0
    const/4 p1, -0x1

    .line 55
    :goto_1
    if-eqz p1, :cond_e

    .line 56
    .line 57
    const-wide/16 v0, 0x0

    .line 58
    .line 59
    if-eq p1, v4, :cond_9

    .line 60
    .line 61
    if-eq p1, v3, :cond_4

    .line 62
    .line 63
    return-wide v0

    .line 64
    :cond_4
    iget-object p1, p0, LAD_x$n2_;->Ialue:Lol01D;

    .line 65
    .line 66
    if-eqz p1, :cond_8

    .line 67
    .line 68
    invoke-virtual {p1}, Lol01D;->sKey7917()Z

    .line 69
    .line 70
    .line 71
    move-result p2

    .line 72
    if-nez p2, :cond_5

    .line 73
    .line 74
    goto :goto_3

    .line 75
    :cond_5
    invoke-virtual {p1}, Lol01D;->POOl()LH8_A_;

    .line 76
    .line 77
    .line 78
    move-result-object p1

    .line 79
    invoke-static {p1}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    const-wide/16 v5, 0x40

    .line 83
    .line 84
    iget-wide v7, p1, LH8_A_;->pCXDYg:J

    .line 85
    .line 86
    and-long/2addr v5, v7

    .line 87
    cmp-long p2, v5, v0

    .line 88
    .line 89
    if-eqz p2, :cond_6

    .line 90
    .line 91
    goto :goto_2

    .line 92
    :cond_6
    iget p2, p1, LH8_A_;->$ÒcdS:I

    .line 93
    .line 94
    if-nez p2, :cond_7

    .line 95
    .line 96
    iget p2, p1, LH8_A_;->jPos3709:I

    .line 97
    .line 98
    iget-object v3, p1, LH8_A_;->Oey:Landroid/util/SparseArray;

    .line 99
    .line 100
    invoke-virtual {v3, p2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object p2

    .line 104
    check-cast p2, Ljava/lang/Integer;

    .line 105
    .line 106
    if-eqz p2, :cond_8

    .line 107
    .line 108
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 109
    .line 110
    .line 111
    move-result p2

    .line 112
    iget-object p1, p1, LH8_A_;->Q1_f_:Ljava/util/ArrayList;

    .line 113
    .line 114
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    add-int/2addr p1, v2

    .line 119
    if-ge p2, p1, :cond_8

    .line 120
    .line 121
    :cond_7
    :goto_2
    const-wide/16 p1, 0x20

    .line 122
    .line 123
    return-wide p1

    .line 124
    :cond_8
    :goto_3
    const-string p1, "android.media.playback.ALWAYS_RESERVE_SPACE_FOR.ACTION_SKIP_TO_NEXT"

    .line 125
    .line 126
    invoke-virtual {p3, p1, v4}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 127
    .line 128
    .line 129
    return-wide v0

    .line 130
    :cond_9
    iget-object p1, p0, LAD_x$n2_;->Ialue:Lol01D;

    .line 131
    .line 132
    if-eqz p1, :cond_d

    .line 133
    .line 134
    invoke-virtual {p1}, Lol01D;->sKey7917()Z

    .line 135
    .line 136
    .line 137
    move-result p2

    .line 138
    if-nez p2, :cond_a

    .line 139
    .line 140
    goto :goto_5

    .line 141
    :cond_a
    invoke-virtual {p1}, Lol01D;->POOl()LH8_A_;

    .line 142
    .line 143
    .line 144
    move-result-object p1

    .line 145
    invoke-static {p1}, Lzl1;->kQy(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    const-wide/16 v2, 0x80

    .line 149
    .line 150
    iget-wide v5, p1, LH8_A_;->pCXDYg:J

    .line 151
    .line 152
    and-long/2addr v2, v5

    .line 153
    cmp-long p2, v2, v0

    .line 154
    .line 155
    if-eqz p2, :cond_b

    .line 156
    .line 157
    goto :goto_4

    .line 158
    :cond_b
    iget p2, p1, LH8_A_;->$ÒcdS:I

    .line 159
    .line 160
    if-nez p2, :cond_c

    .line 161
    .line 162
    iget p2, p1, LH8_A_;->jPos3709:I

    .line 163
    .line 164
    iget-object p1, p1, LH8_A_;->Oey:Landroid/util/SparseArray;

    .line 165
    .line 166
    invoke-virtual {p1, p2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    move-result-object p1

    .line 170
    check-cast p1, Ljava/lang/Integer;

    .line 171
    .line 172
    if-eqz p1, :cond_d

    .line 173
    .line 174
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 175
    .line 176
    .line 177
    move-result p1

    .line 178
    if-lez p1, :cond_d

    .line 179
    .line 180
    :cond_c
    :goto_4
    const-wide/16 p1, 0x10

    .line 181
    .line 182
    return-wide p1

    .line 183
    :cond_d
    :goto_5
    const-string p1, "android.media.playback.ALWAYS_RESERVE_SPACE_FOR.ACTION_SKIP_TO_PREVIOUS"

    .line 184
    .line 185
    invoke-virtual {p3, p1, v4}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 186
    .line 187
    .line 188
    return-wide v0

    .line 189
    :cond_e
    const/4 p1, 0x3

    .line 190
    if-ne p2, p1, :cond_f

    .line 191
    .line 192
    const-wide/16 p2, 0x202

    .line 193
    .line 194
    move-wide v0, p2

    .line 195
    const/4 p2, 0x3

    .line 196
    goto :goto_6

    .line 197
    :cond_f
    const-wide/16 v0, 0x200

    .line 198
    .line 199
    :goto_6
    if-eq p2, v3, :cond_10

    .line 200
    .line 201
    return-wide v0

    .line 202
    :cond_10
    const-wide/16 p1, 0x204

    .line 203
    .line 204
    return-wide p1
.end method

.method public final e8$mp_s$(Lol01D;Lcom/google/android/gms/cast/CastDevice;)V
    .locals 7

    .line 1
    const/4 v0, 0x0

    .line 2
    iget-object v1, p0, LAD_x$n2_;->waiBKÀ:LGtVP;

    .line 3
    .line 4
    if-nez v1, :cond_0

    .line 5
    .line 6
    move-object v2, v0

    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v2, v1, LGtVP;->Ialue:LUF$r$;

    .line 9
    .line 10
    :goto_0
    iget-boolean v3, p0, LAD_x$n2_;->yàÒZ:Z

    .line 11
    .line 12
    const/4 v4, 0x0

    .line 13
    if-nez v3, :cond_7

    .line 14
    .line 15
    if-eqz v1, :cond_7

    .line 16
    .line 17
    if-eqz v2, :cond_7

    .line 18
    .line 19
    iget-object v1, p0, LAD_x$n2_;->JKEoÙX:LPVN$Zh_Vn$;

    .line 20
    .line 21
    if-eqz v1, :cond_7

    .line 22
    .line 23
    if-eqz p1, :cond_7

    .line 24
    .line 25
    if-eqz p2, :cond_7

    .line 26
    .line 27
    iget-object v1, p0, LAD_x$n2_;->sKey7917:Landroid/content/ComponentName;

    .line 28
    .line 29
    if-nez v1, :cond_1

    .line 30
    .line 31
    goto/16 :goto_3

    .line 32
    .line 33
    :cond_1
    iput-object p1, p0, LAD_x$n2_;->Ialue:Lol01D;

    .line 34
    .line 35
    iget-object v3, p0, LAD_x$n2_;->kQy:LXDOQID;

    .line 36
    .line 37
    invoke-virtual {p1, v3}, Lol01D;->valuI(LCoqàaÒ;)V

    .line 38
    .line 39
    .line 40
    iput-object p2, p0, LAD_x$n2_;->valuI:Lcom/google/android/gms/cast/CastDevice;

    .line 41
    .line 42
    new-instance p1, Landroid/content/Intent;

    .line 43
    .line 44
    const-string p2, "android.intent.action.MEDIA_BUTTON"

    .line 45
    .line 46
    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p1, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 50
    .line 51
    .line 52
    sget p2, LgD1_x$l$_;->e8$mp_s$:I

    .line 53
    .line 54
    iget-object v3, p0, LAD_x$n2_;->e8$mp_s$:Landroid/content/Context;

    .line 55
    .line 56
    invoke-static {v3, v4, p1, p2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 57
    .line 58
    .line 59
    move-result-object p1

    .line 60
    iget-boolean p2, v2, LUF$r$;->Ialue:Z

    .line 61
    .line 62
    const/4 v2, 0x1

    .line 63
    if-eqz p2, :cond_6

    .line 64
    .line 65
    new-instance p2, LMl;

    .line 66
    .line 67
    invoke-direct {p2, v3, v1, p1}, LMl;-><init>(Landroid/content/Context;Landroid/content/ComponentName;Landroid/app/PendingIntent;)V

    .line 68
    .line 69
    .line 70
    iput-object p2, p0, LAD_x$n2_;->pCXDYg:LMl;

    .line 71
    .line 72
    invoke-virtual {p0, v4, v0}, LAD_x$n2_;->vaIue(ILcom/google/android/gms/cast/MediaInfo;)V

    .line 73
    .line 74
    .line 75
    iget-object p1, p0, LAD_x$n2_;->valuI:Lcom/google/android/gms/cast/CastDevice;

    .line 76
    .line 77
    if-eqz p1, :cond_4

    .line 78
    .line 79
    iget-object p1, p1, Lcom/google/android/gms/cast/CastDevice;->iOffset934:Ljava/lang/String;

    .line 80
    .line 81
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 82
    .line 83
    .line 84
    move-result p1

    .line 85
    if-nez p1, :cond_4

    .line 86
    .line 87
    new-instance p1, Landroid/os/Bundle;

    .line 88
    .line 89
    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 93
    .line 94
    .line 95
    move-result-object v1

    .line 96
    sget v3, LbOQ;->cast_casting_to_device:I

    .line 97
    .line 98
    iget-object v5, p0, LAD_x$n2_;->valuI:Lcom/google/android/gms/cast/CastDevice;

    .line 99
    .line 100
    iget-object v5, v5, Lcom/google/android/gms/cast/CastDevice;->iOffset934:Ljava/lang/String;

    .line 101
    .line 102
    new-array v6, v2, [Ljava/lang/Object;

    .line 103
    .line 104
    aput-object v5, v6, v4

    .line 105
    .line 106
    invoke-virtual {v1, v3, v6}, Landroid/content/res/Resources;->getString(I[Ljava/lang/Object;)Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    sget-object v3, Landroid/support/v4/media/MediaMetadataCompat;->iOffset934:LhasSize1398;

    .line 111
    .line 112
    const-string v4, "android.media.metadata.ALBUM_ARTIST"

    .line 113
    .line 114
    invoke-virtual {v3, v4}, LZdxMjO;->containsKey(Ljava/lang/Object;)Z

    .line 115
    .line 116
    .line 117
    move-result v5

    .line 118
    if-eqz v5, :cond_3

    .line 119
    .line 120
    invoke-virtual {v3, v4}, LZdxMjO;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    check-cast v3, Ljava/lang/Integer;

    .line 125
    .line 126
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 127
    .line 128
    .line 129
    move-result v3

    .line 130
    if-ne v3, v2, :cond_2

    .line 131
    .line 132
    goto :goto_1

    .line 133
    :cond_2
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 134
    .line 135
    const-string p2, "The android.media.metadata.ALBUM_ARTIST key cannot be used to put a String"

    .line 136
    .line 137
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    throw p1

    .line 141
    :cond_3
    :goto_1
    invoke-virtual {p1, v4, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 142
    .line 143
    .line 144
    new-instance v1, Landroid/support/v4/media/MediaMetadataCompat;

    .line 145
    .line 146
    invoke-direct {v1, p1}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Bundle;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p2, v1}, LMl;->gKey4112(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 150
    .line 151
    .line 152
    :cond_4
    new-instance p1, LvIndex8828;

    .line 153
    .line 154
    invoke-direct {p1, p0}, LvIndex8828;-><init>(LAD_x$n2_;)V

    .line 155
    .line 156
    .line 157
    invoke-virtual {p2, p1, v0}, LMl;->pCXDYg(LfÙqYeh;Landroid/os/Handler;)V

    .line 158
    .line 159
    .line 160
    iget-object p1, p2, LMl;->vaIue:Ljava/lang/Object;

    .line 161
    .line 162
    check-cast p1, LrcDTìq;

    .line 163
    .line 164
    iget-object p1, p1, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    .line 165
    .line 166
    invoke-virtual {p1, v2}, Landroid/media/session/MediaSession;->setActive(Z)V

    .line 167
    .line 168
    .line 169
    iget-object p1, p2, LMl;->iOffset934:Ljava/lang/Object;

    .line 170
    .line 171
    check-cast p1, Ljava/util/ArrayList;

    .line 172
    .line 173
    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 174
    .line 175
    .line 176
    move-result-object p1

    .line 177
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 178
    .line 179
    .line 180
    move-result v0

    .line 181
    if-nez v0, :cond_5

    .line 182
    .line 183
    iget-object p1, p0, LAD_x$n2_;->rz__9J_:LsqùAA;

    .line 184
    .line 185
    invoke-virtual {p1, p2}, LsqùAA;->tmpKey6288(LMl;)V

    .line 186
    .line 187
    .line 188
    goto :goto_2

    .line 189
    :cond_5
    invoke-static {p1}, LRQU_K6$Kv_;->vaIue(Ljava/util/Iterator;)Ljava/lang/ClassCastException;

    .line 190
    .line 191
    .line 192
    move-result-object p1

    .line 193
    throw p1

    .line 194
    :cond_6
    :goto_2
    iput-boolean v2, p0, LAD_x$n2_;->yàÒZ:Z

    .line 195
    .line 196
    invoke-virtual {p0}, LAD_x$n2_;->rz__9J_()V

    .line 197
    .line 198
    .line 199
    return-void

    .line 200
    :cond_7
    :goto_3
    new-array p1, v4, [Ljava/lang/Object;

    .line 201
    .line 202
    const-string p2, "skip attaching media session"

    .line 203
    .line 204
    sget-object v0, LAD_x$n2_;->UC_n_:LhiB_7$0y_;

    .line 205
    .line 206
    invoke-virtual {v0, p2, p1}, LhiB_7$0y_;->e8$mp_s$(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 207
    .line 208
    .line 209
    return-void
.end method

.method public final rz__9J_()V
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, LAD_x$n2_;->Ialue:Lol01D;

    .line 4
    .line 5
    if-nez v1, :cond_0

    .line 6
    .line 7
    goto/16 :goto_6

    .line 8
    .line 9
    :cond_0
    invoke-virtual {v1}, Lol01D;->yàÒZ()I

    .line 10
    .line 11
    .line 12
    move-result v2

    .line 13
    invoke-virtual {v1}, Lol01D;->rz__9J_()Lcom/google/android/gms/cast/MediaInfo;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-virtual {v1}, Lol01D;->vaIue()Z

    .line 18
    .line 19
    .line 20
    move-result v4

    .line 21
    if-eqz v4, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Lol01D;->waiBKÀ()LbZ8$lp_tz$;

    .line 24
    .line 25
    .line 26
    move-result-object v4

    .line 27
    if-eqz v4, :cond_1

    .line 28
    .line 29
    iget-object v4, v4, LbZ8$lp_tz$;->yON3x:Lcom/google/android/gms/cast/MediaInfo;

    .line 30
    .line 31
    if-eqz v4, :cond_1

    .line 32
    .line 33
    move-object v3, v4

    .line 34
    :cond_1
    invoke-virtual {v0, v2, v3}, LAD_x$n2_;->vaIue(ILcom/google/android/gms/cast/MediaInfo;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v1}, Lol01D;->sKey7917()Z

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    if-nez v3, :cond_2

    .line 42
    .line 43
    invoke-virtual {v0}, LAD_x$n2_;->DDù8()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0}, LAD_x$n2_;->yON3x()V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_2
    if-eqz v2, :cond_f

    .line 51
    .line 52
    const/4 v2, 0x1

    .line 53
    iget-object v3, v0, LAD_x$n2_;->vaIue:LPNdgAQ$;

    .line 54
    .line 55
    if-eqz v3, :cond_e

    .line 56
    .line 57
    const-string v4, "Update media notification."

    .line 58
    .line 59
    const/4 v5, 0x0

    .line 60
    new-array v6, v5, [Ljava/lang/Object;

    .line 61
    .line 62
    sget-object v7, LAD_x$n2_;->UC_n_:LhiB_7$0y_;

    .line 63
    .line 64
    invoke-virtual {v7, v4, v6}, LhiB_7$0y_;->e8$mp_s$(Ljava/lang/String;[Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    iget-object v4, v0, LAD_x$n2_;->valuI:Lcom/google/android/gms/cast/CastDevice;

    .line 68
    .line 69
    iget-object v6, v0, LAD_x$n2_;->Ialue:Lol01D;

    .line 70
    .line 71
    iget-object v7, v0, LAD_x$n2_;->pCXDYg:LMl;

    .line 72
    .line 73
    if-eqz v4, :cond_e

    .line 74
    .line 75
    if-eqz v6, :cond_e

    .line 76
    .line 77
    if-nez v7, :cond_3

    .line 78
    .line 79
    goto/16 :goto_5

    .line 80
    .line 81
    :cond_3
    invoke-virtual {v6}, Lol01D;->rz__9J_()Lcom/google/android/gms/cast/MediaInfo;

    .line 82
    .line 83
    .line 84
    move-result-object v8

    .line 85
    if-eqz v8, :cond_e

    .line 86
    .line 87
    iget-object v9, v8, Lcom/google/android/gms/cast/MediaInfo;->iOffset934:LlI1I;

    .line 88
    .line 89
    if-eqz v9, :cond_e

    .line 90
    .line 91
    iget-object v10, v9, LlI1I;->yON3x:Ljava/util/List;

    .line 92
    .line 93
    invoke-virtual {v6}, Lol01D;->POOl()LH8_A_;

    .line 94
    .line 95
    .line 96
    move-result-object v11

    .line 97
    const/4 v12, 0x2

    .line 98
    if-eqz v11, :cond_6

    .line 99
    .line 100
    iget v13, v11, LH8_A_;->$ÒcdS:I

    .line 101
    .line 102
    if-eq v13, v2, :cond_7

    .line 103
    .line 104
    if-eq v13, v12, :cond_7

    .line 105
    .line 106
    const/4 v14, 0x3

    .line 107
    if-eq v13, v14, :cond_7

    .line 108
    .line 109
    iget v13, v11, LH8_A_;->jPos3709:I

    .line 110
    .line 111
    iget-object v14, v11, LH8_A_;->Oey:Landroid/util/SparseArray;

    .line 112
    .line 113
    invoke-virtual {v14, v13}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v13

    .line 117
    check-cast v13, Ljava/lang/Integer;

    .line 118
    .line 119
    if-eqz v13, :cond_6

    .line 120
    .line 121
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 122
    .line 123
    .line 124
    move-result v14

    .line 125
    if-lez v14, :cond_4

    .line 126
    .line 127
    const/4 v14, 0x1

    .line 128
    goto :goto_0

    .line 129
    :cond_4
    const/4 v14, 0x0

    .line 130
    :goto_0
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 131
    .line 132
    .line 133
    move-result v13

    .line 134
    iget-object v11, v11, LH8_A_;->Q1_f_:Ljava/util/ArrayList;

    .line 135
    .line 136
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 137
    .line 138
    .line 139
    move-result v11

    .line 140
    add-int/lit8 v11, v11, -0x1

    .line 141
    .line 142
    if-ge v13, v11, :cond_5

    .line 143
    .line 144
    move/from16 v22, v14

    .line 145
    .line 146
    const/16 v21, 0x1

    .line 147
    .line 148
    goto :goto_1

    .line 149
    :cond_5
    move/from16 v22, v14

    .line 150
    .line 151
    const/16 v21, 0x0

    .line 152
    .line 153
    goto :goto_1

    .line 154
    :cond_6
    const/16 v21, 0x0

    .line 155
    .line 156
    const/16 v22, 0x0

    .line 157
    .line 158
    goto :goto_1

    .line 159
    :cond_7
    const/16 v21, 0x1

    .line 160
    .line 161
    const/16 v22, 0x1

    .line 162
    .line 163
    :goto_1
    invoke-virtual {v6}, Lol01D;->JKEoÙX()I

    .line 164
    .line 165
    .line 166
    move-result v6

    .line 167
    if-ne v6, v12, :cond_8

    .line 168
    .line 169
    const/16 v16, 0x1

    .line 170
    .line 171
    goto :goto_2

    .line 172
    :cond_8
    const/16 v16, 0x0

    .line 173
    .line 174
    :goto_2
    new-instance v15, LgCount1307;

    .line 175
    .line 176
    iget v6, v8, Lcom/google/android/gms/cast/MediaInfo;->vaIue:I

    .line 177
    .line 178
    const-string v8, "com.google.android.gms.cast.metadata.TITLE"

    .line 179
    .line 180
    invoke-virtual {v9, v8}, LlI1I;->rz__9J_(Ljava/lang/String;)Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v18

    .line 184
    iget-object v4, v4, Lcom/google/android/gms/cast/CastDevice;->iOffset934:Ljava/lang/String;

    .line 185
    .line 186
    iget-object v7, v7, LMl;->vaIue:Ljava/lang/Object;

    .line 187
    .line 188
    check-cast v7, LrcDTìq;

    .line 189
    .line 190
    iget-object v7, v7, LrcDTìq;->waiBKÀ:Landroid/support/v4/media/session/MediaSessionCompat$Token;

    .line 191
    .line 192
    move-object/from16 v19, v4

    .line 193
    .line 194
    move/from16 v17, v6

    .line 195
    .line 196
    move-object/from16 v20, v7

    .line 197
    .line 198
    invoke-direct/range {v15 .. v22}, LgCount1307;-><init>(ZILjava/lang/String;Ljava/lang/String;Landroid/support/v4/media/session/MediaSessionCompat$Token;ZZ)V

    .line 199
    .line 200
    .line 201
    move/from16 v6, v16

    .line 202
    .line 203
    move/from16 v7, v17

    .line 204
    .line 205
    move-object/from16 v8, v18

    .line 206
    .line 207
    move-object/from16 v9, v19

    .line 208
    .line 209
    move/from16 v4, v21

    .line 210
    .line 211
    move/from16 v14, v22

    .line 212
    .line 213
    iget-object v11, v3, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 214
    .line 215
    if-eqz v11, :cond_9

    .line 216
    .line 217
    iget-boolean v12, v11, LgCount1307;->waiBKÀ:Z

    .line 218
    .line 219
    if-ne v6, v12, :cond_9

    .line 220
    .line 221
    iget v6, v11, LgCount1307;->rz__9J_:I

    .line 222
    .line 223
    if-ne v7, v6, :cond_9

    .line 224
    .line 225
    iget-object v6, v11, LgCount1307;->POOl:Ljava/lang/String;

    .line 226
    .line 227
    invoke-static {v8, v6}, LtmpData2913;->POOl(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 228
    .line 229
    .line 230
    move-result v6

    .line 231
    if-eqz v6, :cond_9

    .line 232
    .line 233
    iget-object v6, v11, LgCount1307;->JKEoÙX:Ljava/lang/String;

    .line 234
    .line 235
    invoke-static {v9, v6}, LtmpData2913;->POOl(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 236
    .line 237
    .line 238
    move-result v6

    .line 239
    if-eqz v6, :cond_9

    .line 240
    .line 241
    iget-boolean v6, v11, LgCount1307;->tmpData3485:Z

    .line 242
    .line 243
    if-ne v4, v6, :cond_9

    .line 244
    .line 245
    iget-boolean v4, v11, LgCount1307;->sKey7917:Z

    .line 246
    .line 247
    if-eq v14, v4, :cond_a

    .line 248
    .line 249
    :cond_9
    iput-object v15, v3, LPNdgAQ$;->jPos3709:LgCount1307;

    .line 250
    .line 251
    invoke-virtual {v3}, LPNdgAQ$;->waiBKÀ()V

    .line 252
    .line 253
    .line 254
    :cond_a
    new-instance v4, Lavt$p$;

    .line 255
    .line 256
    if-eqz v10, :cond_b

    .line 257
    .line 258
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    .line 259
    .line 260
    .line 261
    move-result v6

    .line 262
    if-nez v6, :cond_b

    .line 263
    .line 264
    invoke-interface {v10, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 265
    .line 266
    .line 267
    move-result-object v5

    .line 268
    check-cast v5, LHDlI;

    .line 269
    .line 270
    goto :goto_3

    .line 271
    :cond_b
    const/4 v5, 0x0

    .line 272
    :goto_3
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 273
    .line 274
    .line 275
    if-nez v5, :cond_c

    .line 276
    .line 277
    const/4 v5, 0x0

    .line 278
    goto :goto_4

    .line 279
    :cond_c
    iget-object v5, v5, LHDlI;->vaIue:Landroid/net/Uri;

    .line 280
    .line 281
    :goto_4
    iput-object v5, v4, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 282
    .line 283
    iget-object v5, v4, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 284
    .line 285
    check-cast v5, Landroid/net/Uri;

    .line 286
    .line 287
    iget-object v6, v3, LPNdgAQ$;->iOffset934:Lavt$p$;

    .line 288
    .line 289
    if-eqz v6, :cond_d

    .line 290
    .line 291
    iget-object v6, v6, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 292
    .line 293
    check-cast v6, Landroid/net/Uri;

    .line 294
    .line 295
    invoke-static {v5, v6}, LtmpData2913;->POOl(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    move-result v6

    .line 299
    if-nez v6, :cond_e

    .line 300
    .line 301
    :cond_d
    iget-object v6, v3, LPNdgAQ$;->yON3x:LKkmORP;

    .line 302
    .line 303
    new-instance v7, Lll1lliI;

    .line 304
    .line 305
    const/16 v8, 0x9

    .line 306
    .line 307
    invoke-direct {v7, v8, v3, v4}, Lll1lliI;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 308
    .line 309
    .line 310
    iput-object v7, v6, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 311
    .line 312
    invoke-virtual {v6, v5}, LKkmORP;->kCount1402(Landroid/net/Uri;)V

    .line 313
    .line 314
    .line 315
    :cond_e
    :goto_5
    invoke-virtual {v1}, Lol01D;->vaIue()Z

    .line 316
    .line 317
    .line 318
    move-result v1

    .line 319
    if-nez v1, :cond_f

    .line 320
    .line 321
    invoke-virtual {v0, v2}, LAD_x$n2_;->sKey7917(Z)V

    .line 322
    .line 323
    .line 324
    :cond_f
    :goto_6
    return-void
.end method

.method public final sKey7917(Z)V
    .locals 5

    .line 1
    iget-object v0, p0, LAD_x$n2_;->waiBKÀ:LGtVP;

    .line 2
    .line 3
    iget-boolean v0, v0, LGtVP;->valuI:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    iget-object v0, p0, LAD_x$n2_;->jPos3709:LlI111l;

    .line 9
    .line 10
    iget-object v1, p0, LAD_x$n2_;->iOffset934:LqàÙ;

    .line 11
    .line 12
    if-eqz v1, :cond_1

    .line 13
    .line 14
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    new-instance v2, Landroid/content/Intent;

    .line 18
    .line 19
    iget-object v3, p0, LAD_x$n2_;->e8$mp_s$:Landroid/content/Context;

    .line 20
    .line 21
    const-class v4, Lcom/google/android/gms/cast/framework/ReconnectionService;

    .line 22
    .line 23
    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object v4

    .line 30
    invoke-virtual {v2, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 31
    .line 32
    .line 33
    :try_start_0
    invoke-virtual {v3, v2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :catch_0
    if-eqz p1, :cond_2

    .line 38
    .line 39
    const-wide/16 v2, 0x3e8

    .line 40
    .line 41
    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 42
    .line 43
    .line 44
    :cond_2
    :goto_0
    return-void
.end method

.method public final tmpData3485(Landroid/support/v4/media/session/sKey7917;Ljava/lang/String;LldÈL;)V
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    move-object/from16 v2, p3

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    const/4 v4, 0x1

    .line 12
    const-string v5, "com.google.android.gms.cast.framework.action.REWIND"

    .line 13
    .line 14
    const/4 v6, 0x2

    .line 15
    const-string v7, "com.google.android.gms.cast.framework.action.STOP_CASTING"

    .line 16
    .line 17
    const-string v9, "com.google.android.gms.cast.framework.action.DISCONNECT"

    .line 18
    .line 19
    const-string v10, "com.google.android.gms.cast.framework.action.FORWARD"

    .line 20
    .line 21
    sparse-switch v3, :sswitch_data_0

    .line 22
    .line 23
    .line 24
    goto :goto_0

    .line 25
    :sswitch_0
    invoke-virtual {v1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result v3

    .line 29
    if-eqz v3, :cond_0

    .line 30
    .line 31
    const/4 v3, 0x0

    .line 32
    goto :goto_1

    .line 33
    :sswitch_1
    invoke-virtual {v1, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-eqz v3, :cond_0

    .line 38
    .line 39
    const/4 v3, 0x3

    .line 40
    goto :goto_1

    .line 41
    :sswitch_2
    invoke-virtual {v1, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-eqz v3, :cond_0

    .line 46
    .line 47
    const/4 v3, 0x2

    .line 48
    goto :goto_1

    .line 49
    :sswitch_3
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_0

    .line 54
    .line 55
    const/4 v3, 0x1

    .line 56
    goto :goto_1

    .line 57
    :cond_0
    :goto_0
    const/4 v3, -0x1

    .line 58
    :goto_1
    iget-object v15, v0, LAD_x$n2_;->e8$mp_s$:Landroid/content/Context;

    .line 59
    .line 60
    const-wide/16 v16, 0x2710

    .line 61
    .line 62
    iget-object v11, v0, LAD_x$n2_;->JKEoÙX:LPVN$Zh_Vn$;

    .line 63
    .line 64
    const-string v12, "You must specify an action to build a CustomAction"

    .line 65
    .line 66
    const-wide/16 v18, 0x7530

    .line 67
    .line 68
    const-string v13, "You must specify a name to build a CustomAction"

    .line 69
    .line 70
    const-string v14, "You must specify an icon resource id to build a CustomAction"

    .line 71
    .line 72
    const/4 v8, 0x0

    .line 73
    if-eqz v3, :cond_17

    .line 74
    .line 75
    if-eq v3, v4, :cond_e

    .line 76
    .line 77
    if-eq v3, v6, :cond_9

    .line 78
    .line 79
    const/4 v4, 0x3

    .line 80
    if-eq v3, v4, :cond_4

    .line 81
    .line 82
    if-eqz v2, :cond_20

    .line 83
    .line 84
    iget-object v3, v2, LldÈL;->jPos3709:Ljava/lang/String;

    .line 85
    .line 86
    iget v2, v2, LldÈL;->vaIue:I

    .line 87
    .line 88
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 89
    .line 90
    .line 91
    move-result v4

    .line 92
    if-nez v4, :cond_3

    .line 93
    .line 94
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    if-nez v4, :cond_2

    .line 99
    .line 100
    if-eqz v2, :cond_1

    .line 101
    .line 102
    new-instance v4, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 103
    .line 104
    invoke-direct {v4, v1, v3, v2, v8}, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;ILandroid/os/Bundle;)V

    .line 105
    .line 106
    .line 107
    move-object v8, v4

    .line 108
    goto/16 :goto_a

    .line 109
    .line 110
    :cond_1
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 111
    .line 112
    invoke-direct {v1, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    throw v1

    .line 116
    :cond_2
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 117
    .line 118
    invoke-direct {v1, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    throw v1

    .line 122
    :cond_3
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 123
    .line 124
    invoke-direct {v1, v12}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 125
    .line 126
    .line 127
    throw v1

    .line 128
    :cond_4
    iget-object v1, v0, LAD_x$n2_;->Qp_Hp$i_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 129
    .line 130
    if-nez v1, :cond_8

    .line 131
    .line 132
    if-eqz v11, :cond_8

    .line 133
    .line 134
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 135
    .line 136
    .line 137
    move-result-object v1

    .line 138
    iget v2, v11, LPVN$Zh_Vn$;->gSy_FG$D_:I

    .line 139
    .line 140
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    iget v2, v11, LPVN$Zh_Vn$;->Q1_f_:I

    .line 145
    .line 146
    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 147
    .line 148
    .line 149
    move-result v3

    .line 150
    if-nez v3, :cond_7

    .line 151
    .line 152
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 153
    .line 154
    .line 155
    move-result v3

    .line 156
    if-nez v3, :cond_6

    .line 157
    .line 158
    if-eqz v2, :cond_5

    .line 159
    .line 160
    new-instance v3, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 161
    .line 162
    invoke-direct {v3, v9, v1, v2, v8}, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;ILandroid/os/Bundle;)V

    .line 163
    .line 164
    .line 165
    iput-object v3, v0, LAD_x$n2_;->Qp_Hp$i_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 166
    .line 167
    goto :goto_2

    .line 168
    :cond_5
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 169
    .line 170
    invoke-direct {v1, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    throw v1

    .line 174
    :cond_6
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 175
    .line 176
    invoke-direct {v1, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    throw v1

    .line 180
    :cond_7
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 181
    .line 182
    invoke-direct {v1, v12}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 183
    .line 184
    .line 185
    throw v1

    .line 186
    :cond_8
    :goto_2
    iget-object v8, v0, LAD_x$n2_;->Qp_Hp$i_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 187
    .line 188
    goto/16 :goto_a

    .line 189
    .line 190
    :cond_9
    iget-object v1, v0, LAD_x$n2_;->K0I:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 191
    .line 192
    if-nez v1, :cond_d

    .line 193
    .line 194
    if-eqz v11, :cond_d

    .line 195
    .line 196
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    iget v2, v11, LPVN$Zh_Vn$;->gSy_FG$D_:I

    .line 201
    .line 202
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v1

    .line 206
    iget v2, v11, LPVN$Zh_Vn$;->Q1_f_:I

    .line 207
    .line 208
    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 209
    .line 210
    .line 211
    move-result v3

    .line 212
    if-nez v3, :cond_c

    .line 213
    .line 214
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 215
    .line 216
    .line 217
    move-result v3

    .line 218
    if-nez v3, :cond_b

    .line 219
    .line 220
    if-eqz v2, :cond_a

    .line 221
    .line 222
    new-instance v3, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 223
    .line 224
    invoke-direct {v3, v7, v1, v2, v8}, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;ILandroid/os/Bundle;)V

    .line 225
    .line 226
    .line 227
    iput-object v3, v0, LAD_x$n2_;->K0I:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 228
    .line 229
    goto :goto_3

    .line 230
    :cond_a
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 231
    .line 232
    invoke-direct {v1, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 233
    .line 234
    .line 235
    throw v1

    .line 236
    :cond_b
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 237
    .line 238
    invoke-direct {v1, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 239
    .line 240
    .line 241
    throw v1

    .line 242
    :cond_c
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 243
    .line 244
    invoke-direct {v1, v12}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 245
    .line 246
    .line 247
    throw v1

    .line 248
    :cond_d
    :goto_3
    iget-object v8, v0, LAD_x$n2_;->K0I:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 249
    .line 250
    goto/16 :goto_a

    .line 251
    .line 252
    :cond_e
    iget-object v1, v0, LAD_x$n2_;->kO_6X_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 253
    .line 254
    if-nez v1, :cond_16

    .line 255
    .line 256
    if-eqz v11, :cond_16

    .line 257
    .line 258
    iget-wide v1, v11, LPVN$Zh_Vn$;->jPos3709:J

    .line 259
    .line 260
    sget-object v3, LLl$l$;->e8$mp_s$:LhiB_7$0y_;

    .line 261
    .line 262
    cmp-long v3, v1, v16

    .line 263
    .line 264
    iget v4, v11, LPVN$Zh_Vn$;->oaX_6_:I

    .line 265
    .line 266
    if-nez v3, :cond_f

    .line 267
    .line 268
    iget v4, v11, LPVN$Zh_Vn$;->BCIm:I

    .line 269
    .line 270
    goto :goto_4

    .line 271
    :cond_f
    cmp-long v6, v1, v18

    .line 272
    .line 273
    if-eqz v6, :cond_10

    .line 274
    .line 275
    goto :goto_4

    .line 276
    :cond_10
    iget v4, v11, LPVN$Zh_Vn$;->zAt$p:I

    .line 277
    .line 278
    :goto_4
    iget v6, v11, LPVN$Zh_Vn$;->UC_n_:I

    .line 279
    .line 280
    if-nez v3, :cond_11

    .line 281
    .line 282
    iget v6, v11, LPVN$Zh_Vn$;->kCount1402:I

    .line 283
    .line 284
    goto :goto_5

    .line 285
    :cond_11
    cmp-long v3, v1, v18

    .line 286
    .line 287
    if-eqz v3, :cond_12

    .line 288
    .line 289
    goto :goto_5

    .line 290
    :cond_12
    iget v6, v11, LPVN$Zh_Vn$;->$ÒcdS:I

    .line 291
    .line 292
    :goto_5
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 293
    .line 294
    .line 295
    move-result-object v1

    .line 296
    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 297
    .line 298
    .line 299
    move-result-object v1

    .line 300
    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 301
    .line 302
    .line 303
    move-result v2

    .line 304
    if-nez v2, :cond_15

    .line 305
    .line 306
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 307
    .line 308
    .line 309
    move-result v2

    .line 310
    if-nez v2, :cond_14

    .line 311
    .line 312
    if-eqz v6, :cond_13

    .line 313
    .line 314
    new-instance v2, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 315
    .line 316
    invoke-direct {v2, v5, v1, v6, v8}, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;ILandroid/os/Bundle;)V

    .line 317
    .line 318
    .line 319
    iput-object v2, v0, LAD_x$n2_;->kO_6X_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 320
    .line 321
    goto :goto_6

    .line 322
    :cond_13
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 323
    .line 324
    invoke-direct {v1, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    throw v1

    .line 328
    :cond_14
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 329
    .line 330
    invoke-direct {v1, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 331
    .line 332
    .line 333
    throw v1

    .line 334
    :cond_15
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 335
    .line 336
    invoke-direct {v1, v12}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 337
    .line 338
    .line 339
    throw v1

    .line 340
    :cond_16
    :goto_6
    iget-object v8, v0, LAD_x$n2_;->kO_6X_:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 341
    .line 342
    goto :goto_a

    .line 343
    :cond_17
    iget-object v1, v0, LAD_x$n2_;->gKey4112:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 344
    .line 345
    if-nez v1, :cond_1f

    .line 346
    .line 347
    if-eqz v11, :cond_1f

    .line 348
    .line 349
    iget-wide v1, v11, LPVN$Zh_Vn$;->jPos3709:J

    .line 350
    .line 351
    sget-object v3, LLl$l$;->e8$mp_s$:LhiB_7$0y_;

    .line 352
    .line 353
    cmp-long v3, v1, v16

    .line 354
    .line 355
    iget v4, v11, LPVN$Zh_Vn$;->Iii:I

    .line 356
    .line 357
    if-nez v3, :cond_18

    .line 358
    .line 359
    iget v4, v11, LPVN$Zh_Vn$;->l1:I

    .line 360
    .line 361
    goto :goto_7

    .line 362
    :cond_18
    cmp-long v5, v1, v18

    .line 363
    .line 364
    if-eqz v5, :cond_19

    .line 365
    .line 366
    goto :goto_7

    .line 367
    :cond_19
    iget v4, v11, LPVN$Zh_Vn$;->pQ1Il:I

    .line 368
    .line 369
    :goto_7
    iget v5, v11, LPVN$Zh_Vn$;->kO_6X_:I

    .line 370
    .line 371
    if-nez v3, :cond_1a

    .line 372
    .line 373
    iget v5, v11, LPVN$Zh_Vn$;->K0I:I

    .line 374
    .line 375
    goto :goto_8

    .line 376
    :cond_1a
    cmp-long v3, v1, v18

    .line 377
    .line 378
    if-eqz v3, :cond_1b

    .line 379
    .line 380
    goto :goto_8

    .line 381
    :cond_1b
    iget v5, v11, LPVN$Zh_Vn$;->Qp_Hp$i_:I

    .line 382
    .line 383
    :goto_8
    invoke-virtual {v15}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 384
    .line 385
    .line 386
    move-result-object v1

    .line 387
    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 388
    .line 389
    .line 390
    move-result-object v1

    .line 391
    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 392
    .line 393
    .line 394
    move-result v2

    .line 395
    if-nez v2, :cond_1e

    .line 396
    .line 397
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 398
    .line 399
    .line 400
    move-result v2

    .line 401
    if-nez v2, :cond_1d

    .line 402
    .line 403
    if-eqz v5, :cond_1c

    .line 404
    .line 405
    new-instance v2, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 406
    .line 407
    invoke-direct {v2, v10, v1, v5, v8}, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;ILandroid/os/Bundle;)V

    .line 408
    .line 409
    .line 410
    iput-object v2, v0, LAD_x$n2_;->gKey4112:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 411
    .line 412
    goto :goto_9

    .line 413
    :cond_1c
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 414
    .line 415
    invoke-direct {v1, v14}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 416
    .line 417
    .line 418
    throw v1

    .line 419
    :cond_1d
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 420
    .line 421
    invoke-direct {v1, v13}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 422
    .line 423
    .line 424
    throw v1

    .line 425
    :cond_1e
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 426
    .line 427
    invoke-direct {v1, v12}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 428
    .line 429
    .line 430
    throw v1

    .line 431
    :cond_1f
    :goto_9
    iget-object v8, v0, LAD_x$n2_;->gKey4112:Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 432
    .line 433
    :cond_20
    :goto_a
    if-eqz v8, :cond_21

    .line 434
    .line 435
    move-object/from16 v1, p1

    .line 436
    .line 437
    iget-object v1, v1, Landroid/support/v4/media/session/sKey7917;->e8$mp_s$:Ljava/util/ArrayList;

    .line 438
    .line 439
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 440
    .line 441
    .line 442
    :cond_21
    return-void

    .line 443
    :sswitch_data_0
    .sparse-switch
        -0x655132e4 -> :sswitch_3
        -0x27d32f79 -> :sswitch_2
        -0x76b6783 -> :sswitch_1
        0x51303e64 -> :sswitch_0
    .end sparse-switch
.end method

.method public final vaIue(ILcom/google/android/gms/cast/MediaInfo;)V
    .locals 23

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v0, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v1, LAD_x$n2_;->pCXDYg:LMl;

    .line 8
    .line 9
    if-nez v3, :cond_0

    .line 10
    .line 11
    goto/16 :goto_12

    .line 12
    .line 13
    :cond_0
    new-instance v4, Landroid/os/Bundle;

    .line 14
    .line 15
    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    .line 16
    .line 17
    .line 18
    new-instance v5, Landroid/support/v4/media/session/sKey7917;

    .line 19
    .line 20
    invoke-direct {v5}, Landroid/support/v4/media/session/sKey7917;-><init>()V

    .line 21
    .line 22
    .line 23
    iget-object v6, v1, LAD_x$n2_;->Ialue:Lol01D;

    .line 24
    .line 25
    const/4 v8, 0x0

    .line 26
    if-eqz v6, :cond_e

    .line 27
    .line 28
    iget-object v11, v1, LAD_x$n2_;->vaIue:LPNdgAQ$;

    .line 29
    .line 30
    if-nez v11, :cond_1

    .line 31
    .line 32
    goto/16 :goto_7

    .line 33
    .line 34
    :cond_1
    invoke-virtual {v6}, Lol01D;->yàÒZ()I

    .line 35
    .line 36
    .line 37
    move-result v11

    .line 38
    if-eqz v11, :cond_2

    .line 39
    .line 40
    invoke-virtual {v6}, Lol01D;->yON3x()Z

    .line 41
    .line 42
    .line 43
    move-result v11

    .line 44
    if-eqz v11, :cond_3

    .line 45
    .line 46
    :cond_2
    const-wide/16 v11, 0x0

    .line 47
    .line 48
    goto :goto_0

    .line 49
    :cond_3
    invoke-virtual {v6}, Lol01D;->e8$mp_s$()J

    .line 50
    .line 51
    .line 52
    move-result-wide v11

    .line 53
    :goto_0
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 54
    .line 55
    .line 56
    move-result-wide v13

    .line 57
    iput v0, v5, Landroid/support/v4/media/session/sKey7917;->waiBKÀ:I

    .line 58
    .line 59
    iput-wide v11, v5, Landroid/support/v4/media/session/sKey7917;->rz__9J_:J

    .line 60
    .line 61
    iput-wide v13, v5, Landroid/support/v4/media/session/sKey7917;->tmpData3485:J

    .line 62
    .line 63
    const/high16 v6, 0x3f800000    # 1.0f

    .line 64
    .line 65
    iput v6, v5, Landroid/support/v4/media/session/sKey7917;->POOl:F

    .line 66
    .line 67
    if-nez v0, :cond_4

    .line 68
    .line 69
    invoke-virtual {v5}, Landroid/support/v4/media/session/sKey7917;->e8$mp_s$()Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 70
    .line 71
    .line 72
    move-result-object v5

    .line 73
    goto/16 :goto_8

    .line 74
    .line 75
    :cond_4
    iget-object v6, v1, LAD_x$n2_;->JKEoÙX:LPVN$Zh_Vn$;

    .line 76
    .line 77
    if-eqz v6, :cond_5

    .line 78
    .line 79
    iget-object v11, v6, LPVN$Zh_Vn$;->iSize4906:LolO$6$;

    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_5
    move-object v11, v8

    .line 83
    :goto_1
    iget-object v12, v1, LAD_x$n2_;->Ialue:Lol01D;

    .line 84
    .line 85
    if-eqz v12, :cond_6

    .line 86
    .line 87
    invoke-virtual {v12}, Lol01D;->yON3x()Z

    .line 88
    .line 89
    .line 90
    move-result v12

    .line 91
    if-nez v12, :cond_6

    .line 92
    .line 93
    iget-object v12, v1, LAD_x$n2_;->Ialue:Lol01D;

    .line 94
    .line 95
    invoke-virtual {v12}, Lol01D;->kQy()Z

    .line 96
    .line 97
    .line 98
    move-result v12

    .line 99
    if-eqz v12, :cond_7

    .line 100
    .line 101
    :cond_6
    const-wide/16 v12, 0x0

    .line 102
    .line 103
    goto :goto_2

    .line 104
    :cond_7
    const-wide/16 v12, 0x100

    .line 105
    .line 106
    :goto_2
    if-eqz v11, :cond_a

    .line 107
    .line 108
    invoke-static {v11}, LLl$l$;->e8$mp_s$(LolO$6$;)Ljava/util/ArrayList;

    .line 109
    .line 110
    .line 111
    move-result-object v6

    .line 112
    if-eqz v6, :cond_d

    .line 113
    .line 114
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 115
    .line 116
    .line 117
    move-result v11

    .line 118
    const/4 v14, 0x0

    .line 119
    :goto_3
    if-ge v14, v11, :cond_d

    .line 120
    .line 121
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 122
    .line 123
    .line 124
    move-result-object v15

    .line 125
    add-int/lit8 v14, v14, 0x1

    .line 126
    .line 127
    check-cast v15, LldÈL;

    .line 128
    .line 129
    iget-object v9, v15, LldÈL;->yON3x:Ljava/lang/String;

    .line 130
    .line 131
    const-string v10, "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"

    .line 132
    .line 133
    invoke-static {v9, v10}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 134
    .line 135
    .line 136
    move-result v10

    .line 137
    if-nez v10, :cond_9

    .line 138
    .line 139
    const-string v10, "com.google.android.gms.cast.framework.action.SKIP_PREV"

    .line 140
    .line 141
    invoke-static {v9, v10}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 142
    .line 143
    .line 144
    move-result v10

    .line 145
    if-nez v10, :cond_9

    .line 146
    .line 147
    const-string v10, "com.google.android.gms.cast.framework.action.SKIP_NEXT"

    .line 148
    .line 149
    invoke-static {v9, v10}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 150
    .line 151
    .line 152
    move-result v10

    .line 153
    if-eqz v10, :cond_8

    .line 154
    .line 155
    goto :goto_4

    .line 156
    :cond_8
    invoke-virtual {v1, v5, v9, v15}, LAD_x$n2_;->tmpData3485(Landroid/support/v4/media/session/sKey7917;Ljava/lang/String;LldÈL;)V

    .line 157
    .line 158
    .line 159
    goto :goto_3

    .line 160
    :cond_9
    :goto_4
    invoke-virtual {v1, v9, v0, v4}, LAD_x$n2_;->POOl(Ljava/lang/String;ILandroid/os/Bundle;)J

    .line 161
    .line 162
    .line 163
    move-result-wide v9

    .line 164
    or-long/2addr v9, v12

    .line 165
    move-wide v12, v9

    .line 166
    goto :goto_3

    .line 167
    :cond_a
    if-eqz v6, :cond_d

    .line 168
    .line 169
    iget-object v6, v6, LPVN$Zh_Vn$;->yON3x:Ljava/util/ArrayList;

    .line 170
    .line 171
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 172
    .line 173
    .line 174
    move-result v9

    .line 175
    const/4 v10, 0x0

    .line 176
    :goto_5
    if-ge v10, v9, :cond_d

    .line 177
    .line 178
    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    move-result-object v11

    .line 182
    add-int/lit8 v10, v10, 0x1

    .line 183
    .line 184
    check-cast v11, Ljava/lang/String;

    .line 185
    .line 186
    const-string v14, "com.google.android.gms.cast.framework.action.TOGGLE_PLAYBACK"

    .line 187
    .line 188
    invoke-static {v11, v14}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 189
    .line 190
    .line 191
    move-result v14

    .line 192
    if-nez v14, :cond_c

    .line 193
    .line 194
    const-string v14, "com.google.android.gms.cast.framework.action.SKIP_PREV"

    .line 195
    .line 196
    invoke-static {v11, v14}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 197
    .line 198
    .line 199
    move-result v14

    .line 200
    if-nez v14, :cond_c

    .line 201
    .line 202
    const-string v14, "com.google.android.gms.cast.framework.action.SKIP_NEXT"

    .line 203
    .line 204
    invoke-static {v11, v14}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 205
    .line 206
    .line 207
    move-result v14

    .line 208
    if-eqz v14, :cond_b

    .line 209
    .line 210
    goto :goto_6

    .line 211
    :cond_b
    invoke-virtual {v1, v5, v11, v8}, LAD_x$n2_;->tmpData3485(Landroid/support/v4/media/session/sKey7917;Ljava/lang/String;LldÈL;)V

    .line 212
    .line 213
    .line 214
    goto :goto_5

    .line 215
    :cond_c
    :goto_6
    invoke-virtual {v1, v11, v0, v4}, LAD_x$n2_;->POOl(Ljava/lang/String;ILandroid/os/Bundle;)J

    .line 216
    .line 217
    .line 218
    move-result-wide v14

    .line 219
    or-long/2addr v12, v14

    .line 220
    goto :goto_5

    .line 221
    :cond_d
    iput-wide v12, v5, Landroid/support/v4/media/session/sKey7917;->JKEoÙX:J

    .line 222
    .line 223
    invoke-virtual {v5}, Landroid/support/v4/media/session/sKey7917;->e8$mp_s$()Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 224
    .line 225
    .line 226
    move-result-object v5

    .line 227
    goto :goto_8

    .line 228
    :cond_e
    :goto_7
    invoke-virtual {v5}, Landroid/support/v4/media/session/sKey7917;->e8$mp_s$()Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 229
    .line 230
    .line 231
    move-result-object v5

    .line 232
    :goto_8
    iget-object v6, v3, LMl;->vaIue:Ljava/lang/Object;

    .line 233
    .line 234
    check-cast v6, LrcDTìq;

    .line 235
    .line 236
    iput-object v5, v6, LrcDTìq;->tmpData3485:Landroid/support/v4/media/session/PlaybackStateCompat;

    .line 237
    .line 238
    iget-object v9, v6, LrcDTìq;->rz__9J_:Ljava/lang/Object;

    .line 239
    .line 240
    monitor-enter v9

    .line 241
    :try_start_0
    iget-object v10, v6, LrcDTìq;->JKEoÙX:Landroid/os/RemoteCallbackList;

    .line 242
    .line 243
    invoke-virtual {v10}, Landroid/os/RemoteCallbackList;->beginBroadcast()I

    .line 244
    .line 245
    .line 246
    move-result v10

    .line 247
    const/4 v11, 0x1

    .line 248
    sub-int/2addr v10, v11

    .line 249
    :goto_9
    if-ltz v10, :cond_f

    .line 250
    .line 251
    iget-object v12, v6, LrcDTìq;->JKEoÙX:Landroid/os/RemoteCallbackList;

    .line 252
    .line 253
    invoke-virtual {v12, v10}, Landroid/os/RemoteCallbackList;->getBroadcastItem(I)Landroid/os/IInterface;

    .line 254
    .line 255
    .line 256
    move-result-object v12

    .line 257
    check-cast v12, Lc1;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 258
    .line 259
    :try_start_1
    invoke-interface {v12, v5}, Lc1;->IO(Landroid/support/v4/media/session/PlaybackStateCompat;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 260
    .line 261
    .line 262
    goto :goto_a

    .line 263
    :catchall_0
    move-exception v0

    .line 264
    goto/16 :goto_13

    .line 265
    .line 266
    :catch_0
    :goto_a
    add-int/lit8 v10, v10, -0x1

    .line 267
    .line 268
    goto :goto_9

    .line 269
    :cond_f
    :try_start_2
    iget-object v10, v6, LrcDTìq;->JKEoÙX:Landroid/os/RemoteCallbackList;

    .line 270
    .line 271
    invoke-virtual {v10}, Landroid/os/RemoteCallbackList;->finishBroadcast()V

    .line 272
    .line 273
    .line 274
    monitor-exit v9
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 275
    iget-object v6, v6, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    .line 276
    .line 277
    iget-object v9, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->K0I:Landroid/media/session/PlaybackState;

    .line 278
    .line 279
    if-nez v9, :cond_13

    .line 280
    .line 281
    invoke-static {}, LsKxYQ;->POOl()Landroid/media/session/PlaybackState$Builder;

    .line 282
    .line 283
    .line 284
    move-result-object v16

    .line 285
    iget v9, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->yON3x:I

    .line 286
    .line 287
    iget-wide v12, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->vaIue:J

    .line 288
    .line 289
    iget v10, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->iOffset934:F

    .line 290
    .line 291
    iget-wide v14, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->pCXDYg:J

    .line 292
    .line 293
    move/from16 v17, v9

    .line 294
    .line 295
    move/from16 v20, v10

    .line 296
    .line 297
    move-wide/from16 v18, v12

    .line 298
    .line 299
    move-wide/from16 v21, v14

    .line 300
    .line 301
    invoke-static/range {v16 .. v22}, LsKxYQ;->$ÒcdS(Landroid/media/session/PlaybackState$Builder;IJFJ)V

    .line 302
    .line 303
    .line 304
    move-object/from16 v9, v16

    .line 305
    .line 306
    iget-wide v12, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->jPos3709:J

    .line 307
    .line 308
    invoke-static {v9, v12, v13}, LsKxYQ;->Qp_Hp$i_(Landroid/media/session/PlaybackState$Builder;J)V

    .line 309
    .line 310
    .line 311
    iget-wide v12, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->kQy:J

    .line 312
    .line 313
    invoke-static {v9, v12, v13}, LsKxYQ;->kO_6X_(Landroid/media/session/PlaybackState$Builder;J)V

    .line 314
    .line 315
    .line 316
    iget-object v10, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->valuI:Ljava/lang/CharSequence;

    .line 317
    .line 318
    invoke-static {v9, v10}, LsKxYQ;->UC_n_(Landroid/media/session/PlaybackState$Builder;Ljava/lang/CharSequence;)V

    .line 319
    .line 320
    .line 321
    iget-object v10, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->yàÒZ:Ljava/util/ArrayList;

    .line 322
    .line 323
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 324
    .line 325
    .line 326
    move-result v12

    .line 327
    const/4 v13, 0x0

    .line 328
    :goto_b
    if-ge v13, v12, :cond_11

    .line 329
    .line 330
    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 331
    .line 332
    .line 333
    move-result-object v14

    .line 334
    add-int/lit8 v13, v13, 0x1

    .line 335
    .line 336
    check-cast v14, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;

    .line 337
    .line 338
    iget-object v15, v14, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->kQy:Landroid/media/session/PlaybackState$CustomAction;

    .line 339
    .line 340
    if-nez v15, :cond_10

    .line 341
    .line 342
    iget-object v15, v14, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->yON3x:Ljava/lang/String;

    .line 343
    .line 344
    iget-object v8, v14, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->vaIue:Ljava/lang/CharSequence;

    .line 345
    .line 346
    iget v7, v14, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->jPos3709:I

    .line 347
    .line 348
    invoke-static {v15, v8, v7}, LsKxYQ;->JKEoÙX(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/media/session/PlaybackState$CustomAction$Builder;

    .line 349
    .line 350
    .line 351
    move-result-object v7

    .line 352
    iget-object v8, v14, Landroid/support/v4/media/session/PlaybackStateCompat$CustomAction;->iOffset934:Landroid/os/Bundle;

    .line 353
    .line 354
    invoke-static {v7, v8}, LsKxYQ;->kCount1402(Landroid/media/session/PlaybackState$CustomAction$Builder;Landroid/os/Bundle;)V

    .line 355
    .line 356
    .line 357
    invoke-static {v7}, LsKxYQ;->waiBKÀ(Landroid/media/session/PlaybackState$CustomAction$Builder;)Landroid/media/session/PlaybackState$CustomAction;

    .line 358
    .line 359
    .line 360
    move-result-object v15

    .line 361
    :cond_10
    invoke-static {v9, v15}, LsKxYQ;->e8$mp_s$(Landroid/media/session/PlaybackState$Builder;Landroid/media/session/PlaybackState$CustomAction;)V

    .line 362
    .line 363
    .line 364
    const/4 v8, 0x0

    .line 365
    goto :goto_b

    .line 366
    :cond_11
    iget-wide v7, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->gKey4112:J

    .line 367
    .line 368
    invoke-static {v9, v7, v8}, LsKxYQ;->K0I(Landroid/media/session/PlaybackState$Builder;J)V

    .line 369
    .line 370
    .line 371
    sget v7, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 372
    .line 373
    const/16 v8, 0x16

    .line 374
    .line 375
    if-lt v7, v8, :cond_12

    .line 376
    .line 377
    iget-object v7, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->kO_6X_:Landroid/os/Bundle;

    .line 378
    .line 379
    invoke-static {v9, v7}, LsOffset9572;->waiBKÀ(Landroid/media/session/PlaybackState$Builder;Landroid/os/Bundle;)V

    .line 380
    .line 381
    .line 382
    :cond_12
    invoke-static {v9}, LsKxYQ;->rz__9J_(Landroid/media/session/PlaybackState$Builder;)Landroid/media/session/PlaybackState;

    .line 383
    .line 384
    .line 385
    move-result-object v7

    .line 386
    iput-object v7, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->K0I:Landroid/media/session/PlaybackState;

    .line 387
    .line 388
    :cond_13
    iget-object v5, v5, Landroid/support/v4/media/session/PlaybackStateCompat;->K0I:Landroid/media/session/PlaybackState;

    .line 389
    .line 390
    invoke-virtual {v6, v5}, Landroid/media/session/MediaSession;->setPlaybackState(Landroid/media/session/PlaybackState;)V

    .line 391
    .line 392
    .line 393
    iget-object v5, v1, LAD_x$n2_;->JKEoÙX:LPVN$Zh_Vn$;

    .line 394
    .line 395
    if-eqz v5, :cond_14

    .line 396
    .line 397
    iget-boolean v6, v5, LPVN$Zh_Vn$;->Txy$$d_w$:Z

    .line 398
    .line 399
    if-eqz v6, :cond_14

    .line 400
    .line 401
    const-string v6, "android.media.playback.ALWAYS_RESERVE_SPACE_FOR.ACTION_SKIP_TO_PREVIOUS"

    .line 402
    .line 403
    invoke-virtual {v4, v6, v11}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 404
    .line 405
    .line 406
    :cond_14
    if-eqz v5, :cond_15

    .line 407
    .line 408
    iget-boolean v5, v5, LPVN$Zh_Vn$;->vz$a$:Z

    .line 409
    .line 410
    if-eqz v5, :cond_15

    .line 411
    .line 412
    const-string v5, "android.media.playback.ALWAYS_RESERVE_SPACE_FOR.ACTION_SKIP_TO_NEXT"

    .line 413
    .line 414
    invoke-virtual {v4, v5, v11}, Landroid/os/Bundle;->putBoolean(Ljava/lang/String;Z)V

    .line 415
    .line 416
    .line 417
    :cond_15
    const-string v5, "android.media.playback.ALWAYS_RESERVE_SPACE_FOR.ACTION_SKIP_TO_PREVIOUS"

    .line 418
    .line 419
    invoke-virtual {v4, v5}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 420
    .line 421
    .line 422
    move-result v5

    .line 423
    if-nez v5, :cond_16

    .line 424
    .line 425
    const-string v5, "android.media.playback.ALWAYS_RESERVE_SPACE_FOR.ACTION_SKIP_TO_NEXT"

    .line 426
    .line 427
    invoke-virtual {v4, v5}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    .line 428
    .line 429
    .line 430
    move-result v5

    .line 431
    if-eqz v5, :cond_17

    .line 432
    .line 433
    :cond_16
    iget-object v5, v3, LMl;->vaIue:Ljava/lang/Object;

    .line 434
    .line 435
    check-cast v5, LrcDTìq;

    .line 436
    .line 437
    iget-object v5, v5, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    .line 438
    .line 439
    invoke-virtual {v5, v4}, Landroid/media/session/MediaSession;->setExtras(Landroid/os/Bundle;)V

    .line 440
    .line 441
    .line 442
    :cond_17
    if-eqz v0, :cond_25

    .line 443
    .line 444
    iget-object v0, v1, LAD_x$n2_;->Ialue:Lol01D;

    .line 445
    .line 446
    if-eqz v0, :cond_19

    .line 447
    .line 448
    iget-object v0, v1, LAD_x$n2_;->tmpData3485:Landroid/content/ComponentName;

    .line 449
    .line 450
    if-nez v0, :cond_18

    .line 451
    .line 452
    const/4 v0, 0x0

    .line 453
    goto :goto_c

    .line 454
    :cond_18
    new-instance v4, Landroid/content/Intent;

    .line 455
    .line 456
    invoke-direct {v4}, Landroid/content/Intent;-><init>()V

    .line 457
    .line 458
    .line 459
    invoke-virtual {v4, v0}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 460
    .line 461
    .line 462
    iget-object v0, v1, LAD_x$n2_;->e8$mp_s$:Landroid/content/Context;

    .line 463
    .line 464
    sget v5, LgD1_x$l$_;->e8$mp_s$:I

    .line 465
    .line 466
    const/high16 v6, 0x8000000

    .line 467
    .line 468
    or-int/2addr v5, v6

    .line 469
    const/4 v6, 0x0

    .line 470
    invoke-static {v0, v6, v4, v5}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 471
    .line 472
    .line 473
    move-result-object v0

    .line 474
    :goto_c
    if-eqz v0, :cond_19

    .line 475
    .line 476
    iget-object v3, v3, LMl;->vaIue:Ljava/lang/Object;

    .line 477
    .line 478
    check-cast v3, LrcDTìq;

    .line 479
    .line 480
    iget-object v3, v3, LrcDTìq;->e8$mp_s$:Landroid/media/session/MediaSession;

    .line 481
    .line 482
    invoke-virtual {v3, v0}, Landroid/media/session/MediaSession;->setSessionActivity(Landroid/app/PendingIntent;)V

    .line 483
    .line 484
    .line 485
    :cond_19
    iget-object v0, v1, LAD_x$n2_;->Ialue:Lol01D;

    .line 486
    .line 487
    if-eqz v0, :cond_24

    .line 488
    .line 489
    iget-object v3, v1, LAD_x$n2_;->pCXDYg:LMl;

    .line 490
    .line 491
    if-eqz v3, :cond_24

    .line 492
    .line 493
    if-eqz v2, :cond_24

    .line 494
    .line 495
    iget-object v4, v2, Lcom/google/android/gms/cast/MediaInfo;->iOffset934:LlI1I;

    .line 496
    .line 497
    if-eqz v4, :cond_24

    .line 498
    .line 499
    invoke-virtual {v0}, Lol01D;->yON3x()Z

    .line 500
    .line 501
    .line 502
    move-result v0

    .line 503
    if-eqz v0, :cond_1a

    .line 504
    .line 505
    const-wide/16 v9, 0x0

    .line 506
    .line 507
    goto :goto_d

    .line 508
    :cond_1a
    iget-wide v9, v2, Lcom/google/android/gms/cast/MediaInfo;->kQy:J

    .line 509
    .line 510
    :goto_d
    const-string v0, "com.google.android.gms.cast.metadata.TITLE"

    .line 511
    .line 512
    invoke-virtual {v4, v0}, LlI1I;->rz__9J_(Ljava/lang/String;)Ljava/lang/String;

    .line 513
    .line 514
    .line 515
    move-result-object v0

    .line 516
    const-string v2, "com.google.android.gms.cast.metadata.SUBTITLE"

    .line 517
    .line 518
    invoke-virtual {v4, v2}, LlI1I;->rz__9J_(Ljava/lang/String;)Ljava/lang/String;

    .line 519
    .line 520
    .line 521
    move-result-object v2

    .line 522
    iget-object v5, v1, LAD_x$n2_;->pCXDYg:LMl;

    .line 523
    .line 524
    if-nez v5, :cond_1c

    .line 525
    .line 526
    :cond_1b
    const/4 v7, 0x0

    .line 527
    goto :goto_e

    .line 528
    :cond_1c
    iget-object v5, v5, LMl;->jPos3709:Ljava/lang/Object;

    .line 529
    .line 530
    check-cast v5, LBqOjcA;

    .line 531
    .line 532
    iget-object v5, v5, LBqOjcA;->vaIue:Ljava/lang/Object;

    .line 533
    .line 534
    check-cast v5, Landroid/support/v4/media/session/waiBKÀ;

    .line 535
    .line 536
    iget-object v5, v5, Landroid/support/v4/media/session/waiBKÀ;->e8$mp_s$:Landroid/media/session/MediaController;

    .line 537
    .line 538
    invoke-virtual {v5}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    .line 539
    .line 540
    .line 541
    move-result-object v5

    .line 542
    if-eqz v5, :cond_1b

    .line 543
    .line 544
    sget-object v6, Landroid/support/v4/media/MediaMetadataCompat;->iOffset934:LhasSize1398;

    .line 545
    .line 546
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 547
    .line 548
    .line 549
    move-result-object v6

    .line 550
    const/4 v7, 0x0

    .line 551
    invoke-virtual {v5, v6, v7}, Landroid/media/MediaMetadata;->writeToParcel(Landroid/os/Parcel;I)V

    .line 552
    .line 553
    .line 554
    invoke-virtual {v6, v7}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 555
    .line 556
    .line 557
    sget-object v7, Landroid/support/v4/media/MediaMetadataCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 558
    .line 559
    invoke-interface {v7, v6}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 560
    .line 561
    .line 562
    move-result-object v7

    .line 563
    check-cast v7, Landroid/support/v4/media/MediaMetadataCompat;

    .line 564
    .line 565
    invoke-virtual {v6}, Landroid/os/Parcel;->recycle()V

    .line 566
    .line 567
    .line 568
    iput-object v5, v7, Landroid/support/v4/media/MediaMetadataCompat;->vaIue:Landroid/media/MediaMetadata;

    .line 569
    .line 570
    :goto_e
    if-nez v7, :cond_1d

    .line 571
    .line 572
    new-instance v5, L$1Q0O;

    .line 573
    .line 574
    const/16 v6, 0x8

    .line 575
    .line 576
    invoke-direct {v5, v6}, L$1Q0O;-><init>(I)V

    .line 577
    .line 578
    .line 579
    goto :goto_f

    .line 580
    :cond_1d
    new-instance v5, L$1Q0O;

    .line 581
    .line 582
    invoke-direct {v5, v7}, L$1Q0O;-><init>(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 583
    .line 584
    .line 585
    :goto_f
    const-string v6, "android.media.metadata.DURATION"

    .line 586
    .line 587
    sget-object v7, Landroid/support/v4/media/MediaMetadataCompat;->iOffset934:LhasSize1398;

    .line 588
    .line 589
    invoke-virtual {v7, v6}, LZdxMjO;->containsKey(Ljava/lang/Object;)Z

    .line 590
    .line 591
    .line 592
    move-result v8

    .line 593
    if-eqz v8, :cond_1f

    .line 594
    .line 595
    invoke-virtual {v7, v6}, LZdxMjO;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 596
    .line 597
    .line 598
    move-result-object v7

    .line 599
    check-cast v7, Ljava/lang/Integer;

    .line 600
    .line 601
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 602
    .line 603
    .line 604
    move-result v7

    .line 605
    if-nez v7, :cond_1e

    .line 606
    .line 607
    goto :goto_10

    .line 608
    :cond_1e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 609
    .line 610
    const-string v2, "The android.media.metadata.DURATION key cannot be used to put a long"

    .line 611
    .line 612
    invoke-direct {v0, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 613
    .line 614
    .line 615
    throw v0

    .line 616
    :cond_1f
    :goto_10
    iget-object v7, v5, L$1Q0O;->vaIue:Ljava/lang/Object;

    .line 617
    .line 618
    check-cast v7, Landroid/os/Bundle;

    .line 619
    .line 620
    invoke-virtual {v7, v6, v9, v10}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    .line 621
    .line 622
    .line 623
    if-eqz v0, :cond_20

    .line 624
    .line 625
    const-string v6, "android.media.metadata.TITLE"

    .line 626
    .line 627
    invoke-virtual {v5, v6, v0}, L$1Q0O;->vaIue(Ljava/lang/String;Ljava/lang/String;)V

    .line 628
    .line 629
    .line 630
    const-string v6, "android.media.metadata.DISPLAY_TITLE"

    .line 631
    .line 632
    invoke-virtual {v5, v6, v0}, L$1Q0O;->vaIue(Ljava/lang/String;Ljava/lang/String;)V

    .line 633
    .line 634
    .line 635
    :cond_20
    if-eqz v2, :cond_21

    .line 636
    .line 637
    const-string v0, "android.media.metadata.DISPLAY_SUBTITLE"

    .line 638
    .line 639
    invoke-virtual {v5, v0, v2}, L$1Q0O;->vaIue(Ljava/lang/String;Ljava/lang/String;)V

    .line 640
    .line 641
    .line 642
    :cond_21
    new-instance v0, Landroid/support/v4/media/MediaMetadataCompat;

    .line 643
    .line 644
    iget-object v2, v5, L$1Q0O;->vaIue:Ljava/lang/Object;

    .line 645
    .line 646
    check-cast v2, Landroid/os/Bundle;

    .line 647
    .line 648
    invoke-direct {v0, v2}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Bundle;)V

    .line 649
    .line 650
    .line 651
    invoke-virtual {v3, v0}, LMl;->gKey4112(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 652
    .line 653
    .line 654
    invoke-virtual {v1, v4}, LAD_x$n2_;->JKEoÙX(LlI1I;)Landroid/net/Uri;

    .line 655
    .line 656
    .line 657
    move-result-object v0

    .line 658
    if-eqz v0, :cond_22

    .line 659
    .line 660
    iget-object v2, v1, LAD_x$n2_;->DDù8:LKkmORP;

    .line 661
    .line 662
    invoke-virtual {v2, v0}, LKkmORP;->kCount1402(Landroid/net/Uri;)V

    .line 663
    .line 664
    .line 665
    const/4 v0, 0x0

    .line 666
    goto :goto_11

    .line 667
    :cond_22
    const/4 v0, 0x0

    .line 668
    const/4 v6, 0x0

    .line 669
    invoke-virtual {v1, v0, v6}, LAD_x$n2_;->waiBKÀ(Landroid/graphics/Bitmap;I)V

    .line 670
    .line 671
    .line 672
    :goto_11
    invoke-virtual {v1, v4}, LAD_x$n2_;->JKEoÙX(LlI1I;)Landroid/net/Uri;

    .line 673
    .line 674
    .line 675
    move-result-object v2

    .line 676
    if-eqz v2, :cond_23

    .line 677
    .line 678
    iget-object v0, v1, LAD_x$n2_;->yON3x:LKkmORP;

    .line 679
    .line 680
    invoke-virtual {v0, v2}, LKkmORP;->kCount1402(Landroid/net/Uri;)V

    .line 681
    .line 682
    .line 683
    return-void

    .line 684
    :cond_23
    const/4 v2, 0x3

    .line 685
    invoke-virtual {v1, v0, v2}, LAD_x$n2_;->waiBKÀ(Landroid/graphics/Bitmap;I)V

    .line 686
    .line 687
    .line 688
    :cond_24
    :goto_12
    return-void

    .line 689
    :cond_25
    new-instance v0, Landroid/os/Bundle;

    .line 690
    .line 691
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 692
    .line 693
    .line 694
    new-instance v2, Landroid/support/v4/media/MediaMetadataCompat;

    .line 695
    .line 696
    invoke-direct {v2, v0}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Bundle;)V

    .line 697
    .line 698
    .line 699
    invoke-virtual {v3, v2}, LMl;->gKey4112(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 700
    .line 701
    .line 702
    return-void

    .line 703
    :goto_13
    :try_start_3
    monitor-exit v9
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 704
    throw v0
.end method

.method public final waiBKÀ(Landroid/graphics/Bitmap;I)V
    .locals 5

    .line 1
    iget-object v0, p0, LAD_x$n2_;->pCXDYg:LMl;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v1, 0x0

    .line 7
    const/4 v2, 0x2

    .line 8
    if-eqz p1, :cond_1

    .line 9
    .line 10
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    .line 11
    .line 12
    .line 13
    move-result v3

    .line 14
    const/4 v4, 0x1

    .line 15
    if-le v3, v4, :cond_1

    .line 16
    .line 17
    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    .line 18
    .line 19
    .line 20
    move-result v3

    .line 21
    if-gt v3, v4, :cond_2

    .line 22
    .line 23
    :cond_1
    sget-object p1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    .line 24
    .line 25
    invoke-static {v2, v2, p1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    invoke-virtual {p1, v1}, Landroid/graphics/Bitmap;->eraseColor(I)V

    .line 30
    .line 31
    .line 32
    :cond_2
    iget-object v3, p0, LAD_x$n2_;->pCXDYg:LMl;

    .line 33
    .line 34
    const/4 v4, 0x0

    .line 35
    if-nez v3, :cond_3

    .line 36
    .line 37
    goto :goto_0

    .line 38
    :cond_3
    iget-object v3, v3, LMl;->jPos3709:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v3, LBqOjcA;

    .line 41
    .line 42
    iget-object v3, v3, LBqOjcA;->vaIue:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v3, Landroid/support/v4/media/session/waiBKÀ;

    .line 45
    .line 46
    iget-object v3, v3, Landroid/support/v4/media/session/waiBKÀ;->e8$mp_s$:Landroid/media/session/MediaController;

    .line 47
    .line 48
    invoke-virtual {v3}, Landroid/media/session/MediaController;->getMetadata()Landroid/media/MediaMetadata;

    .line 49
    .line 50
    .line 51
    move-result-object v3

    .line 52
    if-eqz v3, :cond_4

    .line 53
    .line 54
    sget-object v4, Landroid/support/v4/media/MediaMetadataCompat;->iOffset934:LhasSize1398;

    .line 55
    .line 56
    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    invoke-virtual {v3, v4, v1}, Landroid/media/MediaMetadata;->writeToParcel(Landroid/os/Parcel;I)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v4, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    .line 64
    .line 65
    .line 66
    sget-object v1, Landroid/support/v4/media/MediaMetadataCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    .line 67
    .line 68
    invoke-interface {v1, v4}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v1

    .line 72
    check-cast v1, Landroid/support/v4/media/MediaMetadataCompat;

    .line 73
    .line 74
    invoke-virtual {v4}, Landroid/os/Parcel;->recycle()V

    .line 75
    .line 76
    .line 77
    iput-object v3, v1, Landroid/support/v4/media/MediaMetadataCompat;->vaIue:Landroid/media/MediaMetadata;

    .line 78
    .line 79
    move-object v4, v1

    .line 80
    :cond_4
    :goto_0
    if-nez v4, :cond_5

    .line 81
    .line 82
    new-instance v1, L$1Q0O;

    .line 83
    .line 84
    const/16 v3, 0x8

    .line 85
    .line 86
    invoke-direct {v1, v3}, L$1Q0O;-><init>(I)V

    .line 87
    .line 88
    .line 89
    goto :goto_1

    .line 90
    :cond_5
    new-instance v1, L$1Q0O;

    .line 91
    .line 92
    invoke-direct {v1, v4}, L$1Q0O;-><init>(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 93
    .line 94
    .line 95
    :goto_1
    iget-object v1, v1, L$1Q0O;->vaIue:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast v1, Landroid/os/Bundle;

    .line 98
    .line 99
    if-nez p2, :cond_6

    .line 100
    .line 101
    const-string p2, "android.media.metadata.DISPLAY_ICON"

    .line 102
    .line 103
    goto :goto_2

    .line 104
    :cond_6
    const-string p2, "android.media.metadata.ALBUM_ART"

    .line 105
    .line 106
    :goto_2
    sget-object v3, Landroid/support/v4/media/MediaMetadataCompat;->iOffset934:LhasSize1398;

    .line 107
    .line 108
    invoke-virtual {v3, p2}, LZdxMjO;->containsKey(Ljava/lang/Object;)Z

    .line 109
    .line 110
    .line 111
    move-result v4

    .line 112
    if-eqz v4, :cond_8

    .line 113
    .line 114
    invoke-virtual {v3, p2}, LZdxMjO;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    check-cast v3, Ljava/lang/Integer;

    .line 119
    .line 120
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    if-ne v3, v2, :cond_7

    .line 125
    .line 126
    goto :goto_3

    .line 127
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 128
    .line 129
    const-string v0, "The "

    .line 130
    .line 131
    const-string v1, " key cannot be used to put a Bitmap"

    .line 132
    .line 133
    invoke-static {v0, p2, v1}, LRQU_K6$Kv_;->kQy(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object p2

    .line 137
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    throw p1

    .line 141
    :cond_8
    :goto_3
    invoke-virtual {v1, p2, p1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    .line 142
    .line 143
    .line 144
    new-instance p1, Landroid/support/v4/media/MediaMetadataCompat;

    .line 145
    .line 146
    invoke-direct {p1, v1}, Landroid/support/v4/media/MediaMetadataCompat;-><init>(Landroid/os/Bundle;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {v0, p1}, LMl;->gKey4112(Landroid/support/v4/media/MediaMetadataCompat;)V

    .line 150
    .line 151
    .line 152
    return-void
.end method

.method public final yON3x()V
    .locals 3

    .line 1
    iget-object v0, p0, LAD_x$n2_;->waiBKÀ:LGtVP;

    .line 2
    .line 3
    iget-boolean v0, v0, LGtVP;->valuI:Z

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    return-void

    .line 8
    :cond_0
    iget-object v0, p0, LAD_x$n2_;->jPos3709:LlI111l;

    .line 9
    .line 10
    iget-object v1, p0, LAD_x$n2_;->iOffset934:LqàÙ;

    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Landroid/content/Intent;

    .line 16
    .line 17
    iget-object v1, p0, LAD_x$n2_;->e8$mp_s$:Landroid/content/Context;

    .line 18
    .line 19
    const-class v2, Lcom/google/android/gms/cast/framework/ReconnectionService;

    .line 20
    .line 21
    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object v2

    .line 28
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    .line 29
    .line 30
    .line 31
    invoke-virtual {v1, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z

    .line 32
    .line 33
    .line 34
    return-void
.end method
