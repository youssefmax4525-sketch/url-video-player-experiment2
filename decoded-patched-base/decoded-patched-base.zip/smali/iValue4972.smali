.class public interface abstract LiValue4972;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract POOl()Landroid/net/Uri;
.end method

.method public abstract getDescription()Landroid/content/ClipDescription;
.end method

.method public abstract rz__9J_()V
.end method

.method public abstract tmpData3485()Ljava/lang/Object;
.end method

.method public abstract waiBKÀ()Landroid/net/Uri;
.end method
