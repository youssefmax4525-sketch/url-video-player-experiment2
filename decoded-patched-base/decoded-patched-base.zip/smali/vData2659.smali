.class public final LvData2659;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final POOl:LvData2659;


# instance fields
.field public final e8$mp_s$:Ljava/lang/Runnable;

.field public rz__9J_:LvData2659;

.field public final waiBKÀ:Ljava/util/concurrent/Executor;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, LvData2659;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1, v1}, LvData2659;-><init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 5
    .line 6
    .line 7
    sput-object v0, LvData2659;->POOl:LvData2659;

    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LvData2659;->e8$mp_s$:Ljava/lang/Runnable;

    .line 5
    .line 6
    iput-object p2, p0, LvData2659;->waiBKÀ:Ljava/util/concurrent/Executor;

    .line 7
    .line 8
    return-void
.end method
