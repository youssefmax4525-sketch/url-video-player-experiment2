.class public final synthetic LKYu_ua$nl_;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH2h_go_;


# instance fields
.field public final synthetic vaIue:Landroidx/activity/e8$mp_s$;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(Landroidx/activity/e8$mp_s$;I)V
    .locals 0

    .line 1
    iput p2, p0, LKYu_ua$nl_;->yON3x:I

    iput-object p1, p0, LKYu_ua$nl_;->vaIue:Landroidx/activity/e8$mp_s$;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e8$mp_s$()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LKYu_ua$nl_;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LKYu_ua$nl_;->vaIue:Landroidx/activity/e8$mp_s$;

    .line 7
    .line 8
    invoke-virtual {v0}, Landroidx/activity/e8$mp_s$;->rz__9J_()V

    .line 9
    .line 10
    .line 11
    :goto_0
    sget-object v0, LplQQD0;->valuI:LplQQD0;

    .line 12
    .line 13
    return-object v0

    .line 14
    :pswitch_0
    iget-object v0, p0, LKYu_ua$nl_;->vaIue:Landroidx/activity/e8$mp_s$;

    .line 15
    .line 16
    invoke-virtual {v0}, Landroidx/activity/e8$mp_s$;->waiBKÀ()V

    .line 17
    .line 18
    .line 19
    goto :goto_0

    .line 20
    :pswitch_1
    iget-object v0, p0, LKYu_ua$nl_;->vaIue:Landroidx/activity/e8$mp_s$;

    .line 21
    .line 22
    invoke-virtual {v0}, Landroidx/activity/e8$mp_s$;->rz__9J_()V

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    nop

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
