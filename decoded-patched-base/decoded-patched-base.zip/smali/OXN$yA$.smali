.class public final LOXN$yA$;
.super LoaX_6_;


# virtual methods
.method public final DDù8(LvKey4670;Ljava/lang/String;Lorg/xml/sax/Attributes;)V
    .locals 2

    .line 1
    iget-object v0, p1, LvKey4670;->iOffset934:Ljava/util/Stack;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    iget-object v0, p1, LvKey4670;->iOffset934:Ljava/util/Stack;

    .line 10
    .line 11
    invoke-virtual {v0}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    instance-of v1, v0, LOize;

    .line 16
    .line 17
    if-eqz v1, :cond_0

    .line 18
    .line 19
    check-cast v0, LOize;

    .line 20
    .line 21
    iget-object v0, v0, LOize;->e8$mp_s$:Ljava/net/URL;

    .line 22
    .line 23
    if-eqz v0, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    const/4 v0, 0x0

    .line 27
    :goto_0
    if-eqz v0, :cond_1

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1
    invoke-super {p0, p1, p2, p3}, LoaX_6_;->DDù8(LvKey4670;Ljava/lang/String;Lorg/xml/sax/Attributes;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public final kQy(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 3

    .line 1
    if-eqz p2, :cond_0

    .line 2
    .line 3
    instance-of v0, p2, Ljava/io/FileNotFoundException;

    .line 4
    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    instance-of v0, p2, Ljava/net/UnknownHostException;

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    new-instance v0, LNxccOS;

    .line 12
    .line 13
    iget-object v1, p0, LIQ;->jPos3709:LIQ;

    .line 14
    .line 15
    const/4 v2, 0x1

    .line 16
    invoke-direct {v0, v2, p1, v1, p2}, LNxccOS;-><init>(ILjava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0, v0}, LIQ;->tmpData3485(LNxccOS;)V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :cond_0
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final valuI(LvKey4670;Ljava/net/URL;)V
    .locals 1

    .line 1
    new-instance v0, LOize;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p2, v0, LOize;->e8$mp_s$:Ljava/net/URL;

    .line 7
    .line 8
    invoke-virtual {p1, v0}, LvKey4670;->vaIue(Ljava/lang/Object;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method
