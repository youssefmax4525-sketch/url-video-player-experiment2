.class public final L$H_R$n_;
.super LzSZ$nU_w$;
.source "SourceFile"


# instance fields
.field public final synthetic e8$mp_s$:I

.field public final synthetic rz__9J_:Ljava/lang/Object;

.field public final synthetic waiBKÀ:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/String;)V
    .locals 0

    .line 1
    iput p1, p0, L$H_R$n_;->e8$mp_s$:I

    iput-object p3, p0, L$H_R$n_;->waiBKÀ:Ljava/lang/String;

    iput-object p2, p0, L$H_R$n_;->rz__9J_:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e8$mp_s$(Ljava/lang/String;)V
    .locals 8

    .line 1
    iget v0, p0, L$H_R$n_;->e8$mp_s$:I

    .line 2
    .line 3
    iget-object v1, p0, L$H_R$n_;->waiBKÀ:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v2, p0, L$H_R$n_;->rz__9J_:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v2, LIl11;

    .line 11
    .line 12
    const-string v0, "Failed to generate query info for the tagging library, error: "

    .line 13
    .line 14
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    sget-object v0, LDg_Sz_;->e8$mp_s$:LvSize4545;

    .line 26
    .line 27
    invoke-virtual {v0}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    check-cast v0, Ljava/lang/Boolean;

    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_0

    .line 38
    .line 39
    iget-object v0, v2, LIl11;->jPos3709:Ll1ii1i;

    .line 40
    .line 41
    invoke-virtual {v0}, Ll1ii1i;->e8$mp_s$()Lorg/json/JSONObject;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    const-string v3, ",\"as\":"

    .line 50
    .line 51
    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    goto :goto_0

    .line 56
    :cond_0
    const-string v0, ""

    .line 57
    .line 58
    :goto_0
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 59
    .line 60
    .line 61
    move-result-object v3

    .line 62
    sget-object v4, LDg_Sz_;->rz__9J_:LvSize4545;

    .line 63
    .line 64
    invoke-virtual {v4}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v5

    .line 68
    check-cast v5, Ljava/lang/Boolean;

    .line 69
    .line 70
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    if-eqz v5, :cond_1

    .line 75
    .line 76
    sget-object v5, LDg_Sz_;->tmpData3485:LvSize4545;

    .line 77
    .line 78
    invoke-virtual {v5}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v5

    .line 82
    check-cast v5, Ljava/lang/Long;

    .line 83
    .line 84
    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    .line 85
    .line 86
    .line 87
    move-result-wide v5

    .line 88
    goto :goto_1

    .line 89
    :cond_1
    const-wide/16 v5, 0x0

    .line 90
    .line 91
    :goto_1
    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 92
    .line 93
    .line 94
    move-result-object v5

    .line 95
    const/4 v6, 0x4

    .line 96
    new-array v6, v6, [Ljava/lang/Object;

    .line 97
    .line 98
    const/4 v7, 0x0

    .line 99
    aput-object v1, v6, v7

    .line 100
    .line 101
    const/4 v1, 0x1

    .line 102
    aput-object p1, v6, v1

    .line 103
    .line 104
    const/4 p1, 0x2

    .line 105
    aput-object v5, v6, p1

    .line 106
    .line 107
    const/4 p1, 0x3

    .line 108
    aput-object v0, v6, p1

    .line 109
    .line 110
    const-string p1, "window.postMessage({\"paw_id\":\"%1$s\",\"error\":\"%2$s\",\"sdk_ttl_ms\":%3$d%4$s}, \'*\');"

    .line 111
    .line 112
    invoke-static {v3, p1, v6}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-virtual {v4}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 117
    .line 118
    .line 119
    move-result-object v0

    .line 120
    check-cast v0, Ljava/lang/Boolean;

    .line 121
    .line 122
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-eqz v0, :cond_2

    .line 127
    .line 128
    :try_start_0
    iget-object v0, v2, LIl11;->DDù8:LgID0;

    .line 129
    .line 130
    new-instance v1, LynztM;

    .line 131
    .line 132
    const/16 v3, 0x13

    .line 133
    .line 134
    invoke-direct {v1, v3, p0, p1}, LynztM;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v0, v1}, LgID0;->execute(Ljava/lang/Runnable;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 138
    .line 139
    .line 140
    goto :goto_2

    .line 141
    :catch_0
    move-exception p1

    .line 142
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 143
    .line 144
    iget-object v0, v0, LvItem598;->sKey7917:LNl;

    .line 145
    .line 146
    const-string v1, "TaggingLibraryJsInterface.getQueryInfo.onFailure"

    .line 147
    .line 148
    invoke-virtual {v0, v1, p1}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 149
    .line 150
    .line 151
    goto :goto_2

    .line 152
    :cond_2
    iget-object v0, v2, LIl11;->waiBKÀ:Landroid/webkit/WebView;

    .line 153
    .line 154
    const/4 v1, 0x0

    .line 155
    invoke-virtual {v0, p1, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 156
    .line 157
    .line 158
    :goto_2
    sget-object p1, LDg_Sz_;->e8$mp_s$:LvSize4545;

    .line 159
    .line 160
    invoke-virtual {p1}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    check-cast p1, Ljava/lang/Boolean;

    .line 165
    .line 166
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 167
    .line 168
    .line 169
    move-result p1

    .line 170
    if-eqz p1, :cond_3

    .line 171
    .line 172
    sget-object p1, LDg_Sz_;->waiBKÀ:LvSize4545;

    .line 173
    .line 174
    invoke-virtual {p1}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 175
    .line 176
    .line 177
    move-result-object p1

    .line 178
    check-cast p1, Ljava/lang/Boolean;

    .line 179
    .line 180
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 181
    .line 182
    .line 183
    move-result p1

    .line 184
    if-eqz p1, :cond_3

    .line 185
    .line 186
    iget-object p1, v2, LIl11;->iOffset934:LpJTx9;

    .line 187
    .line 188
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 189
    .line 190
    .line 191
    new-instance v0, LE4o$d_0D$;

    .line 192
    .line 193
    invoke-direct {v0, p1, v7}, LE4o$d_0D$;-><init>(LpJTx9;I)V

    .line 194
    .line 195
    .line 196
    iget-object p1, p1, LpJTx9;->rz__9J_:LgOffset972;

    .line 197
    .line 198
    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 199
    .line 200
    .line 201
    :cond_3
    return-void

    .line 202
    :pswitch_0
    const-string v0, "Failed to generate query info for Custom Tab error: "

    .line 203
    .line 204
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 205
    .line 206
    .line 207
    move-result-object v3

    .line 208
    invoke-virtual {v0, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    invoke-static {v0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 213
    .line 214
    .line 215
    :try_start_1
    check-cast v2, L_nl$lW$;

    .line 216
    .line 217
    iget-object v0, v2, L_nl$lW$;->sKey7917:LIl11l;

    .line 218
    .line 219
    invoke-virtual {v2, v1, p1}, L_nl$lW$;->e8$mp_s$(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 220
    .line 221
    .line 222
    move-result-object p1

    .line 223
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 224
    .line 225
    .line 226
    move-result-object p1

    .line 227
    invoke-virtual {v0, p1}, LIl11l;->iOffset934(Ljava/lang/String;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1

    .line 228
    .line 229
    .line 230
    :catch_1
    return-void

    .line 231
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final waiBKÀ(LCÌaxKk;)V
    .locals 11

    .line 1
    iget v0, p0, L$H_R$n_;->e8$mp_s$:I

    .line 2
    .line 3
    iget-object v1, p0, L$H_R$n_;->rz__9J_:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, L$H_R$n_;->waiBKÀ:Ljava/lang/String;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    check-cast v1, LIl11;

    .line 11
    .line 12
    iget-object v0, v1, LIl11;->jPos3709:Ll1ii1i;

    .line 13
    .line 14
    iget-object v3, p1, LCÌaxKk;->vaIue:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v3, LwYm_BE$mL_;

    .line 17
    .line 18
    iget-object v3, v3, LwYm_BE$mL_;->vaIue:Ljava/lang/String;

    .line 19
    .line 20
    const/4 v4, 0x1

    .line 21
    const/4 v5, 0x0

    .line 22
    const-wide/16 v6, 0x0

    .line 23
    .line 24
    :try_start_0
    new-instance v8, Lorg/json/JSONObject;

    .line 25
    .line 26
    invoke-direct {v8}, Lorg/json/JSONObject;-><init>()V

    .line 27
    .line 28
    .line 29
    const-string v9, "paw_id"

    .line 30
    .line 31
    invoke-virtual {v8, v9, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 32
    .line 33
    .line 34
    const-string v9, "signal"

    .line 35
    .line 36
    invoke-virtual {v8, v9, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 37
    .line 38
    .line 39
    const-string v3, "sdk_ttl_ms"

    .line 40
    .line 41
    sget-object v9, LDg_Sz_;->rz__9J_:LvSize4545;

    .line 42
    .line 43
    invoke-virtual {v9}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v9

    .line 47
    check-cast v9, Ljava/lang/Boolean;

    .line 48
    .line 49
    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    .line 50
    .line 51
    .line 52
    move-result v9

    .line 53
    if-eqz v9, :cond_0

    .line 54
    .line 55
    sget-object v9, LDg_Sz_;->tmpData3485:LvSize4545;

    .line 56
    .line 57
    invoke-virtual {v9}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    check-cast v9, Ljava/lang/Long;

    .line 62
    .line 63
    invoke-virtual {v9}, Ljava/lang/Long;->longValue()J

    .line 64
    .line 65
    .line 66
    move-result-wide v9

    .line 67
    goto :goto_0

    .line 68
    :catch_0
    nop

    .line 69
    goto :goto_1

    .line 70
    :cond_0
    move-wide v9, v6

    .line 71
    :goto_0
    invoke-virtual {v8, v3, v9, v10}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    .line 72
    .line 73
    .line 74
    sget-object v3, LDg_Sz_;->e8$mp_s$:LvSize4545;

    .line 75
    .line 76
    invoke-virtual {v3}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    check-cast v3, Ljava/lang/Boolean;

    .line 81
    .line 82
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    if-eqz v3, :cond_1

    .line 87
    .line 88
    const-string v3, "as"

    .line 89
    .line 90
    invoke-virtual {v0}, Ll1ii1i;->e8$mp_s$()Lorg/json/JSONObject;

    .line 91
    .line 92
    .line 93
    move-result-object v9

    .line 94
    invoke-virtual {v8, v3, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 95
    .line 96
    .line 97
    :cond_1
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    const-string v9, "window.postMessage(%1$s, \'*\');"

    .line 102
    .line 103
    new-array v10, v4, [Ljava/lang/Object;

    .line 104
    .line 105
    aput-object v8, v10, v5

    .line 106
    .line 107
    invoke-static {v3, v9, v10}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 108
    .line 109
    .line 110
    move-result-object p1
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    .line 111
    goto :goto_3

    .line 112
    :goto_1
    sget-object v3, LDg_Sz_;->e8$mp_s$:LvSize4545;

    .line 113
    .line 114
    invoke-virtual {v3}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object v3

    .line 118
    check-cast v3, Ljava/lang/Boolean;

    .line 119
    .line 120
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    if-eqz v3, :cond_2

    .line 125
    .line 126
    invoke-virtual {v0}, Ll1ii1i;->e8$mp_s$()Lorg/json/JSONObject;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v0

    .line 134
    const-string v3, ",\"as\":"

    .line 135
    .line 136
    invoke-virtual {v3, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    goto :goto_2

    .line 141
    :cond_2
    const-string v0, ""

    .line 142
    .line 143
    :goto_2
    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    iget-object p1, p1, LCÌaxKk;->vaIue:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast p1, LwYm_BE$mL_;

    .line 150
    .line 151
    iget-object p1, p1, LwYm_BE$mL_;->vaIue:Ljava/lang/String;

    .line 152
    .line 153
    sget-object v8, LDg_Sz_;->rz__9J_:LvSize4545;

    .line 154
    .line 155
    invoke-virtual {v8}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v8

    .line 159
    check-cast v8, Ljava/lang/Boolean;

    .line 160
    .line 161
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 162
    .line 163
    .line 164
    move-result v8

    .line 165
    if-eqz v8, :cond_3

    .line 166
    .line 167
    sget-object v6, LDg_Sz_;->tmpData3485:LvSize4545;

    .line 168
    .line 169
    invoke-virtual {v6}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v6

    .line 173
    check-cast v6, Ljava/lang/Long;

    .line 174
    .line 175
    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    .line 176
    .line 177
    .line 178
    move-result-wide v6

    .line 179
    :cond_3
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 180
    .line 181
    .line 182
    move-result-object v6

    .line 183
    const/4 v7, 0x4

    .line 184
    new-array v7, v7, [Ljava/lang/Object;

    .line 185
    .line 186
    aput-object v2, v7, v5

    .line 187
    .line 188
    aput-object p1, v7, v4

    .line 189
    .line 190
    const/4 p1, 0x2

    .line 191
    aput-object v6, v7, p1

    .line 192
    .line 193
    const/4 p1, 0x3

    .line 194
    aput-object v0, v7, p1

    .line 195
    .line 196
    const-string p1, "window.postMessage({\"paw_id\":\"%1$s\",\"signal\":\"%2$s\",\"sdk_ttl_ms\":%3$d%4$s}, \'*\');"

    .line 197
    .line 198
    invoke-static {v3, p1, v7}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 199
    .line 200
    .line 201
    move-result-object p1

    .line 202
    :goto_3
    sget-object v0, LDg_Sz_;->rz__9J_:LvSize4545;

    .line 203
    .line 204
    invoke-virtual {v0}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    check-cast v0, Ljava/lang/Boolean;

    .line 209
    .line 210
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 211
    .line 212
    .line 213
    move-result v0

    .line 214
    if-eqz v0, :cond_4

    .line 215
    .line 216
    :try_start_1
    iget-object v0, v1, LIl11;->DDù8:LgID0;

    .line 217
    .line 218
    new-instance v2, LJIF_wM$kP_;

    .line 219
    .line 220
    const/16 v3, 0x17

    .line 221
    .line 222
    invoke-direct {v2, v3, p0, p1}, LJIF_wM$kP_;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 223
    .line 224
    .line 225
    invoke-virtual {v0, v2}, LgID0;->execute(Ljava/lang/Runnable;)V
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    .line 226
    .line 227
    .line 228
    goto :goto_4

    .line 229
    :catch_1
    move-exception p1

    .line 230
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 231
    .line 232
    iget-object v0, v0, LvItem598;->sKey7917:LNl;

    .line 233
    .line 234
    const-string v2, "TaggingLibraryJsInterface.getQueryInfo.onSuccess"

    .line 235
    .line 236
    invoke-virtual {v0, v2, p1}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 237
    .line 238
    .line 239
    goto :goto_4

    .line 240
    :cond_4
    iget-object v0, v1, LIl11;->waiBKÀ:Landroid/webkit/WebView;

    .line 241
    .line 242
    const/4 v2, 0x0

    .line 243
    invoke-virtual {v0, p1, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    .line 244
    .line 245
    .line 246
    :goto_4
    sget-object p1, LDg_Sz_;->e8$mp_s$:LvSize4545;

    .line 247
    .line 248
    invoke-virtual {p1}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 249
    .line 250
    .line 251
    move-result-object p1

    .line 252
    check-cast p1, Ljava/lang/Boolean;

    .line 253
    .line 254
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 255
    .line 256
    .line 257
    move-result p1

    .line 258
    if-eqz p1, :cond_5

    .line 259
    .line 260
    sget-object p1, LDg_Sz_;->waiBKÀ:LvSize4545;

    .line 261
    .line 262
    invoke-virtual {p1}, LvSize4545;->$ÒcdS()Ljava/lang/Object;

    .line 263
    .line 264
    .line 265
    move-result-object p1

    .line 266
    check-cast p1, Ljava/lang/Boolean;

    .line 267
    .line 268
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 269
    .line 270
    .line 271
    move-result p1

    .line 272
    if-eqz p1, :cond_5

    .line 273
    .line 274
    iget-object p1, v1, LIl11;->iOffset934:LpJTx9;

    .line 275
    .line 276
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 277
    .line 278
    .line 279
    new-instance v0, LE4o$d_0D$;

    .line 280
    .line 281
    invoke-direct {v0, p1, v5}, LE4o$d_0D$;-><init>(LpJTx9;I)V

    .line 282
    .line 283
    .line 284
    iget-object p1, p1, LpJTx9;->rz__9J_:LgOffset972;

    .line 285
    .line 286
    invoke-interface {p1, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 287
    .line 288
    .line 289
    :cond_5
    return-void

    .line 290
    :pswitch_0
    iget-object p1, p1, LCÌaxKk;->vaIue:Ljava/lang/Object;

    .line 291
    .line 292
    check-cast p1, LwYm_BE$mL_;

    .line 293
    .line 294
    iget-object p1, p1, LwYm_BE$mL_;->vaIue:Ljava/lang/String;

    .line 295
    .line 296
    :try_start_2
    check-cast v1, L_nl$lW$;

    .line 297
    .line 298
    iget-object v0, v1, L_nl$lW$;->sKey7917:LIl11l;

    .line 299
    .line 300
    invoke-virtual {v1, v2, p1}, L_nl$lW$;->waiBKÀ(Ljava/lang/String;Ljava/lang/String;)Lorg/json/JSONObject;

    .line 301
    .line 302
    .line 303
    move-result-object p1

    .line 304
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    .line 305
    .line 306
    .line 307
    move-result-object p1

    .line 308
    invoke-virtual {v0, p1}, LIl11l;->iOffset934(Ljava/lang/String;)V
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_2

    .line 309
    .line 310
    .line 311
    :catch_2
    return-void

    .line 312
    nop

    .line 313
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
