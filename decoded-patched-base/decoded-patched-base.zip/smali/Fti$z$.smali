.class public final LFti$z$;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LlACD;

.field public final waiBKÀ:LliiI1li;


# direct methods
.method public constructor <init>(LlACD;LliiI1li;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LFti$z$;->e8$mp_s$:LlACD;

    .line 5
    .line 6
    iput-object p2, p0, LFti$z$;->waiBKÀ:LliiI1li;

    .line 7
    .line 8
    return-void
.end method
