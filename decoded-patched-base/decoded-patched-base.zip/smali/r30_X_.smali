.class public final Lr30_X_;
.super LoF_B_;
.source "SourceFile"

# interfaces
.implements LiIndex6955;
.implements LI1illI;


# instance fields
.field public final yON3x:LpQs;


# direct methods
.method public constructor <init>(Lcom/google/ads/mediation/AbstractAdViewAdapter;LpQs;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lr30_X_;->yON3x:LpQs;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final DDù8()V
    .locals 2

    .line 1
    iget-object v0, p0, Lr30_X_;->yON3x:LpQs;

    .line 2
    .line 3
    check-cast v0, LlACD;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v1, "#008 Must be called on the main UI thread."

    .line 9
    .line 10
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "Adapter called onAdLoaded."

    .line 14
    .line 15
    invoke-static {v1}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, L_6_r7$K_;

    .line 21
    .line 22
    invoke-interface {v0}, L_6_r7$K_;->Ialue()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :catch_0
    move-exception v0

    .line 27
    const-string v1, "#007 Could not call remote method."

    .line 28
    .line 29
    invoke-static {v1, v0}, LPJNypàa;->cEi_G$x5_(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final e8$mp_s$()V
    .locals 2

    .line 1
    iget-object v0, p0, Lr30_X_;->yON3x:LpQs;

    .line 2
    .line 3
    check-cast v0, LlACD;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v1, "#008 Must be called on the main UI thread."

    .line 9
    .line 10
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "Adapter called onAdClosed."

    .line 14
    .line 15
    invoke-static {v1}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, L_6_r7$K_;

    .line 21
    .line 22
    invoke-interface {v0}, L_6_r7$K_;->waiBKÀ()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :catch_0
    move-exception v0

    .line 27
    const-string v1, "#007 Could not call remote method."

    .line 28
    .line 29
    invoke-static {v1, v0}, LPJNypàa;->cEi_G$x5_(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final onAdClicked()V
    .locals 2

    .line 1
    iget-object v0, p0, Lr30_X_;->yON3x:LpQs;

    .line 2
    .line 3
    check-cast v0, LlACD;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v1, "#008 Must be called on the main UI thread."

    .line 9
    .line 10
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "Adapter called onAdClicked."

    .line 14
    .line 15
    invoke-static {v1}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, L_6_r7$K_;

    .line 21
    .line 22
    invoke-interface {v0}, L_6_r7$K_;->rz__9J_()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :catch_0
    move-exception v0

    .line 27
    const-string v1, "#007 Could not call remote method."

    .line 28
    .line 29
    invoke-static {v1, v0}, LPJNypàa;->cEi_G$x5_(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final pCXDYg(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    .line 1
    iget-object v0, p0, Lr30_X_;->yON3x:LpQs;

    .line 2
    .line 3
    check-cast v0, LlACD;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v1, "#008 Must be called on the main UI thread."

    .line 9
    .line 10
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "Adapter called onAppEvent."

    .line 14
    .line 15
    invoke-static {v1}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, L_6_r7$K_;

    .line 21
    .line 22
    invoke-interface {v0, p1, p2}, L_6_r7$K_;->I11I1(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :catch_0
    move-exception p1

    .line 27
    const-string p2, "#007 Could not call remote method."

    .line 28
    .line 29
    invoke-static {p2, p1}, LPJNypàa;->cEi_G$x5_(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final rz__9J_(LD6$Ff_rK$;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lr30_X_;->yON3x:LpQs;

    .line 2
    .line 3
    check-cast v0, LlACD;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, LlACD;->iOffset934(LgOffset3699;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final vaIue()V
    .locals 2

    .line 1
    iget-object v0, p0, Lr30_X_;->yON3x:LpQs;

    .line 2
    .line 3
    check-cast v0, LlACD;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const-string v1, "#008 Must be called on the main UI thread."

    .line 9
    .line 10
    invoke-static {v1}, Lzl1;->yON3x(Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    const-string v1, "Adapter called onAdOpened."

    .line 14
    .line 15
    invoke-static {v1}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    :try_start_0
    iget-object v0, v0, LlACD;->vaIue:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v0, L_6_r7$K_;

    .line 21
    .line 22
    invoke-interface {v0}, L_6_r7$K_;->gKey4112()V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :catch_0
    move-exception v0

    .line 27
    const-string v1, "#007 Could not call remote method."

    .line 28
    .line 29
    invoke-static {v1, v0}, LPJNypàa;->cEi_G$x5_(Ljava/lang/String;Ljava/lang/Exception;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method
