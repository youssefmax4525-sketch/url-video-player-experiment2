.class public final LvValue7808;
.super LHDl0DI;
.source "SourceFile"


# instance fields
.field public Ialue:Z

.field public final iOffset934:LYizKm;

.field public final jPos3709:LYizKm;

.field public kQy:I

.field public pCXDYg:I

.field public valuI:Z


# direct methods
.method public constructor <init>(LwÒJK;)V
    .locals 1

    .line 1
    invoke-direct {p0, p1}, LHDl0DI;-><init>(LwÒJK;)V

    .line 2
    .line 3
    .line 4
    new-instance p1, LYizKm;

    .line 5
    .line 6
    sget-object v0, LdlDIQ;->K0I:[B

    .line 7
    .line 8
    invoke-direct {p1, v0}, LYizKm;-><init>([B)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, LvValue7808;->jPos3709:LYizKm;

    .line 12
    .line 13
    new-instance p1, LYizKm;

    .line 14
    .line 15
    const/4 v0, 0x4

    .line 16
    invoke-direct {p1, v0}, LYizKm;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object p1, p0, LvValue7808;->iOffset934:LYizKm;

    .line 20
    .line 21
    return-void
.end method
