.class public final LmID1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LXXìMLÙe;


# instance fields
.field public final synthetic e8$mp_s$:I

.field public final waiBKÀ:LIlIi1;


# direct methods
.method public synthetic constructor <init>(LIlIi1;I)V
    .locals 0

    .line 1
    iput p2, p0, LmID1;->e8$mp_s$:I

    iput-object p1, p0, LmID1;->waiBKÀ:LIlIi1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final POOl()Ljava/lang/Object;
    .locals 3

    .line 1
    iget v0, p0, LmID1;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LmID1;->waiBKÀ:LIlIi1;

    .line 7
    .line 8
    iget-object v0, v0, LIlIi1;->e8$mp_s$:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LOAW$rA__9$;

    .line 11
    .line 12
    new-instance v1, Loo$LU_B$;

    .line 13
    .line 14
    const/4 v2, 0x3

    .line 15
    invoke-direct {v1, v2, v0}, Loo$LU_B$;-><init>(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-object v1

    .line 19
    :pswitch_0
    iget-object v0, p0, LmID1;->waiBKÀ:LIlIi1;

    .line 20
    .line 21
    iget-object v0, v0, LIlIi1;->e8$mp_s$:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, LWDDl;

    .line 24
    .line 25
    new-instance v1, LxMZ7olY;

    .line 26
    .line 27
    const/16 v2, 0x1d

    .line 28
    .line 29
    invoke-direct {v1, v2, v0}, LxMZ7olY;-><init>(ILjava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    return-object v1

    .line 33
    :pswitch_1
    iget-object v0, p0, LmID1;->waiBKÀ:LIlIi1;

    .line 34
    .line 35
    iget-object v0, v0, LIlIi1;->e8$mp_s$:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v0, LvIndex9888;

    .line 38
    .line 39
    new-instance v1, Lah_1k$4v_;

    .line 40
    .line 41
    const/4 v2, 0x1

    .line 42
    invoke-direct {v1, v2, v0}, Lah_1k$4v_;-><init>(ILjava/lang/Object;)V

    .line 43
    .line 44
    .line 45
    return-object v1

    .line 46
    nop

    .line 47
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
