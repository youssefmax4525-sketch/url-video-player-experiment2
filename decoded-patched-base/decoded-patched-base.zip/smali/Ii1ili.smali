.class public abstract LIi1ili;
.super Ljava/lang/Object;
.source "SourceFile"
