.class public interface abstract LULèE;
.super Ljava/lang/Object;
.source "SourceFile"
