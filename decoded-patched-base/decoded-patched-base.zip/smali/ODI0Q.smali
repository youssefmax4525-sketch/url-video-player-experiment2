.class public final synthetic LODI0Q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic vaIue:Linfo/t4w/vp/view/MainActivity;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(Linfo/t4w/vp/view/MainActivity;I)V
    .locals 0

    .line 1
    iput p2, p0, LODI0Q;->yON3x:I

    iput-object p1, p0, LODI0Q;->vaIue:Linfo/t4w/vp/view/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 4

    .line 1
    iget p1, p0, LODI0Q;->yON3x:I

    .line 2
    .line 3
    const/4 v0, 0x2

    .line 4
    iget-object v1, p0, LODI0Q;->vaIue:Linfo/t4w/vp/view/MainActivity;

    .line 5
    .line 6
    packed-switch p1, :pswitch_data_0

    .line 7
    .line 8
    .line 9
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 10
    .line 11
    iget-object p1, v1, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 12
    .line 13
    if-nez p1, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    iget p1, v1, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 17
    .line 18
    new-instance v2, LVèM;

    .line 19
    .line 20
    invoke-direct {v2, v1, v0}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 21
    .line 22
    .line 23
    invoke-static {v1, p1, v2}, LIlIIll;->pCXDYg(LUd$5_1h$;FLfIO;)V

    .line 24
    .line 25
    .line 26
    :goto_0
    return-void

    .line 27
    :pswitch_0
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 28
    .line 29
    invoke-virtual {v1}, Linfo/t4w/vp/view/MainActivity;->yPN$A_n$()V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_1
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 34
    .line 35
    invoke-virtual {v1}, Linfo/t4w/vp/view/MainActivity;->oy_R$Xx_()V

    .line 36
    .line 37
    .line 38
    return-void

    .line 39
    :pswitch_2
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 40
    .line 41
    invoke-virtual {v1}, Linfo/t4w/vp/view/MainActivity;->yPN$A_n$()V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_3
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 46
    .line 47
    const-string p1, "Video Quality"

    .line 48
    .line 49
    const-string v0, "Subtitles"

    .line 50
    .line 51
    const-string v2, "Audio Tracks"

    .line 52
    .line 53
    filled-new-array {v2, p1, v0}, [Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    sget v0, LindeQ;->ic_track_selection:I

    .line 58
    .line 59
    new-instance v2, LVèM;

    .line 60
    .line 61
    const/4 v3, 0x6

    .line 62
    invoke-direct {v2, v1, v3}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 63
    .line 64
    .line 65
    const-string v3, "Track Selection"

    .line 66
    .line 67
    invoke-static {v1, v3, v0, p1, v2}, LdQta;->tmpSize211(Landroid/app/Activity;Ljava/lang/String;I[Ljava/lang/String;LZÌìK;)V

    .line 68
    .line 69
    .line 70
    return-void

    .line 71
    :pswitch_4
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 72
    .line 73
    invoke-virtual {v1}, Linfo/t4w/vp/view/MainActivity;->enterPictureInPictureMode()V

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :pswitch_5
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 78
    .line 79
    invoke-virtual {v1}, Linfo/t4w/vp/view/MainActivity;->oy_R$Xx_()V

    .line 80
    .line 81
    .line 82
    return-void

    .line 83
    :pswitch_6
    iget-object p1, v1, Linfo/t4w/vp/view/MainActivity;->YOD0:Landroidx/media3/common/MediaItem;

    .line 84
    .line 85
    if-eqz p1, :cond_2

    .line 86
    .line 87
    iget-object p1, p1, Landroidx/media3/common/MediaItem;->localConfiguration:Landroidx/media3/common/MediaItem$LocalConfiguration;

    .line 88
    .line 89
    iget-object p1, p1, Landroidx/media3/common/MediaItem$LocalConfiguration;->uri:Landroid/net/Uri;

    .line 90
    .line 91
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v2

    .line 99
    if-eqz v2, :cond_1

    .line 100
    .line 101
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    goto :goto_1

    .line 106
    :cond_1
    const-string p1, "Video"

    .line 107
    .line 108
    :goto_1
    new-instance v2, Landroid/content/Intent;

    .line 109
    .line 110
    const-class v3, Linfo/t4w/vp/view/MultiCastActivity;

    .line 111
    .line 112
    invoke-direct {v2, v1, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 113
    .line 114
    .line 115
    const-string v3, "videoUrl"

    .line 116
    .line 117
    invoke-virtual {v2, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 118
    .line 119
    .line 120
    const-string v0, "videoTitle"

    .line 121
    .line 122
    invoke-virtual {v2, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 123
    .line 124
    .line 125
    const-string p1, "userAgent"

    .line 126
    .line 127
    iget-object v0, v1, Linfo/t4w/vp/view/MainActivity;->CcZMD:Ljava/lang/String;

    .line 128
    .line 129
    invoke-virtual {v2, p1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 130
    .line 131
    .line 132
    invoke-virtual {v1, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 133
    .line 134
    .line 135
    goto :goto_2

    .line 136
    :cond_2
    const-string p1, "Please load a video first"

    .line 137
    .line 138
    const/4 v0, 0x0

    .line 139
    invoke-static {v1, p1, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    .line 140
    .line 141
    .line 142
    move-result-object p1

    .line 143
    invoke-virtual {p1}, Landroid/widget/Toast;->show()V

    .line 144
    .line 145
    .line 146
    :goto_2
    return-void

    .line 147
    :pswitch_7
    sget p1, Linfo/t4w/vp/view/MainActivity;->oO:I

    .line 148
    .line 149
    iget-object p1, v1, Linfo/t4w/vp/view/MainActivity;->oaX_6_:Landroidx/media3/common/Player;

    .line 150
    .line 151
    if-nez p1, :cond_3

    .line 152
    .line 153
    goto :goto_3

    .line 154
    :cond_3
    iget p1, v1, Linfo/t4w/vp/view/MainActivity;->iQ0D:F

    .line 155
    .line 156
    new-instance v2, LVèM;

    .line 157
    .line 158
    invoke-direct {v2, v1, v0}, LVèM;-><init>(Linfo/t4w/vp/view/MainActivity;I)V

    .line 159
    .line 160
    .line 161
    invoke-static {v1, p1, v2}, LIlIIll;->pCXDYg(LUd$5_1h$;FLfIO;)V

    .line 162
    .line 163
    .line 164
    :goto_3
    return-void

    .line 165
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
