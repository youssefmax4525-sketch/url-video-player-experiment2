.class public LJikDgD;
.super LsIndex5935;
.source "SourceFile"


# instance fields
.field public final rz__9J_:Landroid/view/WindowInsets$Builder;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, LsIndex5935;-><init>()V

    .line 2
    invoke-static {}, LnIndex9072;->tmpData3485()Landroid/view/WindowInsets$Builder;

    move-result-object v0

    iput-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    return-void
.end method

.method public constructor <init>(LmSize1198;)V
    .locals 0

    .line 3
    invoke-direct {p0, p1}, LsIndex5935;-><init>(LmSize1198;)V

    .line 4
    invoke-virtual {p1}, LmSize1198;->tmpData3485()Landroid/view/WindowInsets;

    move-result-object p1

    if-eqz p1, :cond_0

    .line 5
    invoke-static {p1}, LnIndex9072;->sKey7917(Landroid/view/WindowInsets;)Landroid/view/WindowInsets$Builder;

    move-result-object p1

    goto :goto_0

    .line 6
    :cond_0
    invoke-static {}, LnIndex9072;->tmpData3485()Landroid/view/WindowInsets$Builder;

    move-result-object p1

    :goto_0
    iput-object p1, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    return-void
.end method


# virtual methods
.method public DDù8(LoI;)V
    .locals 1

    .line 1
    iget-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, LoI;->POOl()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LnIndex9072;->tzKù7Ol1(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public JKEoÙX(LoI;)V
    .locals 1

    .line 1
    iget-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, LoI;->POOl()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LnIndex9072;->kCount1402(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public POOl(LoI;)V
    .locals 1

    .line 1
    iget-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, LoI;->POOl()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LnIndex9072;->sKey6064(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public sKey7917(LoI;)V
    .locals 1

    .line 1
    iget-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, LoI;->POOl()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LnIndex9072;->kO_6X_(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public tmpData3485(LoI;)V
    .locals 1

    .line 1
    iget-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    .line 2
    .line 3
    invoke-virtual {p1}, LoI;->POOl()Landroid/graphics/Insets;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    invoke-static {v0, p1}, LnIndex9072;->tmpSize211(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public waiBKÀ()LmSize1198;
    .locals 3

    .line 1
    invoke-virtual {p0}, LsIndex5935;->e8$mp_s$()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, LJikDgD;->rz__9J_:Landroid/view/WindowInsets$Builder;

    .line 5
    .line 6
    invoke-static {v0}, LnIndex9072;->DDù8(Landroid/view/WindowInsets$Builder;)Landroid/view/WindowInsets;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {v1, v0}, LmSize1198;->sKey7917(Landroid/view/View;Landroid/view/WindowInsets;)LmSize1198;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-object v1, p0, LsIndex5935;->waiBKÀ:[LoI;

    .line 16
    .line 17
    iget-object v2, v0, LmSize1198;->e8$mp_s$:Lkp$1$;

    .line 18
    .line 19
    invoke-virtual {v2, v1}, Lkp$1$;->valuI([LoI;)V

    .line 20
    .line 21
    .line 22
    return-object v0
.end method
