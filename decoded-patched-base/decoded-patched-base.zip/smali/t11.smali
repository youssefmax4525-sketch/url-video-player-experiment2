.class public final Lt11;
.super Ljava/util/AbstractMap;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final K0I:Ljava/lang/Object;

.field public static final kO_6X_:Ljava/lang/Object;


# instance fields
.field public transient Ialue:I

.field public transient gKey4112:Ljava/util/AbstractCollection;

.field public transient iOffset934:[Ljava/lang/Object;

.field public transient jPos3709:[I

.field public transient kQy:[Ljava/lang/Object;

.field public transient pCXDYg:Ljava/util/AbstractSet;

.field public transient vaIue:Ljava/lang/Object;

.field public transient valuI:I

.field public final synthetic yON3x:I

.field public transient yàÒZ:Ljava/util/AbstractSet;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lt11;->kO_6X_:Ljava/lang/Object;

    .line 7
    .line 8
    new-instance v0, Ljava/lang/Object;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v0, Lt11;->K0I:Ljava/lang/Object;

    .line 14
    .line 15
    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    .line 1
    iput p1, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch p1, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/util/AbstractMap;-><init>()V

    .line 7
    .line 8
    .line 9
    return-void

    .line 10
    :pswitch_0
    invoke-direct {p0}, Ljava/util/AbstractMap;-><init>()V

    .line 11
    .line 12
    .line 13
    const/16 p1, 0x8

    .line 14
    .line 15
    const/4 v0, 0x1

    .line 16
    invoke-static {p1, v0}, LqaqSBo;->yPN$A_n$(II)I

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    iput p1, p0, Lt11;->Ialue:I

    .line 21
    .line 22
    return-void

    .line 23
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public static e8$mp_s$()Lt11;
    .locals 4

    .line 1
    new-instance v0, Lt11;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lt11;-><init>(I)V

    .line 5
    .line 6
    .line 7
    const v1, 0x3fffffff    # 1.9999999f

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x3

    .line 11
    const/4 v3, 0x1

    .line 12
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    iput v1, v0, Lt11;->Ialue:I

    .line 21
    .line 22
    return-object v0
.end method

.method public static waiBKÀ(I)Lt11;
    .locals 3

    .line 1
    new-instance v0, Lt11;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Lt11;-><init>(I)V

    .line 5
    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    if-ltz p0, :cond_0

    .line 9
    .line 10
    const/4 v2, 0x1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v2, 0x0

    .line 13
    :goto_0
    if-eqz v2, :cond_1

    .line 14
    .line 15
    const v2, 0x3fffffff    # 1.9999999f

    .line 16
    .line 17
    .line 18
    invoke-static {p0, v1}, Ljava/lang/Math;->max(II)I

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    invoke-static {p0, v2}, Ljava/lang/Math;->min(II)I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    iput p0, v0, Lt11;->Ialue:I

    .line 27
    .line 28
    return-object v0

    .line 29
    :cond_1
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 30
    .line 31
    const-string v0, "Expected size must be >= 0"

    .line 32
    .line 33
    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw p0
.end method


# virtual methods
.method public DDù8(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    invoke-virtual {p0}, Lt11;->sKey7917()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    invoke-virtual {p0}, Lt11;->POOl()I

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    iget-object v4, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Lt11;->yON3x()[I

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    invoke-virtual {p0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    const/4 v7, 0x0

    .line 26
    const/4 v2, 0x0

    .line 27
    move-object v1, p1

    .line 28
    invoke-static/range {v1 .. v7}, Lzl1;->$ÒcdS(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;[I[Ljava/lang/Object;[Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    const/4 v0, -0x1

    .line 33
    if-ne p1, v0, :cond_1

    .line 34
    .line 35
    :goto_0
    sget-object p1, Lt11;->kO_6X_:Ljava/lang/Object;

    .line 36
    .line 37
    return-object p1

    .line 38
    :cond_1
    invoke-virtual {p0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v0

    .line 42
    aget-object v0, v0, p1

    .line 43
    .line 44
    invoke-virtual {p0, p1, v3}, Lt11;->tmpData3485(II)V

    .line 45
    .line 46
    .line 47
    iget p1, p0, Lt11;->valuI:I

    .line 48
    .line 49
    add-int/lit8 p1, p1, -0x1

    .line 50
    .line 51
    iput p1, p0, Lt11;->valuI:I

    .line 52
    .line 53
    iget p1, p0, Lt11;->Ialue:I

    .line 54
    .line 55
    add-int/lit8 p1, p1, 0x20

    .line 56
    .line 57
    iput p1, p0, Lt11;->Ialue:I

    .line 58
    .line 59
    return-object v0
.end method

.method public Ialue()[Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public JKEoÙX(Ljava/lang/Object;)I
    .locals 7

    .line 1
    invoke-virtual {p0}, Lt11;->sKey7917()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    invoke-static {p1}, Lzl1;->sKey6064(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p0}, Lt11;->POOl()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    iget-object v3, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 18
    .line 19
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    and-int v4, v0, v2

    .line 23
    .line 24
    invoke-static {v4, v3}, Lzl1;->tzKù7Ol1(ILjava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    if-nez v3, :cond_1

    .line 29
    .line 30
    return v1

    .line 31
    :cond_1
    not-int v4, v2

    .line 32
    and-int/2addr v0, v4

    .line 33
    :cond_2
    add-int/lit8 v3, v3, -0x1

    .line 34
    .line 35
    invoke-virtual {p0}, Lt11;->yON3x()[I

    .line 36
    .line 37
    .line 38
    move-result-object v5

    .line 39
    aget v5, v5, v3

    .line 40
    .line 41
    and-int v6, v5, v4

    .line 42
    .line 43
    if-ne v6, v0, :cond_3

    .line 44
    .line 45
    invoke-virtual {p0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v6

    .line 49
    aget-object v6, v6, v3

    .line 50
    .line 51
    invoke-static {p1, v6}, LN11Il1;->vaIue(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_3

    .line 56
    .line 57
    return v3

    .line 58
    :cond_3
    and-int v3, v5, v2

    .line 59
    .line 60
    if-nez v3, :cond_2

    .line 61
    .line 62
    return v1
.end method

.method public K0I(Ljava/lang/Object;)I
    .locals 7

    .line 1
    invoke-virtual {p0}, Lt11;->gKey4112()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    return v1

    .line 9
    :cond_0
    invoke-static {p1}, LvB$7$;->tzKù7Ol1(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    invoke-virtual {p0}, Lt11;->kO_6X_()I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    iget-object v3, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 18
    .line 19
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    and-int v4, v0, v2

    .line 23
    .line 24
    invoke-static {v4, v3}, LIlIIll;->sKey6064(ILjava/lang/Object;)I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    if-eqz v3, :cond_4

    .line 29
    .line 30
    not-int v4, v2

    .line 31
    and-int/2addr v0, v4

    .line 32
    :cond_1
    add-int/2addr v3, v1

    .line 33
    invoke-virtual {p0}, Lt11;->kQy()[I

    .line 34
    .line 35
    .line 36
    move-result-object v5

    .line 37
    aget v5, v5, v3

    .line 38
    .line 39
    and-int v6, v5, v4

    .line 40
    .line 41
    if-ne v6, v0, :cond_3

    .line 42
    .line 43
    invoke-virtual {p0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v6

    .line 47
    aget-object v6, v6, v3

    .line 48
    .line 49
    invoke-static {p1, v6}, LqaqSBo;->Q1_f_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    move-result v6

    .line 53
    if-nez v6, :cond_2

    .line 54
    .line 55
    goto :goto_0

    .line 56
    :cond_2
    return v3

    .line 57
    :cond_3
    :goto_0
    and-int v3, v5, v2

    .line 58
    .line 59
    if-nez v3, :cond_1

    .line 60
    .line 61
    :cond_4
    return v1
.end method

.method public POOl()I
    .locals 2

    .line 1
    iget v0, p0, Lt11;->Ialue:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x1f

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    shl-int v0, v1, v0

    .line 7
    .line 8
    sub-int/2addr v0, v1

    .line 9
    return v0
.end method

.method public Qp_Hp$i_(IIII)I
    .locals 8

    .line 1
    add-int/lit8 v0, p2, -0x1

    .line 2
    .line 3
    invoke-static {p2}, LIlIIll;->ll(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p2

    .line 7
    if-eqz p4, :cond_0

    .line 8
    .line 9
    and-int/2addr p3, v0

    .line 10
    add-int/lit8 p4, p4, 0x1

    .line 11
    .line 12
    invoke-static {p3, p4, p2}, LIlIIll;->Oey(IILjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget-object p3, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-static {p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lt11;->kQy()[I

    .line 21
    .line 22
    .line 23
    move-result-object p4

    .line 24
    const/4 v1, 0x0

    .line 25
    :goto_0
    if-gt v1, p1, :cond_2

    .line 26
    .line 27
    invoke-static {v1, p3}, LIlIIll;->sKey6064(ILjava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    :goto_1
    if-eqz v2, :cond_1

    .line 32
    .line 33
    add-int/lit8 v3, v2, -0x1

    .line 34
    .line 35
    aget v4, p4, v3

    .line 36
    .line 37
    not-int v5, p1

    .line 38
    and-int/2addr v5, v4

    .line 39
    or-int/2addr v5, v1

    .line 40
    and-int v6, v5, v0

    .line 41
    .line 42
    invoke-static {v6, p2}, LIlIIll;->sKey6064(ILjava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    invoke-static {v6, v2, p2}, LIlIIll;->Oey(IILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    not-int v2, v0

    .line 50
    and-int v6, v7, v0

    .line 51
    .line 52
    and-int/2addr v2, v5

    .line 53
    or-int/2addr v2, v6

    .line 54
    aput v2, p4, v3

    .line 55
    .line 56
    and-int v2, v4, p1

    .line 57
    .line 58
    goto :goto_1

    .line 59
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    iput-object p2, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 63
    .line 64
    invoke-static {v0}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    .line 65
    .line 66
    .line 67
    move-result p1

    .line 68
    rsub-int/lit8 p1, p1, 0x20

    .line 69
    .line 70
    iget p2, p0, Lt11;->Ialue:I

    .line 71
    .line 72
    and-int/lit8 p2, p2, -0x20

    .line 73
    .line 74
    and-int/lit8 p1, p1, 0x1f

    .line 75
    .line 76
    or-int/2addr p1, p2

    .line 77
    iput p1, p0, Lt11;->Ialue:I

    .line 78
    .line 79
    return v0
.end method

.method public UC_n_(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    .line 1
    invoke-virtual {p0}, Lt11;->gKey4112()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    goto :goto_0

    .line 8
    :cond_0
    invoke-virtual {p0}, Lt11;->kO_6X_()I

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    iget-object v4, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 13
    .line 14
    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Lt11;->kQy()[I

    .line 18
    .line 19
    .line 20
    move-result-object v5

    .line 21
    invoke-virtual {p0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v6

    .line 25
    const/4 v7, 0x0

    .line 26
    const/4 v2, 0x0

    .line 27
    move-object v1, p1

    .line 28
    invoke-static/range {v1 .. v7}, LIlIIll;->$ÒcdS(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;[I[Ljava/lang/Object;[Ljava/lang/Object;)I

    .line 29
    .line 30
    .line 31
    move-result p1

    .line 32
    const/4 v0, -0x1

    .line 33
    if-eq p1, v0, :cond_1

    .line 34
    .line 35
    invoke-virtual {p0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    aget-object v1, v1, p1

    .line 40
    .line 41
    invoke-virtual {p0, p1, v3}, Lt11;->yàÒZ(II)V

    .line 42
    .line 43
    .line 44
    iget p1, p0, Lt11;->valuI:I

    .line 45
    .line 46
    add-int/2addr p1, v0

    .line 47
    iput p1, p0, Lt11;->valuI:I

    .line 48
    .line 49
    iget p1, p0, Lt11;->Ialue:I

    .line 50
    .line 51
    add-int/lit8 p1, p1, 0x20

    .line 52
    .line 53
    iput p1, p0, Lt11;->Ialue:I

    .line 54
    .line 55
    return-object v1

    .line 56
    :cond_1
    :goto_0
    sget-object p1, Lt11;->K0I:Ljava/lang/Object;

    .line 57
    .line 58
    return-object p1
.end method

.method public final clear()V
    .locals 6

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->gKey4112()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_0
    iget v0, p0, Lt11;->Ialue:I

    .line 14
    .line 15
    add-int/lit8 v0, v0, 0x20

    .line 16
    .line 17
    iput v0, p0, Lt11;->Ialue:I

    .line 18
    .line 19
    invoke-virtual {p0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 20
    .line 21
    .line 22
    move-result-object v0

    .line 23
    const/4 v1, 0x0

    .line 24
    const/4 v2, 0x0

    .line 25
    if-eqz v0, :cond_1

    .line 26
    .line 27
    invoke-virtual {p0}, Lt11;->size()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    const/4 v4, 0x3

    .line 32
    invoke-static {v3, v4}, LqaqSBo;->yPN$A_n$(II)I

    .line 33
    .line 34
    .line 35
    move-result v3

    .line 36
    iput v3, p0, Lt11;->Ialue:I

    .line 37
    .line 38
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 39
    .line 40
    .line 41
    iput-object v1, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 42
    .line 43
    iput v2, p0, Lt11;->valuI:I

    .line 44
    .line 45
    goto :goto_1

    .line 46
    :cond_1
    invoke-virtual {p0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    iget v3, p0, Lt11;->valuI:I

    .line 51
    .line 52
    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {p0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    iget v3, p0, Lt11;->valuI:I

    .line 60
    .line 61
    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 65
    .line 66
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    .line 68
    .line 69
    instance-of v1, v0, [B

    .line 70
    .line 71
    if-eqz v1, :cond_2

    .line 72
    .line 73
    check-cast v0, [B

    .line 74
    .line 75
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([BB)V

    .line 76
    .line 77
    .line 78
    goto :goto_0

    .line 79
    :cond_2
    instance-of v1, v0, [S

    .line 80
    .line 81
    if-eqz v1, :cond_3

    .line 82
    .line 83
    check-cast v0, [S

    .line 84
    .line 85
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([SS)V

    .line 86
    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_3
    check-cast v0, [I

    .line 90
    .line 91
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    .line 92
    .line 93
    .line 94
    :goto_0
    invoke-virtual {p0}, Lt11;->kQy()[I

    .line 95
    .line 96
    .line 97
    move-result-object v0

    .line 98
    iget v1, p0, Lt11;->valuI:I

    .line 99
    .line 100
    invoke-static {v0, v2, v1, v2}, Ljava/util/Arrays;->fill([IIII)V

    .line 101
    .line 102
    .line 103
    iput v2, p0, Lt11;->valuI:I

    .line 104
    .line 105
    :goto_1
    return-void

    .line 106
    :pswitch_0
    invoke-virtual {p0}, Lt11;->sKey7917()Z

    .line 107
    .line 108
    .line 109
    move-result v0

    .line 110
    if-eqz v0, :cond_4

    .line 111
    .line 112
    goto :goto_3

    .line 113
    :cond_4
    iget v0, p0, Lt11;->Ialue:I

    .line 114
    .line 115
    add-int/lit8 v0, v0, 0x20

    .line 116
    .line 117
    iput v0, p0, Lt11;->Ialue:I

    .line 118
    .line 119
    invoke-virtual {p0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    const/4 v1, 0x0

    .line 124
    const/4 v2, 0x0

    .line 125
    if-eqz v0, :cond_5

    .line 126
    .line 127
    invoke-virtual {p0}, Lt11;->size()I

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    const v4, 0x3fffffff    # 1.9999999f

    .line 132
    .line 133
    .line 134
    const/4 v5, 0x3

    .line 135
    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    .line 140
    .line 141
    .line 142
    move-result v3

    .line 143
    iput v3, p0, Lt11;->Ialue:I

    .line 144
    .line 145
    invoke-interface {v0}, Ljava/util/Map;->clear()V

    .line 146
    .line 147
    .line 148
    iput-object v1, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 149
    .line 150
    iput v2, p0, Lt11;->valuI:I

    .line 151
    .line 152
    goto :goto_3

    .line 153
    :cond_5
    invoke-virtual {p0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    iget v3, p0, Lt11;->valuI:I

    .line 158
    .line 159
    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {p0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v0

    .line 166
    iget v3, p0, Lt11;->valuI:I

    .line 167
    .line 168
    invoke-static {v0, v2, v3, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 172
    .line 173
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 174
    .line 175
    .line 176
    instance-of v1, v0, [B

    .line 177
    .line 178
    if-eqz v1, :cond_6

    .line 179
    .line 180
    check-cast v0, [B

    .line 181
    .line 182
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([BB)V

    .line 183
    .line 184
    .line 185
    goto :goto_2

    .line 186
    :cond_6
    instance-of v1, v0, [S

    .line 187
    .line 188
    if-eqz v1, :cond_7

    .line 189
    .line 190
    check-cast v0, [S

    .line 191
    .line 192
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([SS)V

    .line 193
    .line 194
    .line 195
    goto :goto_2

    .line 196
    :cond_7
    check-cast v0, [I

    .line 197
    .line 198
    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    .line 199
    .line 200
    .line 201
    :goto_2
    invoke-virtual {p0}, Lt11;->yON3x()[I

    .line 202
    .line 203
    .line 204
    move-result-object v0

    .line 205
    iget v1, p0, Lt11;->valuI:I

    .line 206
    .line 207
    invoke-static {v0, v2, v1, v2}, Ljava/util/Arrays;->fill([IIII)V

    .line 208
    .line 209
    .line 210
    iput v2, p0, Lt11;->valuI:I

    .line 211
    .line 212
    :goto_3
    return-void

    .line 213
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final containsKey(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {p0, p1}, Lt11;->K0I(Ljava/lang/Object;)I

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    const/4 v0, -0x1

    .line 22
    if-ne p1, v0, :cond_1

    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    const/4 p1, 0x1

    .line 27
    :goto_0
    return p1

    .line 28
    :pswitch_0
    invoke-virtual {p0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    if-eqz v0, :cond_2

    .line 33
    .line 34
    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result p1

    .line 38
    goto :goto_1

    .line 39
    :cond_2
    invoke-virtual {p0, p1}, Lt11;->JKEoÙX(Ljava/lang/Object;)I

    .line 40
    .line 41
    .line 42
    move-result p1

    .line 43
    const/4 v0, -0x1

    .line 44
    if-eq p1, v0, :cond_3

    .line 45
    .line 46
    const/4 p1, 0x1

    .line 47
    goto :goto_1

    .line 48
    :cond_3
    const/4 p1, 0x0

    .line 49
    :goto_1
    return p1

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final containsValue(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-nez v0, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    const/4 v1, 0x0

    .line 14
    :goto_0
    iget v2, p0, Lt11;->valuI:I

    .line 15
    .line 16
    if-ge v1, v2, :cond_2

    .line 17
    .line 18
    invoke-virtual {p0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    aget-object v2, v2, v1

    .line 23
    .line 24
    invoke-static {p1, v2}, LqaqSBo;->Q1_f_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-eqz v2, :cond_0

    .line 29
    .line 30
    const/4 v0, 0x1

    .line 31
    goto :goto_1

    .line 32
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 33
    .line 34
    goto :goto_0

    .line 35
    :cond_1
    invoke-interface {v0, p1}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    :cond_2
    :goto_1
    return v0

    .line 40
    :pswitch_0
    invoke-virtual {p0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    if-eqz v0, :cond_3

    .line 45
    .line 46
    invoke-interface {v0, p1}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result p1

    .line 50
    goto :goto_3

    .line 51
    :cond_3
    const/4 v0, 0x0

    .line 52
    const/4 v1, 0x0

    .line 53
    :goto_2
    iget v2, p0, Lt11;->valuI:I

    .line 54
    .line 55
    if-ge v1, v2, :cond_5

    .line 56
    .line 57
    invoke-virtual {p0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    aget-object v2, v2, v1

    .line 62
    .line 63
    invoke-static {p1, v2}, LN11Il1;->vaIue(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-eqz v2, :cond_4

    .line 68
    .line 69
    const/4 p1, 0x1

    .line 70
    goto :goto_3

    .line 71
    :cond_4
    add-int/lit8 v1, v1, 0x1

    .line 72
    .line 73
    goto :goto_2

    .line 74
    :cond_5
    const/4 p1, 0x0

    .line 75
    :goto_3
    return p1

    .line 76
    nop

    .line 77
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final entrySet()Ljava/util/Set;
    .locals 2

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lt11;->yàÒZ:Ljava/util/AbstractSet;

    .line 7
    .line 8
    check-cast v0, LDmCGmD;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    new-instance v0, LDmCGmD;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-direct {v0, p0, v1}, LDmCGmD;-><init>(Lt11;I)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lt11;->yàÒZ:Ljava/util/AbstractSet;

    .line 19
    .line 20
    :cond_0
    return-object v0

    .line 21
    :pswitch_0
    iget-object v0, p0, Lt11;->yàÒZ:Ljava/util/AbstractSet;

    .line 22
    .line 23
    check-cast v0, LxìuÒhÒHÙ;

    .line 24
    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    new-instance v0, LxìuÒhÒHÙ;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    invoke-direct {v0, v1, p0}, LxìuÒhÒHÙ;-><init>(ILjava/util/Map;)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lt11;->yàÒZ:Ljava/util/AbstractSet;

    .line 34
    .line 35
    :cond_1
    return-object v0

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public gKey4112()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    return v0

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    return v0
.end method

.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {p0, p1}, Lt11;->K0I(Ljava/lang/Object;)I

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    const/4 v0, -0x1

    .line 22
    if-ne p1, v0, :cond_1

    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    goto :goto_0

    .line 26
    :cond_1
    invoke-virtual {p0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    aget-object p1, v0, p1

    .line 31
    .line 32
    :goto_0
    return-object p1

    .line 33
    :pswitch_0
    invoke-virtual {p0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    if-eqz v0, :cond_2

    .line 38
    .line 39
    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object p1

    .line 43
    goto :goto_1

    .line 44
    :cond_2
    invoke-virtual {p0, p1}, Lt11;->JKEoÙX(Ljava/lang/Object;)I

    .line 45
    .line 46
    .line 47
    move-result p1

    .line 48
    const/4 v0, -0x1

    .line 49
    if-ne p1, v0, :cond_3

    .line 50
    .line 51
    const/4 p1, 0x0

    .line 52
    goto :goto_1

    .line 53
    :cond_3
    invoke-virtual {p0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    aget-object p1, v0, p1

    .line 58
    .line 59
    :goto_1
    return-object p1

    .line 60
    nop

    .line 61
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public iOffset934(IIII)I
    .locals 8

    .line 1
    invoke-static {p2}, Lzl1;->pCXDYg(I)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    add-int/lit8 p2, p2, -0x1

    .line 6
    .line 7
    if-eqz p4, :cond_0

    .line 8
    .line 9
    and-int/2addr p3, p2

    .line 10
    add-int/lit8 p4, p4, 0x1

    .line 11
    .line 12
    invoke-static {p3, p4, v0}, Lzl1;->ll(IILjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    :cond_0
    iget-object p3, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 16
    .line 17
    invoke-static {p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Lt11;->yON3x()[I

    .line 21
    .line 22
    .line 23
    move-result-object p4

    .line 24
    const/4 v1, 0x0

    .line 25
    :goto_0
    if-gt v1, p1, :cond_2

    .line 26
    .line 27
    invoke-static {v1, p3}, Lzl1;->tzKù7Ol1(ILjava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result v2

    .line 31
    :goto_1
    if-eqz v2, :cond_1

    .line 32
    .line 33
    add-int/lit8 v3, v2, -0x1

    .line 34
    .line 35
    aget v4, p4, v3

    .line 36
    .line 37
    not-int v5, p1

    .line 38
    and-int/2addr v5, v4

    .line 39
    or-int/2addr v5, v1

    .line 40
    and-int v6, v5, p2

    .line 41
    .line 42
    invoke-static {v6, v0}, Lzl1;->tzKù7Ol1(ILjava/lang/Object;)I

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    invoke-static {v6, v2, v0}, Lzl1;->ll(IILjava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    invoke-static {v5, v7, p2}, Lzl1;->Qp_Hp$i_(III)I

    .line 50
    .line 51
    .line 52
    move-result v2

    .line 53
    aput v2, p4, v3

    .line 54
    .line 55
    and-int v2, v4, p1

    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 59
    .line 60
    goto :goto_0

    .line 61
    :cond_2
    iput-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 62
    .line 63
    invoke-static {p2}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    rsub-int/lit8 p1, p1, 0x20

    .line 68
    .line 69
    iget p3, p0, Lt11;->Ialue:I

    .line 70
    .line 71
    const/16 p4, 0x1f

    .line 72
    .line 73
    invoke-static {p3, p1, p4}, Lzl1;->Qp_Hp$i_(III)I

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    iput p1, p0, Lt11;->Ialue:I

    .line 78
    .line 79
    return p2
.end method

.method public final isEmpty()Z
    .locals 1

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->size()I

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v0, 0x0

    .line 15
    :goto_0
    return v0

    .line 16
    :pswitch_0
    invoke-virtual {p0}, Lt11;->size()I

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_1

    .line 21
    .line 22
    const/4 v0, 0x1

    .line 23
    goto :goto_1

    .line 24
    :cond_1
    const/4 v0, 0x0

    .line 25
    :goto_1
    return v0

    .line 26
    nop

    .line 27
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public jPos3709()[Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->kQy:[Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public kO_6X_()I
    .locals 2

    .line 1
    iget v0, p0, Lt11;->Ialue:I

    .line 2
    .line 3
    and-int/lit8 v0, v0, 0x1f

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    shl-int v0, v1, v0

    .line 7
    .line 8
    add-int/lit8 v0, v0, -0x1

    .line 9
    .line 10
    return v0
.end method

.method public kQy()[I
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->jPos3709:[I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [I

    .line 7
    .line 8
    return-object v0
.end method

.method public final keySet()Ljava/util/Set;
    .locals 2

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lt11;->pCXDYg:Ljava/util/AbstractSet;

    .line 7
    .line 8
    check-cast v0, LDmCGmD;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    new-instance v0, LDmCGmD;

    .line 13
    .line 14
    const/4 v1, 0x1

    .line 15
    invoke-direct {v0, p0, v1}, LDmCGmD;-><init>(Lt11;I)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lt11;->pCXDYg:Ljava/util/AbstractSet;

    .line 19
    .line 20
    :cond_0
    return-object v0

    .line 21
    :pswitch_0
    iget-object v0, p0, Lt11;->pCXDYg:Ljava/util/AbstractSet;

    .line 22
    .line 23
    check-cast v0, LxìuÒhÒHÙ;

    .line 24
    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    new-instance v0, LxìuÒhÒHÙ;

    .line 28
    .line 29
    const/4 v1, 0x1

    .line 30
    invoke-direct {v0, v1, p0}, LxìuÒhÒHÙ;-><init>(ILjava/util/Map;)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lt11;->pCXDYg:Ljava/util/AbstractSet;

    .line 34
    .line 35
    :cond_1
    return-object v0

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public pCXDYg()Ljava/util/Map;
    .locals 2

    .line 1
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    instance-of v1, v0, Ljava/util/Map;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    check-cast v0, Ljava/util/Map;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return-object v0
.end method

.method public final put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 23

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget v3, v0, Lt11;->yON3x:I

    .line 8
    .line 9
    packed-switch v3, :pswitch_data_0

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0}, Lt11;->gKey4112()Z

    .line 13
    .line 14
    .line 15
    move-result v3

    .line 16
    const/4 v4, 0x4

    .line 17
    const/4 v5, 0x2

    .line 18
    const/16 v6, 0x20

    .line 19
    .line 20
    const/4 v7, -0x1

    .line 21
    if-eqz v3, :cond_1

    .line 22
    .line 23
    invoke-virtual {v0}, Lt11;->gKey4112()Z

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    const-string v8, "Arrays already allocated"

    .line 28
    .line 29
    invoke-static {v8, v3}, LvItem3158;->sizl(Ljava/lang/String;Z)V

    .line 30
    .line 31
    .line 32
    iget v3, v0, Lt11;->Ialue:I

    .line 33
    .line 34
    add-int/lit8 v8, v3, 0x1

    .line 35
    .line 36
    invoke-static {v8, v5}, Ljava/lang/Math;->max(II)I

    .line 37
    .line 38
    .line 39
    move-result v8

    .line 40
    invoke-static {v8}, Ljava/lang/Integer;->highestOneBit(I)I

    .line 41
    .line 42
    .line 43
    move-result v9

    .line 44
    int-to-double v10, v9

    .line 45
    double-to-int v10, v10

    .line 46
    if-le v8, v10, :cond_0

    .line 47
    .line 48
    add-int/2addr v9, v9

    .line 49
    if-gtz v9, :cond_0

    .line 50
    .line 51
    const/high16 v9, 0x40000000    # 2.0f

    .line 52
    .line 53
    :cond_0
    invoke-static {v4, v9}, Ljava/lang/Math;->max(II)I

    .line 54
    .line 55
    .line 56
    move-result v8

    .line 57
    invoke-static {v8}, LIlIIll;->ll(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v9

    .line 61
    iput-object v9, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 62
    .line 63
    add-int/2addr v8, v7

    .line 64
    invoke-static {v8}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    .line 65
    .line 66
    .line 67
    move-result v8

    .line 68
    rsub-int/lit8 v8, v8, 0x20

    .line 69
    .line 70
    iget v9, v0, Lt11;->Ialue:I

    .line 71
    .line 72
    and-int/lit8 v9, v9, -0x20

    .line 73
    .line 74
    and-int/lit8 v8, v8, 0x1f

    .line 75
    .line 76
    or-int/2addr v8, v9

    .line 77
    iput v8, v0, Lt11;->Ialue:I

    .line 78
    .line 79
    new-array v8, v3, [I

    .line 80
    .line 81
    iput-object v8, v0, Lt11;->jPos3709:[I

    .line 82
    .line 83
    new-array v8, v3, [Ljava/lang/Object;

    .line 84
    .line 85
    iput-object v8, v0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 86
    .line 87
    new-array v3, v3, [Ljava/lang/Object;

    .line 88
    .line 89
    iput-object v3, v0, Lt11;->kQy:[Ljava/lang/Object;

    .line 90
    .line 91
    :cond_1
    invoke-virtual {v0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    if-eqz v3, :cond_2

    .line 96
    .line 97
    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    goto/16 :goto_7

    .line 102
    .line 103
    :cond_2
    invoke-virtual {v0}, Lt11;->kQy()[I

    .line 104
    .line 105
    .line 106
    move-result-object v3

    .line 107
    invoke-virtual {v0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    invoke-virtual {v0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    move-result-object v9

    .line 115
    iget v10, v0, Lt11;->valuI:I

    .line 116
    .line 117
    add-int/lit8 v11, v10, 0x1

    .line 118
    .line 119
    invoke-static {v1}, LvB$7$;->tzKù7Ol1(Ljava/lang/Object;)I

    .line 120
    .line 121
    .line 122
    move-result v12

    .line 123
    invoke-virtual {v0}, Lt11;->kO_6X_()I

    .line 124
    .line 125
    .line 126
    move-result v13

    .line 127
    and-int v14, v12, v13

    .line 128
    .line 129
    iget-object v15, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 130
    .line 131
    invoke-static {v15}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    invoke-static {v14, v15}, LIlIIll;->sKey6064(ILjava/lang/Object;)I

    .line 135
    .line 136
    .line 137
    move-result v15

    .line 138
    if-nez v15, :cond_5

    .line 139
    .line 140
    if-le v11, v13, :cond_4

    .line 141
    .line 142
    if-ge v13, v6, :cond_3

    .line 143
    .line 144
    const/16 v16, 0x4

    .line 145
    .line 146
    goto :goto_0

    .line 147
    :cond_3
    const/16 v16, 0x2

    .line 148
    .line 149
    :goto_0
    add-int/lit8 v3, v13, 0x1

    .line 150
    .line 151
    mul-int v3, v3, v16

    .line 152
    .line 153
    invoke-virtual {v0, v13, v3, v12, v10}, Lt11;->Qp_Hp$i_(IIII)I

    .line 154
    .line 155
    .line 156
    move-result v13

    .line 157
    :goto_1
    const/4 v6, 0x0

    .line 158
    const/16 v21, 0x1

    .line 159
    .line 160
    goto/16 :goto_6

    .line 161
    .line 162
    :cond_4
    iget-object v3, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 163
    .line 164
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    invoke-static {v14, v11, v3}, LIlIIll;->Oey(IILjava/lang/Object;)V

    .line 168
    .line 169
    .line 170
    goto :goto_1

    .line 171
    :cond_5
    not-int v14, v13

    .line 172
    const/16 v17, -0x1

    .line 173
    .line 174
    and-int v7, v12, v14

    .line 175
    .line 176
    const/16 v18, 0x0

    .line 177
    .line 178
    const/16 v19, 0x0

    .line 179
    .line 180
    :goto_2
    add-int/lit8 v15, v15, -0x1

    .line 181
    .line 182
    aget v20, v3, v15

    .line 183
    .line 184
    const/16 v21, 0x1

    .line 185
    .line 186
    and-int v5, v20, v14

    .line 187
    .line 188
    const/16 v22, 0x20

    .line 189
    .line 190
    if-ne v5, v7, :cond_7

    .line 191
    .line 192
    aget-object v6, v8, v15

    .line 193
    .line 194
    invoke-static {v1, v6}, LqaqSBo;->Q1_f_(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 195
    .line 196
    .line 197
    move-result v6

    .line 198
    if-nez v6, :cond_6

    .line 199
    .line 200
    goto :goto_3

    .line 201
    :cond_6
    aget-object v1, v9, v15

    .line 202
    .line 203
    aput-object v2, v9, v15

    .line 204
    .line 205
    goto/16 :goto_7

    .line 206
    .line 207
    :cond_7
    :goto_3
    and-int v6, v20, v13

    .line 208
    .line 209
    add-int/lit8 v4, v19, 0x1

    .line 210
    .line 211
    if-nez v6, :cond_f

    .line 212
    .line 213
    const/16 v6, 0x9

    .line 214
    .line 215
    if-lt v4, v6, :cond_b

    .line 216
    .line 217
    invoke-virtual {v0}, Lt11;->kO_6X_()I

    .line 218
    .line 219
    .line 220
    move-result v3

    .line 221
    add-int/lit8 v3, v3, 0x1

    .line 222
    .line 223
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 224
    .line 225
    const/high16 v5, 0x3f800000    # 1.0f

    .line 226
    .line 227
    invoke-direct {v4, v3, v5}, Ljava/util/LinkedHashMap;-><init>(IF)V

    .line 228
    .line 229
    .line 230
    invoke-virtual {v0}, Lt11;->isEmpty()Z

    .line 231
    .line 232
    .line 233
    move-result v3

    .line 234
    if-eqz v3, :cond_9

    .line 235
    .line 236
    :cond_8
    const/16 v18, -0x1

    .line 237
    .line 238
    :cond_9
    :goto_4
    if-ltz v18, :cond_a

    .line 239
    .line 240
    invoke-virtual {v0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v3

    .line 244
    aget-object v3, v3, v18

    .line 245
    .line 246
    invoke-virtual {v0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 247
    .line 248
    .line 249
    move-result-object v5

    .line 250
    aget-object v5, v5, v18

    .line 251
    .line 252
    invoke-interface {v4, v3, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    add-int/lit8 v3, v18, 0x1

    .line 256
    .line 257
    iget v5, v0, Lt11;->valuI:I

    .line 258
    .line 259
    if-ge v3, v5, :cond_8

    .line 260
    .line 261
    move/from16 v18, v3

    .line 262
    .line 263
    goto :goto_4

    .line 264
    :cond_a
    iput-object v4, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 265
    .line 266
    const/4 v6, 0x0

    .line 267
    iput-object v6, v0, Lt11;->jPos3709:[I

    .line 268
    .line 269
    iput-object v6, v0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 270
    .line 271
    iput-object v6, v0, Lt11;->kQy:[Ljava/lang/Object;

    .line 272
    .line 273
    iget v3, v0, Lt11;->Ialue:I

    .line 274
    .line 275
    add-int/lit8 v3, v3, 0x20

    .line 276
    .line 277
    iput v3, v0, Lt11;->Ialue:I

    .line 278
    .line 279
    invoke-interface {v4, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v1

    .line 283
    goto :goto_7

    .line 284
    :cond_b
    const/4 v6, 0x0

    .line 285
    if-le v11, v13, :cond_d

    .line 286
    .line 287
    const/16 v4, 0x20

    .line 288
    .line 289
    if-ge v13, v4, :cond_c

    .line 290
    .line 291
    const/4 v4, 0x4

    .line 292
    goto :goto_5

    .line 293
    :cond_c
    const/4 v4, 0x2

    .line 294
    :goto_5
    add-int/lit8 v3, v13, 0x1

    .line 295
    .line 296
    mul-int v3, v3, v4

    .line 297
    .line 298
    invoke-virtual {v0, v13, v3, v12, v10}, Lt11;->Qp_Hp$i_(IIII)I

    .line 299
    .line 300
    .line 301
    move-result v13

    .line 302
    goto :goto_6

    .line 303
    :cond_d
    and-int v4, v11, v13

    .line 304
    .line 305
    or-int/2addr v4, v5

    .line 306
    aput v4, v3, v15

    .line 307
    .line 308
    :goto_6
    invoke-virtual {v0}, Lt11;->kQy()[I

    .line 309
    .line 310
    .line 311
    move-result-object v3

    .line 312
    array-length v3, v3

    .line 313
    if-le v11, v3, :cond_e

    .line 314
    .line 315
    ushr-int/lit8 v4, v3, 0x1

    .line 316
    .line 317
    const/4 v5, 0x1

    .line 318
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    .line 319
    .line 320
    .line 321
    move-result v4

    .line 322
    add-int/2addr v4, v3

    .line 323
    or-int/2addr v4, v5

    .line 324
    const v5, 0x3fffffff    # 1.9999999f

    .line 325
    .line 326
    .line 327
    invoke-static {v5, v4}, Ljava/lang/Math;->min(II)I

    .line 328
    .line 329
    .line 330
    move-result v4

    .line 331
    if-eq v4, v3, :cond_e

    .line 332
    .line 333
    invoke-virtual {v0}, Lt11;->kQy()[I

    .line 334
    .line 335
    .line 336
    move-result-object v3

    .line 337
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([II)[I

    .line 338
    .line 339
    .line 340
    move-result-object v3

    .line 341
    iput-object v3, v0, Lt11;->jPos3709:[I

    .line 342
    .line 343
    invoke-virtual {v0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v3

    .line 347
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 348
    .line 349
    .line 350
    move-result-object v3

    .line 351
    iput-object v3, v0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 352
    .line 353
    invoke-virtual {v0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 354
    .line 355
    .line 356
    move-result-object v3

    .line 357
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v3

    .line 361
    iput-object v3, v0, Lt11;->kQy:[Ljava/lang/Object;

    .line 362
    .line 363
    :cond_e
    not-int v3, v13

    .line 364
    and-int/2addr v3, v12

    .line 365
    invoke-virtual {v0}, Lt11;->kQy()[I

    .line 366
    .line 367
    .line 368
    move-result-object v4

    .line 369
    aput v3, v4, v10

    .line 370
    .line 371
    invoke-virtual {v0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 372
    .line 373
    .line 374
    move-result-object v3

    .line 375
    aput-object v1, v3, v10

    .line 376
    .line 377
    invoke-virtual {v0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 378
    .line 379
    .line 380
    move-result-object v1

    .line 381
    aput-object v2, v1, v10

    .line 382
    .line 383
    iput v11, v0, Lt11;->valuI:I

    .line 384
    .line 385
    iget v1, v0, Lt11;->Ialue:I

    .line 386
    .line 387
    const/16 v22, 0x20

    .line 388
    .line 389
    add-int/lit8 v1, v1, 0x20

    .line 390
    .line 391
    iput v1, v0, Lt11;->Ialue:I

    .line 392
    .line 393
    move-object v1, v6

    .line 394
    :goto_7
    return-object v1

    .line 395
    :cond_f
    const/16 v20, 0x0

    .line 396
    .line 397
    move/from16 v19, v4

    .line 398
    .line 399
    move v15, v6

    .line 400
    const/16 v6, 0x20

    .line 401
    .line 402
    goto/16 :goto_2

    .line 403
    .line 404
    :pswitch_0
    invoke-virtual {v0}, Lt11;->sKey7917()Z

    .line 405
    .line 406
    .line 407
    move-result v3

    .line 408
    const/4 v4, 0x2

    .line 409
    const/4 v5, 0x4

    .line 410
    const/16 v6, 0x20

    .line 411
    .line 412
    const/4 v7, 0x1

    .line 413
    if-eqz v3, :cond_13

    .line 414
    .line 415
    invoke-virtual {v0}, Lt11;->sKey7917()Z

    .line 416
    .line 417
    .line 418
    move-result v3

    .line 419
    if-eqz v3, :cond_12

    .line 420
    .line 421
    iget v3, v0, Lt11;->Ialue:I

    .line 422
    .line 423
    add-int/lit8 v8, v3, 0x1

    .line 424
    .line 425
    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    .line 426
    .line 427
    .line 428
    move-result v8

    .line 429
    invoke-static {v8}, Ljava/lang/Integer;->highestOneBit(I)I

    .line 430
    .line 431
    .line 432
    move-result v9

    .line 433
    int-to-double v10, v9

    .line 434
    const-wide/high16 v12, 0x3ff0000000000000L    # 1.0

    .line 435
    .line 436
    mul-double v12, v12, v10

    .line 437
    .line 438
    double-to-int v10, v12

    .line 439
    if-le v8, v10, :cond_11

    .line 440
    .line 441
    shl-int/lit8 v9, v9, 0x1

    .line 442
    .line 443
    if-lez v9, :cond_10

    .line 444
    .line 445
    goto :goto_8

    .line 446
    :cond_10
    const/high16 v9, 0x40000000    # 2.0f

    .line 447
    .line 448
    :cond_11
    :goto_8
    invoke-static {v5, v9}, Ljava/lang/Math;->max(II)I

    .line 449
    .line 450
    .line 451
    move-result v8

    .line 452
    invoke-static {v8}, Lzl1;->pCXDYg(I)Ljava/lang/Object;

    .line 453
    .line 454
    .line 455
    move-result-object v9

    .line 456
    iput-object v9, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 457
    .line 458
    sub-int/2addr v8, v7

    .line 459
    invoke-static {v8}, Ljava/lang/Integer;->numberOfLeadingZeros(I)I

    .line 460
    .line 461
    .line 462
    move-result v8

    .line 463
    rsub-int/lit8 v8, v8, 0x20

    .line 464
    .line 465
    iget v9, v0, Lt11;->Ialue:I

    .line 466
    .line 467
    const/16 v10, 0x1f

    .line 468
    .line 469
    invoke-static {v9, v8, v10}, Lzl1;->Qp_Hp$i_(III)I

    .line 470
    .line 471
    .line 472
    move-result v8

    .line 473
    iput v8, v0, Lt11;->Ialue:I

    .line 474
    .line 475
    new-array v8, v3, [I

    .line 476
    .line 477
    iput-object v8, v0, Lt11;->jPos3709:[I

    .line 478
    .line 479
    new-array v8, v3, [Ljava/lang/Object;

    .line 480
    .line 481
    iput-object v8, v0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 482
    .line 483
    new-array v3, v3, [Ljava/lang/Object;

    .line 484
    .line 485
    iput-object v3, v0, Lt11;->kQy:[Ljava/lang/Object;

    .line 486
    .line 487
    goto :goto_9

    .line 488
    :cond_12
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 489
    .line 490
    const-string v2, "Arrays already allocated"

    .line 491
    .line 492
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 493
    .line 494
    .line 495
    throw v1

    .line 496
    :cond_13
    :goto_9
    invoke-virtual {v0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 497
    .line 498
    .line 499
    move-result-object v3

    .line 500
    if-eqz v3, :cond_14

    .line 501
    .line 502
    invoke-interface {v3, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 503
    .line 504
    .line 505
    move-result-object v1

    .line 506
    goto/16 :goto_10

    .line 507
    .line 508
    :cond_14
    invoke-virtual {v0}, Lt11;->yON3x()[I

    .line 509
    .line 510
    .line 511
    move-result-object v3

    .line 512
    invoke-virtual {v0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 513
    .line 514
    .line 515
    move-result-object v8

    .line 516
    invoke-virtual {v0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 517
    .line 518
    .line 519
    move-result-object v9

    .line 520
    iget v10, v0, Lt11;->valuI:I

    .line 521
    .line 522
    add-int/lit8 v11, v10, 0x1

    .line 523
    .line 524
    invoke-static {v1}, Lzl1;->sKey6064(Ljava/lang/Object;)I

    .line 525
    .line 526
    .line 527
    move-result v12

    .line 528
    invoke-virtual {v0}, Lt11;->POOl()I

    .line 529
    .line 530
    .line 531
    move-result v13

    .line 532
    and-int v14, v12, v13

    .line 533
    .line 534
    iget-object v15, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 535
    .line 536
    invoke-static {v15}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 537
    .line 538
    .line 539
    invoke-static {v14, v15}, Lzl1;->tzKù7Ol1(ILjava/lang/Object;)I

    .line 540
    .line 541
    .line 542
    move-result v15

    .line 543
    if-nez v15, :cond_17

    .line 544
    .line 545
    if-le v11, v13, :cond_16

    .line 546
    .line 547
    if-ge v13, v6, :cond_15

    .line 548
    .line 549
    const/16 v16, 0x4

    .line 550
    .line 551
    goto :goto_a

    .line 552
    :cond_15
    const/16 v16, 0x2

    .line 553
    .line 554
    :goto_a
    add-int/lit8 v3, v13, 0x1

    .line 555
    .line 556
    mul-int v3, v3, v16

    .line 557
    .line 558
    invoke-virtual {v0, v13, v3, v12, v10}, Lt11;->iOffset934(IIII)I

    .line 559
    .line 560
    .line 561
    move-result v13

    .line 562
    :goto_b
    const/4 v5, 0x0

    .line 563
    const/16 v19, 0x1

    .line 564
    .line 565
    goto/16 :goto_f

    .line 566
    .line 567
    :cond_16
    iget-object v3, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 568
    .line 569
    invoke-static {v3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 570
    .line 571
    .line 572
    invoke-static {v14, v11, v3}, Lzl1;->ll(IILjava/lang/Object;)V

    .line 573
    .line 574
    .line 575
    goto :goto_b

    .line 576
    :cond_17
    not-int v14, v13

    .line 577
    and-int v5, v12, v14

    .line 578
    .line 579
    const/16 v18, 0x0

    .line 580
    .line 581
    :goto_c
    sub-int/2addr v15, v7

    .line 582
    const/16 v19, 0x1

    .line 583
    .line 584
    aget v7, v3, v15

    .line 585
    .line 586
    const/16 v20, 0x20

    .line 587
    .line 588
    and-int v6, v7, v14

    .line 589
    .line 590
    if-ne v6, v5, :cond_18

    .line 591
    .line 592
    aget-object v6, v8, v15

    .line 593
    .line 594
    invoke-static {v1, v6}, LN11Il1;->vaIue(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 595
    .line 596
    .line 597
    move-result v6

    .line 598
    if-eqz v6, :cond_18

    .line 599
    .line 600
    aget-object v1, v9, v15

    .line 601
    .line 602
    aput-object v2, v9, v15

    .line 603
    .line 604
    goto/16 :goto_10

    .line 605
    .line 606
    :cond_18
    and-int v6, v7, v13

    .line 607
    .line 608
    add-int/lit8 v4, v18, 0x1

    .line 609
    .line 610
    if-nez v6, :cond_20

    .line 611
    .line 612
    const/16 v5, 0x9

    .line 613
    .line 614
    if-lt v4, v5, :cond_1c

    .line 615
    .line 616
    invoke-virtual {v0}, Lt11;->POOl()I

    .line 617
    .line 618
    .line 619
    move-result v3

    .line 620
    add-int/lit8 v3, v3, 0x1

    .line 621
    .line 622
    new-instance v4, Ljava/util/LinkedHashMap;

    .line 623
    .line 624
    const/high16 v5, 0x3f800000    # 1.0f

    .line 625
    .line 626
    invoke-direct {v4, v3, v5}, Ljava/util/LinkedHashMap;-><init>(IF)V

    .line 627
    .line 628
    .line 629
    invoke-virtual {v0}, Lt11;->isEmpty()Z

    .line 630
    .line 631
    .line 632
    move-result v3

    .line 633
    const/4 v5, -0x1

    .line 634
    if-eqz v3, :cond_1a

    .line 635
    .line 636
    :cond_19
    const/16 v17, -0x1

    .line 637
    .line 638
    goto :goto_d

    .line 639
    :cond_1a
    const/16 v17, 0x0

    .line 640
    .line 641
    :goto_d
    if-ltz v17, :cond_1b

    .line 642
    .line 643
    invoke-virtual {v0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 644
    .line 645
    .line 646
    move-result-object v3

    .line 647
    aget-object v3, v3, v17

    .line 648
    .line 649
    invoke-virtual {v0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 650
    .line 651
    .line 652
    move-result-object v6

    .line 653
    aget-object v6, v6, v17

    .line 654
    .line 655
    invoke-interface {v4, v3, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 656
    .line 657
    .line 658
    add-int/lit8 v3, v17, 0x1

    .line 659
    .line 660
    iget v6, v0, Lt11;->valuI:I

    .line 661
    .line 662
    if-ge v3, v6, :cond_19

    .line 663
    .line 664
    move/from16 v17, v3

    .line 665
    .line 666
    goto :goto_d

    .line 667
    :cond_1b
    iput-object v4, v0, Lt11;->vaIue:Ljava/lang/Object;

    .line 668
    .line 669
    const/4 v5, 0x0

    .line 670
    iput-object v5, v0, Lt11;->jPos3709:[I

    .line 671
    .line 672
    iput-object v5, v0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 673
    .line 674
    iput-object v5, v0, Lt11;->kQy:[Ljava/lang/Object;

    .line 675
    .line 676
    iget v3, v0, Lt11;->Ialue:I

    .line 677
    .line 678
    add-int/lit8 v3, v3, 0x20

    .line 679
    .line 680
    iput v3, v0, Lt11;->Ialue:I

    .line 681
    .line 682
    invoke-interface {v4, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 683
    .line 684
    .line 685
    move-result-object v1

    .line 686
    goto :goto_10

    .line 687
    :cond_1c
    const/4 v5, 0x0

    .line 688
    if-le v11, v13, :cond_1e

    .line 689
    .line 690
    const/16 v4, 0x20

    .line 691
    .line 692
    if-ge v13, v4, :cond_1d

    .line 693
    .line 694
    const/4 v4, 0x4

    .line 695
    goto :goto_e

    .line 696
    :cond_1d
    const/4 v4, 0x2

    .line 697
    :goto_e
    add-int/lit8 v3, v13, 0x1

    .line 698
    .line 699
    mul-int v3, v3, v4

    .line 700
    .line 701
    invoke-virtual {v0, v13, v3, v12, v10}, Lt11;->iOffset934(IIII)I

    .line 702
    .line 703
    .line 704
    move-result v13

    .line 705
    goto :goto_f

    .line 706
    :cond_1e
    invoke-static {v7, v11, v13}, Lzl1;->Qp_Hp$i_(III)I

    .line 707
    .line 708
    .line 709
    move-result v4

    .line 710
    aput v4, v3, v15

    .line 711
    .line 712
    :goto_f
    invoke-virtual {v0}, Lt11;->yON3x()[I

    .line 713
    .line 714
    .line 715
    move-result-object v3

    .line 716
    array-length v3, v3

    .line 717
    if-le v11, v3, :cond_1f

    .line 718
    .line 719
    ushr-int/lit8 v4, v3, 0x1

    .line 720
    .line 721
    const/4 v7, 0x1

    .line 722
    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    .line 723
    .line 724
    .line 725
    move-result v4

    .line 726
    add-int/2addr v4, v3

    .line 727
    or-int/2addr v4, v7

    .line 728
    const v6, 0x3fffffff    # 1.9999999f

    .line 729
    .line 730
    .line 731
    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    .line 732
    .line 733
    .line 734
    move-result v4

    .line 735
    if-eq v4, v3, :cond_1f

    .line 736
    .line 737
    invoke-virtual {v0}, Lt11;->yON3x()[I

    .line 738
    .line 739
    .line 740
    move-result-object v3

    .line 741
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([II)[I

    .line 742
    .line 743
    .line 744
    move-result-object v3

    .line 745
    iput-object v3, v0, Lt11;->jPos3709:[I

    .line 746
    .line 747
    invoke-virtual {v0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 748
    .line 749
    .line 750
    move-result-object v3

    .line 751
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 752
    .line 753
    .line 754
    move-result-object v3

    .line 755
    iput-object v3, v0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 756
    .line 757
    invoke-virtual {v0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 758
    .line 759
    .line 760
    move-result-object v3

    .line 761
    invoke-static {v3, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 762
    .line 763
    .line 764
    move-result-object v3

    .line 765
    iput-object v3, v0, Lt11;->kQy:[Ljava/lang/Object;

    .line 766
    .line 767
    :cond_1f
    const/4 v15, 0x0

    .line 768
    invoke-static {v12, v15, v13}, Lzl1;->Qp_Hp$i_(III)I

    .line 769
    .line 770
    .line 771
    move-result v3

    .line 772
    invoke-virtual {v0}, Lt11;->yON3x()[I

    .line 773
    .line 774
    .line 775
    move-result-object v4

    .line 776
    aput v3, v4, v10

    .line 777
    .line 778
    invoke-virtual {v0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 779
    .line 780
    .line 781
    move-result-object v3

    .line 782
    aput-object v1, v3, v10

    .line 783
    .line 784
    invoke-virtual {v0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 785
    .line 786
    .line 787
    move-result-object v1

    .line 788
    aput-object v2, v1, v10

    .line 789
    .line 790
    iput v11, v0, Lt11;->valuI:I

    .line 791
    .line 792
    iget v1, v0, Lt11;->Ialue:I

    .line 793
    .line 794
    const/16 v20, 0x20

    .line 795
    .line 796
    add-int/lit8 v1, v1, 0x20

    .line 797
    .line 798
    iput v1, v0, Lt11;->Ialue:I

    .line 799
    .line 800
    move-object v1, v5

    .line 801
    :goto_10
    return-object v1

    .line 802
    :cond_20
    const/16 v21, 0x0

    .line 803
    .line 804
    move/from16 v18, v4

    .line 805
    .line 806
    move v15, v6

    .line 807
    const/16 v6, 0x20

    .line 808
    .line 809
    const/4 v7, 0x1

    .line 810
    goto/16 :goto_c

    .line 811
    .line 812
    nop

    .line 813
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final remove(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {p0, p1}, Lt11;->UC_n_(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    sget-object v0, Lt11;->K0I:Ljava/lang/Object;

    .line 22
    .line 23
    if-ne p1, v0, :cond_1

    .line 24
    .line 25
    const/4 p1, 0x0

    .line 26
    :cond_1
    :goto_0
    return-object p1

    .line 27
    :pswitch_0
    invoke-virtual {p0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    if-eqz v0, :cond_2

    .line 32
    .line 33
    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p1

    .line 37
    goto :goto_1

    .line 38
    :cond_2
    invoke-virtual {p0, p1}, Lt11;->DDù8(Ljava/lang/Object;)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    sget-object v0, Lt11;->kO_6X_:Ljava/lang/Object;

    .line 43
    .line 44
    if-ne p1, v0, :cond_3

    .line 45
    .line 46
    const/4 p1, 0x0

    .line 47
    :cond_3
    :goto_1
    return-object p1

    .line 48
    nop

    .line 49
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public rz__9J_()Ljava/util/Map;
    .locals 2

    .line 1
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    instance-of v1, v0, Ljava/util/Map;

    .line 4
    .line 5
    if-eqz v1, :cond_0

    .line 6
    .line 7
    check-cast v0, Ljava/util/Map;

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_0
    const/4 v0, 0x0

    .line 11
    return-object v0
.end method

.method public sKey7917()Z
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    return v0

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    return v0
.end method

.method public final size()I
    .locals 1

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->pCXDYg()Ljava/util/Map;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    goto :goto_0

    .line 17
    :cond_0
    iget v0, p0, Lt11;->valuI:I

    .line 18
    .line 19
    :goto_0
    return v0

    .line 20
    :pswitch_0
    invoke-virtual {p0}, Lt11;->rz__9J_()Ljava/util/Map;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    if-eqz v0, :cond_1

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    goto :goto_1

    .line 31
    :cond_1
    iget v0, p0, Lt11;->valuI:I

    .line 32
    .line 33
    :goto_1
    return v0

    .line 34
    nop

    .line 35
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public tmpData3485(II)V
    .locals 10

    .line 1
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->yON3x()[I

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {p0}, Lt11;->vaIue()[Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {p0}, Lt11;->jPos3709()[Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {p0}, Lt11;->size()I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    add-int/lit8 v5, v4, -0x1

    .line 23
    .line 24
    const/4 v6, 0x0

    .line 25
    const/4 v7, 0x0

    .line 26
    if-ge p1, v5, :cond_2

    .line 27
    .line 28
    aget-object v8, v2, v5

    .line 29
    .line 30
    aput-object v8, v2, p1

    .line 31
    .line 32
    aget-object v9, v3, v5

    .line 33
    .line 34
    aput-object v9, v3, p1

    .line 35
    .line 36
    aput-object v7, v2, v5

    .line 37
    .line 38
    aput-object v7, v3, v5

    .line 39
    .line 40
    aget v2, v1, v5

    .line 41
    .line 42
    aput v2, v1, p1

    .line 43
    .line 44
    aput v6, v1, v5

    .line 45
    .line 46
    invoke-static {v8}, Lzl1;->sKey6064(Ljava/lang/Object;)I

    .line 47
    .line 48
    .line 49
    move-result v2

    .line 50
    and-int/2addr v2, p2

    .line 51
    invoke-static {v2, v0}, Lzl1;->tzKù7Ol1(ILjava/lang/Object;)I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    if-ne v3, v4, :cond_0

    .line 56
    .line 57
    add-int/lit8 p1, p1, 0x1

    .line 58
    .line 59
    invoke-static {v2, p1, v0}, Lzl1;->ll(IILjava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_0
    :goto_0
    add-int/lit8 v3, v3, -0x1

    .line 64
    .line 65
    aget v0, v1, v3

    .line 66
    .line 67
    and-int v2, v0, p2

    .line 68
    .line 69
    if-ne v2, v4, :cond_1

    .line 70
    .line 71
    add-int/lit8 p1, p1, 0x1

    .line 72
    .line 73
    invoke-static {v0, p1, p2}, Lzl1;->Qp_Hp$i_(III)I

    .line 74
    .line 75
    .line 76
    move-result p1

    .line 77
    aput p1, v1, v3

    .line 78
    .line 79
    return-void

    .line 80
    :cond_1
    move v3, v2

    .line 81
    goto :goto_0

    .line 82
    :cond_2
    aput-object v7, v2, p1

    .line 83
    .line 84
    aput-object v7, v3, p1

    .line 85
    .line 86
    aput v6, v1, p1

    .line 87
    .line 88
    return-void
.end method

.method public vaIue()[Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->iOffset934:[Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public valuI()[Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->kQy:[Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [Ljava/lang/Object;

    .line 7
    .line 8
    return-object v0
.end method

.method public final values()Ljava/util/Collection;
    .locals 2

    .line 1
    iget v0, p0, Lt11;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lt11;->gKey4112:Ljava/util/AbstractCollection;

    .line 7
    .line 8
    check-cast v0, Lc1D;

    .line 9
    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    new-instance v0, Lc1D;

    .line 13
    .line 14
    const/4 v1, 0x3

    .line 15
    invoke-direct {v0, v1, p0}, Lc1D;-><init>(ILjava/io/Serializable;)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lt11;->gKey4112:Ljava/util/AbstractCollection;

    .line 19
    .line 20
    :cond_0
    return-object v0

    .line 21
    :pswitch_0
    iget-object v0, p0, Lt11;->gKey4112:Ljava/util/AbstractCollection;

    .line 22
    .line 23
    check-cast v0, Lc1D;

    .line 24
    .line 25
    if-nez v0, :cond_1

    .line 26
    .line 27
    new-instance v0, Lc1D;

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    invoke-direct {v0, v1, p0}, Lc1D;-><init>(ILjava/io/Serializable;)V

    .line 31
    .line 32
    .line 33
    iput-object v0, p0, Lt11;->gKey4112:Ljava/util/AbstractCollection;

    .line 34
    .line 35
    :cond_1
    return-object v0

    .line 36
    nop

    .line 37
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public yON3x()[I
    .locals 1

    .line 1
    iget-object v0, p0, Lt11;->jPos3709:[I

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    check-cast v0, [I

    .line 7
    .line 8
    return-object v0
.end method

.method public yàÒZ(II)V
    .locals 11

    .line 1
    iget-object v0, p0, Lt11;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lt11;->kQy()[I

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {p0}, Lt11;->Ialue()[Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v2

    .line 14
    invoke-virtual {p0}, Lt11;->valuI()[Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {p0}, Lt11;->size()I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    add-int/lit8 v5, v4, -0x1

    .line 23
    .line 24
    const/4 v6, 0x0

    .line 25
    const/4 v7, 0x0

    .line 26
    if-ge p1, v5, :cond_2

    .line 27
    .line 28
    add-int/lit8 v8, p1, 0x1

    .line 29
    .line 30
    aget-object v9, v2, v5

    .line 31
    .line 32
    aput-object v9, v2, p1

    .line 33
    .line 34
    aget-object v10, v3, v5

    .line 35
    .line 36
    aput-object v10, v3, p1

    .line 37
    .line 38
    aput-object v7, v2, v5

    .line 39
    .line 40
    aput-object v7, v3, v5

    .line 41
    .line 42
    aget v2, v1, v5

    .line 43
    .line 44
    aput v2, v1, p1

    .line 45
    .line 46
    aput v6, v1, v5

    .line 47
    .line 48
    invoke-static {v9}, LvB$7$;->tzKù7Ol1(Ljava/lang/Object;)I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    and-int/2addr p1, p2

    .line 53
    invoke-static {p1, v0}, LIlIIll;->sKey6064(ILjava/lang/Object;)I

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    if-eq v2, v4, :cond_1

    .line 58
    .line 59
    :goto_0
    add-int/lit8 v2, v2, -0x1

    .line 60
    .line 61
    aget p1, v1, v2

    .line 62
    .line 63
    and-int v0, p1, p2

    .line 64
    .line 65
    if-eq v0, v4, :cond_0

    .line 66
    .line 67
    move v2, v0

    .line 68
    goto :goto_0

    .line 69
    :cond_0
    not-int v0, p2

    .line 70
    and-int/2addr p1, v0

    .line 71
    and-int/2addr p2, v8

    .line 72
    or-int/2addr p1, p2

    .line 73
    aput p1, v1, v2

    .line 74
    .line 75
    return-void

    .line 76
    :cond_1
    invoke-static {p1, v8, v0}, LIlIIll;->Oey(IILjava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    return-void

    .line 80
    :cond_2
    aput-object v7, v2, p1

    .line 81
    .line 82
    aput-object v7, v3, p1

    .line 83
    .line 84
    aput v6, v1, p1

    .line 85
    .line 86
    return-void
.end method
