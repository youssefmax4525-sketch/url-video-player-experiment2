.class public final LsKey83;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LXXìMLÙe;


# instance fields
.field public final e8$mp_s$:LWÀyùs;


# direct methods
.method public constructor <init>(LWÀyùs;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LsKey83;->e8$mp_s$:LWÀyùs;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final POOl()Ljava/lang/Object;
    .locals 1

    .line 1
    iget-object v0, p0, LsKey83;->e8$mp_s$:LWÀyùs;

    .line 2
    .line 3
    iget-object v0, v0, LWÀyùs;->valuI:LkData5861;

    .line 4
    .line 5
    return-object v0
.end method
