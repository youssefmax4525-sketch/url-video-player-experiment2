.class public interface abstract LDA_N_;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract execute()Ljava/lang/Object;
.end method
