.class public final Lind1x;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LmSize1518;


# static fields
.field public static final DDù8:Ljava/util/List;

.field public static final sKey7917:Ljava/util/List;


# instance fields
.field public final JKEoÙX:LWÒò;

.field public volatile POOl:LUNRnRNBiy;

.field public final e8$mp_s$:La9$I_FH$;

.field public final rz__9J_:Lgp_T_;

.field public volatile tmpData3485:Z

.field public final waiBKÀ:LoU$_h_;


# direct methods
.method static constructor <clinit>()V
    .locals 12

    .line 1
    const-string v10, ":scheme"

    .line 2
    .line 3
    const-string v11, ":authority"

    .line 4
    .line 5
    const-string v0, "connection"

    .line 6
    .line 7
    const-string v1, "host"

    .line 8
    .line 9
    const-string v2, "keep-alive"

    .line 10
    .line 11
    const-string v3, "proxy-connection"

    .line 12
    .line 13
    const-string v4, "te"

    .line 14
    .line 15
    const-string v5, "transfer-encoding"

    .line 16
    .line 17
    const-string v6, "encoding"

    .line 18
    .line 19
    const-string v7, "upgrade"

    .line 20
    .line 21
    const-string v8, ":method"

    .line 22
    .line 23
    const-string v9, ":path"

    .line 24
    .line 25
    filled-new-array/range {v0 .. v11}, [Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, LyhM_S9$N_;->yON3x([Ljava/lang/Object;)Ljava/util/List;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    sput-object v0, Lind1x;->sKey7917:Ljava/util/List;

    .line 34
    .line 35
    const-string v7, "encoding"

    .line 36
    .line 37
    const-string v8, "upgrade"

    .line 38
    .line 39
    const-string v1, "connection"

    .line 40
    .line 41
    const-string v2, "host"

    .line 42
    .line 43
    const-string v3, "keep-alive"

    .line 44
    .line 45
    const-string v4, "proxy-connection"

    .line 46
    .line 47
    const-string v5, "te"

    .line 48
    .line 49
    const-string v6, "transfer-encoding"

    .line 50
    .line 51
    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    invoke-static {v0}, LyhM_S9$N_;->yON3x([Ljava/lang/Object;)Ljava/util/List;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    sput-object v0, Lind1x;->DDù8:Ljava/util/List;

    .line 60
    .line 61
    return-void
.end method

.method public constructor <init>(LtmpKey8240;La9$I_FH$;LoU$_h_;Lgp_T_;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lind1x;->e8$mp_s$:La9$I_FH$;

    .line 5
    .line 6
    iput-object p3, p0, Lind1x;->waiBKÀ:LoU$_h_;

    .line 7
    .line 8
    iput-object p4, p0, Lind1x;->rz__9J_:Lgp_T_;

    .line 9
    .line 10
    iget-object p1, p1, LtmpKey8240;->gKey4112:Ljava/util/List;

    .line 11
    .line 12
    sget-object p2, LWÒò;->Ialue:LWÒò;

    .line 13
    .line 14
    invoke-interface {p1, p2}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    if-eqz p1, :cond_0

    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_0
    sget-object p2, LWÒò;->kQy:LWÒò;

    .line 22
    .line 23
    :goto_0
    iput-object p2, p0, Lind1x;->JKEoÙX:LWÒò;

    .line 24
    .line 25
    return-void
.end method


# virtual methods
.method public final DDù8()V
    .locals 1

    .line 1
    iget-object v0, p0, Lind1x;->rz__9J_:Lgp_T_;

    .line 2
    .line 3
    invoke-virtual {v0}, Lgp_T_;->flush()V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final JKEoÙX(LQìAQèLa;)J
    .locals 2

    .line 1
    invoke-static {p1}, LWll;->e8$mp_s$(LQìAQèLa;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_0

    .line 6
    .line 7
    const-wide/16 v0, 0x0

    .line 8
    .line 9
    return-wide v0

    .line 10
    :cond_0
    invoke-static {p1}, LyhM_S9$N_;->POOl(LQìAQèLa;)J

    .line 11
    .line 12
    .line 13
    move-result-wide v0

    .line 14
    return-wide v0
.end method

.method public final POOl(L$1lD;J)LXG$Z_M$;
    .locals 0

    .line 1
    iget-object p1, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    iget-object p1, p1, LUNRnRNBiy;->yàÒZ:Lllngth;

    .line 4
    .line 5
    return-object p1
.end method

.method public final cancel()V
    .locals 2

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Lind1x;->tmpData3485:Z

    .line 3
    .line 4
    iget-object v0, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    const/16 v1, 0x9

    .line 9
    .line 10
    invoke-virtual {v0, v1}, LUNRnRNBiy;->JKEoÙX(I)V

    .line 11
    .line 12
    .line 13
    :cond_0
    return-void
.end method

.method public final e8$mp_s$(LQìAQèLa;)LJTZ_Ka$1W_;
    .locals 0

    .line 1
    iget-object p1, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    iget-object p1, p1, LUNRnRNBiy;->pCXDYg:LrQIDlQ;

    .line 4
    .line 5
    return-object p1
.end method

.method public final rz__9J_()Z
    .locals 5

    .line 1
    iget-object v0, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_2

    .line 5
    .line 6
    monitor-enter v0

    .line 7
    :try_start_0
    iget-object v2, v0, LUNRnRNBiy;->pCXDYg:LrQIDlQ;

    .line 8
    .line 9
    iget-boolean v3, v2, LrQIDlQ;->vaIue:Z

    .line 10
    .line 11
    const/4 v4, 0x1

    .line 12
    if-eqz v3, :cond_0

    .line 13
    .line 14
    iget-object v2, v2, LrQIDlQ;->iOffset934:Lslze;

    .line 15
    .line 16
    invoke-virtual {v2}, Lslze;->DDù8()Z

    .line 17
    .line 18
    .line 19
    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 20
    if-eqz v2, :cond_0

    .line 21
    .line 22
    const/4 v2, 0x1

    .line 23
    goto :goto_0

    .line 24
    :catchall_0
    move-exception v1

    .line 25
    goto :goto_1

    .line 26
    :cond_0
    const/4 v2, 0x0

    .line 27
    :goto_0
    monitor-exit v0

    .line 28
    if-ne v2, v4, :cond_1

    .line 29
    .line 30
    return v4

    .line 31
    :cond_1
    return v1

    .line 32
    :goto_1
    monitor-exit v0

    .line 33
    throw v1

    .line 34
    :cond_2
    return v1
.end method

.method public final sKey7917(L$1lD;)V
    .locals 14

    .line 1
    iget-object v0, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p1, L$1lD;->POOl:LvSize4545;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x1

    .line 10
    if-eqz v0, :cond_1

    .line 11
    .line 12
    const/4 v0, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_1
    const/4 v0, 0x0

    .line 15
    :goto_0
    iget-object v3, p1, L$1lD;->rz__9J_:LiIùBuO;

    .line 16
    .line 17
    new-instance v4, Ljava/util/ArrayList;

    .line 18
    .line 19
    invoke-virtual {v3}, LiIùBuO;->size()I

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    add-int/lit8 v5, v5, 0x4

    .line 24
    .line 25
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 26
    .line 27
    .line 28
    new-instance v5, LVOz_u3_;

    .line 29
    .line 30
    sget-object v6, LVOz_u3_;->tmpData3485:LindeO;

    .line 31
    .line 32
    iget-object v7, p1, L$1lD;->waiBKÀ:Ljava/lang/String;

    .line 33
    .line 34
    invoke-direct {v5, v6, v7}, LVOz_u3_;-><init>(LindeO;Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    new-instance v5, LVOz_u3_;

    .line 41
    .line 42
    sget-object v6, LVOz_u3_;->sKey7917:LindeO;

    .line 43
    .line 44
    iget-object p1, p1, L$1lD;->e8$mp_s$:LUu_Kn$K_;

    .line 45
    .line 46
    invoke-virtual {p1}, LUu_Kn$K_;->waiBKÀ()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object v7

    .line 50
    invoke-virtual {p1}, LUu_Kn$K_;->POOl()Ljava/lang/String;

    .line 51
    .line 52
    .line 53
    move-result-object v8

    .line 54
    if-eqz v8, :cond_2

    .line 55
    .line 56
    new-instance v9, Ljava/lang/StringBuilder;

    .line 57
    .line 58
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 59
    .line 60
    .line 61
    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 62
    .line 63
    .line 64
    const/16 v7, 0x3f

    .line 65
    .line 66
    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v7

    .line 76
    :cond_2
    invoke-direct {v5, v6, v7}, LVOz_u3_;-><init>(LindeO;Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    const-string v5, "Host"

    .line 83
    .line 84
    invoke-virtual {v3, v5}, LiIùBuO;->e8$mp_s$(Ljava/lang/String;)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v5

    .line 88
    if-eqz v5, :cond_3

    .line 89
    .line 90
    new-instance v6, LVOz_u3_;

    .line 91
    .line 92
    sget-object v7, LVOz_u3_;->yON3x:LindeO;

    .line 93
    .line 94
    invoke-direct {v6, v7, v5}, LVOz_u3_;-><init>(LindeO;Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    :cond_3
    new-instance v5, LVOz_u3_;

    .line 101
    .line 102
    sget-object v6, LVOz_u3_;->DDù8:LindeO;

    .line 103
    .line 104
    iget-object p1, p1, LUu_Kn$K_;->e8$mp_s$:Ljava/lang/String;

    .line 105
    .line 106
    invoke-direct {v5, v6, p1}, LVOz_u3_;-><init>(LindeO;Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 110
    .line 111
    .line 112
    invoke-virtual {v3}, LiIùBuO;->size()I

    .line 113
    .line 114
    .line 115
    move-result p1

    .line 116
    const/4 v5, 0x0

    .line 117
    :goto_1
    if-ge v5, p1, :cond_6

    .line 118
    .line 119
    invoke-virtual {v3, v5}, LiIùBuO;->rz__9J_(I)Ljava/lang/String;

    .line 120
    .line 121
    .line 122
    move-result-object v6

    .line 123
    sget-object v7, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 124
    .line 125
    const-string v8, "US"

    .line 126
    .line 127
    invoke-static {v8, v7}, LdbÙLJ;->sKey7917(Ljava/lang/String;Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {v6, v7}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v6

    .line 134
    const-string v7, "toLowerCase(...)"

    .line 135
    .line 136
    invoke-static {v7, v6}, LdbÙLJ;->sKey7917(Ljava/lang/String;Ljava/lang/Object;)V

    .line 137
    .line 138
    .line 139
    sget-object v7, Lind1x;->sKey7917:Ljava/util/List;

    .line 140
    .line 141
    invoke-interface {v7, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v7

    .line 145
    if-eqz v7, :cond_4

    .line 146
    .line 147
    const-string v7, "te"

    .line 148
    .line 149
    invoke-virtual {v6, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 150
    .line 151
    .line 152
    move-result v7

    .line 153
    if-eqz v7, :cond_5

    .line 154
    .line 155
    invoke-virtual {v3, v5}, LiIùBuO;->sKey7917(I)Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object v7

    .line 159
    const-string v8, "trailers"

    .line 160
    .line 161
    invoke-virtual {v7, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v7

    .line 165
    if-eqz v7, :cond_5

    .line 166
    .line 167
    :cond_4
    new-instance v7, LVOz_u3_;

    .line 168
    .line 169
    invoke-virtual {v3, v5}, LiIùBuO;->sKey7917(I)Ljava/lang/String;

    .line 170
    .line 171
    .line 172
    move-result-object v8

    .line 173
    invoke-direct {v7, v6, v8}, LVOz_u3_;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    :cond_5
    add-int/lit8 v5, v5, 0x1

    .line 180
    .line 181
    goto :goto_1

    .line 182
    :cond_6
    iget-object v8, p0, Lind1x;->rz__9J_:Lgp_T_;

    .line 183
    .line 184
    xor-int/lit8 v9, v0, 0x1

    .line 185
    .line 186
    iget-object p1, v8, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 187
    .line 188
    monitor-enter p1

    .line 189
    :try_start_0
    monitor-enter v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 190
    :try_start_1
    iget v3, v8, Lgp_T_;->kQy:I

    .line 191
    .line 192
    const v5, 0x3fffffff    # 1.9999999f

    .line 193
    .line 194
    .line 195
    if-le v3, v5, :cond_7

    .line 196
    .line 197
    const/16 v3, 0x8

    .line 198
    .line 199
    invoke-virtual {v8, v3}, Lgp_T_;->Ialue(I)V

    .line 200
    .line 201
    .line 202
    goto :goto_2

    .line 203
    :catchall_0
    move-exception v0

    .line 204
    goto/16 :goto_3

    .line 205
    .line 206
    :cond_7
    :goto_2
    iget-boolean v3, v8, Lgp_T_;->Ialue:Z

    .line 207
    .line 208
    if-nez v3, :cond_d

    .line 209
    .line 210
    iget v7, v8, Lgp_T_;->kQy:I

    .line 211
    .line 212
    add-int/lit8 v3, v7, 0x2

    .line 213
    .line 214
    iput v3, v8, Lgp_T_;->kQy:I

    .line 215
    .line 216
    new-instance v6, LUNRnRNBiy;

    .line 217
    .line 218
    const/4 v11, 0x0

    .line 219
    const/4 v10, 0x0

    .line 220
    invoke-direct/range {v6 .. v11}, LUNRnRNBiy;-><init>(ILgp_T_;ZZLiIùBuO;)V

    .line 221
    .line 222
    .line 223
    if-eqz v0, :cond_8

    .line 224
    .line 225
    iget-wide v10, v8, Lgp_T_;->tzKù7Ol1:J

    .line 226
    .line 227
    iget-wide v12, v8, Lgp_T_;->ll:J

    .line 228
    .line 229
    cmp-long v0, v10, v12

    .line 230
    .line 231
    if-gez v0, :cond_8

    .line 232
    .line 233
    iget-wide v10, v6, LUNRnRNBiy;->iOffset934:J

    .line 234
    .line 235
    iget-wide v12, v6, LUNRnRNBiy;->kQy:J

    .line 236
    .line 237
    cmp-long v0, v10, v12

    .line 238
    .line 239
    if-ltz v0, :cond_9

    .line 240
    .line 241
    :cond_8
    const/4 v1, 0x1

    .line 242
    :cond_9
    invoke-virtual {v6}, LUNRnRNBiy;->DDù8()Z

    .line 243
    .line 244
    .line 245
    move-result v0

    .line 246
    if-eqz v0, :cond_a

    .line 247
    .line 248
    iget-object v0, v8, Lgp_T_;->vaIue:Ljava/util/LinkedHashMap;

    .line 249
    .line 250
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 251
    .line 252
    .line 253
    move-result-object v2

    .line 254
    invoke-interface {v0, v2, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 255
    .line 256
    .line 257
    :cond_a
    :try_start_2
    monitor-exit v8

    .line 258
    iget-object v0, v8, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 259
    .line 260
    invoke-virtual {v0, v9, v7, v4}, LoìMB;->Ialue(ZILjava/util/ArrayList;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 261
    .line 262
    .line 263
    monitor-exit p1

    .line 264
    if-eqz v1, :cond_b

    .line 265
    .line 266
    iget-object p1, v8, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 267
    .line 268
    invoke-virtual {p1}, LoìMB;->flush()V

    .line 269
    .line 270
    .line 271
    :cond_b
    iput-object v6, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 272
    .line 273
    iget-boolean p1, p0, Lind1x;->tmpData3485:Z

    .line 274
    .line 275
    if-nez p1, :cond_c

    .line 276
    .line 277
    iget-object p1, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 278
    .line 279
    iget-object p1, p1, LUNRnRNBiy;->gKey4112:LisKey863;

    .line 280
    .line 281
    iget-object v0, p0, Lind1x;->waiBKÀ:LoU$_h_;

    .line 282
    .line 283
    iget v0, v0, LoU$_h_;->sKey7917:I

    .line 284
    .line 285
    int-to-long v0, v0

    .line 286
    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 287
    .line 288
    invoke-virtual {p1, v0, v1}, LSÌÙò9;->sKey7917(J)LSÌÙò9;

    .line 289
    .line 290
    .line 291
    iget-object p1, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 292
    .line 293
    iget-object p1, p1, LUNRnRNBiy;->kO_6X_:LisKey863;

    .line 294
    .line 295
    iget-object v0, p0, Lind1x;->waiBKÀ:LoU$_h_;

    .line 296
    .line 297
    iget v0, v0, LoU$_h_;->DDù8:I

    .line 298
    .line 299
    int-to-long v0, v0

    .line 300
    invoke-virtual {p1, v0, v1}, LSÌÙò9;->sKey7917(J)LSÌÙò9;

    .line 301
    .line 302
    .line 303
    return-void

    .line 304
    :cond_c
    iget-object p1, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 305
    .line 306
    const/16 v0, 0x9

    .line 307
    .line 308
    invoke-virtual {p1, v0}, LUNRnRNBiy;->JKEoÙX(I)V

    .line 309
    .line 310
    .line 311
    new-instance p1, Ljava/io/IOException;

    .line 312
    .line 313
    const-string v0, "Canceled"

    .line 314
    .line 315
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 316
    .line 317
    .line 318
    throw p1

    .line 319
    :catchall_1
    move-exception v0

    .line 320
    goto :goto_4

    .line 321
    :cond_d
    :try_start_3
    new-instance v0, LnData4392;

    .line 322
    .line 323
    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    .line 324
    .line 325
    .line 326
    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    .line 327
    :goto_3
    :try_start_4
    monitor-exit v8

    .line 328
    throw v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 329
    :goto_4
    monitor-exit p1

    .line 330
    throw v0
.end method

.method public final tmpData3485(Z)LUX$zx$;
    .locals 11

    .line 1
    iget-object v0, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    if-eqz v0, :cond_f

    .line 4
    .line 5
    monitor-enter v0

    .line 6
    :cond_0
    :goto_0
    :try_start_0
    iget-object v1, v0, LUNRnRNBiy;->Ialue:Ljava/util/ArrayDeque;

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    const/4 v2, 0x0

    .line 13
    if-eqz v1, :cond_7

    .line 14
    .line 15
    invoke-virtual {v0}, LUNRnRNBiy;->tmpData3485()I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-nez v1, :cond_7

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    if-nez p1, :cond_3

    .line 23
    .line 24
    iget-object v3, v0, LUNRnRNBiy;->vaIue:Lgp_T_;

    .line 25
    .line 26
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    iget-object v3, v0, LUNRnRNBiy;->yàÒZ:Lllngth;

    .line 30
    .line 31
    iget-boolean v4, v3, Lllngth;->jPos3709:Z

    .line 32
    .line 33
    if-nez v4, :cond_2

    .line 34
    .line 35
    iget-boolean v3, v3, Lllngth;->yON3x:Z

    .line 36
    .line 37
    if-eqz v3, :cond_1

    .line 38
    .line 39
    goto :goto_1

    .line 40
    :cond_1
    const/4 v3, 0x0

    .line 41
    goto :goto_2

    .line 42
    :cond_2
    :goto_1
    const/4 v3, 0x1

    .line 43
    :goto_2
    if-eqz v3, :cond_4

    .line 44
    .line 45
    :cond_3
    const/4 v2, 0x1

    .line 46
    :cond_4
    if-eqz v2, :cond_5

    .line 47
    .line 48
    iget-object v1, v0, LUNRnRNBiy;->gKey4112:LisKey863;

    .line 49
    .line 50
    invoke-virtual {v1}, LwQ1l;->DDù8()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 51
    .line 52
    .line 53
    goto :goto_3

    .line 54
    :catchall_0
    move-exception p1

    .line 55
    goto/16 :goto_8

    .line 56
    .line 57
    :cond_5
    :goto_3
    :try_start_1
    invoke-virtual {v0}, Ljava/lang/Object;->wait()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    .line 58
    .line 59
    .line 60
    if-eqz v2, :cond_0

    .line 61
    .line 62
    :try_start_2
    iget-object v1, v0, LUNRnRNBiy;->gKey4112:LisKey863;

    .line 63
    .line 64
    invoke-virtual {v1}, LisKey863;->iOffset934()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 65
    .line 66
    .line 67
    goto :goto_0

    .line 68
    :catchall_1
    move-exception p1

    .line 69
    goto :goto_4

    .line 70
    :catch_0
    :try_start_3
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    invoke-virtual {p1}, Ljava/lang/Thread;->interrupt()V

    .line 75
    .line 76
    .line 77
    new-instance p1, Ljava/io/InterruptedIOException;

    .line 78
    .line 79
    invoke-direct {p1}, Ljava/io/InterruptedIOException;-><init>()V

    .line 80
    .line 81
    .line 82
    throw p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 83
    :goto_4
    if-eqz v2, :cond_6

    .line 84
    .line 85
    :try_start_4
    iget-object v1, v0, LUNRnRNBiy;->gKey4112:LisKey863;

    .line 86
    .line 87
    invoke-virtual {v1}, LisKey863;->iOffset934()V

    .line 88
    .line 89
    .line 90
    :cond_6
    throw p1

    .line 91
    :cond_7
    iget-object v1, v0, LUNRnRNBiy;->Ialue:Ljava/util/ArrayDeque;

    .line 92
    .line 93
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->isEmpty()Z

    .line 94
    .line 95
    .line 96
    move-result v1

    .line 97
    if-nez v1, :cond_d

    .line 98
    .line 99
    iget-object v1, v0, LUNRnRNBiy;->Ialue:Ljava/util/ArrayDeque;

    .line 100
    .line 101
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->removeFirst()Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object v1

    .line 105
    const-string v3, "removeFirst(...)"

    .line 106
    .line 107
    invoke-static {v3, v1}, LdbÙLJ;->sKey7917(Ljava/lang/String;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    check-cast v1, LiIùBuO;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    .line 111
    .line 112
    monitor-exit v0

    .line 113
    iget-object v0, p0, Lind1x;->JKEoÙX:LWÒò;

    .line 114
    .line 115
    new-instance v3, Ljava/util/ArrayList;

    .line 116
    .line 117
    const/16 v4, 0x14

    .line 118
    .line 119
    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v1}, LiIùBuO;->size()I

    .line 123
    .line 124
    .line 125
    move-result v4

    .line 126
    const/4 v5, 0x0

    .line 127
    move-object v7, v5

    .line 128
    const/4 v6, 0x0

    .line 129
    :goto_5
    if-ge v6, v4, :cond_a

    .line 130
    .line 131
    invoke-virtual {v1, v6}, LiIùBuO;->rz__9J_(I)Ljava/lang/String;

    .line 132
    .line 133
    .line 134
    move-result-object v8

    .line 135
    invoke-virtual {v1, v6}, LiIùBuO;->sKey7917(I)Ljava/lang/String;

    .line 136
    .line 137
    .line 138
    move-result-object v9

    .line 139
    const-string v10, ":status"

    .line 140
    .line 141
    invoke-virtual {v8, v10}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 142
    .line 143
    .line 144
    move-result v10

    .line 145
    if-eqz v10, :cond_8

    .line 146
    .line 147
    const-string v7, "HTTP/1.1 "

    .line 148
    .line 149
    invoke-virtual {v7, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 150
    .line 151
    .line 152
    move-result-object v7

    .line 153
    invoke-static {v7}, LQ6$k$;->valuI(Ljava/lang/String;)LvSize4545;

    .line 154
    .line 155
    .line 156
    move-result-object v7

    .line 157
    goto :goto_6

    .line 158
    :cond_8
    sget-object v10, Lind1x;->DDù8:Ljava/util/List;

    .line 159
    .line 160
    invoke-interface {v10, v8}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 161
    .line 162
    .line 163
    move-result v10

    .line 164
    if-nez v10, :cond_9

    .line 165
    .line 166
    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 167
    .line 168
    .line 169
    invoke-static {v9}, LKSÙVÌJj;->inlex(Ljava/lang/String;)Ljava/lang/CharSequence;

    .line 170
    .line 171
    .line 172
    move-result-object v8

    .line 173
    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 174
    .line 175
    .line 176
    move-result-object v8

    .line 177
    invoke-virtual {v3, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 178
    .line 179
    .line 180
    :cond_9
    :goto_6
    add-int/lit8 v6, v6, 0x1

    .line 181
    .line 182
    goto :goto_5

    .line 183
    :cond_a
    if-eqz v7, :cond_c

    .line 184
    .line 185
    new-instance v1, LUX$zx$;

    .line 186
    .line 187
    invoke-direct {v1}, LUX$zx$;-><init>()V

    .line 188
    .line 189
    .line 190
    iput-object v0, v1, LUX$zx$;->waiBKÀ:LWÒò;

    .line 191
    .line 192
    iget v0, v7, LvSize4545;->vaIue:I

    .line 193
    .line 194
    iput v0, v1, LUX$zx$;->rz__9J_:I

    .line 195
    .line 196
    iget-object v0, v7, LvSize4545;->iOffset934:Ljava/lang/Object;

    .line 197
    .line 198
    check-cast v0, Ljava/lang/String;

    .line 199
    .line 200
    iput-object v0, v1, LUX$zx$;->POOl:Ljava/lang/String;

    .line 201
    .line 202
    new-array v0, v2, [Ljava/lang/String;

    .line 203
    .line 204
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    check-cast v0, [Ljava/lang/String;

    .line 209
    .line 210
    new-instance v2, LCÌaxKk;

    .line 211
    .line 212
    const/4 v3, 0x7

    .line 213
    invoke-direct {v2, v3}, LCÌaxKk;-><init>(I)V

    .line 214
    .line 215
    .line 216
    iget-object v3, v2, LCÌaxKk;->vaIue:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast v3, Ljava/util/ArrayList;

    .line 219
    .line 220
    invoke-static {v0}, LmÒxeI;->BCIm([Ljava/lang/Object;)Ljava/util/List;

    .line 221
    .line 222
    .line 223
    move-result-object v0

    .line 224
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 225
    .line 226
    .line 227
    iput-object v2, v1, LUX$zx$;->tmpData3485:LCÌaxKk;

    .line 228
    .line 229
    if-eqz p1, :cond_b

    .line 230
    .line 231
    iget p1, v1, LUX$zx$;->rz__9J_:I

    .line 232
    .line 233
    const/16 v0, 0x64

    .line 234
    .line 235
    if-ne p1, v0, :cond_b

    .line 236
    .line 237
    return-object v5

    .line 238
    :cond_b
    return-object v1

    .line 239
    :cond_c
    new-instance p1, Ljava/net/ProtocolException;

    .line 240
    .line 241
    const-string v0, "Expected \':status\' header not present"

    .line 242
    .line 243
    invoke-direct {p1, v0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    .line 244
    .line 245
    .line 246
    throw p1

    .line 247
    :cond_d
    :try_start_5
    iget-object p1, v0, LUNRnRNBiy;->Qp_Hp$i_:Ljava/io/IOException;

    .line 248
    .line 249
    if-eqz p1, :cond_e

    .line 250
    .line 251
    goto :goto_7

    .line 252
    :cond_e
    new-instance p1, LiIndex5728;

    .line 253
    .line 254
    invoke-virtual {v0}, LUNRnRNBiy;->tmpData3485()I

    .line 255
    .line 256
    .line 257
    move-result v1

    .line 258
    invoke-direct {p1, v1}, LiIndex5728;-><init>(I)V

    .line 259
    .line 260
    .line 261
    :goto_7
    throw p1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    .line 262
    :goto_8
    monitor-exit v0

    .line 263
    throw p1

    .line 264
    :cond_f
    new-instance p1, Ljava/io/IOException;

    .line 265
    .line 266
    const-string v0, "stream wasn\'t created"

    .line 267
    .line 268
    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 269
    .line 270
    .line 271
    throw p1
.end method

.method public final vaIue()LVB8J;
    .locals 1

    .line 1
    iget-object v0, p0, Lind1x;->e8$mp_s$:La9$I_FH$;

    .line 2
    .line 3
    return-object v0
.end method

.method public final waiBKÀ()V
    .locals 1

    .line 1
    iget-object v0, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    iget-object v0, v0, LUNRnRNBiy;->yàÒZ:Lllngth;

    .line 4
    .line 5
    invoke-virtual {v0}, Lllngth;->close()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final yON3x()Lpòk5PD8;
    .locals 1

    .line 1
    iget-object v0, p0, Lind1x;->POOl:LUNRnRNBiy;

    .line 2
    .line 3
    return-object v0
.end method
