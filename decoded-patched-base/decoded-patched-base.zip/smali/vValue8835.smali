.class public final synthetic LvValue8835;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LbD0DID;


# instance fields
.field public final synthetic vaIue:Ljava/lang/Object;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LvValue8835;->yON3x:I

    iput-object p2, p0, LvValue8835;->vaIue:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LvValue8835;->yON3x:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LvValue8835;->vaIue:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    return-object v0

    :pswitch_0
    iget-object v0, p0, LvValue8835;->vaIue:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/trackselection/TrackSelector;

    invoke-static {v0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->kQy(Landroidx/media3/exoplayer/trackselection/TrackSelector;)Landroidx/media3/exoplayer/trackselection/TrackSelector;

    move-result-object v0

    return-object v0

    :pswitch_1
    iget-object v0, p0, LvValue8835;->vaIue:Ljava/lang/Object;

    check-cast v0, Landroidx/media3/exoplayer/trackselection/TrackSelector;

    invoke-static {v0}, Landroidx/media3/exoplayer/ExoPlayer$Builder;->kO_6X_(Landroidx/media3/exoplayer/trackselection/TrackSelector;)Landroidx/media3/exoplayer/trackselection/TrackSelector;

    move-result-object v0

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
