.class public final LJ11D;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LT4_Mx$be_;
.implements LT9R$JI_p4$;
.implements LUQD;
.implements Lul0I0;
.implements LkItem6218;
.implements LyBs$K_2$;
.implements LnA$3g_00$;
.implements LbesqìA;
.implements LhasKey5903;
.implements LsData8261;
.implements LtmpOffset2707;
.implements LO9q$c$;


# instance fields
.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LJ11D;->yON3x:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(LAM$cR$;)V
    .locals 0

    const/4 p1, 0x5

    iput p1, p0, LJ11D;->yON3x:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static Ialue(Landroid/content/Context;)Z
    .locals 3

    .line 1
    sget-object v0, LisIndex2415;->IIl:LSdE$n$;

    .line 2
    .line 3
    sget-object v1, LIl1il;->POOl:LIl1il;

    .line 4
    .line 5
    iget-object v1, v1, LIl1il;->rz__9J_:LnCount1076;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    const-string p0, "Omid flag is disabled"

    .line 21
    .line 22
    invoke-static {p0}, LPJNypàa;->po0(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    return v1

    .line 26
    :cond_0
    new-instance v0, LnqmY$qt;

    .line 27
    .line 28
    const/4 v2, 0x3

    .line 29
    invoke-direct {v0, p0, v2}, LnqmY$qt;-><init>(Landroid/content/Context;I)V

    .line 30
    .line 31
    .line 32
    :try_start_0
    invoke-virtual {v0}, LnqmY$qt;->e8$mp_s$()Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object p0
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    goto :goto_0

    .line 37
    :catch_0
    move-exception p0

    .line 38
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 39
    .line 40
    iget-object v0, v0, LvItem598;->sKey7917:LNl;

    .line 41
    .line 42
    const-string v2, "omid exception"

    .line 43
    .line 44
    invoke-virtual {v0, v2, p0}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 45
    .line 46
    .line 47
    const/4 p0, 0x0

    .line 48
    :goto_0
    check-cast p0, Ljava/lang/Boolean;

    .line 49
    .line 50
    if-eqz p0, :cond_1

    .line 51
    .line 52
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 53
    .line 54
    .line 55
    move-result p0

    .line 56
    if-eqz p0, :cond_1

    .line 57
    .line 58
    const/4 p0, 0x1

    .line 59
    return p0

    .line 60
    :cond_1
    return v1
.end method

.method public static JKEoÙX(IILandroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)LtmpCount6784;
    .locals 9

    .line 1
    sget-object v0, LisIndex2415;->IIl:LSdE$n$;

    .line 2
    .line 3
    sget-object v1, LIl1il;->POOl:LIl1il;

    .line 4
    .line 5
    iget-object v1, v1, LIl1il;->rz__9J_:LnCount1076;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x0

    .line 18
    if-eqz v0, :cond_1

    .line 19
    .line 20
    sget-object v0, LIlIIll;->sKey7917:LmSize5576;

    .line 21
    .line 22
    iget-boolean v0, v0, LmSize5576;->vaIue:Z

    .line 23
    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    goto :goto_1

    .line 27
    :cond_0
    new-instance v2, L$àvàjXs;

    .line 28
    .line 29
    move v4, p0

    .line 30
    move v3, p1

    .line 31
    move-object v5, p2

    .line 32
    move-object v6, p3

    .line 33
    move-object v7, p4

    .line 34
    move-object v8, p5

    .line 35
    invoke-direct/range {v2 .. v8}, L$àvàjXs;-><init>(IILandroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    :try_start_0
    invoke-virtual {v2}, L$àvàjXs;->e8$mp_s$()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    goto :goto_0

    .line 43
    :catch_0
    move-exception v0

    .line 44
    move-object p0, v0

    .line 45
    sget-object p1, LvItem598;->tzKù7Ol1:LvItem598;

    .line 46
    .line 47
    iget-object p1, p1, LvItem598;->sKey7917:LNl;

    .line 48
    .line 49
    const-string p2, "omid exception"

    .line 50
    .line 51
    invoke-virtual {p1, p2, p0}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 52
    .line 53
    .line 54
    :goto_0
    check-cast v1, LtmpCount6784;

    .line 55
    .line 56
    :cond_1
    :goto_1
    return-object v1
.end method

.method public static final gKey4112(Ljava/lang/Runnable;)V
    .locals 2

    .line 1
    :try_start_0
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 2
    .line 3
    .line 4
    return-void

    .line 5
    :catch_0
    move-exception p0

    .line 6
    sget-object v0, LvItem598;->tzKù7Ol1:LvItem598;

    .line 7
    .line 8
    iget-object v0, v0, LvItem598;->sKey7917:LNl;

    .line 9
    .line 10
    const-string v1, "omid exception"

    .line 11
    .line 12
    invoke-virtual {v0, v1, p0}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public static iOffset934(LSQDQ0l;)V
    .locals 2

    .line 1
    sget-object v0, LisIndex2415;->IIl:LSdE$n$;

    .line 2
    .line 3
    sget-object v1, LIl1il;->POOl:LIl1il;

    .line 4
    .line 5
    iget-object v1, v1, LIl1il;->rz__9J_:LnCount1076;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    sget-object v0, LIlIIll;->sKey7917:LmSize5576;

    .line 20
    .line 21
    iget-boolean v0, v0, LmSize5576;->vaIue:Z

    .line 22
    .line 23
    if-nez v0, :cond_0

    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_0
    new-instance v0, LvàÙfXl;

    .line 27
    .line 28
    const/4 v1, 0x0

    .line 29
    invoke-direct {v0, p0, v1}, LvàÙfXl;-><init>(LSQDQ0l;I)V

    .line 30
    .line 31
    .line 32
    invoke-static {v0}, LJ11D;->gKey4112(Ljava/lang/Runnable;)V

    .line 33
    .line 34
    .line 35
    :cond_1
    :goto_0
    return-void
.end method

.method public static jPos3709(LSQDQ0l;Landroid/view/View;)V
    .locals 2

    .line 1
    new-instance v0, LfnXtaxx;

    .line 2
    .line 3
    const/4 v1, 0x6

    .line 4
    invoke-direct {v0, v1, p0, p1}, LfnXtaxx;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    invoke-static {v0}, LJ11D;->gKey4112(Ljava/lang/Runnable;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public static pCXDYg(Ljava/lang/String;)L$x_6_;
    .locals 4

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, -0x41cfa846

    .line 6
    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    const/4 v3, 0x2

    .line 10
    if-eq v0, v1, :cond_2

    .line 11
    .line 12
    const v1, 0x4e906dcd

    .line 13
    .line 14
    .line 15
    if-eq v0, v1, :cond_1

    .line 16
    .line 17
    const v1, 0x768243c0

    .line 18
    .line 19
    .line 20
    if-eq v0, v1, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const-string v0, "onePixel"

    .line 24
    .line 25
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-eqz p0, :cond_3

    .line 30
    .line 31
    const/4 p0, 0x2

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    const-string v0, "definedByJavascript"

    .line 34
    .line 35
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    if-eqz p0, :cond_3

    .line 40
    .line 41
    const/4 p0, 0x1

    .line 42
    goto :goto_1

    .line 43
    :cond_2
    const-string v0, "beginToRender"

    .line 44
    .line 45
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result p0

    .line 49
    if-eqz p0, :cond_3

    .line 50
    .line 51
    const/4 p0, 0x0

    .line 52
    goto :goto_1

    .line 53
    :cond_3
    :goto_0
    const/4 p0, -0x1

    .line 54
    :goto_1
    if-eqz p0, :cond_6

    .line 55
    .line 56
    if-eq p0, v2, :cond_5

    .line 57
    .line 58
    if-eq p0, v3, :cond_4

    .line 59
    .line 60
    sget-object p0, L$x_6_;->jPos3709:L$x_6_;

    .line 61
    .line 62
    return-object p0

    .line 63
    :cond_4
    sget-object p0, L$x_6_;->kQy:L$x_6_;

    .line 64
    .line 65
    return-object p0

    .line 66
    :cond_5
    sget-object p0, L$x_6_;->vaIue:L$x_6_;

    .line 67
    .line 68
    return-object p0

    .line 69
    :cond_6
    sget-object p0, L$x_6_;->iOffset934:L$x_6_;

    .line 70
    .line 71
    return-object p0
.end method

.method public static sKey7917(LxED$DU_3A$;Landroid/webkit/WebView;)LKkmORP;
    .locals 2

    .line 1
    :try_start_0
    iget v0, p0, LxED$DU_3A$;->vaIue:I

    .line 2
    .line 3
    iget p0, p0, LxED$DU_3A$;->jPos3709:I

    .line 4
    .line 5
    new-instance v1, Ljava/lang/StringBuilder;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v0, "."

    .line 14
    .line 15
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 19
    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object p0

    .line 25
    const-string v0, "Google"

    .line 26
    .line 27
    invoke-static {v0, p0}, LkData4393;->e8$mp_s$(Ljava/lang/String;Ljava/lang/String;)LkData4393;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    new-instance v0, LKkmORP;

    .line 32
    .line 33
    invoke-direct {v0, p0, p1}, LKkmORP;-><init>(LkData4393;Landroid/webkit/WebView;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 34
    .line 35
    .line 36
    return-object v0

    .line 37
    :catch_0
    move-exception p0

    .line 38
    sget-object p1, LvItem598;->tzKù7Ol1:LvItem598;

    .line 39
    .line 40
    iget-object p1, p1, LvItem598;->sKey7917:LNl;

    .line 41
    .line 42
    const-string v0, "omid exception"

    .line 43
    .line 44
    invoke-virtual {p1, v0, p0}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 45
    .line 46
    .line 47
    const/4 p0, 0x0

    .line 48
    return-object p0
.end method

.method public static vaIue()Ljava/lang/String;
    .locals 4

    .line 1
    sget-object v0, LisIndex2415;->IIl:LSdE$n$;

    .line 2
    .line 3
    sget-object v1, LIl1il;->POOl:LIl1il;

    .line 4
    .line 5
    iget-object v1, v1, LIl1il;->rz__9J_:LnCount1076;

    .line 6
    .line 7
    invoke-virtual {v1, v0}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    check-cast v0, Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    const/4 v1, 0x0

    .line 18
    if-nez v0, :cond_0

    .line 19
    .line 20
    return-object v1

    .line 21
    :cond_0
    :try_start_0
    const-string v0, "a.1.5.2-google_20241009"
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    .line 23
    return-object v0

    .line 24
    :catch_0
    move-exception v0

    .line 25
    sget-object v2, LvItem598;->tzKù7Ol1:LvItem598;

    .line 26
    .line 27
    iget-object v2, v2, LvItem598;->sKey7917:LNl;

    .line 28
    .line 29
    const-string v3, "omid exception"

    .line 30
    .line 31
    invoke-virtual {v2, v3, v0}, LNl;->DDù8(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 32
    .line 33
    .line 34
    return-object v1
.end method

.method public static valuI(Ljava/lang/String;)LgValue655;
    .locals 4

    .line 1
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, -0x16d03d69

    .line 6
    .line 7
    .line 8
    const/4 v2, 0x2

    .line 9
    const/4 v3, 0x1

    .line 10
    if-eq v0, v1, :cond_2

    .line 11
    .line 12
    const v1, 0x6b0147b

    .line 13
    .line 14
    .line 15
    if-eq v0, v1, :cond_1

    .line 16
    .line 17
    const v1, 0x2a9c68ab

    .line 18
    .line 19
    .line 20
    if-eq v0, v1, :cond_0

    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const-string v0, "nativeDisplay"

    .line 24
    .line 25
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 26
    .line 27
    .line 28
    move-result p0

    .line 29
    if-eqz p0, :cond_3

    .line 30
    .line 31
    const/4 p0, 0x1

    .line 32
    goto :goto_1

    .line 33
    :cond_1
    const-string v0, "video"

    .line 34
    .line 35
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    if-eqz p0, :cond_3

    .line 40
    .line 41
    const/4 p0, 0x2

    .line 42
    goto :goto_1

    .line 43
    :cond_2
    const-string v0, "htmlDisplay"

    .line 44
    .line 45
    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 46
    .line 47
    .line 48
    move-result p0

    .line 49
    if-eqz p0, :cond_3

    .line 50
    .line 51
    const/4 p0, 0x0

    .line 52
    goto :goto_1

    .line 53
    :cond_3
    :goto_0
    const/4 p0, -0x1

    .line 54
    :goto_1
    if-eqz p0, :cond_6

    .line 55
    .line 56
    if-eq p0, v3, :cond_5

    .line 57
    .line 58
    if-eq p0, v2, :cond_4

    .line 59
    .line 60
    const/4 p0, 0x0

    .line 61
    return-object p0

    .line 62
    :cond_4
    sget-object p0, LgValue655;->kQy:LgValue655;

    .line 63
    .line 64
    return-object p0

    .line 65
    :cond_5
    sget-object p0, LgValue655;->iOffset934:LgValue655;

    .line 66
    .line 67
    return-object p0

    .line 68
    :cond_6
    sget-object p0, LgValue655;->jPos3709:LgValue655;

    .line 69
    .line 70
    return-object p0
.end method

.method public static yàÒZ(Ljava/lang/String;)LazsàS9l;
    .locals 1

    .line 1
    const-string v0, "native"

    .line 2
    .line 3
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    sget-object p0, LazsàS9l;->vaIue:LazsàS9l;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_0
    const-string v0, "javascript"

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    if-eqz p0, :cond_1

    .line 19
    .line 20
    sget-object p0, LazsàS9l;->jPos3709:LazsàS9l;

    .line 21
    .line 22
    return-object p0

    .line 23
    :cond_1
    sget-object p0, LazsàS9l;->iOffset934:LazsàS9l;

    .line 24
    .line 25
    return-object p0
.end method


# virtual methods
.method public DDù8(LnPos7306;)LPni$zp$;
    .locals 5

    .line 1
    iget v0, p0, LJ11D;->yON3x:I

    .line 2
    .line 3
    sparse-switch v0, :sswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LA_g_b$CS_;

    .line 7
    .line 8
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    const-string v1, "type.googleapis.com/google.crypto.tink.AesCmacKey"

    .line 13
    .line 14
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-static {}, LtmpData4724;->$ÒcdS()LZèbexXHi;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-static {}, LtmpIndex5460;->$ÒcdS()LOKHSJQG;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    iget v3, p1, LA_g_b$CS_;->waiBKÀ:I

    .line 26
    .line 27
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 28
    .line 29
    .line 30
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 31
    .line 32
    check-cast v4, LtmpIndex5460;

    .line 33
    .line 34
    invoke-static {v4, v3}, LtmpIndex5460;->tmpSize211(LtmpIndex5460;I)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    check-cast v2, LtmpIndex5460;

    .line 42
    .line 43
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 44
    .line 45
    .line 46
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 47
    .line 48
    check-cast v3, LtmpData4724;

    .line 49
    .line 50
    invoke-static {v3, v2}, LtmpData4724;->tzKù7Ol1(LtmpData4724;LtmpIndex5460;)V

    .line 51
    .line 52
    .line 53
    iget v2, p1, LA_g_b$CS_;->e8$mp_s$:I

    .line 54
    .line 55
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 56
    .line 57
    .line 58
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 59
    .line 60
    check-cast v3, LtmpData4724;

    .line 61
    .line 62
    invoke-static {v3, v2}, LtmpData4724;->sKey6064(LtmpData4724;I)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v1}, Lw1I;->waiBKÀ()LHU$B$;

    .line 66
    .line 67
    .line 68
    move-result-object v1

    .line 69
    check-cast v1, LtmpData4724;

    .line 70
    .line 71
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 72
    .line 73
    .line 74
    move-result-object v1

    .line 75
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 76
    .line 77
    .line 78
    iget-object p1, p1, LA_g_b$CS_;->rz__9J_:LTa$A4$;

    .line 79
    .line 80
    invoke-static {p1}, LqB_y0$j_;->waiBKÀ(LTa$A4$;)Lkòè;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    check-cast p1, LjPT$NJ$;

    .line 92
    .line 93
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    return-object p1

    .line 98
    :sswitch_0
    check-cast p1, LBI;

    .line 99
    .line 100
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    const-string v1, "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key"

    .line 105
    .line 106
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 107
    .line 108
    .line 109
    invoke-static {}, LnàLComW;->kCount1402()LnàLComW;

    .line 110
    .line 111
    .line 112
    move-result-object v1

    .line 113
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 114
    .line 115
    .line 116
    move-result-object v1

    .line 117
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 118
    .line 119
    .line 120
    iget-object p1, p1, LBI;->e8$mp_s$:LgOffset2847;

    .line 121
    .line 122
    invoke-static {p1}, LozFAqI;->waiBKÀ(LgOffset2847;)Lkòè;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 127
    .line 128
    .line 129
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 130
    .line 131
    .line 132
    move-result-object p1

    .line 133
    check-cast p1, LjPT$NJ$;

    .line 134
    .line 135
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    return-object p1

    .line 140
    :sswitch_1
    check-cast p1, LIx_OW_;

    .line 141
    .line 142
    invoke-static {}, LjPT$NJ$;->kCount1402()LWVW_We$l_;

    .line 143
    .line 144
    .line 145
    move-result-object v0

    .line 146
    const-string v1, "type.googleapis.com/google.crypto.tink.AesEaxKey"

    .line 147
    .line 148
    invoke-virtual {v0, v1}, LWVW_We$l_;->sKey7917(Ljava/lang/String;)V

    .line 149
    .line 150
    .line 151
    invoke-static {}, LPÌ_lQ;->$ÒcdS()Lna$pa_E$;

    .line 152
    .line 153
    .line 154
    move-result-object v1

    .line 155
    invoke-static {}, LSQI;->$ÒcdS()LfO_T_;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    iget v3, p1, LIx_OW_;->waiBKÀ:I

    .line 160
    .line 161
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 162
    .line 163
    .line 164
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 165
    .line 166
    check-cast v4, LSQI;

    .line 167
    .line 168
    invoke-static {v4, v3}, LSQI;->tmpSize211(LSQI;I)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    .line 172
    .line 173
    .line 174
    move-result-object v2

    .line 175
    check-cast v2, LSQI;

    .line 176
    .line 177
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 178
    .line 179
    .line 180
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 181
    .line 182
    check-cast v3, LPÌ_lQ;

    .line 183
    .line 184
    invoke-static {v3, v2}, LPÌ_lQ;->tzKù7Ol1(LPÌ_lQ;LSQI;)V

    .line 185
    .line 186
    .line 187
    iget v2, p1, LIx_OW_;->e8$mp_s$:I

    .line 188
    .line 189
    invoke-virtual {v1}, Lw1I;->POOl()V

    .line 190
    .line 191
    .line 192
    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 193
    .line 194
    check-cast v3, LPÌ_lQ;

    .line 195
    .line 196
    invoke-static {v3, v2}, LPÌ_lQ;->sKey6064(LPÌ_lQ;I)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v1}, Lw1I;->waiBKÀ()LHU$B$;

    .line 200
    .line 201
    .line 202
    move-result-object v1

    .line 203
    check-cast v1, LPÌ_lQ;

    .line 204
    .line 205
    invoke-virtual {v1}, Lp1l;->waiBKÀ()LDtc_7t_;

    .line 206
    .line 207
    .line 208
    move-result-object v1

    .line 209
    invoke-virtual {v0, v1}, LWVW_We$l_;->DDù8(Lll11I;)V

    .line 210
    .line 211
    .line 212
    iget-object p1, p1, LIx_OW_;->rz__9J_:LIIII;

    .line 213
    .line 214
    invoke-static {p1}, LvDmnuNT;->waiBKÀ(LIIII;)Lkòè;

    .line 215
    .line 216
    .line 217
    move-result-object p1

    .line 218
    invoke-virtual {v0, p1}, LWVW_We$l_;->tmpData3485(Lkòè;)V

    .line 219
    .line 220
    .line 221
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    .line 222
    .line 223
    .line 224
    move-result-object p1

    .line 225
    check-cast p1, LjPT$NJ$;

    .line 226
    .line 227
    invoke-static {p1}, LPni$zp$;->e8$mp_s$(LjPT$NJ$;)LPni$zp$;

    .line 228
    .line 229
    .line 230
    move-result-object p1

    .line 231
    return-object p1

    .line 232
    nop

    .line 233
    :sswitch_data_0
    .sparse-switch
        0xf -> :sswitch_1
        0x13 -> :sswitch_0
    .end sparse-switch
.end method

.method public POOl(LBDO;)LvB$7$;
    .locals 5

    .line 1
    iget v0, p0, LJ11D;->yON3x:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const-string v2, "Only version 0 keys are accepted"

    .line 5
    .line 6
    sparse-switch v0, :sswitch_data_0

    .line 7
    .line 8
    .line 9
    iget-object v0, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 10
    .line 11
    const-string v3, "type.googleapis.com/google.crypto.tink.AesCmacKey"

    .line 12
    .line 13
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_1

    .line 18
    .line 19
    :try_start_0
    iget-object v0, p1, LBDO;->rz__9J_:Lll11I;

    .line 20
    .line 21
    sget-object v3, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 22
    .line 23
    sget-object v3, LLKmiA;->rz__9J_:LLKmiA;

    .line 24
    .line 25
    sget-object v3, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 26
    .line 27
    invoke-static {v0, v3}, LnKey6895;->Q1_f_(Lll11I;LOìJÒ6;)LnKey6895;

    .line 28
    .line 29
    .line 30
    move-result-object v0

    .line 31
    invoke-virtual {v0}, LnKey6895;->kCount1402()I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    if-nez v3, :cond_0

    .line 36
    .line 37
    new-instance v2, LMl;

    .line 38
    .line 39
    const/16 v3, 0x1c

    .line 40
    .line 41
    invoke-direct {v2, v3}, LMl;-><init>(I)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0}, LnKey6895;->sKey6064()Lll11I;

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    invoke-virtual {v3}, Lll11I;->tmpData3485()I

    .line 49
    .line 50
    .line 51
    move-result v3

    .line 52
    invoke-virtual {v2, v3}, LMl;->$ÒcdS(I)V

    .line 53
    .line 54
    .line 55
    invoke-virtual {v0}, LnKey6895;->tmpSize211()LtmpIndex5460;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    invoke-virtual {v3}, LtmpIndex5460;->kCount1402()I

    .line 60
    .line 61
    .line 62
    move-result v3

    .line 63
    invoke-virtual {v2, v3}, LMl;->tzKù7Ol1(I)V

    .line 64
    .line 65
    .line 66
    iget-object v3, p1, LBDO;->JKEoÙX:Lkòè;

    .line 67
    .line 68
    invoke-static {v3}, LqB_y0$j_;->e8$mp_s$(Lkòè;)LTa$A4$;

    .line 69
    .line 70
    .line 71
    move-result-object v3

    .line 72
    iput-object v3, v2, LMl;->iOffset934:Ljava/lang/Object;

    .line 73
    .line 74
    invoke-virtual {v2}, LMl;->Oey()LA_g_b$CS_;

    .line 75
    .line 76
    .line 77
    move-result-object v2

    .line 78
    new-instance v3, LlACD;

    .line 79
    .line 80
    const/16 v4, 0x1b

    .line 81
    .line 82
    invoke-direct {v3, v4, v1}, LlACD;-><init>(IZ)V

    .line 83
    .line 84
    .line 85
    iput-object v2, v3, LlACD;->vaIue:Ljava/lang/Object;

    .line 86
    .line 87
    invoke-virtual {v0}, LnKey6895;->sKey6064()Lll11I;

    .line 88
    .line 89
    .line 90
    move-result-object v0

    .line 91
    invoke-virtual {v0}, Lll11I;->e8$mp_s$()[B

    .line 92
    .line 93
    .line 94
    move-result-object v0

    .line 95
    invoke-static {v0}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    iput-object v0, v3, LlACD;->jPos3709:Ljava/lang/Object;

    .line 100
    .line 101
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 102
    .line 103
    iput-object p1, v3, LlACD;->iOffset934:Ljava/lang/Object;

    .line 104
    .line 105
    invoke-virtual {v3}, LlACD;->$ÒcdS()LtmpSize266;

    .line 106
    .line 107
    .line 108
    move-result-object p1

    .line 109
    return-object p1

    .line 110
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 111
    .line 112
    invoke-direct {p1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    throw p1
    :try_end_0
    .catch LtbdÀ7Ì; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 116
    :catch_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 117
    .line 118
    const-string v0, "Parsing AesCmacKey failed"

    .line 119
    .line 120
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    throw p1

    .line 124
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 125
    .line 126
    const-string v0, "Wrong type URL in call to AesCmacProtoSerialization.parseKey"

    .line 127
    .line 128
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 129
    .line 130
    .line 131
    throw p1

    .line 132
    :sswitch_0
    iget-object v0, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 133
    .line 134
    const-string v1, "type.googleapis.com/google.crypto.tink.ChaCha20Poly1305Key"

    .line 135
    .line 136
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 137
    .line 138
    .line 139
    move-result v0

    .line 140
    if-eqz v0, :cond_3

    .line 141
    .line 142
    :try_start_1
    iget-object v0, p1, LBDO;->rz__9J_:Lll11I;

    .line 143
    .line 144
    sget-object v1, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 145
    .line 146
    sget-object v1, LLKmiA;->rz__9J_:LLKmiA;

    .line 147
    .line 148
    sget-object v1, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 149
    .line 150
    invoke-static {v0, v1}, LvSize1769;->Q1_f_(Lll11I;LOìJÒ6;)LvSize1769;

    .line 151
    .line 152
    .line 153
    move-result-object v0

    .line 154
    invoke-virtual {v0}, LvSize1769;->kCount1402()I

    .line 155
    .line 156
    .line 157
    move-result v1

    .line 158
    if-nez v1, :cond_2

    .line 159
    .line 160
    iget-object v1, p1, LBDO;->JKEoÙX:Lkòè;

    .line 161
    .line 162
    invoke-static {v1}, LozFAqI;->e8$mp_s$(Lkòè;)LgOffset2847;

    .line 163
    .line 164
    .line 165
    move-result-object v1

    .line 166
    invoke-virtual {v0}, LvSize1769;->tmpSize211()Lll11I;

    .line 167
    .line 168
    .line 169
    move-result-object v0

    .line 170
    invoke-virtual {v0}, Lll11I;->e8$mp_s$()[B

    .line 171
    .line 172
    .line 173
    move-result-object v0

    .line 174
    invoke-static {v0}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 175
    .line 176
    .line 177
    move-result-object v0

    .line 178
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 179
    .line 180
    invoke-static {v1, v0, p1}, LgValue5267;->oy_R$Xx_(LgOffset2847;LkGd_Gk_;Ljava/lang/Integer;)LgValue5267;

    .line 181
    .line 182
    .line 183
    move-result-object p1

    .line 184
    return-object p1

    .line 185
    :cond_2
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 186
    .line 187
    invoke-direct {p1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 188
    .line 189
    .line 190
    throw p1
    :try_end_1
    .catch LtbdÀ7Ì; {:try_start_1 .. :try_end_1} :catch_1

    .line 191
    :catch_1
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 192
    .line 193
    const-string v0, "Parsing ChaCha20Poly1305Key failed"

    .line 194
    .line 195
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    throw p1

    .line 199
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 200
    .line 201
    const-string v0, "Wrong type URL in call to ChaCha20Poly1305ProtoSerialization.parseKey"

    .line 202
    .line 203
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 204
    .line 205
    .line 206
    throw p1

    .line 207
    :sswitch_1
    iget-object v0, p1, LBDO;->e8$mp_s$:Ljava/lang/String;

    .line 208
    .line 209
    const-string v3, "type.googleapis.com/google.crypto.tink.AesEaxKey"

    .line 210
    .line 211
    invoke-virtual {v0, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 212
    .line 213
    .line 214
    move-result v0

    .line 215
    if-eqz v0, :cond_5

    .line 216
    .line 217
    :try_start_2
    iget-object v0, p1, LBDO;->rz__9J_:Lll11I;

    .line 218
    .line 219
    sget-object v3, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 220
    .line 221
    sget-object v3, LLKmiA;->rz__9J_:LLKmiA;

    .line 222
    .line 223
    sget-object v3, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 224
    .line 225
    invoke-static {v0, v3}, LvSize7856;->Q1_f_(Lll11I;LOìJÒ6;)LvSize7856;

    .line 226
    .line 227
    .line 228
    move-result-object v0

    .line 229
    invoke-virtual {v0}, LvSize7856;->kCount1402()I

    .line 230
    .line 231
    .line 232
    move-result v3

    .line 233
    if-nez v3, :cond_4

    .line 234
    .line 235
    new-instance v2, LtmpCount1613;

    .line 236
    .line 237
    const/16 v3, 0x17

    .line 238
    .line 239
    invoke-direct {v2, v3}, LtmpCount1613;-><init>(I)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v0}, LvSize7856;->sKey6064()Lll11I;

    .line 243
    .line 244
    .line 245
    move-result-object v3

    .line 246
    invoke-virtual {v3}, Lll11I;->tmpData3485()I

    .line 247
    .line 248
    .line 249
    move-result v3

    .line 250
    invoke-virtual {v2, v3}, LtmpCount1613;->kO_6X_(I)V

    .line 251
    .line 252
    .line 253
    invoke-virtual {v0}, LvSize7856;->tmpSize211()LSQI;

    .line 254
    .line 255
    .line 256
    move-result-object v3

    .line 257
    invoke-virtual {v3}, LSQI;->kCount1402()I

    .line 258
    .line 259
    .line 260
    move-result v3

    .line 261
    invoke-virtual {v2, v3}, LtmpCount1613;->iOffset934(I)V

    .line 262
    .line 263
    .line 264
    invoke-virtual {v2}, LtmpCount1613;->kCount1402()V

    .line 265
    .line 266
    .line 267
    iget-object v3, p1, LBDO;->JKEoÙX:Lkòè;

    .line 268
    .line 269
    invoke-static {v3}, LvDmnuNT;->e8$mp_s$(Lkòè;)LIIII;

    .line 270
    .line 271
    .line 272
    move-result-object v3

    .line 273
    iput-object v3, v2, LtmpCount1613;->kQy:Ljava/lang/Object;

    .line 274
    .line 275
    invoke-virtual {v2}, LtmpCount1613;->oy_R$Xx_()LIx_OW_;

    .line 276
    .line 277
    .line 278
    move-result-object v2

    .line 279
    new-instance v3, LsIndex9566;

    .line 280
    .line 281
    const/16 v4, 0x1a

    .line 282
    .line 283
    invoke-direct {v3, v4, v1}, LsIndex9566;-><init>(IB)V

    .line 284
    .line 285
    .line 286
    iput-object v2, v3, LsIndex9566;->vaIue:Ljava/lang/Object;

    .line 287
    .line 288
    invoke-virtual {v0}, LvSize7856;->sKey6064()Lll11I;

    .line 289
    .line 290
    .line 291
    move-result-object v0

    .line 292
    invoke-virtual {v0}, Lll11I;->e8$mp_s$()[B

    .line 293
    .line 294
    .line 295
    move-result-object v0

    .line 296
    invoke-static {v0}, LkGd_Gk_;->gc_$M_w2$([B)LkGd_Gk_;

    .line 297
    .line 298
    .line 299
    move-result-object v0

    .line 300
    iput-object v0, v3, LsIndex9566;->jPos3709:Ljava/lang/Object;

    .line 301
    .line 302
    iget-object p1, p1, LBDO;->tmpData3485:Ljava/lang/Integer;

    .line 303
    .line 304
    iput-object p1, v3, LsIndex9566;->iOffset934:Ljava/lang/Object;

    .line 305
    .line 306
    invoke-virtual {v3}, LsIndex9566;->Q1_f_()LHllD;

    .line 307
    .line 308
    .line 309
    move-result-object p1

    .line 310
    return-object p1

    .line 311
    :cond_4
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 312
    .line 313
    invoke-direct {p1, v2}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 314
    .line 315
    .line 316
    throw p1
    :try_end_2
    .catch LtbdÀ7Ì; {:try_start_2 .. :try_end_2} :catch_2

    .line 317
    :catch_2
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 318
    .line 319
    const-string v0, "Parsing AesEaxcKey failed"

    .line 320
    .line 321
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 322
    .line 323
    .line 324
    throw p1

    .line 325
    :cond_5
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 326
    .line 327
    const-string v0, "Wrong type URL in call to AesEaxProtoSerialization.parseKey"

    .line 328
    .line 329
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    throw p1

    .line 333
    :sswitch_data_0
    .sparse-switch
        0x10 -> :sswitch_1
        0x14 -> :sswitch_0
    .end sparse-switch
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 1

    .line 1
    check-cast p1, LzD1I0;

    .line 2
    .line 3
    check-cast p2, LfiCÈÀ5;

    .line 4
    .line 5
    new-instance v0, LkValue3621;

    .line 6
    .line 7
    invoke-direct {v0, p2}, LkValue3621;-><init>(LfiCÈÀ5;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1}, Ly01I0I;->Qp_Hp$i_()Landroid/os/IInterface;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    check-cast p1, LSUN$HK$;

    .line 15
    .line 16
    invoke-virtual {p1}, LrEÈQD;->gc_$M_w2$()Landroid/os/Parcel;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    invoke-static {p2, v0}, LWoaOàtYj;->POOl(Landroid/os/Parcel;Landroid/os/IInterface;)V

    .line 21
    .line 22
    .line 23
    const/4 v0, 0x2

    .line 24
    invoke-virtual {p1, p2, v0}, LrEÈQD;->gKey1542(Landroid/os/Parcel;I)V

    .line 25
    .line 26
    .line 27
    return-void
.end method

.method public e8$mp_s$()Ljava/lang/Object;
    .locals 2

    .line 1
    iget v0, p0, LJ11D;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const/4 v0, -0x1

    .line 7
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    return-object v0

    .line 12
    :pswitch_0
    sget-object v0, LI1lIill;->waiBKÀ:LLkh_Q$w_;

    .line 13
    .line 14
    invoke-static {v0}, LvB$7$;->tmpSize211(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    new-instance v1, LCml_xzO;

    .line 18
    .line 19
    invoke-direct {v1, v0}, LCml_xzO;-><init>(Ljava/util/concurrent/Executor;)V

    .line 20
    .line 21
    .line 22
    return-object v1

    .line 23
    :pswitch_data_0
    .packed-switch 0x4
        :pswitch_0
    .end packed-switch
.end method

.method public kQy(Ljava/lang/Object;)V
    .locals 1

    .line 1
    iget v0, p0, LJ11D;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, LcIIQO;

    .line 7
    .line 8
    invoke-interface {p1}, LcIIQO;->gc_$M_w2$()V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :pswitch_0
    check-cast p1, LbK$h_uX$;

    .line 13
    .line 14
    invoke-interface {p1}, LbK$h_uX$;->tmpData3485()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    nop

    .line 19
    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method

.method public rz__9J_(LPni$zp$;)LnPos7306;
    .locals 3

    .line 1
    iget v0, p0, LJ11D;->yON3x:I

    .line 2
    .line 3
    const-string v1, "Only version 0 parameters are accepted"

    .line 4
    .line 5
    sparse-switch v0, :sswitch_data_0

    .line 6
    .line 7
    .line 8
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 9
    .line 10
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    const-string v2, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    .line 15
    .line 16
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_1

    .line 21
    .line 22
    :try_start_0
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 27
    .line 28
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 29
    .line 30
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 31
    .line 32
    invoke-static {v0, v2}, LIili1i;->Q1_f_(Lll11I;LOìJÒ6;)LIili1i;

    .line 33
    .line 34
    .line 35
    move-result-object v0
    :try_end_0
    .catch LtbdÀ7Ì; {:try_start_0 .. :try_end_0} :catch_0

    .line 36
    invoke-virtual {v0}, LIili1i;->kCount1402()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_0

    .line 41
    .line 42
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-static {p1}, LPIlDQ;->e8$mp_s$(Lkòè;)LnPos4111;

    .line 47
    .line 48
    .line 49
    move-result-object p1

    .line 50
    new-instance v0, LisOffset5675;

    .line 51
    .line 52
    invoke-direct {v0, p1}, LisOffset5675;-><init>(LnPos4111;)V

    .line 53
    .line 54
    .line 55
    return-object v0

    .line 56
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 57
    .line 58
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 59
    .line 60
    .line 61
    throw p1

    .line 62
    :catch_0
    move-exception p1

    .line 63
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 64
    .line 65
    const-string v1, "Parsing XChaCha20Poly1305Parameters failed: "

    .line 66
    .line 67
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 68
    .line 69
    .line 70
    throw v0

    .line 71
    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 72
    .line 73
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    const-string v1, "Wrong type URL in call to XChaCha20Poly1305ProtoSerialization.parseParameters: "

    .line 82
    .line 83
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    throw v0

    .line 91
    :sswitch_0
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 92
    .line 93
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v0

    .line 97
    const-string v2, "type.googleapis.com/google.crypto.tink.AesGcmSivKey"

    .line 98
    .line 99
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_5

    .line 104
    .line 105
    :try_start_1
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 106
    .line 107
    .line 108
    move-result-object v0

    .line 109
    sget-object v2, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 110
    .line 111
    sget-object v2, LLKmiA;->rz__9J_:LLKmiA;

    .line 112
    .line 113
    sget-object v2, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 114
    .line 115
    invoke-static {v0, v2}, LNùIÀS;->tmpSize211(Lll11I;LOìJÒ6;)LNùIÀS;

    .line 116
    .line 117
    .line 118
    move-result-object v0
    :try_end_1
    .catch LtbdÀ7Ì; {:try_start_1 .. :try_end_1} :catch_1

    .line 119
    invoke-virtual {v0}, LNùIÀS;->$ÒcdS()I

    .line 120
    .line 121
    .line 122
    move-result v2

    .line 123
    if-nez v2, :cond_4

    .line 124
    .line 125
    invoke-virtual {v0}, LNùIÀS;->kCount1402()I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    const/16 v1, 0x10

    .line 130
    .line 131
    if-eq v0, v1, :cond_3

    .line 132
    .line 133
    const/16 v1, 0x20

    .line 134
    .line 135
    if-ne v0, v1, :cond_2

    .line 136
    .line 137
    goto :goto_0

    .line 138
    :cond_2
    new-instance p1, Ljava/security/InvalidAlgorithmParameterException;

    .line 139
    .line 140
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 141
    .line 142
    .line 143
    move-result-object v0

    .line 144
    const/4 v1, 0x1

    .line 145
    new-array v1, v1, [Ljava/lang/Object;

    .line 146
    .line 147
    const/4 v2, 0x0

    .line 148
    aput-object v0, v1, v2

    .line 149
    .line 150
    const-string v0, "Invalid key size %d; only 16-byte and 32-byte AES keys are supported"

    .line 151
    .line 152
    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 153
    .line 154
    .line 155
    move-result-object v0

    .line 156
    invoke-direct {p1, v0}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    throw p1

    .line 160
    :cond_3
    :goto_0
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    invoke-static {p1}, LvData9200;->e8$mp_s$(Lkòè;)LTa$A4$;

    .line 165
    .line 166
    .line 167
    move-result-object p1

    .line 168
    new-instance v1, LhasKey8276;

    .line 169
    .line 170
    invoke-direct {v1, v0, p1}, LhasKey8276;-><init>(ILTa$A4$;)V

    .line 171
    .line 172
    .line 173
    return-object v1

    .line 174
    :cond_4
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 175
    .line 176
    invoke-direct {p1, v1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 177
    .line 178
    .line 179
    throw p1

    .line 180
    :catch_1
    move-exception p1

    .line 181
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 182
    .line 183
    const-string v1, "Parsing AesGcmSivParameters failed: "

    .line 184
    .line 185
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 186
    .line 187
    .line 188
    throw v0

    .line 189
    :cond_5
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 190
    .line 191
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object p1

    .line 195
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object p1

    .line 199
    const-string v1, "Wrong type URL in call to AesGcmSivProtoSerialization.parseParameters: "

    .line 200
    .line 201
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    throw v0

    .line 209
    :sswitch_1
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 210
    .line 211
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 212
    .line 213
    .line 214
    move-result-object v0

    .line 215
    const-string v1, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    .line 216
    .line 217
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 218
    .line 219
    .line 220
    move-result v0

    .line 221
    if-eqz v0, :cond_7

    .line 222
    .line 223
    :try_start_2
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    sget-object v1, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 228
    .line 229
    sget-object v1, LLKmiA;->rz__9J_:LLKmiA;

    .line 230
    .line 231
    sget-object v1, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 232
    .line 233
    invoke-static {v0, v1}, LhOOIDD;->$ÒcdS(Lll11I;LOìJÒ6;)LhOOIDD;

    .line 234
    .line 235
    .line 236
    move-result-object v0
    :try_end_2
    .catch LtbdÀ7Ì; {:try_start_2 .. :try_end_2} :catch_2

    .line 237
    invoke-virtual {v0}, LhOOIDD;->tmpSize211()LWasIjTc;

    .line 238
    .line 239
    .line 240
    move-result-object v1

    .line 241
    invoke-virtual {v1}, LWasIjTc;->$ÒcdS()I

    .line 242
    .line 243
    .line 244
    move-result v1

    .line 245
    if-nez v1, :cond_6

    .line 246
    .line 247
    new-instance v1, LIiII11I;

    .line 248
    .line 249
    const/16 v2, 0xc

    .line 250
    .line 251
    invoke-direct {v1, v2}, LIiII11I;-><init>(I)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v0}, LhOOIDD;->Q1_f_()Ldij;

    .line 255
    .line 256
    .line 257
    move-result-object v2

    .line 258
    invoke-virtual {v2}, Ldij;->kCount1402()I

    .line 259
    .line 260
    .line 261
    move-result v2

    .line 262
    invoke-virtual {v1, v2}, LIiII11I;->gKey4112(I)V

    .line 263
    .line 264
    .line 265
    invoke-virtual {v0}, LhOOIDD;->tmpSize211()LWasIjTc;

    .line 266
    .line 267
    .line 268
    move-result-object v2

    .line 269
    invoke-virtual {v2}, LWasIjTc;->kCount1402()I

    .line 270
    .line 271
    .line 272
    move-result v2

    .line 273
    invoke-virtual {v1, v2}, LIiII11I;->UC_n_(I)V

    .line 274
    .line 275
    .line 276
    invoke-virtual {v0}, LhOOIDD;->Q1_f_()Ldij;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    invoke-virtual {v2}, Ldij;->tmpSize211()LjData2289;

    .line 281
    .line 282
    .line 283
    move-result-object v2

    .line 284
    invoke-virtual {v2}, LjData2289;->kCount1402()I

    .line 285
    .line 286
    .line 287
    move-result v2

    .line 288
    invoke-virtual {v1, v2}, LIiII11I;->$ÒcdS(I)V

    .line 289
    .line 290
    .line 291
    invoke-virtual {v0}, LhOOIDD;->tmpSize211()LWasIjTc;

    .line 292
    .line 293
    .line 294
    move-result-object v2

    .line 295
    invoke-virtual {v2}, LWasIjTc;->tzKù7Ol1()LQll;

    .line 296
    .line 297
    .line 298
    move-result-object v2

    .line 299
    invoke-virtual {v2}, LQll;->kCount1402()I

    .line 300
    .line 301
    .line 302
    move-result v2

    .line 303
    invoke-virtual {v1, v2}, LIiII11I;->tmpSize211(I)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {v0}, LhOOIDD;->tmpSize211()LWasIjTc;

    .line 307
    .line 308
    .line 309
    move-result-object v0

    .line 310
    invoke-virtual {v0}, LWasIjTc;->tzKù7Ol1()LQll;

    .line 311
    .line 312
    .line 313
    move-result-object v0

    .line 314
    invoke-virtual {v0}, LQll;->$ÒcdS()LhasIndex1121;

    .line 315
    .line 316
    .line 317
    move-result-object v0

    .line 318
    invoke-static {v0}, LUW$4b_A$;->e8$mp_s$(LhasIndex1121;)LXK__E$$1_;

    .line 319
    .line 320
    .line 321
    move-result-object v0

    .line 322
    iput-object v0, v1, LIiII11I;->Ialue:Ljava/lang/Object;

    .line 323
    .line 324
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 325
    .line 326
    .line 327
    move-result-object p1

    .line 328
    invoke-static {p1}, LUW$4b_A$;->waiBKÀ(Lkòè;)LgOffset1083;

    .line 329
    .line 330
    .line 331
    move-result-object p1

    .line 332
    iput-object p1, v1, LIiII11I;->valuI:Ljava/lang/Object;

    .line 333
    .line 334
    invoke-virtual {v1}, LIiII11I;->ll()L$_V$X_6S$;

    .line 335
    .line 336
    .line 337
    move-result-object p1

    .line 338
    return-object p1

    .line 339
    :cond_6
    new-instance p1, Ljava/security/GeneralSecurityException;

    .line 340
    .line 341
    const-string v0, "Only version 0 keys are accepted"

    .line 342
    .line 343
    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    .line 344
    .line 345
    .line 346
    throw p1

    .line 347
    :catch_2
    move-exception p1

    .line 348
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 349
    .line 350
    const-string v1, "Parsing AesCtrHmacAeadParameters failed: "

    .line 351
    .line 352
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 353
    .line 354
    .line 355
    throw v0

    .line 356
    :cond_7
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 357
    .line 358
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object p1

    .line 362
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 363
    .line 364
    .line 365
    move-result-object p1

    .line 366
    const-string v1, "Wrong type URL in call to AesCtrHmacAeadProtoSerialization.parseParameters: "

    .line 367
    .line 368
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 369
    .line 370
    .line 371
    move-result-object p1

    .line 372
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    throw v0

    .line 376
    :sswitch_2
    iget-object p1, p1, LPni$zp$;->waiBKÀ:LjPT$NJ$;

    .line 377
    .line 378
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v0

    .line 382
    const-string v1, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    .line 383
    .line 384
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 385
    .line 386
    .line 387
    move-result v0

    .line 388
    if-eqz v0, :cond_8

    .line 389
    .line 390
    :try_start_3
    invoke-virtual {p1}, LjPT$NJ$;->sKey6064()Lll11I;

    .line 391
    .line 392
    .line 393
    move-result-object v0

    .line 394
    sget-object v1, LOìJÒ6;->e8$mp_s$:LOìJÒ6;

    .line 395
    .line 396
    sget-object v1, LLKmiA;->rz__9J_:LLKmiA;

    .line 397
    .line 398
    sget-object v1, LOìJÒ6;->waiBKÀ:LOìJÒ6;

    .line 399
    .line 400
    invoke-static {v0, v1}, LgSize7297;->tmpSize211(Lll11I;LOìJÒ6;)LgSize7297;

    .line 401
    .line 402
    .line 403
    move-result-object v0
    :try_end_3
    .catch LtbdÀ7Ì; {:try_start_3 .. :try_end_3} :catch_3

    .line 404
    invoke-virtual {p1}, LjPT$NJ$;->tmpSize211()Lkòè;

    .line 405
    .line 406
    .line 407
    move-result-object p1

    .line 408
    invoke-static {v0, p1}, Lf53$O$;->e8$mp_s$(LgSize7297;Lkòè;)LSXX$fW$;

    .line 409
    .line 410
    .line 411
    move-result-object p1

    .line 412
    return-object p1

    .line 413
    :catch_3
    move-exception p1

    .line 414
    new-instance v0, Ljava/security/GeneralSecurityException;

    .line 415
    .line 416
    const-string v1, "Parsing KmsEnvelopeAeadKeyFormat failed: "

    .line 417
    .line 418
    invoke-direct {v0, v1, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 419
    .line 420
    .line 421
    throw v0

    .line 422
    :cond_8
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 423
    .line 424
    invoke-virtual {p1}, LjPT$NJ$;->tzKù7Ol1()Ljava/lang/String;

    .line 425
    .line 426
    .line 427
    move-result-object p1

    .line 428
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 429
    .line 430
    .line 431
    move-result-object p1

    .line 432
    const-string v1, "Wrong type URL in call to LegacyKmsEnvelopeAeadProtoSerialization.parseParameters: "

    .line 433
    .line 434
    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 435
    .line 436
    .line 437
    move-result-object p1

    .line 438
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 439
    .line 440
    .line 441
    throw v0

    .line 442
    nop

    .line 443
    :sswitch_data_0
    .sparse-switch
        0xc -> :sswitch_2
        0xe -> :sswitch_1
        0x12 -> :sswitch_0
    .end sparse-switch
.end method

.method public bridge synthetic tmpData3485(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, LJ11D;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    if-nez p2, :cond_0

    .line 7
    .line 8
    invoke-static {p1}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;)Ljava/security/KeyPairGenerator;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    goto :goto_0

    .line 13
    :cond_0
    invoke-static {p1, p2}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyPairGenerator;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    :goto_0
    return-object p1

    .line 18
    :pswitch_0
    if-nez p2, :cond_1

    .line 19
    .line 20
    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    goto :goto_1

    .line 25
    :cond_1
    invoke-static {p1, p2}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljavax/crypto/Cipher;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    :goto_1
    return-object p1

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x1c
        :pswitch_0
    .end packed-switch
.end method

.method public waiBKÀ(LvB$7$;)LBDO;
    .locals 5

    iget v0, p0, LJ11D;->yON3x:I

    sparse-switch v0, :sswitch_data_0

    check-cast p1, LCicqEZY;

    .line 41
    invoke-static {}, LOM_o$vs_;->$ÒcdS()L$IQ;

    move-result-object v0

    .line 42
    iget-object v1, p1, LCicqEZY;->BCIm:L_lQ0D;

    .line 43
    invoke-static {}, LQll;->Q1_f_()LkOffset1453;

    move-result-object v2

    .line 44
    iget v3, v1, L_lQ0D;->waiBKÀ:I

    .line 45
    invoke-virtual {v2}, Lw1I;->POOl()V

    .line 46
    iget-object v4, v2, Lw1I;->vaIue:LHU$B$;

    .line 47
    check-cast v4, LQll;

    invoke-static {v4, v3}, LQll;->tzKù7Ol1(LQll;I)V

    .line 48
    sget-object v3, LTW$mG_5$;->waiBKÀ:LVF$4t_2$;

    .line 49
    iget-object v1, v1, L_lQ0D;->POOl:LFER_Ag$V_;

    .line 50
    invoke-virtual {v3, v1}, LVF$4t_2$;->waiBKÀ(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v1

    check-cast v1, LhasIndex1121;

    .line 51
    invoke-virtual {v2}, Lw1I;->POOl()V

    iget-object v3, v2, Lw1I;->vaIue:LHU$B$;

    .line 52
    check-cast v3, LQll;

    invoke-static {v3, v1}, LQll;->sKey6064(LQll;LhasIndex1121;)V

    .line 53
    invoke-virtual {v2}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v1

    check-cast v1, LQll;

    .line 54
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 55
    check-cast v2, LOM_o$vs_;

    invoke-static {v2, v1}, LOM_o$vs_;->yPN$A_n$(LOM_o$vs_;LQll;)V

    .line 56
    iget-object v1, p1, LCicqEZY;->zAt$p:LkGd_Gk_;

    .line 57
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 58
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 59
    array-length v2, v1

    const/4 v3, 0x0

    .line 60
    invoke-static {v1, v3, v2}, Lll11I;->yàÒZ([BII)LDtc_7t_;

    move-result-object v1

    .line 61
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 62
    check-cast v2, LOM_o$vs_;

    invoke-static {v2, v1}, LOM_o$vs_;->oy_R$Xx_(LOM_o$vs_;LDtc_7t_;)V

    .line 63
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LOM_o$vs_;

    .line 64
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    sget-object v1, LTW$mG_5$;->e8$mp_s$:LVF$4t_2$;

    .line 65
    iget-object v2, p1, LCicqEZY;->BCIm:L_lQ0D;

    .line 66
    iget-object v2, v2, L_lQ0D;->rz__9J_:LxsQmI;

    .line 67
    invoke-virtual {v1, v2}, LVF$4t_2$;->waiBKÀ(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v1

    check-cast v1, Lkòè;

    .line 68
    iget-object p1, p1, LCicqEZY;->iSize4906:Ljava/lang/Integer;

    .line 69
    const-string v2, "type.googleapis.com/google.crypto.tink.HmacKey"

    const/4 v3, 0x2

    .line 70
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    .line 71
    :sswitch_0
    check-cast p1, LfDXÙ6Z1ih;

    .line 72
    iget-object p1, p1, LfDXÙ6Z1ih;->BCIm:LBDO;

    .line 73
    sget-object v0, LRo_4_;->waiBKÀ:[I

    .line 74
    iget v1, p1, LBDO;->POOl:I

    .line 75
    invoke-static {v1}, LBRK_m_;->UC_n_(I)I

    move-result v1

    aget v0, v0, v1

    return-object p1

    .line 76
    :sswitch_1
    check-cast p1, LsJ4xy;

    .line 77
    invoke-static {}, LoMWq;->$ÒcdS()LbSNoìèU;

    move-result-object v0

    .line 78
    iget-object v1, p1, LsJ4xy;->zAt$p:LkGd_Gk_;

    .line 79
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 80
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 81
    array-length v2, v1

    const/4 v3, 0x0

    .line 82
    invoke-static {v1, v3, v2}, Lll11I;->yàÒZ([BII)LDtc_7t_;

    move-result-object v1

    .line 83
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 84
    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 85
    check-cast v2, LoMWq;

    invoke-static {v2, v1}, LoMWq;->tzKù7Ol1(LoMWq;LDtc_7t_;)V

    .line 86
    invoke-static {}, LBE$Yk$;->$ÒcdS()LMY5to;

    move-result-object v1

    .line 87
    iget-object v2, p1, LsJ4xy;->BCIm:LL1QIl;

    .line 88
    iget v3, v2, LL1QIl;->waiBKÀ:I

    .line 89
    invoke-virtual {v1}, Lw1I;->POOl()V

    iget-object v4, v1, Lw1I;->vaIue:LHU$B$;

    .line 90
    check-cast v4, LBE$Yk$;

    invoke-static {v4, v3}, LBE$Yk$;->tmpSize211(LBE$Yk$;I)V

    .line 91
    invoke-virtual {v1}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v1

    check-cast v1, LBE$Yk$;

    .line 92
    invoke-virtual {v0}, Lw1I;->POOl()V

    iget-object v3, v0, Lw1I;->vaIue:LHU$B$;

    .line 93
    check-cast v3, LoMWq;

    invoke-static {v3, v1}, LoMWq;->ll(LoMWq;LBE$Yk$;)V

    .line 94
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, LoMWq;

    .line 95
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    .line 96
    iget-object v1, v2, LL1QIl;->e8$mp_s$:LIIII;

    .line 97
    invoke-static {v1}, LeeNl2èPO;->waiBKÀ(LIIII;)Lkòè;

    move-result-object v1

    .line 98
    iget-object p1, p1, LsJ4xy;->iSize4906:Ljava/lang/Integer;

    .line 99
    const-string v2, "type.googleapis.com/google.crypto.tink.XAesGcmKey"

    const/4 v3, 0x2

    .line 100
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    .line 101
    :sswitch_2
    check-cast p1, LsValue8721;

    .line 102
    invoke-static {}, Lef7$WK_NH$;->$ÒcdS()LTùÌBI0;

    move-result-object v0

    .line 103
    iget-object v1, p1, LsValue8721;->zAt$p:LkGd_Gk_;

    .line 104
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 105
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 106
    array-length v2, v1

    const/4 v3, 0x0

    .line 107
    invoke-static {v1, v3, v2}, Lll11I;->yàÒZ([BII)LDtc_7t_;

    move-result-object v1

    .line 108
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 109
    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 110
    check-cast v2, Lef7$WK_NH$;

    invoke-static {v2, v1}, Lef7$WK_NH$;->tzKù7Ol1(Lef7$WK_NH$;LDtc_7t_;)V

    .line 111
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, Lef7$WK_NH$;

    .line 112
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    .line 113
    iget-object v1, p1, LsValue8721;->BCIm:Lh1OO;

    .line 114
    iget-object v1, v1, Lh1OO;->waiBKÀ:LnPos4111;

    .line 115
    invoke-static {v1}, LvKey4797;->waiBKÀ(LnPos4111;)Lkòè;

    move-result-object v1

    .line 116
    iget-object p1, p1, LsValue8721;->iSize4906:Ljava/lang/Integer;

    .line 117
    const-string v2, "type.googleapis.com/google.crypto.tink.AesGcmKey"

    const/4 v3, 0x2

    .line 118
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    .line 119
    :sswitch_3
    check-cast p1, LlO_q_;

    .line 120
    invoke-static {}, Lrp_4f_;->$ÒcdS()Lb1;

    move-result-object v0

    .line 121
    invoke-static {}, LnItem6218;->kCount1402()LzHL_Um$mP_;

    move-result-object v1

    .line 122
    iget-object v2, p1, LlO_q_;->BCIm:LjValue555;

    .line 123
    iget-object v2, v2, LjValue555;->e8$mp_s$:Ljava/lang/String;

    .line 124
    invoke-virtual {v1}, Lw1I;->POOl()V

    iget-object v3, v1, Lw1I;->vaIue:LHU$B$;

    .line 125
    check-cast v3, LnItem6218;

    invoke-static {v3, v2}, LnItem6218;->sKey6064(LnItem6218;Ljava/lang/String;)V

    .line 126
    invoke-virtual {v1}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v1

    check-cast v1, LnItem6218;

    .line 127
    invoke-virtual {v0}, Lw1I;->POOl()V

    .line 128
    iget-object v2, v0, Lw1I;->vaIue:LHU$B$;

    .line 129
    check-cast v2, Lrp_4f_;

    invoke-static {v2, v1}, Lrp_4f_;->tzKù7Ol1(Lrp_4f_;LnItem6218;)V

    .line 130
    invoke-virtual {v0}, Lw1I;->waiBKÀ()LHU$B$;

    move-result-object v0

    check-cast v0, Lrp_4f_;

    .line 131
    invoke-virtual {v0}, Lp1l;->waiBKÀ()LDtc_7t_;

    move-result-object v0

    .line 132
    iget-object v1, p1, LlO_q_;->BCIm:LjValue555;

    .line 133
    iget-object v1, v1, LjValue555;->waiBKÀ:LwYm_BE$mL_;

    .line 134
    invoke-static {v1}, LMSEqVZ;->waiBKÀ(LwYm_BE$mL_;)Lkòè;

    move-result-object v1

    .line 135
    iget-object p1, p1, LlO_q_;->zAt$p:Ljava/lang/Integer;

    .line 136
    const-string v2, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    const/4 v3, 0x5

    .line 137
    invoke-static {v2, v0, v3, v1, p1}, LBDO;->e8$mp_s$(Ljava/lang/String;Lll11I;ILkòè;Ljava/lang/Integer;)LBDO;

    move-result-object p1

    return-object p1

    :sswitch_data_0
    .sparse-switch
        0xb -> :sswitch_3
        0x11 -> :sswitch_2
        0x15 -> :sswitch_1
        0x17 -> :sswitch_0
    .end sparse-switch
.end method

.method public waiBKÀ(LvB$7$;)Ljava/lang/Object;
    .locals 9

    iget v0, p0, LJ11D;->yON3x:I

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    new-instance v0, L_00Dl;

    check-cast p1, LCicqEZY;

    .line 1
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x2

    invoke-static {p1}, LnItem4702;->sKey6064(I)Z

    move-result p1

    if-eqz p1, :cond_0

    return-object v0

    .line 2
    :cond_0
    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string v0, "Can not use HMAC in FIPS-mode, as BoringCrypto module is not available."

    invoke-direct {p1, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    .line 3
    :pswitch_1
    check-cast p1, LsJ4xy;

    .line 4
    new-instance v0, LRnvpCLY;

    .line 5
    iget-object v1, p1, LsJ4xy;->zAt$p:LkGd_Gk_;

    .line 6
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 7
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 8
    iget-object v2, p1, LsJ4xy;->gSy_FG$D_:LrlI;

    .line 9
    iget-object p1, p1, LsJ4xy;->BCIm:LL1QIl;

    .line 10
    iget p1, p1, LL1QIl;->waiBKÀ:I

    .line 11
    invoke-direct {v0, v1, v2, p1}, LRnvpCLY;-><init>([BLrlI;I)V

    return-object v0

    .line 12
    :pswitch_2
    check-cast p1, LaQ00Il;

    sget-object v0, LhòzBcbxG;->e8$mp_s$:LUEè;

    .line 13
    iget-object p1, p1, LaQ00Il;->BCIm:LSXX$fW$;

    .line 14
    iget-object p1, p1, LSXX$fW$;->waiBKÀ:Ljava/lang/String;

    .line 15
    invoke-static {p1}, LpswIHQfiW;->e8$mp_s$(Ljava/lang/String;)V

    const/4 p1, 0x0

    throw p1

    .line 16
    :pswitch_3
    check-cast p1, LCBUP;

    .line 17
    new-instance v0, LtXràR;

    .line 18
    iget-object v1, p1, LCBUP;->zAt$p:LkGd_Gk_;

    .line 19
    iget-object v1, v1, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v1, LrlI;

    .line 20
    invoke-virtual {v1}, LrlI;->waiBKÀ()[B

    move-result-object v1

    .line 21
    iget-object p1, p1, LCBUP;->gSy_FG$D_:LrlI;

    .line 22
    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    move-result-object p1

    invoke-direct {v0, v1, p1}, LtXràR;-><init>([B[B)V

    return-object v0

    .line 23
    :pswitch_4
    check-cast p1, LUnZmKt;

    .line 24
    new-instance v0, LMc_q_;

    new-instance v1, LIi1lIIl;

    .line 25
    iget-object v2, p1, LUnZmKt;->zAt$p:LkGd_Gk_;

    .line 26
    iget-object v2, v2, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v2, LrlI;

    .line 27
    invoke-virtual {v2}, LrlI;->waiBKÀ()[B

    move-result-object v2

    .line 28
    iget-object v3, p1, LUnZmKt;->BCIm:L$_V$X_6S$;

    .line 29
    iget v4, v3, L$_V$X_6S$;->rz__9J_:I

    .line 30
    invoke-direct {v1, v2, v4}, LIi1lIIl;-><init>([BI)V

    new-instance v2, LBÌ7Sì;

    new-instance v4, LgOffset3699;

    .line 31
    iget-object v5, v3, L$_V$X_6S$;->tmpData3485:LXK__E$$1_;

    .line 32
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljavax/crypto/spec/SecretKeySpec;

    .line 33
    iget-object v7, p1, LUnZmKt;->gSy_FG$D_:LkGd_Gk_;

    .line 34
    iget-object v7, v7, LkGd_Gk_;->vaIue:Ljava/lang/Object;

    check-cast v7, LrlI;

    .line 35
    invoke-virtual {v7}, LrlI;->waiBKÀ()[B

    move-result-object v7

    .line 36
    const-string v8, "HMAC"

    invoke-direct {v6, v7, v8}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    invoke-virtual {v8, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-direct {v4, v5, v6}, LgOffset3699;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    .line 37
    iget v3, v3, L$_V$X_6S$;->POOl:I

    .line 38
    invoke-direct {v2, v4, v3}, LBÌ7Sì;-><init>(LgOffset3699;I)V

    .line 39
    iget-object p1, p1, LUnZmKt;->iSize4906:LrlI;

    .line 40
    invoke-virtual {p1}, LrlI;->waiBKÀ()[B

    move-result-object p1

    invoke-direct {v0, v1, v2, v3, p1}, LMc_q_;-><init>(LIi1lIIl;LBÌ7Sì;I[B)V

    return-object v0

    nop

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method public yON3x(LkGd_Gk_;Ljava/lang/CharSequence;)Ljava/util/Iterator;
    .locals 0

    .line 1
    new-instance p1, Lli1iI;

    .line 2
    .line 3
    invoke-direct {p1, p2}, LrF$F_o$;-><init>(Ljava/lang/CharSequence;)V

    .line 4
    .line 5
    .line 6
    return-object p1
.end method
