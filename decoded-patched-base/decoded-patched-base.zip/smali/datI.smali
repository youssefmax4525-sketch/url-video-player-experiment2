.class public final LdatI;
.super Landroid/view/View$AccessibilityDelegate;
.source "SourceFile"


# instance fields
.field public final e8$mp_s$:LmQQI;


# direct methods
.method public constructor <init>(LmQQI;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/view/View$AccessibilityDelegate;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LmQQI;->e8$mp_s$(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, LmQQI;->waiBKÀ(Landroid/view/View;)LJw_Mi$Hk_;

    .line 4
    .line 5
    .line 6
    move-result-object p1

    .line 7
    if-eqz p1, :cond_0

    .line 8
    .line 9
    iget-object p1, p1, LJw_Mi$Hk_;->vaIue:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast p1, Landroid/view/accessibility/AccessibilityNodeProvider;

    .line 12
    .line 13
    return-object p1

    .line 14
    :cond_0
    const/4 p1, 0x0

    .line 15
    return-object p1
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LmQQI;->rz__9J_(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 17

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    new-instance v2, LkIy;

    .line 6
    .line 7
    invoke-direct {v2, v1}, LkIy;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 8
    .line 9
    .line 10
    sget-object v3, Ll11Il;->e8$mp_s$:Ljava/util/WeakHashMap;

    .line 11
    .line 12
    sget v3, LyNAt$Bè;->tag_screen_reader_focusable:I

    .line 13
    .line 14
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 15
    .line 16
    const/4 v5, 0x0

    .line 17
    const/16 v6, 0x1c

    .line 18
    .line 19
    const-class v7, Ljava/lang/Boolean;

    .line 20
    .line 21
    if-lt v4, v6, :cond_0

    .line 22
    .line 23
    invoke-static {v0}, LYzN$PV_sZ$;->rz__9J_(Landroid/view/View;)Z

    .line 24
    .line 25
    .line 26
    move-result v3

    .line 27
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    goto :goto_0

    .line 32
    :cond_0
    invoke-virtual {v0, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v7, v3}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-eqz v4, :cond_1

    .line 41
    .line 42
    goto :goto_0

    .line 43
    :cond_1
    move-object v3, v5

    .line 44
    :goto_0
    check-cast v3, Ljava/lang/Boolean;

    .line 45
    .line 46
    const/4 v4, 0x0

    .line 47
    const/4 v8, 0x1

    .line 48
    if-eqz v3, :cond_2

    .line 49
    .line 50
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 51
    .line 52
    .line 53
    move-result v3

    .line 54
    if-eqz v3, :cond_2

    .line 55
    .line 56
    const/4 v3, 0x1

    .line 57
    goto :goto_1

    .line 58
    :cond_2
    const/4 v3, 0x0

    .line 59
    :goto_1
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 60
    .line 61
    if-lt v9, v6, :cond_3

    .line 62
    .line 63
    invoke-static {v1, v3}, LCA$b_$K$;->K0I(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 64
    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_3
    invoke-virtual {v2, v8, v3}, LkIy;->DDù8(IZ)V

    .line 68
    .line 69
    .line 70
    :goto_2
    sget v3, LyNAt$Bè;->tag_accessibility_heading:I

    .line 71
    .line 72
    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 73
    .line 74
    if-lt v10, v6, :cond_4

    .line 75
    .line 76
    invoke-static {v0}, LYzN$PV_sZ$;->waiBKÀ(Landroid/view/View;)Z

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 81
    .line 82
    .line 83
    move-result-object v3

    .line 84
    goto :goto_3

    .line 85
    :cond_4
    invoke-virtual {v0, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 86
    .line 87
    .line 88
    move-result-object v3

    .line 89
    invoke-virtual {v7, v3}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v7

    .line 93
    if-eqz v7, :cond_5

    .line 94
    .line 95
    goto :goto_3

    .line 96
    :cond_5
    move-object v3, v5

    .line 97
    :goto_3
    check-cast v3, Ljava/lang/Boolean;

    .line 98
    .line 99
    if-eqz v3, :cond_6

    .line 100
    .line 101
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 102
    .line 103
    .line 104
    move-result v3

    .line 105
    if-eqz v3, :cond_6

    .line 106
    .line 107
    goto :goto_4

    .line 108
    :cond_6
    const/4 v8, 0x0

    .line 109
    :goto_4
    if-lt v9, v6, :cond_7

    .line 110
    .line 111
    invoke-static {v1, v8}, LCA$b_$K$;->ll(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 112
    .line 113
    .line 114
    goto :goto_5

    .line 115
    :cond_7
    const/4 v3, 0x2

    .line 116
    invoke-virtual {v2, v3, v8}, LkIy;->DDù8(IZ)V

    .line 117
    .line 118
    .line 119
    :goto_5
    invoke-static {v0}, Ll11Il;->JKEoÙX(Landroid/view/View;)Ljava/lang/CharSequence;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    if-lt v9, v6, :cond_8

    .line 124
    .line 125
    invoke-static {v1, v3}, LCA$b_$K$;->kO_6X_(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V

    .line 126
    .line 127
    .line 128
    goto :goto_6

    .line 129
    :cond_8
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 130
    .line 131
    .line 132
    move-result-object v6

    .line 133
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY"

    .line 134
    .line 135
    invoke-virtual {v6, v7, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 136
    .line 137
    .line 138
    :goto_6
    sget v3, LyNAt$Bè;->tag_state_description:I

    .line 139
    .line 140
    const/16 v6, 0x1e

    .line 141
    .line 142
    if-lt v9, v6, :cond_9

    .line 143
    .line 144
    invoke-static {v0}, LsKey9217;->waiBKÀ(Landroid/view/View;)Ljava/lang/CharSequence;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    goto :goto_7

    .line 149
    :cond_9
    invoke-virtual {v0, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    const-class v7, Ljava/lang/CharSequence;

    .line 154
    .line 155
    invoke-virtual {v7, v3}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 156
    .line 157
    .line 158
    move-result v7

    .line 159
    if-eqz v7, :cond_a

    .line 160
    .line 161
    goto :goto_7

    .line 162
    :cond_a
    move-object v3, v5

    .line 163
    :goto_7
    check-cast v3, Ljava/lang/CharSequence;

    .line 164
    .line 165
    if-lt v9, v6, :cond_b

    .line 166
    .line 167
    invoke-static {v1, v3}, LVàìcOÀl;->DDù8(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V

    .line 168
    .line 169
    .line 170
    :goto_8
    move-object/from16 v3, p0

    .line 171
    .line 172
    goto :goto_9

    .line 173
    :cond_b
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 174
    .line 175
    .line 176
    move-result-object v6

    .line 177
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"

    .line 178
    .line 179
    invoke-virtual {v6, v7, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 180
    .line 181
    .line 182
    goto :goto_8

    .line 183
    :goto_9
    iget-object v6, v3, LdatI;->e8$mp_s$:LmQQI;

    .line 184
    .line 185
    invoke-virtual {v6, v0, v2}, LmQQI;->POOl(Landroid/view/View;LkIy;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    .line 189
    .line 190
    .line 191
    move-result-object v6

    .line 192
    const/16 v7, 0x1a

    .line 193
    .line 194
    if-ge v9, v7, :cond_13

    .line 195
    .line 196
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 197
    .line 198
    .line 199
    move-result-object v7

    .line 200
    const-string v8, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY"

    .line 201
    .line 202
    invoke-virtual {v7, v8}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 203
    .line 204
    .line 205
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 206
    .line 207
    .line 208
    move-result-object v7

    .line 209
    const-string v9, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY"

    .line 210
    .line 211
    invoke-virtual {v7, v9}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 212
    .line 213
    .line 214
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 215
    .line 216
    .line 217
    move-result-object v7

    .line 218
    const-string v10, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY"

    .line 219
    .line 220
    invoke-virtual {v7, v10}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 221
    .line 222
    .line 223
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 224
    .line 225
    .line 226
    move-result-object v7

    .line 227
    const-string v11, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY"

    .line 228
    .line 229
    invoke-virtual {v7, v11}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 230
    .line 231
    .line 232
    sget v7, LyNAt$Bè;->tag_accessibility_clickable_spans:I

    .line 233
    .line 234
    invoke-virtual {v0, v7}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 235
    .line 236
    .line 237
    move-result-object v7

    .line 238
    check-cast v7, Landroid/util/SparseArray;

    .line 239
    .line 240
    if-eqz v7, :cond_e

    .line 241
    .line 242
    new-instance v12, Ljava/util/ArrayList;

    .line 243
    .line 244
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 245
    .line 246
    .line 247
    const/4 v13, 0x0

    .line 248
    :goto_a
    invoke-virtual {v7}, Landroid/util/SparseArray;->size()I

    .line 249
    .line 250
    .line 251
    move-result v14

    .line 252
    if-ge v13, v14, :cond_d

    .line 253
    .line 254
    invoke-virtual {v7, v13}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v14

    .line 258
    check-cast v14, Ljava/lang/ref/WeakReference;

    .line 259
    .line 260
    invoke-virtual {v14}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    move-result-object v14

    .line 264
    if-nez v14, :cond_c

    .line 265
    .line 266
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 267
    .line 268
    .line 269
    move-result-object v14

    .line 270
    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 271
    .line 272
    .line 273
    :cond_c
    add-int/lit8 v13, v13, 0x1

    .line 274
    .line 275
    goto :goto_a

    .line 276
    :cond_d
    const/4 v13, 0x0

    .line 277
    :goto_b
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 278
    .line 279
    .line 280
    move-result v14

    .line 281
    if-ge v13, v14, :cond_e

    .line 282
    .line 283
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object v14

    .line 287
    check-cast v14, Ljava/lang/Integer;

    .line 288
    .line 289
    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    .line 290
    .line 291
    .line 292
    move-result v14

    .line 293
    invoke-virtual {v7, v14}, Landroid/util/SparseArray;->remove(I)V

    .line 294
    .line 295
    .line 296
    add-int/lit8 v13, v13, 0x1

    .line 297
    .line 298
    goto :goto_b

    .line 299
    :cond_e
    instance-of v7, v6, Landroid/text/Spanned;

    .line 300
    .line 301
    if-eqz v7, :cond_f

    .line 302
    .line 303
    move-object v5, v6

    .line 304
    check-cast v5, Landroid/text/Spanned;

    .line 305
    .line 306
    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    .line 307
    .line 308
    .line 309
    move-result v7

    .line 310
    const-class v12, Landroid/text/style/ClickableSpan;

    .line 311
    .line 312
    invoke-interface {v5, v4, v7, v12}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object v5

    .line 316
    check-cast v5, [Landroid/text/style/ClickableSpan;

    .line 317
    .line 318
    :cond_f
    if-eqz v5, :cond_13

    .line 319
    .line 320
    array-length v7, v5

    .line 321
    if-lez v7, :cond_13

    .line 322
    .line 323
    invoke-virtual {v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->getExtras()Landroid/os/Bundle;

    .line 324
    .line 325
    .line 326
    move-result-object v1

    .line 327
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY"

    .line 328
    .line 329
    sget v12, LyNAt$Bè;->accessibility_action_clickable_span:I

    .line 330
    .line 331
    invoke-virtual {v1, v7, v12}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 332
    .line 333
    .line 334
    sget v1, LyNAt$Bè;->tag_accessibility_clickable_spans:I

    .line 335
    .line 336
    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 337
    .line 338
    .line 339
    move-result-object v1

    .line 340
    check-cast v1, Landroid/util/SparseArray;

    .line 341
    .line 342
    if-nez v1, :cond_10

    .line 343
    .line 344
    new-instance v1, Landroid/util/SparseArray;

    .line 345
    .line 346
    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    .line 347
    .line 348
    .line 349
    sget v7, LyNAt$Bè;->tag_accessibility_clickable_spans:I

    .line 350
    .line 351
    invoke-virtual {v0, v7, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 352
    .line 353
    .line 354
    :cond_10
    const/4 v7, 0x0

    .line 355
    :goto_c
    array-length v12, v5

    .line 356
    if-ge v7, v12, :cond_13

    .line 357
    .line 358
    aget-object v12, v5, v7

    .line 359
    .line 360
    const/4 v13, 0x0

    .line 361
    :goto_d
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 362
    .line 363
    .line 364
    move-result v14

    .line 365
    if-ge v13, v14, :cond_12

    .line 366
    .line 367
    invoke-virtual {v1, v13}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v14

    .line 371
    check-cast v14, Ljava/lang/ref/WeakReference;

    .line 372
    .line 373
    invoke-virtual {v14}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 374
    .line 375
    .line 376
    move-result-object v14

    .line 377
    check-cast v14, Landroid/text/style/ClickableSpan;

    .line 378
    .line 379
    invoke-virtual {v12, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 380
    .line 381
    .line 382
    move-result v14

    .line 383
    if-eqz v14, :cond_11

    .line 384
    .line 385
    invoke-virtual {v1, v13}, Landroid/util/SparseArray;->keyAt(I)I

    .line 386
    .line 387
    .line 388
    move-result v12

    .line 389
    goto :goto_e

    .line 390
    :cond_11
    add-int/lit8 v13, v13, 0x1

    .line 391
    .line 392
    goto :goto_d

    .line 393
    :cond_12
    sget v12, LkIy;->rz__9J_:I

    .line 394
    .line 395
    add-int/lit8 v13, v12, 0x1

    .line 396
    .line 397
    sput v13, LkIy;->rz__9J_:I

    .line 398
    .line 399
    :goto_e
    new-instance v13, Ljava/lang/ref/WeakReference;

    .line 400
    .line 401
    aget-object v14, v5, v7

    .line 402
    .line 403
    invoke-direct {v13, v14}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 404
    .line 405
    .line 406
    invoke-virtual {v1, v12, v13}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 407
    .line 408
    .line 409
    aget-object v13, v5, v7

    .line 410
    .line 411
    move-object v14, v6

    .line 412
    check-cast v14, Landroid/text/Spanned;

    .line 413
    .line 414
    invoke-virtual {v2, v8}, LkIy;->rz__9J_(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 415
    .line 416
    .line 417
    move-result-object v15

    .line 418
    invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 419
    .line 420
    .line 421
    move-result v16

    .line 422
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 423
    .line 424
    .line 425
    move-result-object v4

    .line 426
    invoke-interface {v15, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 427
    .line 428
    .line 429
    invoke-virtual {v2, v9}, LkIy;->rz__9J_(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 430
    .line 431
    .line 432
    move-result-object v4

    .line 433
    invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 434
    .line 435
    .line 436
    move-result v15

    .line 437
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 438
    .line 439
    .line 440
    move-result-object v15

    .line 441
    invoke-interface {v4, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 442
    .line 443
    .line 444
    invoke-virtual {v2, v10}, LkIy;->rz__9J_(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 445
    .line 446
    .line 447
    move-result-object v4

    .line 448
    invoke-interface {v14, v13}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I

    .line 449
    .line 450
    .line 451
    move-result v13

    .line 452
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 453
    .line 454
    .line 455
    move-result-object v13

    .line 456
    invoke-interface {v4, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 457
    .line 458
    .line 459
    invoke-virtual {v2, v11}, LkIy;->rz__9J_(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 460
    .line 461
    .line 462
    move-result-object v4

    .line 463
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 464
    .line 465
    .line 466
    move-result-object v12

    .line 467
    invoke-interface {v4, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 468
    .line 469
    .line 470
    add-int/lit8 v7, v7, 0x1

    .line 471
    .line 472
    const/4 v4, 0x0

    .line 473
    goto :goto_c

    .line 474
    :cond_13
    sget v1, LyNAt$Bè;->tag_accessibility_actions:I

    .line 475
    .line 476
    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v0

    .line 480
    check-cast v0, Ljava/util/List;

    .line 481
    .line 482
    if-nez v0, :cond_14

    .line 483
    .line 484
    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 485
    .line 486
    :cond_14
    const/4 v4, 0x0

    .line 487
    :goto_f
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 488
    .line 489
    .line 490
    move-result v1

    .line 491
    if-ge v4, v1, :cond_15

    .line 492
    .line 493
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 494
    .line 495
    .line 496
    move-result-object v1

    .line 497
    check-cast v1, LvSize9930;

    .line 498
    .line 499
    invoke-virtual {v2, v1}, LkIy;->waiBKÀ(LvSize9930;)V

    .line 500
    .line 501
    .line 502
    add-int/lit8 v4, v4, 0x1

    .line 503
    .line 504
    goto :goto_f

    .line 505
    :cond_15
    return-void
.end method

.method public final onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LmQQI;->JKEoÙX(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2, p3}, LmQQI;->tmpData3485(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2, p3}, LmQQI;->sKey7917(Landroid/view/View;ILandroid/os/Bundle;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    return p1
.end method

.method public final sendAccessibilityEvent(Landroid/view/View;I)V
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LmQQI;->DDù8(Landroid/view/View;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, LdatI;->e8$mp_s$:LmQQI;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2}, LmQQI;->yON3x(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
