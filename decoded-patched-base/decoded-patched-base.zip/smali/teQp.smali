.class public abstract LteQp;
.super Ljava/lang/Object;


# static fields
.field public static lb_action_bg:I = 0x7f08021d

.field public static lb_action_bg_focused:I = 0x7f08021e

.field public static lb_background:I = 0x7f08021f

.field public static lb_card_foreground:I = 0x7f080220

.field public static lb_card_shadow_focused:I = 0x7f080221

.field public static lb_card_shadow_normal:I = 0x7f080222

.field public static lb_control_button_primary:I = 0x7f080223

.field public static lb_control_button_secondary:I = 0x7f080224

.field public static lb_headers_right_fading:I = 0x7f080225

.field public static lb_ic_actions_right_arrow:I = 0x7f080226

.field public static lb_ic_cc:I = 0x7f080227

.field public static lb_ic_fast_forward:I = 0x7f080228

.field public static lb_ic_fast_rewind:I = 0x7f080229

.field public static lb_ic_guidedactions_item_chevron:I = 0x7f08022a

.field public static lb_ic_hq:I = 0x7f08022b

.field public static lb_ic_in_app_search:I = 0x7f08022c

.field public static lb_ic_loop:I = 0x7f08022d

.field public static lb_ic_loop_one:I = 0x7f08022e

.field public static lb_ic_more:I = 0x7f08022f

.field public static lb_ic_nav_arrow:I = 0x7f080230

.field public static lb_ic_pause:I = 0x7f080231

.field public static lb_ic_pip:I = 0x7f080232

.field public static lb_ic_play:I = 0x7f080233

.field public static lb_ic_play_fit:I = 0x7f080234

.field public static lb_ic_playback_loop:I = 0x7f080235

.field public static lb_ic_replay:I = 0x7f080236

.field public static lb_ic_sad_cloud:I = 0x7f080237

.field public static lb_ic_search_mic:I = 0x7f080238

.field public static lb_ic_search_mic_out:I = 0x7f080239

.field public static lb_ic_shuffle:I = 0x7f08023a

.field public static lb_ic_skip_next:I = 0x7f08023b

.field public static lb_ic_skip_previous:I = 0x7f08023c

.field public static lb_ic_stop:I = 0x7f08023d

.field public static lb_ic_thumb_down:I = 0x7f08023e

.field public static lb_ic_thumb_down_outline:I = 0x7f08023f

.field public static lb_ic_thumb_up:I = 0x7f080240

.field public static lb_ic_thumb_up_outline:I = 0x7f080241

.field public static lb_in_app_search_bg:I = 0x7f080242

.field public static lb_in_app_search_shadow_focused:I = 0x7f080243

.field public static lb_in_app_search_shadow_normal:I = 0x7f080244

.field public static lb_onboarding_start_button_background:I = 0x7f080245

.field public static lb_playback_now_playing_bar:I = 0x7f080246

.field public static lb_playback_progress_bar:I = 0x7f080247

.field public static lb_search_orb:I = 0x7f080248

.field public static lb_selectable_item_rounded_rect:I = 0x7f080249

.field public static lb_speech_orb:I = 0x7f08024a

.field public static lb_text_dot_one:I = 0x7f08024b

.field public static lb_text_dot_one_small:I = 0x7f08024c

.field public static lb_text_dot_two:I = 0x7f08024d

.field public static lb_text_dot_two_small:I = 0x7f08024e
