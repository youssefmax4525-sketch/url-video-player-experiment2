.class public interface abstract LiIndex2585;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract e8$mp_s$(LRKT$IX_hj$;)Z
.end method
