.class public final Llllli;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final POOl:Llllli;


# instance fields
.field public final e8$mp_s$:Ljava/lang/Runnable;

.field public rz__9J_:Llllli;

.field public final waiBKÀ:Ljava/util/concurrent/Executor;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    .line 1
    new-instance v0, Llllli;

    .line 2
    .line 3
    invoke-direct {v0}, Llllli;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Llllli;->POOl:Llllli;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Llllli;->e8$mp_s$:Ljava/lang/Runnable;

    iput-object v0, p0, Llllli;->waiBKÀ:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Llllli;->e8$mp_s$:Ljava/lang/Runnable;

    iput-object p2, p0, Llllli;->waiBKÀ:Ljava/util/concurrent/Executor;

    return-void
.end method
