.class public final LhasIndex4731;
.super LdnEìr;
.source "SourceFile"


# instance fields
.field public final synthetic yON3x:LTlOO;


# direct methods
.method public constructor <init>(LTlOO;)V
    .locals 0

    .line 1
    iput-object p1, p0, LhasIndex4731;->yON3x:LTlOO;

    .line 2
    .line 3
    invoke-direct {p0}, LdnEìr;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final ZIOOQI(LvItem9074;)V
    .locals 3

    .line 1
    iget-object v0, p0, LhasIndex4731;->yON3x:LTlOO;

    .line 2
    .line 3
    iget-object v0, v0, LTlOO;->yON3x:LHHH$Qf$;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    new-instance v1, Ll1IIll;

    .line 9
    .line 10
    iget-object v2, p1, LvItem9074;->yON3x:Ljava/lang/String;

    .line 11
    .line 12
    iget p1, p1, LvItem9074;->vaIue:I

    .line 13
    .line 14
    invoke-direct {v1, v2, p1}, Ll1IIll;-><init>(Ljava/lang/String;I)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, v1}, LHHH$Qf$;->rz__9J_(Ljava/lang/Throwable;)Z

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final lii11(Landroid/os/ParcelFileDescriptor;)V
    .locals 3

    .line 1
    new-instance v0, LQl;

    .line 2
    .line 3
    new-instance v1, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;

    .line 4
    .line 5
    invoke-direct {v1, p1}, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;-><init>(Landroid/os/ParcelFileDescriptor;)V

    .line 6
    .line 7
    .line 8
    iget-object p1, p0, LhasIndex4731;->yON3x:LTlOO;

    .line 9
    .line 10
    iget-object v2, p1, LTlOO;->kQy:LK0OQ;

    .line 11
    .line 12
    invoke-direct {v0, v1, v2}, LQl;-><init>(Ljava/io/InputStream;LK0OQ;)V

    .line 13
    .line 14
    .line 15
    iget-object p1, p1, LTlOO;->yON3x:LHHH$Qf$;

    .line 16
    .line 17
    invoke-virtual {p1, v0}, LHHH$Qf$;->waiBKÀ(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final oF_B_(Landroid/os/ParcelFileDescriptor;LK0OQ;)V
    .locals 2

    .line 1
    new-instance v0, LQl;

    .line 2
    .line 3
    new-instance v1, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;

    .line 4
    .line 5
    invoke-direct {v1, p1}, Landroid/os/ParcelFileDescriptor$AutoCloseInputStream;-><init>(Landroid/os/ParcelFileDescriptor;)V

    .line 6
    .line 7
    .line 8
    invoke-direct {v0, v1, p2}, LQl;-><init>(Ljava/io/InputStream;LK0OQ;)V

    .line 9
    .line 10
    .line 11
    iget-object p1, p0, LhasIndex4731;->yON3x:LTlOO;

    .line 12
    .line 13
    iget-object p1, p1, LTlOO;->yON3x:LHHH$Qf$;

    .line 14
    .line 15
    invoke-virtual {p1, v0}, LHHH$Qf$;->waiBKÀ(Ljava/lang/Object;)Z

    .line 16
    .line 17
    .line 18
    return-void
.end method
