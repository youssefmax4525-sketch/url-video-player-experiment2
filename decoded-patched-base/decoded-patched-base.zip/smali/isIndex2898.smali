.class public final LisIndex2898;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# instance fields
.field public final synthetic vaIue:Ljava/lang/Object;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LisIndex2898;->yON3x:I

    iput-object p2, p0, LisIndex2898;->vaIue:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onGlobalLayout()V
    .locals 10

    .line 1
    iget v0, p0, LisIndex2898;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LisIndex2898;->vaIue:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, LpO4$GQ_C$;

    .line 9
    .line 10
    iget-object v1, v0, LpO4$GQ_C$;->pCXDYg:LmCount8983;

    .line 11
    .line 12
    invoke-virtual {v0}, LpO4$GQ_C$;->e8$mp_s$()Z

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    if-eqz v2, :cond_2

    .line 17
    .line 18
    iget-boolean v2, v1, Liq_r$DZ_;->Iii:Z

    .line 19
    .line 20
    if-nez v2, :cond_2

    .line 21
    .line 22
    iget-object v2, v0, LpO4$GQ_C$;->Qp_Hp$i_:Landroid/view/View;

    .line 23
    .line 24
    if-eqz v2, :cond_1

    .line 25
    .line 26
    invoke-virtual {v2}, Landroid/view/View;->isShown()Z

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    if-nez v2, :cond_0

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_0
    invoke-virtual {v1}, Liq_r$DZ_;->tmpData3485()V

    .line 34
    .line 35
    .line 36
    goto :goto_1

    .line 37
    :cond_1
    :goto_0
    invoke-virtual {v0}, LpO4$GQ_C$;->dismiss()V

    .line 38
    .line 39
    .line 40
    :cond_2
    :goto_1
    return-void

    .line 41
    :pswitch_0
    iget-object v0, p0, LisIndex2898;->vaIue:Ljava/lang/Object;

    .line 42
    .line 43
    check-cast v0, Landroidx/mediarouter/app/POOl;

    .line 44
    .line 45
    iget-object v1, v0, Landroidx/mediarouter/app/POOl;->iSize4906:Landroidx/mediarouter/app/OverlayListView;

    .line 46
    .line 47
    invoke-virtual {v1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 48
    .line 49
    .line 50
    move-result-object v1

    .line 51
    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 52
    .line 53
    .line 54
    iget-object v1, v0, Landroidx/mediarouter/app/POOl;->ChI_KH_:Ljava/util/HashSet;

    .line 55
    .line 56
    const/4 v2, 0x1

    .line 57
    if-eqz v1, :cond_5

    .line 58
    .line 59
    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    .line 60
    .line 61
    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_5

    .line 64
    .line 65
    new-instance v1, LX8H$D_a$;

    .line 66
    .line 67
    const/4 v3, 0x0

    .line 68
    invoke-direct {v1, v3, v0}, LX8H$D_a$;-><init>(ILjava/lang/Object;)V

    .line 69
    .line 70
    .line 71
    iget-object v3, v0, Landroidx/mediarouter/app/POOl;->iSize4906:Landroidx/mediarouter/app/OverlayListView;

    .line 72
    .line 73
    invoke-virtual {v3}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    .line 74
    .line 75
    .line 76
    move-result v3

    .line 77
    const/4 v4, 0x0

    .line 78
    const/4 v5, 0x0

    .line 79
    :goto_2
    iget-object v6, v0, Landroidx/mediarouter/app/POOl;->iSize4906:Landroidx/mediarouter/app/OverlayListView;

    .line 80
    .line 81
    invoke-virtual {v6}, Landroid/view/ViewGroup;->getChildCount()I

    .line 82
    .line 83
    .line 84
    move-result v6

    .line 85
    if-ge v4, v6, :cond_6

    .line 86
    .line 87
    iget-object v6, v0, Landroidx/mediarouter/app/POOl;->iSize4906:Landroidx/mediarouter/app/OverlayListView;

    .line 88
    .line 89
    invoke-virtual {v6, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 90
    .line 91
    .line 92
    move-result-object v6

    .line 93
    add-int v7, v3, v4

    .line 94
    .line 95
    iget-object v8, v0, Landroidx/mediarouter/app/POOl;->Txy$$d_w$:Landroidx/mediarouter/app/rz__9J_;

    .line 96
    .line 97
    invoke-virtual {v8, v7}, Landroid/widget/ArrayAdapter;->getItem(I)Ljava/lang/Object;

    .line 98
    .line 99
    .line 100
    move-result-object v7

    .line 101
    check-cast v7, LRo_Zk$ML_;

    .line 102
    .line 103
    iget-object v8, v0, Landroidx/mediarouter/app/POOl;->ChI_KH_:Ljava/util/HashSet;

    .line 104
    .line 105
    invoke-virtual {v8, v7}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v7

    .line 109
    if-eqz v7, :cond_4

    .line 110
    .line 111
    new-instance v7, Landroid/view/animation/AlphaAnimation;

    .line 112
    .line 113
    const/4 v8, 0x0

    .line 114
    const/high16 v9, 0x3f800000    # 1.0f

    .line 115
    .line 116
    invoke-direct {v7, v8, v9}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    .line 117
    .line 118
    .line 119
    iget v8, v0, Landroidx/mediarouter/app/POOl;->sTxÒ7:I

    .line 120
    .line 121
    int-to-long v8, v8

    .line 122
    invoke-virtual {v7, v8, v9}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {v7, v2}, Landroid/view/animation/Animation;->setFillEnabled(Z)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v7, v2}, Landroid/view/animation/Animation;->setFillAfter(Z)V

    .line 129
    .line 130
    .line 131
    if-nez v5, :cond_3

    .line 132
    .line 133
    invoke-virtual {v7, v1}, Landroid/view/animation/Animation;->setAnimationListener(Landroid/view/animation/Animation$AnimationListener;)V

    .line 134
    .line 135
    .line 136
    const/4 v5, 0x1

    .line 137
    :cond_3
    invoke-virtual {v6}, Landroid/view/View;->clearAnimation()V

    .line 138
    .line 139
    .line 140
    invoke-virtual {v6, v7}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 141
    .line 142
    .line 143
    :cond_4
    add-int/lit8 v4, v4, 0x1

    .line 144
    .line 145
    goto :goto_2

    .line 146
    :cond_5
    invoke-virtual {v0, v2}, Landroidx/mediarouter/app/POOl;->jPos3709(Z)V

    .line 147
    .line 148
    .line 149
    :cond_6
    return-void

    .line 150
    :pswitch_1
    iget-object v0, p0, LisIndex2898;->vaIue:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast v0, LfO;

    .line 153
    .line 154
    iget-object v1, v0, LfO;->pCXDYg:Ljava/util/ArrayList;

    .line 155
    .line 156
    invoke-virtual {v0}, LfO;->e8$mp_s$()Z

    .line 157
    .line 158
    .line 159
    move-result v2

    .line 160
    if-eqz v2, :cond_9

    .line 161
    .line 162
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 163
    .line 164
    .line 165
    move-result v2

    .line 166
    if-lez v2, :cond_9

    .line 167
    .line 168
    const/4 v2, 0x0

    .line 169
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v3

    .line 173
    check-cast v3, LL1lOOO;

    .line 174
    .line 175
    iget-object v3, v3, LL1lOOO;->e8$mp_s$:LmCount8983;

    .line 176
    .line 177
    iget-boolean v3, v3, Liq_r$DZ_;->Iii:Z

    .line 178
    .line 179
    if-nez v3, :cond_9

    .line 180
    .line 181
    iget-object v3, v0, LfO;->kCount1402:Landroid/view/View;

    .line 182
    .line 183
    if-eqz v3, :cond_8

    .line 184
    .line 185
    invoke-virtual {v3}, Landroid/view/View;->isShown()Z

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    if-nez v3, :cond_7

    .line 190
    .line 191
    goto :goto_4

    .line 192
    :cond_7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 193
    .line 194
    .line 195
    move-result v0

    .line 196
    :goto_3
    if-ge v2, v0, :cond_9

    .line 197
    .line 198
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 199
    .line 200
    .line 201
    move-result-object v3

    .line 202
    add-int/lit8 v2, v2, 0x1

    .line 203
    .line 204
    check-cast v3, LL1lOOO;

    .line 205
    .line 206
    iget-object v3, v3, LL1lOOO;->e8$mp_s$:LmCount8983;

    .line 207
    .line 208
    invoke-virtual {v3}, Liq_r$DZ_;->tmpData3485()V

    .line 209
    .line 210
    .line 211
    goto :goto_3

    .line 212
    :cond_8
    :goto_4
    invoke-virtual {v0}, LfO;->dismiss()V

    .line 213
    .line 214
    .line 215
    :cond_9
    return-void

    .line 216
    :pswitch_2
    iget-object v0, p0, LisIndex2898;->vaIue:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast v0, LxGa$p$;

    .line 219
    .line 220
    iget-object v1, v0, LxGa$p$;->vz$a$:LjCount6240;

    .line 221
    .line 222
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 223
    .line 224
    .line 225
    invoke-virtual {v1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 226
    .line 227
    .line 228
    move-result v2

    .line 229
    if-eqz v2, :cond_a

    .line 230
    .line 231
    iget-object v2, v0, LxGa$p$;->iSize4906:Landroid/graphics/Rect;

    .line 232
    .line 233
    invoke-virtual {v1, v2}, Landroid/view/View;->getGlobalVisibleRect(Landroid/graphics/Rect;)Z

    .line 234
    .line 235
    .line 236
    move-result v1

    .line 237
    if-eqz v1, :cond_a

    .line 238
    .line 239
    invoke-virtual {v0}, LxGa$p$;->kO_6X_()V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v0}, Liq_r$DZ_;->tmpData3485()V

    .line 243
    .line 244
    .line 245
    goto :goto_5

    .line 246
    :cond_a
    invoke-virtual {v0}, Liq_r$DZ_;->dismiss()V

    .line 247
    .line 248
    .line 249
    :goto_5
    return-void

    .line 250
    :pswitch_3
    iget-object v0, p0, LisIndex2898;->vaIue:Ljava/lang/Object;

    .line 251
    .line 252
    check-cast v0, LjCount6240;

    .line 253
    .line 254
    invoke-virtual {v0}, LjCount6240;->getInternalPopup()LHÒAEKÙ;

    .line 255
    .line 256
    .line 257
    move-result-object v1

    .line 258
    invoke-interface {v1}, LHÒAEKÙ;->e8$mp_s$()Z

    .line 259
    .line 260
    .line 261
    move-result v1

    .line 262
    if-nez v1, :cond_b

    .line 263
    .line 264
    iget-object v1, v0, LjCount6240;->Ialue:LHÒAEKÙ;

    .line 265
    .line 266
    invoke-virtual {v0}, Landroid/view/View;->getTextDirection()I

    .line 267
    .line 268
    .line 269
    move-result v2

    .line 270
    invoke-virtual {v0}, Landroid/view/View;->getTextAlignment()I

    .line 271
    .line 272
    .line 273
    move-result v3

    .line 274
    invoke-interface {v1, v2, v3}, LHÒAEKÙ;->Ialue(II)V

    .line 275
    .line 276
    .line 277
    :cond_b
    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 278
    .line 279
    .line 280
    move-result-object v0

    .line 281
    if-eqz v0, :cond_c

    .line 282
    .line 283
    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    .line 284
    .line 285
    .line 286
    :cond_c
    return-void

    .line 287
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
