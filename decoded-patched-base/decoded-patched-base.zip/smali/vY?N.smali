.class public final LvYèN;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic JKEoÙX:Ljava/lang/Object;

.field public final synthetic POOl:I

.field public final synthetic e8$mp_s$:I

.field public final synthetic rz__9J_:Ljava/lang/Object;

.field public final synthetic waiBKÀ:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(LiOffset3986;LQ1o$jL_AB$;ILandroid/os/Bundle;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LvYèN;->e8$mp_s$:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LvYèN;->waiBKÀ:Ljava/lang/Object;

    iput-object p2, p0, LvYèN;->rz__9J_:Ljava/lang/Object;

    iput p3, p0, LvYèN;->POOl:I

    iput-object p4, p0, LvYèN;->JKEoÙX:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Landroid/content/Context;Ljava/lang/Object;II)V
    .locals 0

    .line 1
    iput p5, p0, LvYèN;->e8$mp_s$:I

    iput-object p1, p0, LvYèN;->waiBKÀ:Ljava/lang/Object;

    iput-object p2, p0, LvYèN;->rz__9J_:Ljava/lang/Object;

    iput-object p3, p0, LvYèN;->JKEoÙX:Ljava/lang/Object;

    iput p4, p0, LvYèN;->POOl:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .locals 15

    .line 1
    iget v0, p0, LvYèN;->e8$mp_s$:I

    .line 2
    .line 3
    iget v1, p0, LvYèN;->POOl:I

    .line 4
    .line 5
    iget-object v2, p0, LvYèN;->JKEoÙX:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object v3, p0, LvYèN;->rz__9J_:Ljava/lang/Object;

    .line 8
    .line 9
    iget-object v4, p0, LvYèN;->waiBKÀ:Ljava/lang/Object;

    .line 10
    .line 11
    packed-switch v0, :pswitch_data_0

    .line 12
    .line 13
    .line 14
    move-object v5, v4

    .line 15
    check-cast v5, LiOffset3986;

    .line 16
    .line 17
    move-object v14, v3

    .line 18
    check-cast v14, LQ1o$jL_AB$;

    .line 19
    .line 20
    move-object v13, v2

    .line 21
    check-cast v13, Landroid/os/Bundle;

    .line 22
    .line 23
    iget-object v6, v5, LiOffset3986;->jPos3709:Landroid/content/Context;

    .line 24
    .line 25
    iget-object v7, v14, LQ1o$jL_AB$;->yON3x:Ljava/lang/String;

    .line 26
    .line 27
    iget-object v8, v14, LQ1o$jL_AB$;->vaIue:Ljava/lang/String;

    .line 28
    .line 29
    iget-object v9, v14, LQ1o$jL_AB$;->jPos3709:Lmh_p$kn_;

    .line 30
    .line 31
    iget-object v10, v14, LQ1o$jL_AB$;->iOffset934:LfO0;

    .line 32
    .line 33
    iget-object v12, v14, LQ1o$jL_AB$;->Ialue:Ljava/lang/String;

    .line 34
    .line 35
    iget v11, p0, LvYèN;->POOl:I

    .line 36
    .line 37
    invoke-virtual/range {v5 .. v14}, LiOffset3986;->iSize9261(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Lmh_p$kn_;LfO0;ILjava/lang/String;Landroid/os/Bundle;LQ1o$jL_AB$;)Laùaèà;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    return-object v0

    .line 42
    :pswitch_0
    :try_start_0
    check-cast v4, Ljava/lang/String;

    .line 43
    .line 44
    check-cast v3, Landroid/content/Context;

    .line 45
    .line 46
    check-cast v2, Ljava/util/List;

    .line 47
    .line 48
    invoke-static {v4, v3, v2, v1}, LT$4$gz_l$;->waiBKÀ(Ljava/lang/String;Landroid/content/Context;Ljava/util/List;I)Llen0th;

    .line 49
    .line 50
    .line 51
    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 52
    goto :goto_0

    .line 53
    :catchall_0
    new-instance v0, Llen0th;

    .line 54
    .line 55
    const/4 v1, -0x3

    .line 56
    invoke-direct {v0, v1}, Llen0th;-><init>(I)V

    .line 57
    .line 58
    .line 59
    :goto_0
    return-object v0

    .line 60
    :pswitch_1
    check-cast v4, Ljava/lang/String;

    .line 61
    .line 62
    check-cast v3, Landroid/content/Context;

    .line 63
    .line 64
    check-cast v2, LisData4758;

    .line 65
    .line 66
    const/4 v0, 0x1

    .line 67
    new-array v5, v0, [Ljava/lang/Object;

    .line 68
    .line 69
    const/4 v6, 0x0

    .line 70
    aput-object v2, v5, v6

    .line 71
    .line 72
    new-instance v2, Ljava/util/ArrayList;

    .line 73
    .line 74
    invoke-direct {v2, v0}, Ljava/util/ArrayList;-><init>(I)V

    .line 75
    .line 76
    .line 77
    aget-object v0, v5, v6

    .line 78
    .line 79
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    .line 86
    .line 87
    .line 88
    move-result-object v0

    .line 89
    invoke-static {v4, v3, v0, v1}, LT$4$gz_l$;->waiBKÀ(Ljava/lang/String;Landroid/content/Context;Ljava/util/List;I)Llen0th;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    return-object v0

    .line 94
    nop

    .line 95
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
