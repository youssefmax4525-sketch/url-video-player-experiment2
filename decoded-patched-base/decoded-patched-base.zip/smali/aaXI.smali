.class public interface abstract LaaXI;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LsItem4571;
