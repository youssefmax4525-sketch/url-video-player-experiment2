.class public final LeO1IQI;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LTQO;


# instance fields
.field public DDù8:Z

.field public JKEoÙX:Lq0;

.field public POOl:I

.field public final e8$mp_s$:LiValue784;

.field public jPos3709:Z

.field public rz__9J_:I

.field public sKey7917:Z

.field public tmpData3485:Z

.field public vaIue:I

.field public final waiBKÀ:LZKy6àp;

.field public yON3x:I


# direct methods
.method public constructor <init>(LiValue784;)V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LeO1IQI;->e8$mp_s$:LiValue784;

    .line 5
    .line 6
    new-instance p1, LZKy6àp;

    .line 7
    .line 8
    const/16 v0, 0xa

    .line 9
    .line 10
    new-array v1, v0, [B

    .line 11
    .line 12
    invoke-direct {p1, v1, v0}, LZKy6àp;-><init>([BI)V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, LeO1IQI;->waiBKÀ:LZKy6àp;

    .line 16
    .line 17
    const/4 p1, 0x0

    .line 18
    iput p1, p0, LeO1IQI;->rz__9J_:I

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final DDù8()V
    .locals 1

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, LeO1IQI;->rz__9J_:I

    .line 3
    .line 4
    iput v0, p0, LeO1IQI;->POOl:I

    .line 5
    .line 6
    iput-boolean v0, p0, LeO1IQI;->DDù8:Z

    .line 7
    .line 8
    iget-object v0, p0, LeO1IQI;->e8$mp_s$:LiValue784;

    .line 9
    .line 10
    invoke-interface {v0}, LiValue784;->rz__9J_()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public final e8$mp_s$(ILYizKm;)V
    .locals 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    iget-object v2, v0, LeO1IQI;->JKEoÙX:Lq0;

    .line 6
    .line 7
    invoke-static {v2}, LvItem3158;->po0(Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    and-int/lit8 v2, p1, 0x1

    .line 11
    .line 12
    iget-object v3, v0, LeO1IQI;->e8$mp_s$:LiValue784;

    .line 13
    .line 14
    const/4 v4, -0x1

    .line 15
    const/4 v5, 0x2

    .line 16
    const/4 v6, 0x0

    .line 17
    const/4 v7, 0x1

    .line 18
    if-eqz v2, :cond_4

    .line 19
    .line 20
    iget v2, v0, LeO1IQI;->rz__9J_:I

    .line 21
    .line 22
    if-eqz v2, :cond_3

    .line 23
    .line 24
    if-eq v2, v7, :cond_3

    .line 25
    .line 26
    if-eq v2, v5, :cond_2

    .line 27
    .line 28
    iget v2, v0, LeO1IQI;->vaIue:I

    .line 29
    .line 30
    if-eq v2, v4, :cond_0

    .line 31
    .line 32
    new-instance v8, Ljava/lang/StringBuilder;

    .line 33
    .line 34
    const-string v9, "Unexpected start indicator: expected "

    .line 35
    .line 36
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    const-string v2, " more bytes"

    .line 43
    .line 44
    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    invoke-static {v2}, Lzl1;->RD(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    :cond_0
    iget v2, v1, LYizKm;->rz__9J_:I

    .line 55
    .line 56
    if-nez v2, :cond_1

    .line 57
    .line 58
    const/4 v2, 0x1

    .line 59
    goto :goto_0

    .line 60
    :cond_1
    const/4 v2, 0x0

    .line 61
    :goto_0
    invoke-interface {v3, v2}, LiValue784;->POOl(Z)V

    .line 62
    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_2
    const-string v2, "Unexpected start indicator reading extended header"

    .line 66
    .line 67
    invoke-static {v2}, Lzl1;->RD(Ljava/lang/String;)V

    .line 68
    .line 69
    .line 70
    :cond_3
    :goto_1
    iput v7, v0, LeO1IQI;->rz__9J_:I

    .line 71
    .line 72
    iput v6, v0, LeO1IQI;->POOl:I

    .line 73
    .line 74
    :cond_4
    move/from16 v2, p1

    .line 75
    .line 76
    :goto_2
    invoke-virtual {v1}, LYizKm;->valuI()I

    .line 77
    .line 78
    .line 79
    move-result v8

    .line 80
    if-lez v8, :cond_11

    .line 81
    .line 82
    iget v8, v0, LeO1IQI;->rz__9J_:I

    .line 83
    .line 84
    if-eqz v8, :cond_10

    .line 85
    .line 86
    iget-object v9, v0, LeO1IQI;->waiBKÀ:LZKy6àp;

    .line 87
    .line 88
    if-eq v8, v7, :cond_c

    .line 89
    .line 90
    if-eq v8, v5, :cond_8

    .line 91
    .line 92
    invoke-virtual {v1}, LYizKm;->valuI()I

    .line 93
    .line 94
    .line 95
    move-result v8

    .line 96
    iget v9, v0, LeO1IQI;->vaIue:I

    .line 97
    .line 98
    if-ne v9, v4, :cond_5

    .line 99
    .line 100
    const/4 v9, 0x0

    .line 101
    goto :goto_3

    .line 102
    :cond_5
    sub-int v9, v8, v9

    .line 103
    .line 104
    :goto_3
    if-lez v9, :cond_6

    .line 105
    .line 106
    sub-int/2addr v8, v9

    .line 107
    iget v9, v1, LYizKm;->waiBKÀ:I

    .line 108
    .line 109
    add-int/2addr v9, v8

    .line 110
    invoke-virtual {v1, v9}, LYizKm;->yON3x(I)V

    .line 111
    .line 112
    .line 113
    :cond_6
    invoke-interface {v3, v1}, LiValue784;->waiBKÀ(LYizKm;)V

    .line 114
    .line 115
    .line 116
    iget v9, v0, LeO1IQI;->vaIue:I

    .line 117
    .line 118
    if-eq v9, v4, :cond_7

    .line 119
    .line 120
    sub-int/2addr v9, v8

    .line 121
    iput v9, v0, LeO1IQI;->vaIue:I

    .line 122
    .line 123
    if-nez v9, :cond_7

    .line 124
    .line 125
    invoke-interface {v3, v6}, LiValue784;->POOl(Z)V

    .line 126
    .line 127
    .line 128
    iput v7, v0, LeO1IQI;->rz__9J_:I

    .line 129
    .line 130
    iput v6, v0, LeO1IQI;->POOl:I

    .line 131
    .line 132
    :cond_7
    const/4 v8, 0x2

    .line 133
    const/4 v9, -0x1

    .line 134
    goto/16 :goto_7

    .line 135
    .line 136
    :cond_8
    const/16 v8, 0xa

    .line 137
    .line 138
    iget v10, v0, LeO1IQI;->yON3x:I

    .line 139
    .line 140
    invoke-static {v8, v10}, Ljava/lang/Math;->min(II)I

    .line 141
    .line 142
    .line 143
    move-result v8

    .line 144
    iget-object v10, v9, LZKy6àp;->waiBKÀ:[B

    .line 145
    .line 146
    invoke-virtual {v0, v1, v10, v8}, LeO1IQI;->waiBKÀ(LYizKm;[BI)Z

    .line 147
    .line 148
    .line 149
    move-result v8

    .line 150
    if-eqz v8, :cond_7

    .line 151
    .line 152
    const/4 v8, 0x0

    .line 153
    iget v10, v0, LeO1IQI;->yON3x:I

    .line 154
    .line 155
    invoke-virtual {v0, v1, v8, v10}, LeO1IQI;->waiBKÀ(LYizKm;[BI)Z

    .line 156
    .line 157
    .line 158
    move-result v8

    .line 159
    if-eqz v8, :cond_7

    .line 160
    .line 161
    invoke-virtual {v9, v6}, LZKy6àp;->kO_6X_(I)V

    .line 162
    .line 163
    .line 164
    iget-boolean v8, v0, LeO1IQI;->tmpData3485:Z

    .line 165
    .line 166
    const/4 v10, 0x3

    .line 167
    const/4 v11, 0x4

    .line 168
    if-eqz v8, :cond_a

    .line 169
    .line 170
    invoke-virtual {v9, v11}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v9, v10}, LZKy6àp;->tmpData3485(I)I

    .line 174
    .line 175
    .line 176
    move-result v8

    .line 177
    int-to-long v12, v8

    .line 178
    invoke-virtual {v9, v7}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 179
    .line 180
    .line 181
    const/16 v8, 0xf

    .line 182
    .line 183
    invoke-virtual {v9, v8}, LZKy6àp;->tmpData3485(I)I

    .line 184
    .line 185
    .line 186
    move-result v14

    .line 187
    shl-int/2addr v14, v8

    .line 188
    invoke-virtual {v9, v7}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v9, v8}, LZKy6àp;->tmpData3485(I)I

    .line 192
    .line 193
    .line 194
    move-result v15

    .line 195
    int-to-long v4, v15

    .line 196
    invoke-virtual {v9, v7}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 197
    .line 198
    .line 199
    iget-boolean v15, v0, LeO1IQI;->DDù8:Z

    .line 200
    .line 201
    const/16 v16, 0x1e

    .line 202
    .line 203
    if-nez v15, :cond_9

    .line 204
    .line 205
    iget-boolean v15, v0, LeO1IQI;->sKey7917:Z

    .line 206
    .line 207
    if-eqz v15, :cond_9

    .line 208
    .line 209
    invoke-virtual {v9, v11}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {v9, v10}, LZKy6àp;->tmpData3485(I)I

    .line 213
    .line 214
    .line 215
    move-result v15

    .line 216
    move-wide/from16 v17, v12

    .line 217
    .line 218
    int-to-long v11, v15

    .line 219
    shl-long v11, v11, v16

    .line 220
    .line 221
    invoke-virtual {v9, v7}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 222
    .line 223
    .line 224
    invoke-virtual {v9, v8}, LZKy6àp;->tmpData3485(I)I

    .line 225
    .line 226
    .line 227
    move-result v13

    .line 228
    shl-int/2addr v13, v8

    .line 229
    invoke-virtual {v9, v7}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 230
    .line 231
    .line 232
    invoke-virtual {v9, v8}, LZKy6àp;->tmpData3485(I)I

    .line 233
    .line 234
    .line 235
    move-result v8

    .line 236
    move-wide/from16 v19, v11

    .line 237
    .line 238
    int-to-long v10, v8

    .line 239
    invoke-virtual {v9, v7}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 240
    .line 241
    .line 242
    iget-object v8, v0, LeO1IQI;->JKEoÙX:Lq0;

    .line 243
    .line 244
    int-to-long v12, v13

    .line 245
    or-long v12, v19, v12

    .line 246
    .line 247
    or-long/2addr v10, v12

    .line 248
    invoke-virtual {v8, v10, v11}, Lq0;->waiBKÀ(J)J

    .line 249
    .line 250
    .line 251
    iput-boolean v7, v0, LeO1IQI;->DDù8:Z

    .line 252
    .line 253
    goto :goto_4

    .line 254
    :cond_9
    move-wide/from16 v17, v12

    .line 255
    .line 256
    :goto_4
    shl-long v8, v17, v16

    .line 257
    .line 258
    int-to-long v10, v14

    .line 259
    or-long/2addr v8, v10

    .line 260
    or-long/2addr v4, v8

    .line 261
    iget-object v8, v0, LeO1IQI;->JKEoÙX:Lq0;

    .line 262
    .line 263
    invoke-virtual {v8, v4, v5}, Lq0;->waiBKÀ(J)J

    .line 264
    .line 265
    .line 266
    move-result-wide v4

    .line 267
    goto :goto_5

    .line 268
    :cond_a
    const-wide v4, -0x7fffffffffffffffL    # -4.9E-324

    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    :goto_5
    iget-boolean v8, v0, LeO1IQI;->jPos3709:Z

    .line 274
    .line 275
    if-eq v7, v8, :cond_b

    .line 276
    .line 277
    const/4 v11, 0x0

    .line 278
    goto :goto_6

    .line 279
    :cond_b
    const/4 v11, 0x4

    .line 280
    :goto_6
    or-int/2addr v2, v11

    .line 281
    invoke-interface {v3, v2, v4, v5}, LiValue784;->tmpData3485(IJ)V

    .line 282
    .line 283
    .line 284
    const/4 v15, 0x3

    .line 285
    iput v15, v0, LeO1IQI;->rz__9J_:I

    .line 286
    .line 287
    iput v6, v0, LeO1IQI;->POOl:I

    .line 288
    .line 289
    :goto_7
    const/4 v4, -0x1

    .line 290
    const/4 v5, 0x2

    .line 291
    goto/16 :goto_2

    .line 292
    .line 293
    :cond_c
    iget-object v4, v9, LZKy6àp;->waiBKÀ:[B

    .line 294
    .line 295
    const/16 v5, 0x9

    .line 296
    .line 297
    invoke-virtual {v0, v1, v4, v5}, LeO1IQI;->waiBKÀ(LYizKm;[BI)Z

    .line 298
    .line 299
    .line 300
    move-result v4

    .line 301
    if-eqz v4, :cond_7

    .line 302
    .line 303
    invoke-virtual {v9, v6}, LZKy6àp;->kO_6X_(I)V

    .line 304
    .line 305
    .line 306
    const/16 v4, 0x18

    .line 307
    .line 308
    invoke-virtual {v9, v4}, LZKy6àp;->tmpData3485(I)I

    .line 309
    .line 310
    .line 311
    move-result v4

    .line 312
    if-eq v4, v7, :cond_d

    .line 313
    .line 314
    const-string v5, "Unexpected start code prefix: "

    .line 315
    .line 316
    invoke-static {v4, v5}, LRQU_K6$Kv_;->kO_6X_(ILjava/lang/String;)V

    .line 317
    .line 318
    .line 319
    const/4 v4, -0x1

    .line 320
    iput v4, v0, LeO1IQI;->vaIue:I

    .line 321
    .line 322
    const/4 v4, 0x0

    .line 323
    const/4 v8, 0x2

    .line 324
    const/4 v9, -0x1

    .line 325
    goto :goto_9

    .line 326
    :cond_d
    const/16 v4, 0x8

    .line 327
    .line 328
    invoke-virtual {v9, v4}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 329
    .line 330
    .line 331
    const/16 v5, 0x10

    .line 332
    .line 333
    invoke-virtual {v9, v5}, LZKy6àp;->tmpData3485(I)I

    .line 334
    .line 335
    .line 336
    move-result v5

    .line 337
    const/4 v8, 0x5

    .line 338
    invoke-virtual {v9, v8}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 339
    .line 340
    .line 341
    invoke-virtual {v9}, LZKy6àp;->kCount1402()Z

    .line 342
    .line 343
    .line 344
    move-result v8

    .line 345
    iput-boolean v8, v0, LeO1IQI;->jPos3709:Z

    .line 346
    .line 347
    const/4 v8, 0x2

    .line 348
    invoke-virtual {v9, v8}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 349
    .line 350
    .line 351
    invoke-virtual {v9}, LZKy6àp;->kCount1402()Z

    .line 352
    .line 353
    .line 354
    move-result v10

    .line 355
    iput-boolean v10, v0, LeO1IQI;->tmpData3485:Z

    .line 356
    .line 357
    invoke-virtual {v9}, LZKy6àp;->kCount1402()Z

    .line 358
    .line 359
    .line 360
    move-result v10

    .line 361
    iput-boolean v10, v0, LeO1IQI;->sKey7917:Z

    .line 362
    .line 363
    const/4 v10, 0x6

    .line 364
    invoke-virtual {v9, v10}, LZKy6àp;->Qp_Hp$i_(I)V

    .line 365
    .line 366
    .line 367
    invoke-virtual {v9, v4}, LZKy6àp;->tmpData3485(I)I

    .line 368
    .line 369
    .line 370
    move-result v4

    .line 371
    iput v4, v0, LeO1IQI;->yON3x:I

    .line 372
    .line 373
    const/4 v9, -0x1

    .line 374
    if-nez v5, :cond_f

    .line 375
    .line 376
    iput v9, v0, LeO1IQI;->vaIue:I

    .line 377
    .line 378
    :cond_e
    :goto_8
    const/4 v4, 0x2

    .line 379
    goto :goto_9

    .line 380
    :cond_f
    add-int/lit8 v5, v5, -0x3

    .line 381
    .line 382
    sub-int/2addr v5, v4

    .line 383
    iput v5, v0, LeO1IQI;->vaIue:I

    .line 384
    .line 385
    if-gez v5, :cond_e

    .line 386
    .line 387
    const-string v4, "Found negative packet payload size: "

    .line 388
    .line 389
    invoke-static {v5, v4}, LRQU_K6$Kv_;->kO_6X_(ILjava/lang/String;)V

    .line 390
    .line 391
    .line 392
    iput v9, v0, LeO1IQI;->vaIue:I

    .line 393
    .line 394
    goto :goto_8

    .line 395
    :goto_9
    iput v4, v0, LeO1IQI;->rz__9J_:I

    .line 396
    .line 397
    iput v6, v0, LeO1IQI;->POOl:I

    .line 398
    .line 399
    goto :goto_7

    .line 400
    :cond_10
    const/4 v8, 0x2

    .line 401
    const/4 v9, -0x1

    .line 402
    invoke-virtual {v1}, LYizKm;->valuI()I

    .line 403
    .line 404
    .line 405
    move-result v4

    .line 406
    invoke-virtual {v1, v4}, LYizKm;->jPos3709(I)V

    .line 407
    .line 408
    .line 409
    goto :goto_7

    .line 410
    :cond_11
    return-void
.end method

.method public final rz__9J_(Lq0;LvD9$JN$;LkKey9521;)V
    .locals 0

    .line 1
    iput-object p1, p0, LeO1IQI;->JKEoÙX:Lq0;

    .line 2
    .line 3
    iget-object p1, p0, LeO1IQI;->e8$mp_s$:LiValue784;

    .line 4
    .line 5
    invoke-interface {p1, p2, p3}, LiValue784;->JKEoÙX(LvD9$JN$;LkKey9521;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public final waiBKÀ(LYizKm;[BI)Z
    .locals 3

    .line 1
    invoke-virtual {p1}, LYizKm;->valuI()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget v1, p0, LeO1IQI;->POOl:I

    .line 6
    .line 7
    sub-int v1, p3, v1

    .line 8
    .line 9
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x1

    .line 14
    if-gtz v0, :cond_0

    .line 15
    .line 16
    return v1

    .line 17
    :cond_0
    if-nez p2, :cond_1

    .line 18
    .line 19
    invoke-virtual {p1, v0}, LYizKm;->jPos3709(I)V

    .line 20
    .line 21
    .line 22
    goto :goto_0

    .line 23
    :cond_1
    iget v2, p0, LeO1IQI;->POOl:I

    .line 24
    .line 25
    invoke-virtual {p1, p2, v2, v0}, LYizKm;->tmpData3485([BII)V

    .line 26
    .line 27
    .line 28
    :goto_0
    iget p1, p0, LeO1IQI;->POOl:I

    .line 29
    .line 30
    add-int/2addr p1, v0

    .line 31
    iput p1, p0, LeO1IQI;->POOl:I

    .line 32
    .line 33
    if-ne p1, p3, :cond_2

    .line 34
    .line 35
    return v1

    .line 36
    :cond_2
    const/4 p1, 0x0

    .line 37
    return p1
.end method
