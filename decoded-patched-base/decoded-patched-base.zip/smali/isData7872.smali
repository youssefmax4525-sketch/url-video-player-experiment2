.class public LisData7872;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LkQQ;


# instance fields
.field public final synthetic e8$mp_s$:I

.field public final rz__9J_:Ljava/lang/Object;

.field public final waiBKÀ:J


# direct methods
.method public constructor <init>(JJ)V
    .locals 2

    const/4 v0, 0x1

    iput v0, p0, LisData7872;->e8$mp_s$:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, LisData7872;->waiBKÀ:J

    const-wide/16 p1, 0x0

    cmp-long v0, p3, p1

    new-instance v1, LWXSl;

    if-nez v0, :cond_0

    sget-object p1, Lc4l$M8_L$;->rz__9J_:Lc4l$M8_L$;

    goto :goto_0

    :cond_0
    new-instance v0, Lc4l$M8_L$;

    .line 3
    invoke-direct {v0, p1, p2, p3, p4}, Lc4l$M8_L$;-><init>(JJ)V

    move-object p1, v0

    .line 4
    :goto_0
    invoke-direct {v1, p1, p1}, LWXSl;-><init>(Lc4l$M8_L$;Lc4l$M8_L$;)V

    iput-object v1, p0, LisData7872;->rz__9J_:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;JI)V
    .locals 0

    .line 1
    iput p4, p0, LisData7872;->e8$mp_s$:I

    iput-object p1, p0, LisData7872;->rz__9J_:Ljava/lang/Object;

    iput-wide p2, p0, LisData7872;->waiBKÀ:J

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final e8$mp_s$()J
    .locals 2

    .line 1
    iget v0, p0, LisData7872;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-wide v0, p0, LisData7872;->waiBKÀ:J

    .line 7
    .line 8
    return-wide v0

    .line 9
    :pswitch_0
    iget-wide v0, p0, LisData7872;->waiBKÀ:J

    .line 10
    .line 11
    return-wide v0

    .line 12
    :pswitch_1
    iget-object v0, p0, LisData7872;->rz__9J_:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v0, LGC_e$v_;

    .line 15
    .line 16
    invoke-virtual {v0}, LGC_e$v_;->e8$mp_s$()J

    .line 17
    .line 18
    .line 19
    move-result-wide v0

    .line 20
    return-wide v0

    .line 21
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final sKey7917()Z
    .locals 1

    .line 1
    iget v0, p0, LisData7872;->e8$mp_s$:I

    packed-switch v0, :pswitch_data_0

    const/4 v0, 0x1

    return v0

    :pswitch_0
    const/4 v0, 0x0

    return v0

    :pswitch_1
    const/4 v0, 0x1

    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final yON3x(J)LWXSl;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-wide/from16 v1, p1

    .line 4
    .line 5
    iget v3, v0, LisData7872;->e8$mp_s$:I

    .line 6
    .line 7
    packed-switch v3, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    iget-object v3, v0, LisData7872;->rz__9J_:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v3, LKDlQl;

    .line 13
    .line 14
    iget-object v4, v3, LKDlQl;->yON3x:[LlIll11;

    .line 15
    .line 16
    const/4 v5, 0x0

    .line 17
    aget-object v4, v4, v5

    .line 18
    .line 19
    invoke-virtual {v4, v1, v2}, LlIll11;->e8$mp_s$(J)LWXSl;

    .line 20
    .line 21
    .line 22
    move-result-object v4

    .line 23
    const/4 v5, 0x1

    .line 24
    :goto_0
    iget-object v6, v3, LKDlQl;->yON3x:[LlIll11;

    .line 25
    .line 26
    array-length v7, v6

    .line 27
    if-ge v5, v7, :cond_1

    .line 28
    .line 29
    aget-object v6, v6, v5

    .line 30
    .line 31
    invoke-virtual {v6, v1, v2}, LlIll11;->e8$mp_s$(J)LWXSl;

    .line 32
    .line 33
    .line 34
    move-result-object v6

    .line 35
    iget-object v7, v6, LWXSl;->e8$mp_s$:Lc4l$M8_L$;

    .line 36
    .line 37
    iget-object v8, v4, LWXSl;->e8$mp_s$:Lc4l$M8_L$;

    .line 38
    .line 39
    iget-wide v9, v7, Lc4l$M8_L$;->waiBKÀ:J

    .line 40
    .line 41
    iget-wide v7, v8, Lc4l$M8_L$;->waiBKÀ:J

    .line 42
    .line 43
    cmp-long v11, v9, v7

    .line 44
    .line 45
    if-gez v11, :cond_0

    .line 46
    .line 47
    move-object v4, v6

    .line 48
    :cond_0
    add-int/lit8 v5, v5, 0x1

    .line 49
    .line 50
    goto :goto_0

    .line 51
    :cond_1
    return-object v4

    .line 52
    :pswitch_0
    iget-object v1, v0, LisData7872;->rz__9J_:Ljava/lang/Object;

    .line 53
    .line 54
    check-cast v1, LWXSl;

    .line 55
    .line 56
    return-object v1

    .line 57
    :pswitch_1
    iget-object v3, v0, LisData7872;->rz__9J_:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast v3, LGC_e$v_;

    .line 60
    .line 61
    iget-object v4, v3, LGC_e$v_;->jPos3709:LjSize1789;

    .line 62
    .line 63
    invoke-static {v4}, LvItem3158;->po0(Ljava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iget-object v4, v3, LGC_e$v_;->jPos3709:LjSize1789;

    .line 67
    .line 68
    iget-object v5, v4, LjSize1789;->vaIue:Ljava/lang/Object;

    .line 69
    .line 70
    check-cast v5, [J

    .line 71
    .line 72
    iget-object v4, v4, LjSize1789;->jPos3709:Ljava/lang/Object;

    .line 73
    .line 74
    check-cast v4, [J

    .line 75
    .line 76
    iget v6, v3, LGC_e$v_;->JKEoÙX:I

    .line 77
    .line 78
    int-to-long v6, v6

    .line 79
    mul-long v6, v6, v1

    .line 80
    .line 81
    iget-wide v8, v3, LGC_e$v_;->vaIue:J

    .line 82
    .line 83
    const-wide/32 v10, 0xf4240

    .line 84
    .line 85
    .line 86
    div-long/2addr v6, v10

    .line 87
    const-wide/16 v12, -0x1

    .line 88
    .line 89
    add-long/2addr v8, v12

    .line 90
    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->min(JJ)J

    .line 91
    .line 92
    .line 93
    move-result-wide v6

    .line 94
    const-wide/16 v8, 0x0

    .line 95
    .line 96
    invoke-static {v8, v9, v6, v7}, Ljava/lang/Math;->max(JJ)J

    .line 97
    .line 98
    .line 99
    move-result-wide v6

    .line 100
    const/4 v12, 0x0

    .line 101
    invoke-static {v5, v6, v7, v12}, LnPos2706;->vaIue([JJZ)I

    .line 102
    .line 103
    .line 104
    move-result v6

    .line 105
    const/4 v7, -0x1

    .line 106
    if-ne v6, v7, :cond_2

    .line 107
    .line 108
    move-wide v12, v8

    .line 109
    goto :goto_1

    .line 110
    :cond_2
    aget-wide v12, v5, v6

    .line 111
    .line 112
    :goto_1
    if-ne v6, v7, :cond_3

    .line 113
    .line 114
    goto :goto_2

    .line 115
    :cond_3
    aget-wide v8, v4, v6

    .line 116
    .line 117
    :goto_2
    iget v3, v3, LGC_e$v_;->JKEoÙX:I

    .line 118
    .line 119
    mul-long v12, v12, v10

    .line 120
    .line 121
    int-to-long v14, v3

    .line 122
    div-long/2addr v12, v14

    .line 123
    new-instance v14, Lc4l$M8_L$;

    .line 124
    .line 125
    move-wide/from16 v16, v8

    .line 126
    .line 127
    const/4 v15, -0x1

    .line 128
    iget-wide v7, v0, LisData7872;->waiBKÀ:J

    .line 129
    .line 130
    move-wide/from16 v18, v10

    .line 131
    .line 132
    add-long v10, v7, v16

    .line 133
    .line 134
    invoke-direct {v14, v12, v13, v10, v11}, Lc4l$M8_L$;-><init>(JJ)V

    .line 135
    .line 136
    .line 137
    cmp-long v9, v12, v1

    .line 138
    .line 139
    if-eqz v9, :cond_5

    .line 140
    .line 141
    array-length v1, v5

    .line 142
    add-int/2addr v1, v15

    .line 143
    if-ne v6, v1, :cond_4

    .line 144
    .line 145
    goto :goto_3

    .line 146
    :cond_4
    add-int/lit8 v6, v6, 0x1

    .line 147
    .line 148
    aget-wide v1, v5, v6

    .line 149
    .line 150
    aget-wide v5, v4, v6

    .line 151
    .line 152
    mul-long v1, v1, v18

    .line 153
    .line 154
    int-to-long v3, v3

    .line 155
    div-long/2addr v1, v3

    .line 156
    new-instance v3, Lc4l$M8_L$;

    .line 157
    .line 158
    add-long/2addr v7, v5

    .line 159
    invoke-direct {v3, v1, v2, v7, v8}, Lc4l$M8_L$;-><init>(JJ)V

    .line 160
    .line 161
    .line 162
    new-instance v1, LWXSl;

    .line 163
    .line 164
    invoke-direct {v1, v14, v3}, LWXSl;-><init>(Lc4l$M8_L$;Lc4l$M8_L$;)V

    .line 165
    .line 166
    .line 167
    goto :goto_4

    .line 168
    :cond_5
    :goto_3
    new-instance v1, LWXSl;

    .line 169
    .line 170
    invoke-direct {v1, v14, v14}, LWXSl;-><init>(Lc4l$M8_L$;Lc4l$M8_L$;)V

    .line 171
    .line 172
    .line 173
    :goto_4
    return-object v1

    .line 174
    nop

    .line 175
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
