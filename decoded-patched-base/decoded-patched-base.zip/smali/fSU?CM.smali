.class public final LfSUìCM;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public e8$mp_s$:F

.field public rz__9J_:I

.field public waiBKÀ:I


# direct methods
.method public constructor <init>(FII)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, LfSUìCM;->e8$mp_s$:F

    .line 5
    .line 6
    iput p2, p0, LfSUìCM;->waiBKÀ:I

    .line 7
    .line 8
    iput p3, p0, LfSUìCM;->rz__9J_:I

    .line 9
    .line 10
    return-void
.end method
