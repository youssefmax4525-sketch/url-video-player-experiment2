.class public interface abstract LXtc;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract sKey7917(LisSize5256;)V
.end method
