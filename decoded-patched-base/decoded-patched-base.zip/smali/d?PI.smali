.class public abstract LdèPI;
.super Ljava/lang/Object;


# static fields
.field public static NO_DEBUG:I = 0x7f0b000a

.field public static SHOW_ALL:I = 0x7f0b000c

.field public static SHOW_PATH:I = 0x7f0b000d

.field public static SHOW_PROGRESS:I = 0x7f0b000e

.field public static above:I = 0x7f0b0013

.field public static accelerate:I = 0x7f0b0014

.field public static actionDown:I = 0x7f0b0037

.field public static actionDownUp:I = 0x7f0b0038

.field public static actionUp:I = 0x7f0b003a

.field public static aligned:I = 0x7f0b0065

.field public static allStates:I = 0x7f0b0067

.field public static animateToEnd:I = 0x7f0b0069

.field public static animateToStart:I = 0x7f0b006a

.field public static antiClockwise:I = 0x7f0b006b

.field public static anticipate:I = 0x7f0b006c

.field public static asConfigured:I = 0x7f0b006e

.field public static auto:I = 0x7f0b0071

.field public static autoComplete:I = 0x7f0b0072

.field public static autoCompleteToEnd:I = 0x7f0b0073

.field public static autoCompleteToStart:I = 0x7f0b0074

.field public static axisRelative:I = 0x7f0b0075

.field public static baseline:I = 0x7f0b0081

.field public static below:I = 0x7f0b0084

.field public static bestChoice:I = 0x7f0b0085

.field public static bottom:I = 0x7f0b0088

.field public static bounce:I = 0x7f0b008b

.field public static callMeasure:I = 0x7f0b00ac

.field public static carryVelocity:I = 0x7f0b00af

.field public static center:I = 0x7f0b00be

.field public static chain:I = 0x7f0b00c4

.field public static chain2:I = 0x7f0b00c5

.field public static clockwise:I = 0x7f0b00ce

.field public static closest:I = 0x7f0b00cf

.field public static constraint:I = 0x7f0b00d4

.field public static continuousVelocity:I = 0x7f0b00e1

.field public static cos:I = 0x7f0b00e9

.field public static currentState:I = 0x7f0b00ec

.field public static decelerate:I = 0x7f0b00f3

.field public static decelerateAndComplete:I = 0x7f0b00f4

.field public static deltaRelative:I = 0x7f0b00f7

.field public static dragAnticlockwise:I = 0x7f0b0115

.field public static dragClockwise:I = 0x7f0b0116

.field public static dragDown:I = 0x7f0b0117

.field public static dragEnd:I = 0x7f0b0118

.field public static dragLeft:I = 0x7f0b0119

.field public static dragRight:I = 0x7f0b011a

.field public static dragStart:I = 0x7f0b011b

.field public static dragUp:I = 0x7f0b011c

.field public static easeIn:I = 0x7f0b011f

.field public static easeInOut:I = 0x7f0b0120

.field public static easeOut:I = 0x7f0b0121

.field public static east:I = 0x7f0b0122

.field public static end:I = 0x7f0b012e

.field public static flip:I = 0x7f0b0182

.field public static frost:I = 0x7f0b0187

.field public static gone:I = 0x7f0b018e

.field public static honorRequest:I = 0x7f0b01b4

.field public static horizontal:I = 0x7f0b01b5

.field public static horizontal_only:I = 0x7f0b01b6

.field public static ignore:I = 0x7f0b01be

.field public static ignoreRequest:I = 0x7f0b01bf

.field public static immediateStop:I = 0x7f0b01c1

.field public static included:I = 0x7f0b01c2

.field public static invisible:I = 0x7f0b01ca

.field public static jumpToEnd:I = 0x7f0b01d0

.field public static jumpToStart:I = 0x7f0b01d1

.field public static layout:I = 0x7f0b01d4

.field public static left:I = 0x7f0b01f5

.field public static linear:I = 0x7f0b01fb

.field public static match_constraint:I = 0x7f0b020f

.field public static match_parent:I = 0x7f0b0210

.field public static middle:I = 0x7f0b0238

.field public static motion_base:I = 0x7f0b0241

.field public static neverCompleteToEnd:I = 0x7f0b02a1

.field public static neverCompleteToStart:I = 0x7f0b02a2

.field public static noState:I = 0x7f0b02a4

.field public static none:I = 0x7f0b02a6

.field public static normal:I = 0x7f0b02a7

.field public static north:I = 0x7f0b02a8

.field public static overshoot:I = 0x7f0b02cb

.field public static packed:I = 0x7f0b02cc

.field public static parent:I = 0x7f0b02d0

.field public static parentRelative:I = 0x7f0b02d2

.field public static path:I = 0x7f0b02d5

.field public static pathRelative:I = 0x7f0b02d6

.field public static percent:I = 0x7f0b02d9

.field public static position:I = 0x7f0b02e6

.field public static postLayout:I = 0x7f0b02e7

.field public static rectangles:I = 0x7f0b02f0

.field public static reverseSawtooth:I = 0x7f0b02f4

.field public static right:I = 0x7f0b02f5

.field public static sawtooth:I = 0x7f0b0301

.field public static sharedValueSet:I = 0x7f0b0320

.field public static sharedValueUnset:I = 0x7f0b0321

.field public static sin:I = 0x7f0b0326

.field public static skipped:I = 0x7f0b0328

.field public static south:I = 0x7f0b032f

.field public static spline:I = 0x7f0b0338

.field public static spread:I = 0x7f0b033a

.field public static spread_inside:I = 0x7f0b033b

.field public static spring:I = 0x7f0b033c

.field public static square:I = 0x7f0b033d

.field public static standard:I = 0x7f0b0341

.field public static start:I = 0x7f0b0342

.field public static startHorizontal:I = 0x7f0b0343

.field public static startVertical:I = 0x7f0b0345

.field public static staticLayout:I = 0x7f0b0348

.field public static staticPostLayout:I = 0x7f0b0349

.field public static stop:I = 0x7f0b034e

.field public static top:I = 0x7f0b038e

.field public static triangle:I = 0x7f0b03a0

.field public static vertical:I = 0x7f0b03ab

.field public static vertical_only:I = 0x7f0b03ac

.field public static view_transition:I = 0x7f0b03b8

.field public static visible:I = 0x7f0b03be

.field public static west:I = 0x7f0b03c5

.field public static wrap:I = 0x7f0b03cb

.field public static wrap_content:I = 0x7f0b03cc

.field public static wrap_content_constrained:I = 0x7f0b03cd

.field public static x_left:I = 0x7f0b03ce

.field public static x_right:I = 0x7f0b03cf
