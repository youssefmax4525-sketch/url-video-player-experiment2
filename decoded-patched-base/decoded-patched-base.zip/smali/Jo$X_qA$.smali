.class public abstract LJo$X_qA$;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final POOl:LkKey8355;

.field public static final e8$mp_s$:L$òuj;

.field public static final rz__9J_:LVìmDs;

.field public static final waiBKÀ:LUEè;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, LtmpPos8530;

    .line 2
    .line 3
    const/16 v1, 0xd

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-direct {v0, v1, v2}, LtmpPos8530;-><init>(IB)V

    .line 7
    .line 8
    .line 9
    new-instance v1, L$òuj;

    .line 10
    .line 11
    const-class v2, LzèOÌz;

    .line 12
    .line 13
    const-class v3, Lfòei;

    .line 14
    .line 15
    invoke-direct {v1, v2, v3, v0}, L$òuj;-><init>(Ljava/lang/Class;Ljava/lang/Class;LnA$3g_00$;)V

    .line 16
    .line 17
    .line 18
    sput-object v1, LJo$X_qA$;->e8$mp_s$:L$òuj;

    .line 19
    .line 20
    invoke-static {}, LE_Y_mV_;->sKey6064()Lw00OID;

    .line 21
    .line 22
    .line 23
    new-instance v0, LUEè;

    .line 24
    .line 25
    const/4 v1, 0x2

    .line 26
    const-string v2, "type.googleapis.com/google.crypto.tink.XChaCha20Poly1305Key"

    .line 27
    .line 28
    invoke-direct {v0, v1, v3, v2}, LUEè;-><init>(ILjava/lang/Class;Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    sput-object v0, LJo$X_qA$;->waiBKÀ:LUEè;

    .line 32
    .line 33
    new-instance v0, LVìmDs;

    .line 34
    .line 35
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 36
    .line 37
    .line 38
    sput-object v0, LJo$X_qA$;->rz__9J_:LVìmDs;

    .line 39
    .line 40
    new-instance v0, LkKey8355;

    .line 41
    .line 42
    const/16 v1, 0x8

    .line 43
    .line 44
    invoke-direct {v0, v1}, LkKey8355;-><init>(I)V

    .line 45
    .line 46
    .line 47
    sput-object v0, LJo$X_qA$;->POOl:LkKey8355;

    .line 48
    .line 49
    return-void
.end method
