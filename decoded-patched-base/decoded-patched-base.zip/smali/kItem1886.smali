.class public final LkItem1886;
.super LTlOO;
.source "SourceFile"


# instance fields
.field public pCXDYg:I

.field public valuI:Ljava/lang/String;


# virtual methods
.method public final iQ0D(Landroid/os/Bundle;)V
    .locals 6

    .line 1
    iget-object p1, p0, LTlOO;->vaIue:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter p1

    .line 4
    :try_start_0
    iget-boolean v0, p0, LTlOO;->iOffset934:Z

    .line 5
    .line 6
    if-nez v0, :cond_4

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    iput-boolean v0, p0, LTlOO;->iOffset934:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 10
    .line 11
    :try_start_1
    iget v1, p0, LkItem1886;->pCXDYg:I

    .line 12
    .line 13
    const/4 v2, 0x2

    .line 14
    if-ne v1, v2, :cond_1

    .line 15
    .line 16
    iget-object v1, p0, LTlOO;->Ialue:LiItem1456;

    .line 17
    .line 18
    invoke-virtual {v1}, Ly01I0I;->Qp_Hp$i_()Landroid/os/IInterface;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, LjIndex5669;

    .line 23
    .line 24
    iget-object v2, p0, LTlOO;->kQy:LK0OQ;

    .line 25
    .line 26
    sget-object v3, LisIndex2415;->lIi1ll:LSdE$n$;

    .line 27
    .line 28
    sget-object v4, LIl1il;->POOl:LIl1il;

    .line 29
    .line 30
    iget-object v4, v4, LIl1il;->rz__9J_:LnCount1076;

    .line 31
    .line 32
    invoke-virtual {v4, v3}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    check-cast v3, Ljava/lang/Boolean;

    .line 37
    .line 38
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 39
    .line 40
    .line 41
    move-result v3

    .line 42
    if-eqz v3, :cond_0

    .line 43
    .line 44
    new-instance v3, LUuK$N_yz$;

    .line 45
    .line 46
    iget-object v4, p0, LTlOO;->yON3x:LHHH$Qf$;

    .line 47
    .line 48
    iget-object v5, p0, LTlOO;->kQy:LK0OQ;

    .line 49
    .line 50
    invoke-direct {v3, v4, v5}, LUuK$N_yz$;-><init>(LHHH$Qf$;LK0OQ;)V

    .line 51
    .line 52
    .line 53
    goto :goto_0

    .line 54
    :catchall_0
    move-exception v1

    .line 55
    goto :goto_2

    .line 56
    :cond_0
    new-instance v3, LhasIndex4731;

    .line 57
    .line 58
    invoke-direct {v3, p0}, LhasIndex4731;-><init>(LTlOO;)V

    .line 59
    .line 60
    .line 61
    :goto_0
    invoke-interface {v1, v2, v3}, LjIndex5669;->tmpValue6454(LK0OQ;LwTZTcòJ;)V

    .line 62
    .line 63
    .line 64
    goto :goto_3

    .line 65
    :cond_1
    const/4 v2, 0x3

    .line 66
    if-ne v1, v2, :cond_3

    .line 67
    .line 68
    iget-object v1, p0, LTlOO;->Ialue:LiItem1456;

    .line 69
    .line 70
    invoke-virtual {v1}, Ly01I0I;->Qp_Hp$i_()Landroid/os/IInterface;

    .line 71
    .line 72
    .line 73
    move-result-object v1

    .line 74
    check-cast v1, LjIndex5669;

    .line 75
    .line 76
    iget-object v2, p0, LkItem1886;->valuI:Ljava/lang/String;

    .line 77
    .line 78
    sget-object v3, LisIndex2415;->lIi1ll:LSdE$n$;

    .line 79
    .line 80
    sget-object v4, LIl1il;->POOl:LIl1il;

    .line 81
    .line 82
    iget-object v4, v4, LIl1il;->rz__9J_:LnCount1076;

    .line 83
    .line 84
    invoke-virtual {v4, v3}, LnCount1076;->e8$mp_s$(LSdE$n$;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v3

    .line 88
    check-cast v3, Ljava/lang/Boolean;

    .line 89
    .line 90
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    if-eqz v3, :cond_2

    .line 95
    .line 96
    new-instance v3, LUuK$N_yz$;

    .line 97
    .line 98
    iget-object v4, p0, LTlOO;->yON3x:LHHH$Qf$;

    .line 99
    .line 100
    iget-object v5, p0, LTlOO;->kQy:LK0OQ;

    .line 101
    .line 102
    invoke-direct {v3, v4, v5}, LUuK$N_yz$;-><init>(LHHH$Qf$;LK0OQ;)V

    .line 103
    .line 104
    .line 105
    goto :goto_1

    .line 106
    :cond_2
    new-instance v3, LhasIndex4731;

    .line 107
    .line 108
    invoke-direct {v3, p0}, LhasIndex4731;-><init>(LTlOO;)V

    .line 109
    .line 110
    .line 111
    :goto_1
    invoke-interface {v1, v2, v3}, LjIndex5669;->XÒiDZdXm(Ljava/lang/String;LwTZTcòJ;)V

    .line 112
    .line 113
    .line 114
    goto :goto_3

    .line 115
    :cond_3
    iget-object v1, p0, LTlOO;->yON3x:LHHH$Qf$;

    .line 116
    .line 117
    new-instance v2, Lkyd_Q0_;

    .line 118
    .line 119
    invoke-direct {v2, v0}, LLÀmNÙà;-><init>(I)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v1, v2}, LHHH$Qf$;->rz__9J_(Ljava/lang/Throwable;)Z
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 123
    .line 124
    .line 125
    goto :goto_3

    .line 126
    :goto_2
    :try_start_2
    sget-object v2, LvItem598;->tzKù7Ol1:LvItem598;

    .line 127
    .line 128
    iget-object v2, v2, LvItem598;->sKey7917:LNl;

    .line 129
    .line 130
    const-string v3, "RemoteUrlAndCacheKeyClientTask.onConnected"

    .line 131
    .line 132
    invoke-virtual {v2, v3, v1}, LNl;->yON3x(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 133
    .line 134
    .line 135
    iget-object v1, p0, LTlOO;->yON3x:LHHH$Qf$;

    .line 136
    .line 137
    new-instance v2, Lkyd_Q0_;

    .line 138
    .line 139
    invoke-direct {v2, v0}, LLÀmNÙà;-><init>(I)V

    .line 140
    .line 141
    .line 142
    invoke-virtual {v1, v2}, LHHH$Qf$;->rz__9J_(Ljava/lang/Throwable;)Z

    .line 143
    .line 144
    .line 145
    goto :goto_3

    .line 146
    :catchall_1
    move-exception v0

    .line 147
    goto :goto_4

    .line 148
    :catch_0
    iget-object v1, p0, LTlOO;->yON3x:LHHH$Qf$;

    .line 149
    .line 150
    new-instance v2, Lkyd_Q0_;

    .line 151
    .line 152
    invoke-direct {v2, v0}, LLÀmNÙà;-><init>(I)V

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1, v2}, LHHH$Qf$;->rz__9J_(Ljava/lang/Throwable;)Z

    .line 156
    .line 157
    .line 158
    :cond_4
    :goto_3
    monitor-exit p1

    .line 159
    return-void

    .line 160
    :goto_4
    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    .line 161
    throw v0
.end method

.method public final iSize4906(Lke0;)V
    .locals 1

    .line 1
    const-string p1, "Cannot connect to remote service, fallback to local instance."

    .line 2
    .line 3
    invoke-static {p1}, LPJNypàa;->iQ0D(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    new-instance p1, Lkyd_Q0_;

    .line 7
    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p1, v0}, LLÀmNÙà;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iget-object v0, p0, LTlOO;->yON3x:LHHH$Qf$;

    .line 13
    .line 14
    invoke-virtual {v0, p1}, LHHH$Qf$;->rz__9J_(Ljava/lang/Throwable;)Z

    .line 15
    .line 16
    .line 17
    return-void
.end method
