.class public final LisIndex4661;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final JKEoÙX:[Ljava/lang/String;


# instance fields
.field public POOl:Z

.field public e8$mp_s$:J

.field public rz__9J_:J

.field public waiBKÀ:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "android:establish_vpn_service"

    .line 2
    .line 3
    const-string v1, "android:establish_vpn_manager"

    .line 4
    .line 5
    filled-new-array {v0, v1}, [Ljava/lang/String;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    sput-object v0, LisIndex4661;->JKEoÙX:[Ljava/lang/String;

    .line 10
    .line 11
    return-void
.end method

.method public static e8$mp_s$(Landroid/content/Context;Ljava/util/concurrent/Executor;)LisIndex4661;
    .locals 4

    .line 1
    sget-object v0, LisIndex4661;->JKEoÙX:[Ljava/lang/String;

    .line 2
    .line 3
    new-instance v1, LisIndex4661;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    const-wide/16 v2, 0x0

    .line 9
    .line 10
    iput-wide v2, v1, LisIndex4661;->e8$mp_s$:J

    .line 11
    .line 12
    iput-wide v2, v1, LisIndex4661;->waiBKÀ:J

    .line 13
    .line 14
    const-wide/16 v2, -0x1

    .line 15
    .line 16
    iput-wide v2, v1, LisIndex4661;->rz__9J_:J

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    iput-boolean v2, v1, LisIndex4661;->POOl:Z

    .line 20
    .line 21
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 22
    .line 23
    const/16 v3, 0x1e

    .line 24
    .line 25
    if-ge v2, v3, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    new-instance v2, LhasOffset1394;

    .line 29
    .line 30
    invoke-direct {v2, v1}, LhasOffset1394;-><init>(LisIndex4661;)V

    .line 31
    .line 32
    .line 33
    :try_start_0
    const-string v3, "appops"

    .line 34
    .line 35
    invoke-virtual {p0, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    check-cast p0, Landroid/app/AppOpsManager;

    .line 40
    .line 41
    invoke-static {p0, v0, p1, v2}, LtEtE;->JKEoÙX(Landroid/app/AppOpsManager;[Ljava/lang/String;Ljava/util/concurrent/Executor;LhasOffset1394;)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodError; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    .line 42
    .line 43
    .line 44
    :catch_0
    :goto_0
    return-object v1
.end method
