.class public interface abstract LZ1QD1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract Oo$1_r$(LjData6565;)V
.end method
