.class public LyIDlQ;
.super LisSize9260;
.source "SourceFile"

# interfaces
.implements LULì;


# annotations
.annotation build Landroidx/media3/common/util/UnstableApi;
.end annotation


# instance fields
.field public colnt:Ljava/util/ArrayList;

.field public lIl1:Lm1;

.field public po0:Landroid/widget/TextView;

.field public s$_D_:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 1
    invoke-direct {p0}, LisSize9260;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final JKEoÙX(LUN3Jt;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, LisSize9260;->jPos3709()LUd$5_1h$;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v0, v0, Linfo/t4w/vp/view/MainActivity;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {p0}, LisSize9260;->jPos3709()LUd$5_1h$;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    check-cast v0, Linfo/t4w/vp/view/MainActivity;

    .line 14
    .line 15
    iget-object v1, p1, LUN3Jt;->rz__9J_:Ljava/lang/String;

    .line 16
    .line 17
    iget-object p1, p1, LUN3Jt;->tmpData3485:Ljava/lang/String;

    .line 18
    .line 19
    invoke-virtual {v0, v1, p1}, Linfo/t4w/vp/view/MainActivity;->sKey6064(Ljava/lang/String;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    :cond_0
    return-void
.end method

.method public final Q1_f_(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 2

    .line 1
    sget v0, LKùiu;->fragment_video_list:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p1, v0, p2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    sget p2, LRO1QI;->recycler_view:I

    .line 9
    .line 10
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    check-cast p2, Landroidx/recyclerview/widget/RecyclerView;

    .line 15
    .line 16
    iput-object p2, p0, LyIDlQ;->s$_D_:Landroidx/recyclerview/widget/RecyclerView;

    .line 17
    .line 18
    sget p2, LRO1QI;->empty_view:I

    .line 19
    .line 20
    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 21
    .line 22
    .line 23
    move-result-object p2

    .line 24
    check-cast p2, Landroid/widget/TextView;

    .line 25
    .line 26
    iput-object p2, p0, LyIDlQ;->po0:Landroid/widget/TextView;

    .line 27
    .line 28
    iget-object p2, p0, LyIDlQ;->s$_D_:Landroidx/recyclerview/widget/RecyclerView;

    .line 29
    .line 30
    new-instance v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    .line 31
    .line 32
    invoke-virtual {p0}, LisSize9260;->pQ1Il()Landroid/content/Context;

    .line 33
    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    invoke-direct {v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(I)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p2, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/JKEoÙX;)V

    .line 40
    .line 41
    .line 42
    new-instance p2, Lm1;

    .line 43
    .line 44
    invoke-virtual {p0}, LisSize9260;->pQ1Il()Landroid/content/Context;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-direct {p2, v0}, Lm1;-><init>(Landroid/content/Context;)V

    .line 49
    .line 50
    .line 51
    iput-object p2, p0, LyIDlQ;->lIl1:Lm1;

    .line 52
    .line 53
    invoke-virtual {p0}, LyIDlQ;->gSy_FG$D_()V

    .line 54
    .line 55
    .line 56
    return-object p1
.end method

.method public final gSy_FG$D_()V
    .locals 8

    .line 1
    iget-object v0, p0, LyIDlQ;->lIl1:Lm1;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    new-instance v1, Ljava/util/ArrayList;

    .line 7
    .line 8
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    const/4 v2, 0x0

    .line 16
    const-string v3, "SELECT * FROM videos WHERE is_favorite=1 ORDER BY timestamp DESC"

    .line 17
    .line 18
    invoke-virtual {v0, v3, v2}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-interface {v2}, Landroid/database/Cursor;->moveToFirst()Z

    .line 23
    .line 24
    .line 25
    move-result v3

    .line 26
    if-eqz v3, :cond_3

    .line 27
    .line 28
    :cond_0
    new-instance v3, LUN3Jt;

    .line 29
    .line 30
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 31
    .line 32
    .line 33
    const/4 v4, 0x0

    .line 34
    invoke-interface {v2, v4}, Landroid/database/Cursor;->getLong(I)J

    .line 35
    .line 36
    .line 37
    move-result-wide v5

    .line 38
    iput-wide v5, v3, LUN3Jt;->e8$mp_s$:J

    .line 39
    .line 40
    const/4 v5, 0x1

    .line 41
    invoke-interface {v2, v5}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v6

    .line 45
    iput-object v6, v3, LUN3Jt;->waiBKÀ:Ljava/lang/String;

    .line 46
    .line 47
    const/4 v6, 0x2

    .line 48
    invoke-interface {v2, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v6

    .line 52
    iput-object v6, v3, LUN3Jt;->rz__9J_:Ljava/lang/String;

    .line 53
    .line 54
    const/4 v6, 0x3

    .line 55
    invoke-interface {v2, v6}, Landroid/database/Cursor;->getLong(I)J

    .line 56
    .line 57
    .line 58
    move-result-wide v6

    .line 59
    iput-wide v6, v3, LUN3Jt;->POOl:J

    .line 60
    .line 61
    const/4 v6, 0x4

    .line 62
    invoke-interface {v2, v6}, Landroid/database/Cursor;->getInt(I)I

    .line 63
    .line 64
    .line 65
    move-result v6

    .line 66
    if-ne v6, v5, :cond_1

    .line 67
    .line 68
    const/4 v4, 0x1

    .line 69
    :cond_1
    iput-boolean v4, v3, LUN3Jt;->JKEoÙX:Z

    .line 70
    .line 71
    const/4 v4, 0x5

    .line 72
    invoke-interface {v2, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    if-eqz v5, :cond_2

    .line 77
    .line 78
    invoke-interface {v2, v4}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    goto :goto_0

    .line 83
    :cond_2
    const-string v4, ""

    .line 84
    .line 85
    :goto_0
    iput-object v4, v3, LUN3Jt;->tmpData3485:Ljava/lang/String;

    .line 86
    .line 87
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 88
    .line 89
    .line 90
    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    if-nez v3, :cond_0

    .line 95
    .line 96
    :cond_3
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    .line 97
    .line 98
    .line 99
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteClosable;->close()V

    .line 100
    .line 101
    .line 102
    iput-object v1, p0, LyIDlQ;->colnt:Ljava/util/ArrayList;

    .line 103
    .line 104
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 105
    .line 106
    .line 107
    move-result v0

    .line 108
    if-lez v0, :cond_4

    .line 109
    .line 110
    iget-object v0, p0, LyIDlQ;->po0:Landroid/widget/TextView;

    .line 111
    .line 112
    const/16 v1, 0x8

    .line 113
    .line 114
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 115
    .line 116
    .line 117
    :cond_4
    new-instance v0, LvàZ;

    .line 118
    .line 119
    invoke-virtual {p0}, LisSize9260;->pQ1Il()Landroid/content/Context;

    .line 120
    .line 121
    .line 122
    move-result-object v1

    .line 123
    iget-object v2, p0, LyIDlQ;->colnt:Ljava/util/ArrayList;

    .line 124
    .line 125
    invoke-direct {v0, v1, v2, p0}, LvàZ;-><init>(Landroid/content/Context;Ljava/util/ArrayList;LULì;)V

    .line 126
    .line 127
    .line 128
    iget-object v1, p0, LyIDlQ;->s$_D_:Landroidx/recyclerview/widget/RecyclerView;

    .line 129
    .line 130
    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Landroidx/recyclerview/widget/rz__9J_;)V

    .line 131
    .line 132
    .line 133
    return-void
.end method

.method public final ll()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, LisSize9260;->BCIm:Z

    .line 3
    .line 4
    invoke-virtual {p0}, LyIDlQ;->gSy_FG$D_()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final sKey7917(LUN3Jt;)V
    .locals 10

    .line 1
    new-instance v6, Landroid/app/Dialog;

    .line 2
    .line 3
    invoke-virtual {p0}, LisSize9260;->pQ1Il()Landroid/content/Context;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-direct {v6, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, LisSize9260;->gCount1961:Landroid/view/LayoutInflater;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    if-nez v0, :cond_0

    .line 14
    .line 15
    invoke-virtual {p0, v1}, LisSize9260;->tzKù7Ol1(Landroid/os/Bundle;)Landroid/view/LayoutInflater;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iput-object v0, p0, LisSize9260;->gCount1961:Landroid/view/LayoutInflater;

    .line 20
    .line 21
    :cond_0
    sget v2, LKùiu;->dialog_edit_video:I

    .line 22
    .line 23
    invoke-virtual {v0, v2, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v8

    .line 27
    invoke-virtual {v6, v8}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v6}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    if-eqz v0, :cond_1

    .line 35
    .line 36
    invoke-virtual {v6}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    .line 37
    .line 38
    .line 39
    move-result-object v0

    .line 40
    new-instance v1, Landroid/graphics/drawable/ColorDrawable;

    .line 41
    .line 42
    const/4 v2, 0x0

    .line 43
    invoke-direct {v1, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0, v1}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 47
    .line 48
    .line 49
    :cond_1
    sget v0, LRO1QI;->edit_title_input:I

    .line 50
    .line 51
    invoke-virtual {v8, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    move-object v2, v0

    .line 56
    check-cast v2, Landroid/widget/EditText;

    .line 57
    .line 58
    sget v0, LRO1QI;->edit_url_input:I

    .line 59
    .line 60
    invoke-virtual {v8, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    move-object v3, v0

    .line 65
    check-cast v3, Landroid/widget/EditText;

    .line 66
    .line 67
    sget v0, LRO1QI;->edit_user_agent_input:I

    .line 68
    .line 69
    invoke-virtual {v8, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    move-object v4, v0

    .line 74
    check-cast v4, Landroid/widget/EditText;

    .line 75
    .line 76
    iget-object v0, p1, LUN3Jt;->waiBKÀ:Ljava/lang/String;

    .line 77
    .line 78
    invoke-virtual {v2, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 79
    .line 80
    .line 81
    iget-object v0, p1, LUN3Jt;->rz__9J_:Ljava/lang/String;

    .line 82
    .line 83
    invoke-virtual {v3, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 84
    .line 85
    .line 86
    iget-object v0, p1, LUN3Jt;->tmpData3485:Ljava/lang/String;

    .line 87
    .line 88
    invoke-virtual {v4, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 89
    .line 90
    .line 91
    sget v0, LRO1QI;->edit_save_button:I

    .line 92
    .line 93
    invoke-virtual {v8, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 94
    .line 95
    .line 96
    move-result-object v9

    .line 97
    new-instance v0, LwG$A$;

    .line 98
    .line 99
    const/4 v7, 0x0

    .line 100
    move-object v1, p0

    .line 101
    move-object v5, p1

    .line 102
    invoke-direct/range {v0 .. v7}, LwG$A$;-><init>(LisSize9260;Landroid/widget/EditText;Landroid/widget/EditText;Landroid/widget/EditText;LUN3Jt;Landroid/app/Dialog;I)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v9, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 106
    .line 107
    .line 108
    sget p1, LRO1QI;->edit_cancel_button:I

    .line 109
    .line 110
    invoke-virtual {v8, p1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 111
    .line 112
    .line 113
    move-result-object p1

    .line 114
    new-instance v0, LG1O1;

    .line 115
    .line 116
    const/4 v1, 0x0

    .line 117
    invoke-direct {v0, v6, v1}, LG1O1;-><init>(Landroid/app/Dialog;I)V

    .line 118
    .line 119
    .line 120
    invoke-virtual {p1, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v6}, Landroid/app/Dialog;->show()V

    .line 124
    .line 125
    .line 126
    invoke-virtual {v2}, Landroid/view/View;->requestFocus()Z

    .line 127
    .line 128
    .line 129
    return-void
.end method

.method public final tmpData3485(LUN3Jt;)V
    .locals 3

    .line 1
    iget-object v0, p0, LyIDlQ;->lIl1:Lm1;

    .line 2
    .line 3
    iget-wide v1, p1, LUN3Jt;->e8$mp_s$:J

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    invoke-static {v1, v2}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v0

    .line 13
    filled-new-array {v0}, [Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    const-string v1, "videos"

    .line 18
    .line 19
    const-string v2, "id=?"

    .line 20
    .line 21
    invoke-virtual {p1, v1, v2, v0}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    .line 22
    .line 23
    .line 24
    invoke-virtual {p1}, Landroid/database/sqlite/SQLiteClosable;->close()V

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, LyIDlQ;->gSy_FG$D_()V

    .line 28
    .line 29
    .line 30
    return-void
.end method

.method public final waiBKÀ(LUN3Jt;)V
    .locals 3

    .line 1
    iget-object v0, p0, LyIDlQ;->lIl1:Lm1;

    .line 2
    .line 3
    iget-wide v1, p1, LUN3Jt;->e8$mp_s$:J

    .line 4
    .line 5
    invoke-virtual {v0, v1, v2}, Lm1;->DDù8(J)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, LyIDlQ;->gSy_FG$D_()V

    .line 9
    .line 10
    .line 11
    return-void
.end method
