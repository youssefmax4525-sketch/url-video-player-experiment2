.class public final LlIIllI;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final JKEoÙX:LlIIllI;

.field public static tmpData3485:LlIIllI;


# instance fields
.field public POOl:I

.field public final synthetic e8$mp_s$:I

.field public rz__9J_:J

.field public waiBKÀ:J


# direct methods
.method static constructor <clinit>()V
    .locals 6

    .line 1
    new-instance v0, LlIIllI;

    .line 2
    .line 3
    const-wide v2, -0x7fffffffffffffffL    # -4.9E-324

    .line 4
    .line 5
    .line 6
    .line 7
    .line 8
    const-wide/16 v4, -0x1

    .line 9
    .line 10
    const/4 v1, -0x3

    .line 11
    invoke-direct/range {v0 .. v5}, LlIIllI;-><init>(IJJ)V

    .line 12
    .line 13
    .line 14
    sput-object v0, LlIIllI;->JKEoÙX:LlIIllI;

    .line 15
    .line 16
    return-void
.end method

.method public synthetic constructor <init>()V
    .locals 1

    .line 1
    const/4 v0, 0x1

    iput v0, p0, LlIIllI;->e8$mp_s$:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(I)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LlIIllI;->e8$mp_s$:I

    .line 8
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 9
    iput p1, p0, LlIIllI;->POOl:I

    return-void
.end method

.method public constructor <init>(IJJ)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LlIIllI;->e8$mp_s$:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, LlIIllI;->POOl:I

    iput-wide p2, p0, LlIIllI;->waiBKÀ:J

    iput-wide p4, p0, LlIIllI;->rz__9J_:J

    return-void
.end method

.method public constructor <init>(LZlTMJ;)V
    .locals 2

    const/4 v0, 0x3

    iput v0, p0, LlIIllI;->e8$mp_s$:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iget p1, p1, LZlTMJ;->vaIue:I

    .line 5
    iput p1, p0, LlIIllI;->POOl:I

    .line 6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 7
    iput-wide v0, p0, LlIIllI;->waiBKÀ:J

    return-void
.end method

.method public static rz__9J_(LlIIllI;JJI)V
    .locals 3

    .line 1
    and-int/lit8 v0, p5, 0x1

    .line 2
    .line 3
    const-wide/16 v1, 0x0

    .line 4
    .line 5
    if-eqz v0, :cond_0

    .line 6
    .line 7
    move-wide p1, v1

    .line 8
    :cond_0
    and-int/lit8 p5, p5, 0x2

    .line 9
    .line 10
    if-eqz p5, :cond_1

    .line 11
    .line 12
    move-wide p3, v1

    .line 13
    :cond_1
    monitor-enter p0

    .line 14
    cmp-long p5, p1, v1

    .line 15
    .line 16
    if-ltz p5, :cond_4

    .line 17
    .line 18
    cmp-long p5, p3, v1

    .line 19
    .line 20
    if-ltz p5, :cond_3

    .line 21
    .line 22
    :try_start_0
    iget-wide v0, p0, LlIIllI;->waiBKÀ:J

    .line 23
    .line 24
    add-long/2addr v0, p1

    .line 25
    iput-wide v0, p0, LlIIllI;->waiBKÀ:J

    .line 26
    .line 27
    iget-wide p1, p0, LlIIllI;->rz__9J_:J

    .line 28
    .line 29
    add-long/2addr p1, p3

    .line 30
    iput-wide p1, p0, LlIIllI;->rz__9J_:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 31
    .line 32
    cmp-long p3, p1, v0

    .line 33
    .line 34
    if-gtz p3, :cond_2

    .line 35
    .line 36
    monitor-exit p0

    .line 37
    return-void

    .line 38
    :cond_2
    :try_start_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 39
    .line 40
    const-string p2, "Check failed."

    .line 41
    .line 42
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    throw p1

    .line 46
    :catchall_0
    move-exception p1

    .line 47
    goto :goto_0

    .line 48
    :cond_3
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 49
    .line 50
    const-string p2, "Check failed."

    .line 51
    .line 52
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    throw p1

    .line 56
    :cond_4
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 57
    .line 58
    const-string p2, "Check failed."

    .line 59
    .line 60
    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    throw p1

    .line 64
    :goto_0
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 65
    throw p1
.end method


# virtual methods
.method public e8$mp_s$(JDD)V
    .locals 14

    .line 1
    const-wide v0, 0xdc6d62da00L

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    sub-long v2, p1, v0

    .line 7
    .line 8
    long-to-float v2, v2

    .line 9
    const v3, 0x4ca4cb80    # 8.64E7f

    .line 10
    .line 11
    .line 12
    div-float/2addr v2, v3

    .line 13
    const v3, 0x3c8ceb25

    .line 14
    .line 15
    .line 16
    mul-float v3, v3, v2

    .line 17
    .line 18
    const v4, 0x40c7ae92

    .line 19
    .line 20
    .line 21
    add-float/2addr v3, v4

    .line 22
    float-to-double v4, v3

    .line 23
    const-wide v6, 0x3fa11c5fc0000000L    # 0.03341960161924362

    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    .line 29
    .line 30
    .line 31
    move-result-wide v8

    .line 32
    mul-double v8, v8, v6

    .line 33
    .line 34
    add-double/2addr v8, v4

    .line 35
    const/high16 v6, 0x40000000    # 2.0f

    .line 36
    .line 37
    mul-float v6, v6, v3

    .line 38
    .line 39
    float-to-double v6, v6

    .line 40
    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    .line 41
    .line 42
    .line 43
    move-result-wide v6

    .line 44
    const-wide v10, 0x3f36e05b00000000L    # 3.4906598739326E-4

    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    mul-double v6, v6, v10

    .line 50
    .line 51
    add-double/2addr v6, v8

    .line 52
    const/high16 v8, 0x40400000    # 3.0f

    .line 53
    .line 54
    mul-float v3, v3, v8

    .line 55
    .line 56
    float-to-double v8, v3

    .line 57
    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    .line 58
    .line 59
    .line 60
    move-result-wide v8

    .line 61
    const-wide v10, 0x3ed5f61cc0000000L    # 5.236000106378924E-6

    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    mul-double v8, v8, v10

    .line 67
    .line 68
    add-double/2addr v8, v6

    .line 69
    const-wide v6, 0x3ffcbed85e1ce332L    # 1.796593063

    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    add-double/2addr v8, v6

    .line 75
    const-wide v6, 0x400921fb54442d18L    # Math.PI

    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    add-double/2addr v8, v6

    .line 81
    move-wide/from16 v6, p5

    .line 82
    .line 83
    neg-double v6, v6

    .line 84
    const-wide v10, 0x4076800000000000L    # 360.0

    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    div-double/2addr v6, v10

    .line 90
    const v3, 0x3a6bedfa    # 9.0E-4f

    .line 91
    .line 92
    .line 93
    sub-float/2addr v2, v3

    .line 94
    float-to-double v10, v2

    .line 95
    sub-double/2addr v10, v6

    .line 96
    invoke-static {v10, v11}, Ljava/lang/Math;->round(D)J

    .line 97
    .line 98
    .line 99
    move-result-wide v10

    .line 100
    long-to-float v2, v10

    .line 101
    add-float/2addr v2, v3

    .line 102
    float-to-double v2, v2

    .line 103
    add-double/2addr v2, v6

    .line 104
    const-wide v6, 0x3f75b573eab367a1L    # 0.0053

    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    .line 110
    .line 111
    .line 112
    move-result-wide v4

    .line 113
    mul-double v4, v4, v6

    .line 114
    .line 115
    add-double/2addr v4, v2

    .line 116
    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    .line 117
    .line 118
    mul-double v2, v2, v8

    .line 119
    .line 120
    invoke-static {v2, v3}, Ljava/lang/Math;->sin(D)D

    .line 121
    .line 122
    .line 123
    move-result-wide v2

    .line 124
    const-wide v6, -0x4083bcd35a858794L    # -0.0069

    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    mul-double v2, v2, v6

    .line 130
    .line 131
    add-double/2addr v2, v4

    .line 132
    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    .line 133
    .line 134
    .line 135
    move-result-wide v4

    .line 136
    const-wide v6, 0x3fda31a380000000L    # 0.4092797040939331

    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    .line 142
    .line 143
    .line 144
    move-result-wide v6

    .line 145
    mul-double v6, v6, v4

    .line 146
    .line 147
    invoke-static {v6, v7}, Ljava/lang/Math;->asin(D)D

    .line 148
    .line 149
    .line 150
    move-result-wide v4

    .line 151
    const-wide v6, 0x3f91df46a0000000L    # 0.01745329238474369

    .line 152
    .line 153
    .line 154
    .line 155
    .line 156
    mul-double v6, v6, p3

    .line 157
    .line 158
    const-wide v8, -0x4045311600000000L    # -0.10471975803375244

    .line 159
    .line 160
    .line 161
    .line 162
    .line 163
    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    .line 164
    .line 165
    .line 166
    move-result-wide v8

    .line 167
    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    .line 168
    .line 169
    .line 170
    move-result-wide v10

    .line 171
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    .line 172
    .line 173
    .line 174
    move-result-wide v12

    .line 175
    mul-double v12, v12, v10

    .line 176
    .line 177
    sub-double/2addr v8, v12

    .line 178
    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    .line 179
    .line 180
    .line 181
    move-result-wide v6

    .line 182
    invoke-static {v4, v5}, Ljava/lang/Math;->cos(D)D

    .line 183
    .line 184
    .line 185
    move-result-wide v4

    .line 186
    mul-double v4, v4, v6

    .line 187
    .line 188
    div-double/2addr v8, v4

    .line 189
    const-wide/high16 v4, 0x3ff0000000000000L    # 1.0

    .line 190
    .line 191
    const/4 v6, 0x1

    .line 192
    const-wide/16 v10, -0x1

    .line 193
    .line 194
    cmpl-double v7, v8, v4

    .line 195
    .line 196
    if-ltz v7, :cond_0

    .line 197
    .line 198
    iput v6, p0, LlIIllI;->POOl:I

    .line 199
    .line 200
    iput-wide v10, p0, LlIIllI;->waiBKÀ:J

    .line 201
    .line 202
    iput-wide v10, p0, LlIIllI;->rz__9J_:J

    .line 203
    .line 204
    return-void

    .line 205
    :cond_0
    const-wide/high16 v4, -0x4010000000000000L    # -1.0

    .line 206
    .line 207
    const/4 v7, 0x0

    .line 208
    cmpg-double v12, v8, v4

    .line 209
    .line 210
    if-gtz v12, :cond_1

    .line 211
    .line 212
    iput v7, p0, LlIIllI;->POOl:I

    .line 213
    .line 214
    iput-wide v10, p0, LlIIllI;->waiBKÀ:J

    .line 215
    .line 216
    iput-wide v10, p0, LlIIllI;->rz__9J_:J

    .line 217
    .line 218
    return-void

    .line 219
    :cond_1
    invoke-static {v8, v9}, Ljava/lang/Math;->acos(D)D

    .line 220
    .line 221
    .line 222
    move-result-wide v4

    .line 223
    const-wide v8, 0x401921fb54442d18L    # 6.283185307179586

    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    div-double/2addr v4, v8

    .line 229
    double-to-float v4, v4

    .line 230
    float-to-double v4, v4

    .line 231
    add-double v8, v2, v4

    .line 232
    .line 233
    const-wide v10, 0x4194997000000000L    # 8.64E7

    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    mul-double v8, v8, v10

    .line 239
    .line 240
    invoke-static {v8, v9}, Ljava/lang/Math;->round(D)J

    .line 241
    .line 242
    .line 243
    move-result-wide v8

    .line 244
    add-long/2addr v8, v0

    .line 245
    iput-wide v8, p0, LlIIllI;->waiBKÀ:J

    .line 246
    .line 247
    sub-double/2addr v2, v4

    .line 248
    mul-double v2, v2, v10

    .line 249
    .line 250
    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    .line 251
    .line 252
    .line 253
    move-result-wide v2

    .line 254
    add-long/2addr v2, v0

    .line 255
    iput-wide v2, p0, LlIIllI;->rz__9J_:J

    .line 256
    .line 257
    cmp-long v0, v2, p1

    .line 258
    .line 259
    if-gez v0, :cond_2

    .line 260
    .line 261
    iget-wide v0, p0, LlIIllI;->waiBKÀ:J

    .line 262
    .line 263
    cmp-long v2, v0, p1

    .line 264
    .line 265
    if-lez v2, :cond_2

    .line 266
    .line 267
    iput v7, p0, LlIIllI;->POOl:I

    .line 268
    .line 269
    return-void

    .line 270
    :cond_2
    iput v6, p0, LlIIllI;->POOl:I

    .line 271
    .line 272
    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    .line 1
    iget v0, p0, LlIIllI;->e8$mp_s$:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    return-object v0

    .line 11
    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "WindowCounter(streamId="

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget v1, p0, LlIIllI;->POOl:I

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", total="

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-wide v1, p0, LlIIllI;->waiBKÀ:J

    .line 29
    .line 30
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 31
    .line 32
    .line 33
    const-string v1, ", acknowledged="

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    iget-wide v1, p0, LlIIllI;->rz__9J_:J

    .line 39
    .line 40
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 41
    .line 42
    .line 43
    const-string v1, ", unacknowledged="

    .line 44
    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0}, LlIIllI;->waiBKÀ()J

    .line 49
    .line 50
    .line 51
    move-result-wide v1

    .line 52
    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    const/16 v1, 0x29

    .line 56
    .line 57
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    return-object v0

    .line 65
    :pswitch_data_0
    .packed-switch 0x2
        :pswitch_0
    .end packed-switch
.end method

.method public declared-synchronized waiBKÀ()J
    .locals 4

    .line 1
    monitor-enter p0

    .line 2
    :try_start_0
    iget-wide v0, p0, LlIIllI;->waiBKÀ:J

    .line 3
    .line 4
    iget-wide v2, p0, LlIIllI;->rz__9J_:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 5
    .line 6
    sub-long/2addr v0, v2

    .line 7
    monitor-exit p0

    .line 8
    return-wide v0

    .line 9
    :catchall_0
    move-exception v0

    .line 10
    :try_start_1
    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 11
    throw v0
.end method
