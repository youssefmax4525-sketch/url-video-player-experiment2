.class public final LvData9772;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static DDù8:LvData9772;


# instance fields
.field public final JKEoÙX:Ljava/lang/Object;

.field public POOl:Z

.field public final e8$mp_s$:Ljava/lang/Object;

.field public rz__9J_:Z

.field public final sKey7917:LZDI;

.field public tmpData3485:LkVI_h$D_;

.field public final waiBKÀ:Ljava/util/ArrayList;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    .line 1
    new-instance v0, Ljava/util/HashSet;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    new-array v1, v1, [LwCjA2ì;

    .line 5
    .line 6
    sget-object v2, LwCjA2ì;->valuI:LwCjA2ì;

    .line 7
    .line 8
    const/4 v3, 0x0

    .line 9
    aput-object v2, v1, v3

    .line 10
    .line 11
    sget-object v2, LwCjA2ì;->jPos3709:LwCjA2ì;

    .line 12
    .line 13
    const/4 v3, 0x1

    .line 14
    aput-object v2, v1, v3

    .line 15
    .line 16
    sget-object v2, LwCjA2ì;->iOffset934:LwCjA2ì;

    .line 17
    .line 18
    const/4 v3, 0x2

    .line 19
    aput-object v2, v1, v3

    .line 20
    .line 21
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    invoke-direct {v0, v1}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public constructor <init>()V
    .locals 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, LvData9772;->e8$mp_s$:Ljava/lang/Object;

    .line 10
    .line 11
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, LvData9772;->rz__9J_:Z

    .line 13
    .line 14
    iput-boolean v0, p0, LvData9772;->POOl:Z

    .line 15
    .line 16
    new-instance v0, Ljava/lang/Object;

    .line 17
    .line 18
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 19
    .line 20
    .line 21
    iput-object v0, p0, LvData9772;->JKEoÙX:Ljava/lang/Object;

    .line 22
    .line 23
    new-instance v0, Ljava/util/ArrayList;

    .line 24
    .line 25
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 26
    .line 27
    .line 28
    new-instance v1, LZDI;

    .line 29
    .line 30
    invoke-direct {v1, v0}, LZDI;-><init>(Ljava/util/ArrayList;)V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, LvData9772;->sKey7917:LZDI;

    .line 34
    .line 35
    new-instance v0, Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, LvData9772;->waiBKÀ:Ljava/util/ArrayList;

    .line 41
    .line 42
    return-void
.end method

.method public static JKEoÙX()LvData9772;
    .locals 2

    .line 1
    const-class v0, LvData9772;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    sget-object v1, LvData9772;->DDù8:LvData9772;

    .line 5
    .line 6
    if-nez v1, :cond_0

    .line 7
    .line 8
    new-instance v1, LvData9772;

    .line 9
    .line 10
    invoke-direct {v1}, LvData9772;-><init>()V

    .line 11
    .line 12
    .line 13
    sput-object v1, LvData9772;->DDù8:LvData9772;

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :catchall_0
    move-exception v1

    .line 17
    goto :goto_1

    .line 18
    :cond_0
    :goto_0
    sget-object v1, LvData9772;->DDù8:LvData9772;

    .line 19
    .line 20
    monitor-exit v0

    .line 21
    return-object v1

    .line 22
    :goto_1
    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 23
    throw v1
.end method

.method public static e8$mp_s$(Ljava/util/List;)LadH$eU_Q7$;
    .locals 4

    .line 1
    new-instance v0, Ljava/util/HashMap;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    :goto_0
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v1

    .line 20
    check-cast v1, LgOffset5049;

    .line 21
    .line 22
    iget-object v1, v1, LgOffset5049;->yON3x:Ljava/lang/String;

    .line 23
    .line 24
    new-instance v2, LnData6800;

    .line 25
    .line 26
    const/4 v3, 0x3

    .line 27
    invoke-direct {v2, v3}, LnData6800;-><init>(I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    goto :goto_0

    .line 34
    :cond_0
    new-instance p0, LadH$eU_Q7$;

    .line 35
    .line 36
    const/4 v0, 0x3

    .line 37
    invoke-direct {p0, v0}, LadH$eU_Q7$;-><init>(I)V

    .line 38
    .line 39
    .line 40
    return-object p0
.end method


# virtual methods
.method public final POOl()LT9R$JI_p4$;
    .locals 3

    .line 1
    iget-object v0, p0, LvData9772;->JKEoÙX:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_0
    iget-object v1, p0, LvData9772;->tmpData3485:LkVI_h$D_;

    .line 5
    .line 6
    if-eqz v1, :cond_0

    .line 7
    .line 8
    const/4 v1, 0x1

    .line 9
    goto :goto_0

    .line 10
    :cond_0
    const/4 v1, 0x0

    .line 11
    :goto_0
    const-string v2, "MobileAds.initialize() must be called prior to getting initialization status."

    .line 12
    .line 13
    invoke-static {v2, v1}, Lzl1;->valuI(Ljava/lang/String;Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 14
    .line 15
    .line 16
    :try_start_1
    iget-object v1, p0, LvData9772;->tmpData3485:LkVI_h$D_;

    .line 17
    .line 18
    invoke-interface {v1}, LkVI_h$D_;->tmpData3485()Ljava/util/List;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    invoke-static {v1}, LvData9772;->e8$mp_s$(Ljava/util/List;)LadH$eU_Q7$;

    .line 23
    .line 24
    .line 25
    move-result-object v1
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 26
    :try_start_2
    monitor-exit v0

    .line 27
    return-object v1

    .line 28
    :catchall_0
    move-exception v1

    .line 29
    goto :goto_1

    .line 30
    :catch_0
    const-string v1, "Unable to get Initialization status."

    .line 31
    .line 32
    invoke-static {v1}, LPJNypàa;->WoI_9_(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    new-instance v1, LJ11D;

    .line 36
    .line 37
    const/4 v2, 0x2

    .line 38
    invoke-direct {v1, v2}, LJ11D;-><init>(I)V

    .line 39
    .line 40
    .line 41
    monitor-exit v0

    .line 42
    return-object v1

    .line 43
    :goto_1
    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 44
    throw v1
.end method

.method public final rz__9J_(LUd$5_1h$;)V
    .locals 2

    .line 1
    iget-object v0, p0, LvData9772;->tmpData3485:LkVI_h$D_;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    sget-object v0, LUmmExqÀV;->tmpData3485:LUmmExqÀV;

    .line 6
    .line 7
    iget-object v0, v0, LUmmExqÀV;->waiBKÀ:LKkmORP;

    .line 8
    .line 9
    new-instance v1, LKar_7$qe_;

    .line 10
    .line 11
    invoke-direct {v1, v0, p1}, LKar_7$qe_;-><init>(LKkmORP;LUd$5_1h$;)V

    .line 12
    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    invoke-virtual {v1, p1, v0}, LylxdbBq;->POOl(Landroid/content/Context;Z)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p1

    .line 19
    check-cast p1, LkVI_h$D_;

    .line 20
    .line 21
    iput-object p1, p0, LvData9772;->tmpData3485:LkVI_h$D_;

    .line 22
    .line 23
    :cond_0
    return-void
.end method

.method public final waiBKÀ(LUd$5_1h$;)V
    .locals 4

    .line 1
    :try_start_0
    sget-object v0, LxMZ7olY;->iOffset934:LxMZ7olY;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, LxMZ7olY;

    .line 6
    .line 7
    const/16 v1, 0x13

    .line 8
    .line 9
    invoke-direct {v0, v1}, LxMZ7olY;-><init>(I)V

    .line 10
    .line 11
    .line 12
    sput-object v0, LxMZ7olY;->iOffset934:LxMZ7olY;

    .line 13
    .line 14
    :cond_0
    sget-object v0, LxMZ7olY;->iOffset934:LxMZ7olY;

    .line 15
    .line 16
    iget-object v0, v0, LxMZ7olY;->vaIue:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 19
    .line 20
    const/4 v1, 0x0

    .line 21
    const/4 v2, 0x1

    .line 22
    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    const/4 v1, 0x0

    .line 27
    if-nez v0, :cond_1

    .line 28
    .line 29
    goto :goto_0

    .line 30
    :cond_1
    new-instance v0, Ljava/lang/Thread;

    .line 31
    .line 32
    new-instance v2, LynztM;

    .line 33
    .line 34
    const/16 v3, 0x11

    .line 35
    .line 36
    invoke-direct {v2, v3, p1, v1}, LynztM;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    .line 43
    .line 44
    .line 45
    :goto_0
    iget-object p1, p0, LvData9772;->tmpData3485:LkVI_h$D_;

    .line 46
    .line 47
    invoke-interface {p1}, LkVI_h$D_;->jPos3709()V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, LvData9772;->tmpData3485:LkVI_h$D_;

    .line 51
    .line 52
    new-instance v0, Lfdo_n_;

    .line 53
    .line 54
    invoke-direct {v0, v1}, Lfdo_n_;-><init>(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    invoke-interface {p1, v0, v1}, LkVI_h$D_;->tmpIndex917(LKàaq;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    .line 58
    .line 59
    .line 60
    :catch_0
    return-void
.end method
