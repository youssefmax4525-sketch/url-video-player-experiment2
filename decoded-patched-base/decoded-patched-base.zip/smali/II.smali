.class public final LII;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic e8$mp_s$:LTSYa;


# direct methods
.method public constructor <init>(LTSYa;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LII;->e8$mp_s$:LTSYa;

    .line 5
    .line 6
    return-void
.end method
