.class public final LZD$x$;
.super LlIiII1l;
.source "SourceFile"


# instance fields
.field public final synthetic JKEoÙX:I


# direct methods
.method public synthetic constructor <init>(L$1ll0I;I)V
    .locals 0

    .line 1
    iput p2, p0, LZD$x$;->JKEoÙX:I

    invoke-direct {p0, p1}, LlIiII1l;-><init>(L$1ll0I;)V

    return-void
.end method


# virtual methods
.method public final e8$mp_s$(LurU$_$;)Z
    .locals 2

    .line 1
    iget v0, p0, LZD$x$;->JKEoÙX:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object p1, p1, LurU$_$;->vaIue:LbògMgB;

    .line 7
    .line 8
    iget-boolean p1, p1, LbògMgB;->JKEoÙX:Z

    .line 9
    .line 10
    return p1

    .line 11
    :pswitch_0
    iget-object p1, p1, LurU$_$;->vaIue:LbògMgB;

    .line 12
    .line 13
    iget p1, p1, LbògMgB;->e8$mp_s$:I

    .line 14
    .line 15
    const/4 v0, 0x3

    .line 16
    if-eq p1, v0, :cond_1

    .line 17
    .line 18
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 19
    .line 20
    const/16 v1, 0x1e

    .line 21
    .line 22
    if-lt v0, v1, :cond_0

    .line 23
    .line 24
    const/4 v0, 0x6

    .line 25
    if-ne p1, v0, :cond_0

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    const/4 p1, 0x0

    .line 29
    goto :goto_1

    .line 30
    :cond_1
    :goto_0
    const/4 p1, 0x1

    .line 31
    :goto_1
    return p1

    .line 32
    :pswitch_1
    iget-object p1, p1, LurU$_$;->vaIue:LbògMgB;

    .line 33
    .line 34
    iget p1, p1, LbògMgB;->e8$mp_s$:I

    .line 35
    .line 36
    const/4 v0, 0x2

    .line 37
    if-ne p1, v0, :cond_2

    .line 38
    .line 39
    const/4 p1, 0x1

    .line 40
    goto :goto_2

    .line 41
    :cond_2
    const/4 p1, 0x0

    .line 42
    :goto_2
    return p1

    .line 43
    :pswitch_2
    iget-object p1, p1, LurU$_$;->vaIue:LbògMgB;

    .line 44
    .line 45
    iget-boolean p1, p1, LbògMgB;->POOl:Z

    .line 46
    .line 47
    return p1

    .line 48
    :pswitch_3
    iget-object p1, p1, LurU$_$;->vaIue:LbògMgB;

    .line 49
    .line 50
    iget-boolean p1, p1, LbògMgB;->waiBKÀ:Z

    .line 51
    .line 52
    return p1

    .line 53
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final waiBKÀ(Ljava/lang/Object;)Z
    .locals 3

    .line 1
    iget v0, p0, LZD$x$;->JKEoÙX:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Ljava/lang/Boolean;

    .line 7
    .line 8
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    :goto_0
    xor-int/lit8 p1, p1, 0x1

    .line 13
    .line 14
    return p1

    .line 15
    :pswitch_0
    check-cast p1, LvÒK;

    .line 16
    .line 17
    iget-boolean v0, p1, LvÒK;->e8$mp_s$:Z

    .line 18
    .line 19
    if-eqz v0, :cond_1

    .line 20
    .line 21
    iget-boolean p1, p1, LvÒK;->rz__9J_:Z

    .line 22
    .line 23
    if-eqz p1, :cond_0

    .line 24
    .line 25
    goto :goto_1

    .line 26
    :cond_0
    const/4 p1, 0x0

    .line 27
    goto :goto_2

    .line 28
    :cond_1
    :goto_1
    const/4 p1, 0x1

    .line 29
    :goto_2
    return p1

    .line 30
    :pswitch_1
    check-cast p1, LvÒK;

    .line 31
    .line 32
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 33
    .line 34
    const/16 v1, 0x1a

    .line 35
    .line 36
    const/4 v2, 0x1

    .line 37
    if-lt v0, v1, :cond_3

    .line 38
    .line 39
    iget-boolean v0, p1, LvÒK;->e8$mp_s$:Z

    .line 40
    .line 41
    if-eqz v0, :cond_4

    .line 42
    .line 43
    iget-boolean p1, p1, LvÒK;->waiBKÀ:Z

    .line 44
    .line 45
    if-nez p1, :cond_2

    .line 46
    .line 47
    goto :goto_3

    .line 48
    :cond_2
    const/4 v2, 0x0

    .line 49
    goto :goto_3

    .line 50
    :cond_3
    iget-boolean p1, p1, LvÒK;->e8$mp_s$:Z

    .line 51
    .line 52
    xor-int/2addr v2, p1

    .line 53
    :cond_4
    :goto_3
    return v2

    .line 54
    :pswitch_2
    check-cast p1, Ljava/lang/Boolean;

    .line 55
    .line 56
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 57
    .line 58
    .line 59
    move-result p1

    .line 60
    goto :goto_0

    .line 61
    :pswitch_3
    check-cast p1, Ljava/lang/Boolean;

    .line 62
    .line 63
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 64
    .line 65
    .line 66
    move-result p1

    .line 67
    goto :goto_0

    .line 68
    nop

    .line 69
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
