.class public interface abstract LDO;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract yàÒZ(LjData6565;)V
.end method
