.class public final Lk6x_8$a_;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Lsyirkh;


# instance fields
.field public $ÒcdS:Lavt$p$;

.field public final Ialue:LjKey6994;

.field public Iii:I

.field public K0I:I

.field public Oey:I

.field public Q1_f_:Lavt$p$;

.field public Qp_Hp$i_:I

.field public UC_n_:LjValue5229;

.field public gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

.field public final iOffset934:J

.field public final jPos3709:Landroid/media/metrics/PlaybackSession;

.field public kCount1402:Lavt$p$;

.field public kO_6X_:I

.field public final kQy:LgValue7788;

.field public l1:Z

.field public ll:Z

.field public oy_R$Xx_:Z

.field public final pCXDYg:Ljava/util/HashMap;

.field public sKey6064:LgItem9321;

.field public tmpSize211:LgItem9321;

.field public tzKù7Ol1:LgItem9321;

.field public final vaIue:LisPos6698;

.field public final valuI:Ljava/util/HashMap;

.field public final yON3x:Landroid/content/Context;

.field public yPN$A_n$:I

.field public yàÒZ:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/media/metrics/PlaybackSession;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lk6x_8$a_;->yON3x:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p2, p0, Lk6x_8$a_;->jPos3709:Landroid/media/metrics/PlaybackSession;

    .line 11
    .line 12
    new-instance p1, LgValue7788;

    .line 13
    .line 14
    invoke-direct {p1}, LgValue7788;-><init>()V

    .line 15
    .line 16
    .line 17
    iput-object p1, p0, Lk6x_8$a_;->kQy:LgValue7788;

    .line 18
    .line 19
    new-instance p1, LjKey6994;

    .line 20
    .line 21
    invoke-direct {p1}, LjKey6994;-><init>()V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Lk6x_8$a_;->Ialue:LjKey6994;

    .line 25
    .line 26
    new-instance p1, Ljava/util/HashMap;

    .line 27
    .line 28
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 29
    .line 30
    .line 31
    iput-object p1, p0, Lk6x_8$a_;->pCXDYg:Ljava/util/HashMap;

    .line 32
    .line 33
    new-instance p1, Ljava/util/HashMap;

    .line 34
    .line 35
    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object p1, p0, Lk6x_8$a_;->valuI:Ljava/util/HashMap;

    .line 39
    .line 40
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 41
    .line 42
    .line 43
    move-result-wide p1

    .line 44
    iput-wide p1, p0, Lk6x_8$a_;->iOffset934:J

    .line 45
    .line 46
    const/4 p1, 0x0

    .line 47
    iput p1, p0, Lk6x_8$a_;->K0I:I

    .line 48
    .line 49
    iput p1, p0, Lk6x_8$a_;->Qp_Hp$i_:I

    .line 50
    .line 51
    new-instance p1, LisPos6698;

    .line 52
    .line 53
    invoke-direct {p1}, LisPos6698;-><init>()V

    .line 54
    .line 55
    .line 56
    iput-object p1, p0, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 57
    .line 58
    iput-object p0, p1, LisPos6698;->POOl:Lk6x_8$a_;

    .line 59
    .line 60
    return-void
.end method


# virtual methods
.method public final DDù8(LjValue5229;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lk6x_8$a_;->UC_n_:LjValue5229;

    .line 2
    .line 3
    return-void
.end method

.method public final Ialue(I)V
    .locals 1

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, v0, :cond_0

    .line 3
    .line 4
    iput-boolean v0, p0, Lk6x_8$a_;->ll:Z

    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    :cond_0
    iput p1, p0, Lk6x_8$a_;->kO_6X_:I

    .line 8
    .line 9
    return-void
.end method

.method public final JKEoÙX(LB7Y_m$E_;)V
    .locals 2

    .line 1
    iget v0, p0, Lk6x_8$a_;->yPN$A_n$:I

    .line 2
    .line 3
    iget v1, p1, LB7Y_m$E_;->sKey7917:I

    .line 4
    .line 5
    add-int/2addr v0, v1

    .line 6
    iput v0, p0, Lk6x_8$a_;->yPN$A_n$:I

    .line 7
    .line 8
    iget v0, p0, Lk6x_8$a_;->Oey:I

    .line 9
    .line 10
    iget p1, p1, LB7Y_m$E_;->JKEoÙX:I

    .line 11
    .line 12
    add-int/2addr v0, p1

    .line 13
    iput v0, p0, Lk6x_8$a_;->Oey:I

    .line 14
    .line 15
    return-void
.end method

.method public final synthetic Oey(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final POOl(LjPRÒÒI;Ldl1OI;)V
    .locals 4

    .line 1
    iget-object v0, p1, LjPRÒÒI;->POOl:Laa2l;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    iget-object v1, p2, Ldl1OI;->waiBKÀ:LgItem9321;

    .line 7
    .line 8
    new-instance v2, Lavt$p$;

    .line 9
    .line 10
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iget-object v3, p0, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 14
    .line 15
    iget-object p1, p1, LjPRÒÒI;->waiBKÀ:LisItem9853;

    .line 16
    .line 17
    invoke-virtual {v3, p1, v0}, LisPos6698;->e8$mp_s$(LisItem9853;Laa2l;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object p1

    .line 21
    invoke-direct {v2, p1, v1}, Lavt$p$;-><init>(Ljava/lang/String;LgItem9321;)V

    .line 22
    .line 23
    .line 24
    iget p1, p2, Ldl1OI;->e8$mp_s$:I

    .line 25
    .line 26
    if-eqz p1, :cond_3

    .line 27
    .line 28
    const/4 p2, 0x1

    .line 29
    if-eq p1, p2, :cond_2

    .line 30
    .line 31
    const/4 p2, 0x2

    .line 32
    if-eq p1, p2, :cond_3

    .line 33
    .line 34
    const/4 p2, 0x3

    .line 35
    if-eq p1, p2, :cond_1

    .line 36
    .line 37
    :goto_0
    return-void

    .line 38
    :cond_1
    iput-object v2, p0, Lk6x_8$a_;->Q1_f_:Lavt$p$;

    .line 39
    .line 40
    return-void

    .line 41
    :cond_2
    iput-object v2, p0, Lk6x_8$a_;->$ÒcdS:Lavt$p$;

    .line 42
    .line 43
    return-void

    .line 44
    :cond_3
    iput-object v2, p0, Lk6x_8$a_;->kCount1402:Lavt$p$;

    .line 45
    .line 46
    return-void
.end method

.method public final synthetic e8$mp_s$(LgItem9321;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final synthetic iOffset934(LgItem9321;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final synthetic jI(I)V
    .locals 0

    .line 1
    return-void
.end method

.method public final jPos3709(LjPRÒÒI;IJ)V
    .locals 8

    .line 1
    iget-object v0, p1, LjPRÒÒI;->POOl:Laa2l;

    .line 2
    .line 3
    if-eqz v0, :cond_2

    .line 4
    .line 5
    iget-object v1, p0, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 6
    .line 7
    iget-object p1, p1, LjPRÒÒI;->waiBKÀ:LisItem9853;

    .line 8
    .line 9
    invoke-virtual {v1, p1, v0}, LisPos6698;->e8$mp_s$(LisItem9853;Laa2l;)Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    iget-object v0, p0, Lk6x_8$a_;->pCXDYg:Ljava/util/HashMap;

    .line 14
    .line 15
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Ljava/lang/Long;

    .line 20
    .line 21
    iget-object v2, p0, Lk6x_8$a_;->valuI:Ljava/util/HashMap;

    .line 22
    .line 23
    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    check-cast v3, Ljava/lang/Long;

    .line 28
    .line 29
    const-wide/16 v4, 0x0

    .line 30
    .line 31
    if-nez v1, :cond_0

    .line 32
    .line 33
    move-wide v6, v4

    .line 34
    goto :goto_0

    .line 35
    :cond_0
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    .line 36
    .line 37
    .line 38
    move-result-wide v6

    .line 39
    :goto_0
    add-long/2addr v6, p3

    .line 40
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 41
    .line 42
    .line 43
    move-result-object p3

    .line 44
    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    if-nez v3, :cond_1

    .line 48
    .line 49
    goto :goto_1

    .line 50
    :cond_1
    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    .line 51
    .line 52
    .line 53
    move-result-wide v4

    .line 54
    :goto_1
    int-to-long p2, p2

    .line 55
    add-long/2addr v4, p2

    .line 56
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 57
    .line 58
    .line 59
    move-result-object p2

    .line 60
    invoke-virtual {v2, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    :cond_2
    return-void
.end method

.method public final kQy(LisItem9853;Laa2l;)V
    .locals 9

    .line 1
    iget-object v0, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 2
    .line 3
    if-nez p2, :cond_0

    .line 4
    .line 5
    goto/16 :goto_6

    .line 6
    .line 7
    :cond_0
    iget-object p2, p2, Laa2l;->e8$mp_s$:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-virtual {p1, p2}, LisItem9853;->e8$mp_s$(Ljava/lang/Object;)I

    .line 10
    .line 11
    .line 12
    move-result p2

    .line 13
    const/4 v1, -0x1

    .line 14
    if-eq p2, v1, :cond_13

    .line 15
    .line 16
    iget-object v2, p0, Lk6x_8$a_;->Ialue:LjKey6994;

    .line 17
    .line 18
    const/4 v3, 0x0

    .line 19
    invoke-virtual {p1, p2, v2, v3}, LisItem9853;->POOl(ILjKey6994;Z)LjKey6994;

    .line 20
    .line 21
    .line 22
    iget p2, v2, LjKey6994;->rz__9J_:I

    .line 23
    .line 24
    const-wide/16 v4, 0x0

    .line 25
    .line 26
    iget-object v2, p0, Lk6x_8$a_;->kQy:LgValue7788;

    .line 27
    .line 28
    invoke-virtual {p1, p2, v2, v4, v5}, LisItem9853;->JKEoÙX(ILgValue7788;J)LgValue7788;

    .line 29
    .line 30
    .line 31
    iget-object p1, v2, LgValue7788;->waiBKÀ:LkIndex922;

    .line 32
    .line 33
    iget-object p1, p1, LkIndex922;->waiBKÀ:LKÒyÙ;

    .line 34
    .line 35
    const/4 p2, 0x2

    .line 36
    const/4 v4, 0x1

    .line 37
    if-nez p1, :cond_1

    .line 38
    .line 39
    goto/16 :goto_5

    .line 40
    .line 41
    :cond_1
    iget-object p1, p1, LKÒyÙ;->e8$mp_s$:Landroid/net/Uri;

    .line 42
    .line 43
    sget v5, LnPos2706;->e8$mp_s$:I

    .line 44
    .line 45
    invoke-virtual {p1}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    const/4 v6, 0x4

    .line 50
    const/4 v7, 0x3

    .line 51
    if-eqz v5, :cond_3

    .line 52
    .line 53
    const-string v8, "rtsp"

    .line 54
    .line 55
    invoke-static {v8, v5}, LN11Il1;->gSy_FG$D_(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    if-nez v5, :cond_2

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    const/4 v3, 0x3

    .line 63
    goto/16 :goto_4

    .line 64
    .line 65
    :cond_3
    :goto_0
    invoke-virtual {p1}, Landroid/net/Uri;->getLastPathSegment()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    if-nez v5, :cond_5

    .line 70
    .line 71
    :cond_4
    const/4 v3, 0x4

    .line 72
    goto/16 :goto_4

    .line 73
    .line 74
    :cond_5
    const/16 v8, 0x2e

    .line 75
    .line 76
    invoke-virtual {v5, v8}, Ljava/lang/String;->lastIndexOf(I)I

    .line 77
    .line 78
    .line 79
    move-result v8

    .line 80
    if-ltz v8, :cond_b

    .line 81
    .line 82
    add-int/2addr v8, v4

    .line 83
    invoke-virtual {v5, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    invoke-static {v5}, LN11Il1;->oy_R$Xx_(Ljava/lang/String;)Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v5

    .line 91
    invoke-virtual {v5}, Ljava/lang/String;->hashCode()I

    .line 92
    .line 93
    .line 94
    move-result v8

    .line 95
    sparse-switch v8, :sswitch_data_0

    .line 96
    .line 97
    .line 98
    goto :goto_1

    .line 99
    :sswitch_0
    const-string v8, "m3u8"

    .line 100
    .line 101
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v5

    .line 105
    if-eqz v5, :cond_6

    .line 106
    .line 107
    const/4 v1, 0x1

    .line 108
    goto :goto_1

    .line 109
    :sswitch_1
    const-string v8, "isml"

    .line 110
    .line 111
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v5

    .line 115
    if-eqz v5, :cond_6

    .line 116
    .line 117
    const/4 v1, 0x3

    .line 118
    goto :goto_1

    .line 119
    :sswitch_2
    const-string v8, "mpd"

    .line 120
    .line 121
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 122
    .line 123
    .line 124
    move-result v5

    .line 125
    if-eqz v5, :cond_6

    .line 126
    .line 127
    const/4 v1, 0x0

    .line 128
    goto :goto_1

    .line 129
    :sswitch_3
    const-string v8, "ism"

    .line 130
    .line 131
    invoke-virtual {v5, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    move-result v5

    .line 135
    if-eqz v5, :cond_6

    .line 136
    .line 137
    const/4 v1, 0x2

    .line 138
    :cond_6
    :goto_1
    if-eqz v1, :cond_9

    .line 139
    .line 140
    if-eq v1, v4, :cond_8

    .line 141
    .line 142
    if-eq v1, p2, :cond_7

    .line 143
    .line 144
    if-eq v1, v7, :cond_7

    .line 145
    .line 146
    const/4 v1, 0x4

    .line 147
    goto :goto_2

    .line 148
    :cond_7
    const/4 v1, 0x1

    .line 149
    goto :goto_2

    .line 150
    :cond_8
    const/4 v1, 0x2

    .line 151
    goto :goto_2

    .line 152
    :cond_9
    const/4 v1, 0x0

    .line 153
    :goto_2
    if-ne v1, v6, :cond_a

    .line 154
    .line 155
    goto :goto_3

    .line 156
    :cond_a
    move v3, v1

    .line 157
    goto :goto_4

    .line 158
    :cond_b
    :goto_3
    sget-object v1, LnPos2706;->sKey7917:Ljava/util/regex/Pattern;

    .line 159
    .line 160
    invoke-virtual {p1}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    .line 161
    .line 162
    .line 163
    move-result-object p1

    .line 164
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 165
    .line 166
    .line 167
    invoke-virtual {v1, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 168
    .line 169
    .line 170
    move-result-object p1

    .line 171
    invoke-virtual {p1}, Ljava/util/regex/Matcher;->matches()Z

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    if-eqz v1, :cond_4

    .line 176
    .line 177
    invoke-virtual {p1, p2}, Ljava/util/regex/Matcher;->group(I)Ljava/lang/String;

    .line 178
    .line 179
    .line 180
    move-result-object p1

    .line 181
    if-eqz p1, :cond_d

    .line 182
    .line 183
    const-string v1, "format=mpd-time-csf"

    .line 184
    .line 185
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 186
    .line 187
    .line 188
    move-result v1

    .line 189
    if-eqz v1, :cond_c

    .line 190
    .line 191
    goto :goto_4

    .line 192
    :cond_c
    const-string v1, "format=m3u8-aapl"

    .line 193
    .line 194
    invoke-virtual {p1, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 195
    .line 196
    .line 197
    move-result p1

    .line 198
    if-eqz p1, :cond_d

    .line 199
    .line 200
    const/4 v3, 0x2

    .line 201
    goto :goto_4

    .line 202
    :cond_d
    const/4 v3, 0x1

    .line 203
    :goto_4
    if-eqz v3, :cond_10

    .line 204
    .line 205
    if-eq v3, v4, :cond_f

    .line 206
    .line 207
    if-eq v3, p2, :cond_e

    .line 208
    .line 209
    const/4 v3, 0x1

    .line 210
    goto :goto_5

    .line 211
    :cond_e
    const/4 v3, 0x4

    .line 212
    goto :goto_5

    .line 213
    :cond_f
    const/4 v3, 0x5

    .line 214
    goto :goto_5

    .line 215
    :cond_10
    const/4 v3, 0x3

    .line 216
    :goto_5
    invoke-static {v0, v3}, LnPos5502;->kQy(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 217
    .line 218
    .line 219
    iget-wide v5, v2, LgValue7788;->vaIue:J

    .line 220
    .line 221
    const-wide v7, -0x7fffffffffffffffL    # -4.9E-324

    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    cmp-long p1, v5, v7

    .line 227
    .line 228
    if-eqz p1, :cond_11

    .line 229
    .line 230
    iget-boolean p1, v2, LgValue7788;->yON3x:Z

    .line 231
    .line 232
    if-nez p1, :cond_11

    .line 233
    .line 234
    iget-boolean p1, v2, LgValue7788;->sKey7917:Z

    .line 235
    .line 236
    if-nez p1, :cond_11

    .line 237
    .line 238
    invoke-virtual {v2}, LgValue7788;->waiBKÀ()Z

    .line 239
    .line 240
    .line 241
    move-result p1

    .line 242
    if-nez p1, :cond_11

    .line 243
    .line 244
    invoke-static {v5, v6}, LnPos2706;->UC_n_(J)J

    .line 245
    .line 246
    .line 247
    move-result-wide v5

    .line 248
    invoke-static {v0, v5, v6}, LnPos5502;->Ialue(Landroid/media/metrics/PlaybackMetrics$Builder;J)V

    .line 249
    .line 250
    .line 251
    :cond_11
    invoke-virtual {v2}, LgValue7788;->waiBKÀ()Z

    .line 252
    .line 253
    .line 254
    move-result p1

    .line 255
    if-eq v4, p1, :cond_12

    .line 256
    .line 257
    const/4 p2, 0x1

    .line 258
    :cond_12
    invoke-static {v0, p2}, LnPos5502;->UC_n_(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 259
    .line 260
    .line 261
    iput-boolean v4, p0, Lk6x_8$a_;->l1:Z

    .line 262
    .line 263
    :cond_13
    :goto_6
    return-void

    .line 264
    nop

    .line 265
    :sswitch_data_0
    .sparse-switch
        0x19883 -> :sswitch_3
        0x1a721 -> :sswitch_2
        0x317849 -> :sswitch_1
        0x325a49 -> :sswitch_0
    .end sparse-switch
.end method

.method public final pCXDYg(Lavt$p$;)Z
    .locals 2

    .line 1
    if-eqz p1, :cond_0

    .line 2
    .line 3
    iget-object v0, p0, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 4
    .line 5
    iget-object p1, p1, Lavt$p$;->waiBKÀ:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p1, Ljava/lang/String;

    .line 8
    .line 9
    monitor-enter v0

    .line 10
    :try_start_0
    iget-object v1, v0, LisPos6698;->tmpData3485:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 11
    .line 12
    monitor-exit v0

    .line 13
    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    return p1

    .line 21
    :catchall_0
    move-exception p1

    .line 22
    :try_start_1
    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 23
    throw p1

    .line 24
    :cond_0
    const/4 p1, 0x0

    .line 25
    return p1
.end method

.method public final rz__9J_(LTÈ$Dzp;)V
    .locals 4

    .line 1
    iget-object v0, p0, Lk6x_8$a_;->kCount1402:Lavt$p$;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v1, v0, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, LgItem9321;

    .line 8
    .line 9
    iget v2, v1, LgItem9321;->Qp_Hp$i_:I

    .line 10
    .line 11
    const/4 v3, -0x1

    .line 12
    if-ne v2, v3, :cond_0

    .line 13
    .line 14
    new-instance v2, LtmpOffset9868;

    .line 15
    .line 16
    invoke-direct {v2, v1}, LtmpOffset9868;-><init>(LgItem9321;)V

    .line 17
    .line 18
    .line 19
    iget v1, p1, LTÈ$Dzp;->e8$mp_s$:I

    .line 20
    .line 21
    iput v1, v2, LtmpOffset9868;->kO_6X_:I

    .line 22
    .line 23
    iget p1, p1, LTÈ$Dzp;->waiBKÀ:I

    .line 24
    .line 25
    iput p1, v2, LtmpOffset9868;->K0I:I

    .line 26
    .line 27
    new-instance p1, LgItem9321;

    .line 28
    .line 29
    invoke-direct {p1, v2}, LgItem9321;-><init>(LtmpOffset9868;)V

    .line 30
    .line 31
    .line 32
    iget-object v0, v0, Lavt$p$;->waiBKÀ:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast v0, Ljava/lang/String;

    .line 35
    .line 36
    new-instance v1, Lavt$p$;

    .line 37
    .line 38
    invoke-direct {v1, v0, p1}, Lavt$p$;-><init>(Ljava/lang/String;LgItem9321;)V

    .line 39
    .line 40
    .line 41
    iput-object v1, p0, Lk6x_8$a_;->kCount1402:Lavt$p$;

    .line 42
    .line 43
    :cond_0
    return-void
.end method

.method public final synthetic sKey7917()V
    .locals 0

    .line 1
    return-void
.end method

.method public final tmpData3485(LjPRÒÒI;Ljava/lang/String;)V
    .locals 0

    .line 1
    iget-object p1, p1, LjPRÒÒI;->POOl:Laa2l;

    .line 2
    .line 3
    if-eqz p1, :cond_0

    .line 4
    .line 5
    invoke-virtual {p1}, Laa2l;->waiBKÀ()Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-nez p1, :cond_1

    .line 10
    .line 11
    :cond_0
    iget-object p1, p0, Lk6x_8$a_;->yàÒZ:Ljava/lang/String;

    .line 12
    .line 13
    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    if-eqz p1, :cond_1

    .line 18
    .line 19
    invoke-virtual {p0}, Lk6x_8$a_;->yON3x()V

    .line 20
    .line 21
    .line 22
    :cond_1
    iget-object p1, p0, Lk6x_8$a_;->valuI:Ljava/util/HashMap;

    .line 23
    .line 24
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, Lk6x_8$a_;->pCXDYg:Ljava/util/HashMap;

    .line 28
    .line 29
    invoke-virtual {p1, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public final vaIue(LHDl0DI;Lll1lliI;)V
    .locals 22

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p2

    .line 4
    .line 5
    iget-object v2, v0, Lll1lliI;->vaIue:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v2, Lli1il1i;

    .line 8
    .line 9
    iget-object v2, v2, Lli1il1i;->e8$mp_s$:Landroid/util/SparseBooleanArray;

    .line 10
    .line 11
    invoke-virtual {v2}, Landroid/util/SparseBooleanArray;->size()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    if-nez v2, :cond_0

    .line 16
    .line 17
    goto/16 :goto_24

    .line 18
    .line 19
    :cond_0
    const/4 v7, 0x0

    .line 20
    const/4 v2, 0x0

    .line 21
    :goto_0
    iget-object v3, v0, Lll1lliI;->vaIue:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v3, Lli1il1i;

    .line 24
    .line 25
    iget-object v3, v3, Lli1il1i;->e8$mp_s$:Landroid/util/SparseBooleanArray;

    .line 26
    .line 27
    invoke-virtual {v3}, Landroid/util/SparseBooleanArray;->size()I

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    const/16 v8, 0xb

    .line 32
    .line 33
    const/4 v5, 0x0

    .line 34
    if-ge v2, v3, :cond_8

    .line 35
    .line 36
    iget-object v3, v0, Lll1lliI;->vaIue:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v3, Lli1il1i;

    .line 39
    .line 40
    invoke-virtual {v3, v2}, Lli1il1i;->e8$mp_s$(I)I

    .line 41
    .line 42
    .line 43
    move-result v3

    .line 44
    iget-object v4, v0, Lll1lliI;->jPos3709:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast v4, Landroid/util/SparseArray;

    .line 47
    .line 48
    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v4

    .line 52
    check-cast v4, LjPRÒÒI;

    .line 53
    .line 54
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    if-nez v3, :cond_6

    .line 58
    .line 59
    iget-object v6, v1, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 60
    .line 61
    monitor-enter v6

    .line 62
    :try_start_0
    iget-object v3, v6, LisPos6698;->POOl:Lk6x_8$a_;

    .line 63
    .line 64
    if-eqz v3, :cond_5

    .line 65
    .line 66
    iget-object v3, v6, LisPos6698;->JKEoÙX:LisItem9853;

    .line 67
    .line 68
    iget-object v5, v4, LjPRÒÒI;->waiBKÀ:LisItem9853;

    .line 69
    .line 70
    iput-object v5, v6, LisPos6698;->JKEoÙX:LisItem9853;

    .line 71
    .line 72
    iget-object v5, v6, LisPos6698;->rz__9J_:Ljava/util/HashMap;

    .line 73
    .line 74
    invoke-virtual {v5}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    .line 75
    .line 76
    .line 77
    move-result-object v5

    .line 78
    invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 79
    .line 80
    .line 81
    move-result-object v5

    .line 82
    :cond_1
    :goto_1
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 83
    .line 84
    .line 85
    move-result v8

    .line 86
    if-eqz v8, :cond_4

    .line 87
    .line 88
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v8

    .line 92
    check-cast v8, LgItem4936;

    .line 93
    .line 94
    iget-object v9, v6, LisPos6698;->JKEoÙX:LisItem9853;

    .line 95
    .line 96
    invoke-virtual {v8, v3, v9}, LgItem4936;->waiBKÀ(LisItem9853;LisItem9853;)Z

    .line 97
    .line 98
    .line 99
    move-result v9

    .line 100
    if-eqz v9, :cond_2

    .line 101
    .line 102
    invoke-virtual {v8, v4}, LgItem4936;->e8$mp_s$(LjPRÒÒI;)Z

    .line 103
    .line 104
    .line 105
    move-result v9

    .line 106
    if-eqz v9, :cond_1

    .line 107
    .line 108
    goto :goto_2

    .line 109
    :catchall_0
    move-exception v0

    .line 110
    goto :goto_3

    .line 111
    :cond_2
    :goto_2
    invoke-interface {v5}, Ljava/util/Iterator;->remove()V

    .line 112
    .line 113
    .line 114
    iget-boolean v9, v8, LgItem4936;->JKEoÙX:Z

    .line 115
    .line 116
    if-eqz v9, :cond_1

    .line 117
    .line 118
    iget-object v9, v8, LgItem4936;->e8$mp_s$:Ljava/lang/String;

    .line 119
    .line 120
    iget-object v10, v6, LisPos6698;->tmpData3485:Ljava/lang/String;

    .line 121
    .line 122
    invoke-virtual {v9, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v9

    .line 126
    if-eqz v9, :cond_3

    .line 127
    .line 128
    invoke-virtual {v6, v8}, LisPos6698;->tmpData3485(LgItem4936;)V

    .line 129
    .line 130
    .line 131
    :cond_3
    iget-object v9, v6, LisPos6698;->POOl:Lk6x_8$a_;

    .line 132
    .line 133
    iget-object v8, v8, LgItem4936;->e8$mp_s$:Ljava/lang/String;

    .line 134
    .line 135
    invoke-virtual {v9, v4, v8}, Lk6x_8$a_;->tmpData3485(LjPRÒÒI;Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    goto :goto_1

    .line 139
    :cond_4
    invoke-virtual {v6, v4}, LisPos6698;->sKey7917(LjPRÒÒI;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 140
    .line 141
    .line 142
    monitor-exit v6

    .line 143
    goto :goto_4

    .line 144
    :cond_5
    :try_start_1
    throw v5

    .line 145
    :goto_3
    monitor-exit v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 146
    throw v0

    .line 147
    :cond_6
    if-ne v3, v8, :cond_7

    .line 148
    .line 149
    iget-object v3, v1, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 150
    .line 151
    iget v5, v1, Lk6x_8$a_;->kO_6X_:I

    .line 152
    .line 153
    invoke-virtual {v3, v4, v5}, LisPos6698;->POOl(LjPRÒÒI;I)V

    .line 154
    .line 155
    .line 156
    goto :goto_4

    .line 157
    :cond_7
    iget-object v3, v1, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 158
    .line 159
    invoke-virtual {v3, v4}, LisPos6698;->rz__9J_(LjPRÒÒI;)V

    .line 160
    .line 161
    .line 162
    :goto_4
    add-int/lit8 v2, v2, 0x1

    .line 163
    .line 164
    goto/16 :goto_0

    .line 165
    .line 166
    :cond_8
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 167
    .line 168
    .line 169
    move-result-wide v3

    .line 170
    invoke-virtual {v0, v7}, Lll1lliI;->sKey6064(I)Z

    .line 171
    .line 172
    .line 173
    move-result v2

    .line 174
    if-eqz v2, :cond_9

    .line 175
    .line 176
    iget-object v2, v0, Lll1lliI;->jPos3709:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v2, Landroid/util/SparseArray;

    .line 179
    .line 180
    invoke-virtual {v2, v7}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v2

    .line 184
    check-cast v2, LjPRÒÒI;

    .line 185
    .line 186
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 187
    .line 188
    .line 189
    iget-object v6, v1, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 190
    .line 191
    if-eqz v6, :cond_9

    .line 192
    .line 193
    iget-object v6, v2, LjPRÒÒI;->waiBKÀ:LisItem9853;

    .line 194
    .line 195
    iget-object v2, v2, LjPRÒÒI;->POOl:Laa2l;

    .line 196
    .line 197
    invoke-virtual {v1, v6, v2}, Lk6x_8$a_;->kQy(LisItem9853;Laa2l;)V

    .line 198
    .line 199
    .line 200
    :cond_9
    const/4 v9, 0x2

    .line 201
    invoke-virtual {v0, v9}, Lll1lliI;->sKey6064(I)Z

    .line 202
    .line 203
    .line 204
    move-result v2

    .line 205
    const/4 v11, 0x3

    .line 206
    const/4 v12, 0x1

    .line 207
    if-eqz v2, :cond_11

    .line 208
    .line 209
    iget-object v2, v1, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 210
    .line 211
    if-eqz v2, :cond_11

    .line 212
    .line 213
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->vIndex5686()LSc_bl_;

    .line 214
    .line 215
    .line 216
    move-result-object v2

    .line 217
    iget-object v2, v2, LSc_bl_;->e8$mp_s$:LnW_cN_;

    .line 218
    .line 219
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 220
    .line 221
    .line 222
    move-result v6

    .line 223
    const/4 v13, 0x0

    .line 224
    :goto_5
    if-ge v13, v6, :cond_c

    .line 225
    .line 226
    invoke-interface {v2, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v14

    .line 230
    check-cast v14, LipmbqQ;

    .line 231
    .line 232
    const/4 v15, 0x0

    .line 233
    :goto_6
    iget v8, v14, LipmbqQ;->e8$mp_s$:I

    .line 234
    .line 235
    add-int/lit8 v16, v13, 0x1

    .line 236
    .line 237
    if-ge v15, v8, :cond_b

    .line 238
    .line 239
    iget-object v8, v14, LipmbqQ;->JKEoÙX:[Z

    .line 240
    .line 241
    aget-boolean v8, v8, v15

    .line 242
    .line 243
    if-eqz v8, :cond_a

    .line 244
    .line 245
    iget-object v8, v14, LipmbqQ;->waiBKÀ:LgData1538;

    .line 246
    .line 247
    iget-object v8, v8, LgData1538;->POOl:[LgItem9321;

    .line 248
    .line 249
    aget-object v8, v8, v15

    .line 250
    .line 251
    iget-object v8, v8, LgItem9321;->yàÒZ:LzN_S$ec_;

    .line 252
    .line 253
    if-eqz v8, :cond_a

    .line 254
    .line 255
    goto :goto_7

    .line 256
    :cond_a
    add-int/lit8 v15, v15, 0x1

    .line 257
    .line 258
    goto :goto_6

    .line 259
    :cond_b
    move/from16 v13, v16

    .line 260
    .line 261
    const/16 v8, 0xb

    .line 262
    .line 263
    goto :goto_5

    .line 264
    :cond_c
    move-object v8, v5

    .line 265
    :goto_7
    if-eqz v8, :cond_11

    .line 266
    .line 267
    iget-object v2, v1, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 268
    .line 269
    sget v6, LnPos2706;->e8$mp_s$:I

    .line 270
    .line 271
    invoke-static {v2}, LnPos5502;->vaIue(Ljava/lang/Object;)Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 272
    .line 273
    .line 274
    move-result-object v2

    .line 275
    const/4 v6, 0x0

    .line 276
    :goto_8
    iget v13, v8, LzN_S$ec_;->iOffset934:I

    .line 277
    .line 278
    if-ge v6, v13, :cond_10

    .line 279
    .line 280
    iget-object v13, v8, LzN_S$ec_;->yON3x:[LfOD;

    .line 281
    .line 282
    aget-object v13, v13, v6

    .line 283
    .line 284
    iget-object v13, v13, LfOD;->vaIue:Ljava/util/UUID;

    .line 285
    .line 286
    sget-object v14, LTSjI;->POOl:Ljava/util/UUID;

    .line 287
    .line 288
    invoke-virtual {v13, v14}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 289
    .line 290
    .line 291
    move-result v14

    .line 292
    if-eqz v14, :cond_d

    .line 293
    .line 294
    const/4 v6, 0x3

    .line 295
    goto :goto_9

    .line 296
    :cond_d
    sget-object v14, LTSjI;->JKEoÙX:Ljava/util/UUID;

    .line 297
    .line 298
    invoke-virtual {v13, v14}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 299
    .line 300
    .line 301
    move-result v14

    .line 302
    if-eqz v14, :cond_e

    .line 303
    .line 304
    const/4 v6, 0x2

    .line 305
    goto :goto_9

    .line 306
    :cond_e
    sget-object v14, LTSjI;->rz__9J_:Ljava/util/UUID;

    .line 307
    .line 308
    invoke-virtual {v13, v14}, Ljava/util/UUID;->equals(Ljava/lang/Object;)Z

    .line 309
    .line 310
    .line 311
    move-result v13

    .line 312
    if-eqz v13, :cond_f

    .line 313
    .line 314
    const/4 v6, 0x6

    .line 315
    goto :goto_9

    .line 316
    :cond_f
    add-int/lit8 v6, v6, 0x1

    .line 317
    .line 318
    goto :goto_8

    .line 319
    :cond_10
    const/4 v6, 0x1

    .line 320
    :goto_9
    invoke-static {v2, v6}, LnPos5502;->$ÒcdS(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 321
    .line 322
    .line 323
    :cond_11
    const/16 v2, 0x3f3

    .line 324
    .line 325
    invoke-virtual {v0, v2}, Lll1lliI;->sKey6064(I)Z

    .line 326
    .line 327
    .line 328
    move-result v2

    .line 329
    if-eqz v2, :cond_12

    .line 330
    .line 331
    iget v2, v1, Lk6x_8$a_;->Iii:I

    .line 332
    .line 333
    add-int/2addr v2, v12

    .line 334
    iput v2, v1, Lk6x_8$a_;->Iii:I

    .line 335
    .line 336
    :cond_12
    iget-object v2, v1, Lk6x_8$a_;->UC_n_:LjValue5229;

    .line 337
    .line 338
    const/16 v16, 0x9

    .line 339
    .line 340
    if-nez v2, :cond_13

    .line 341
    .line 342
    goto/16 :goto_11

    .line 343
    .line 344
    :cond_13
    iget-object v6, v1, Lk6x_8$a_;->yON3x:Landroid/content/Context;

    .line 345
    .line 346
    iget v8, v2, LjValue5229;->yON3x:I

    .line 347
    .line 348
    const/16 v10, 0x3e9

    .line 349
    .line 350
    if-ne v8, v10, :cond_15

    .line 351
    .line 352
    const/16 v6, 0x14

    .line 353
    .line 354
    :cond_14
    :goto_a
    const/4 v8, 0x0

    .line 355
    goto/16 :goto_10

    .line 356
    .line 357
    :cond_15
    move-object v8, v2

    .line 358
    check-cast v8, LZ0lI;

    .line 359
    .line 360
    iget v10, v8, LZ0lI;->jPos3709:I

    .line 361
    .line 362
    if-ne v10, v12, :cond_16

    .line 363
    .line 364
    const/4 v10, 0x1

    .line 365
    goto :goto_b

    .line 366
    :cond_16
    const/4 v10, 0x0

    .line 367
    :goto_b
    iget v8, v8, LZ0lI;->valuI:I

    .line 368
    .line 369
    invoke-virtual {v2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 370
    .line 371
    .line 372
    move-result-object v13

    .line 373
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 374
    .line 375
    .line 376
    instance-of v14, v13, Ljava/io/IOException;

    .line 377
    .line 378
    const/16 v17, 0x1c

    .line 379
    .line 380
    const/16 v18, 0x19

    .line 381
    .line 382
    const/16 v19, 0x1a

    .line 383
    .line 384
    const/16 v20, 0x18

    .line 385
    .line 386
    const/16 v21, 0x1b

    .line 387
    .line 388
    const/16 v15, 0x17

    .line 389
    .line 390
    if-eqz v14, :cond_28

    .line 391
    .line 392
    instance-of v8, v13, LPÙDYx;

    .line 393
    .line 394
    if-eqz v8, :cond_17

    .line 395
    .line 396
    check-cast v13, LPÙDYx;

    .line 397
    .line 398
    iget v6, v13, LPÙDYx;->jPos3709:I

    .line 399
    .line 400
    move v8, v6

    .line 401
    const/4 v6, 0x5

    .line 402
    goto/16 :goto_10

    .line 403
    .line 404
    :cond_17
    instance-of v8, v13, LhasIndex1902;

    .line 405
    .line 406
    if-eqz v8, :cond_18

    .line 407
    .line 408
    const/16 v6, 0xb

    .line 409
    .line 410
    goto :goto_a

    .line 411
    :cond_18
    instance-of v8, v13, LvQs_w$S_;

    .line 412
    .line 413
    if-nez v8, :cond_23

    .line 414
    .line 415
    instance-of v10, v13, LRlI0O;

    .line 416
    .line 417
    if-eqz v10, :cond_19

    .line 418
    .line 419
    goto/16 :goto_f

    .line 420
    .line 421
    :cond_19
    iget v6, v2, LjValue5229;->yON3x:I

    .line 422
    .line 423
    const/16 v8, 0x3ea

    .line 424
    .line 425
    if-ne v6, v8, :cond_1a

    .line 426
    .line 427
    const/16 v6, 0x15

    .line 428
    .line 429
    goto :goto_a

    .line 430
    :cond_1a
    instance-of v6, v13, LHm$K$;

    .line 431
    .line 432
    if-eqz v6, :cond_20

    .line 433
    .line 434
    invoke-virtual {v13}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 435
    .line 436
    .line 437
    move-result-object v6

    .line 438
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 439
    .line 440
    .line 441
    instance-of v8, v6, Landroid/media/MediaDrm$MediaDrmStateException;

    .line 442
    .line 443
    if-eqz v8, :cond_1b

    .line 444
    .line 445
    check-cast v6, Landroid/media/MediaDrm$MediaDrmStateException;

    .line 446
    .line 447
    invoke-virtual {v6}, Landroid/media/MediaDrm$MediaDrmStateException;->getDiagnosticInfo()Ljava/lang/String;

    .line 448
    .line 449
    .line 450
    move-result-object v6

    .line 451
    invoke-static {v6}, LnPos2706;->pCXDYg(Ljava/lang/String;)I

    .line 452
    .line 453
    .line 454
    move-result v6

    .line 455
    invoke-static {v6}, LnPos2706;->valuI(I)I

    .line 456
    .line 457
    .line 458
    move-result v8

    .line 459
    packed-switch v8, :pswitch_data_0

    .line 460
    .line 461
    .line 462
    :goto_c
    const/16 v17, 0x1b

    .line 463
    .line 464
    goto :goto_d

    .line 465
    :pswitch_0
    const/16 v17, 0x1a

    .line 466
    .line 467
    goto :goto_d

    .line 468
    :pswitch_1
    const/16 v17, 0x19

    .line 469
    .line 470
    goto :goto_d

    .line 471
    :pswitch_2
    const/16 v17, 0x18

    .line 472
    .line 473
    :goto_d
    :pswitch_3
    move v8, v6

    .line 474
    move/from16 v6, v17

    .line 475
    .line 476
    goto/16 :goto_10

    .line 477
    .line 478
    :cond_1b
    sget v8, LnPos2706;->e8$mp_s$:I

    .line 479
    .line 480
    if-lt v8, v15, :cond_1c

    .line 481
    .line 482
    invoke-static {v6}, LWdtÈhQMÌz;->$ÒcdS(Ljava/lang/Throwable;)Z

    .line 483
    .line 484
    .line 485
    move-result v8

    .line 486
    if-eqz v8, :cond_1c

    .line 487
    .line 488
    const/16 v6, 0x1b

    .line 489
    .line 490
    goto/16 :goto_a

    .line 491
    .line 492
    :cond_1c
    instance-of v8, v6, Landroid/media/NotProvisionedException;

    .line 493
    .line 494
    if-eqz v8, :cond_1d

    .line 495
    .line 496
    const/16 v6, 0x18

    .line 497
    .line 498
    goto/16 :goto_a

    .line 499
    .line 500
    :cond_1d
    instance-of v8, v6, Landroid/media/DeniedByServerException;

    .line 501
    .line 502
    if-eqz v8, :cond_1e

    .line 503
    .line 504
    const/16 v6, 0x1d

    .line 505
    .line 506
    goto/16 :goto_a

    .line 507
    .line 508
    :cond_1e
    instance-of v6, v6, LpQ;

    .line 509
    .line 510
    if-eqz v6, :cond_1f

    .line 511
    .line 512
    :goto_e
    const/16 v6, 0x17

    .line 513
    .line 514
    goto/16 :goto_a

    .line 515
    .line 516
    :cond_1f
    const/16 v6, 0x1e

    .line 517
    .line 518
    goto/16 :goto_a

    .line 519
    .line 520
    :cond_20
    instance-of v6, v13, LisCount5221;

    .line 521
    .line 522
    if-eqz v6, :cond_22

    .line 523
    .line 524
    invoke-virtual {v13}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 525
    .line 526
    .line 527
    move-result-object v6

    .line 528
    instance-of v6, v6, Ljava/io/FileNotFoundException;

    .line 529
    .line 530
    if-eqz v6, :cond_22

    .line 531
    .line 532
    invoke-virtual {v13}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 533
    .line 534
    .line 535
    move-result-object v6

    .line 536
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 537
    .line 538
    .line 539
    invoke-virtual {v6}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 540
    .line 541
    .line 542
    move-result-object v6

    .line 543
    instance-of v8, v6, Landroid/system/ErrnoException;

    .line 544
    .line 545
    const/16 v10, 0x1f

    .line 546
    .line 547
    if-eqz v8, :cond_21

    .line 548
    .line 549
    check-cast v6, Landroid/system/ErrnoException;

    .line 550
    .line 551
    iget v6, v6, Landroid/system/ErrnoException;->errno:I

    .line 552
    .line 553
    sget v8, Landroid/system/OsConstants;->EACCES:I

    .line 554
    .line 555
    if-ne v6, v8, :cond_21

    .line 556
    .line 557
    const/16 v6, 0x20

    .line 558
    .line 559
    goto/16 :goto_a

    .line 560
    .line 561
    :cond_21
    const/16 v6, 0x1f

    .line 562
    .line 563
    goto/16 :goto_a

    .line 564
    .line 565
    :cond_22
    const/16 v6, 0x9

    .line 566
    .line 567
    goto/16 :goto_a

    .line 568
    .line 569
    :cond_23
    :goto_f
    invoke-static {v6}, LgOffset3699;->jPos3709(Landroid/content/Context;)LgOffset3699;

    .line 570
    .line 571
    .line 572
    move-result-object v6

    .line 573
    invoke-virtual {v6}, LgOffset3699;->POOl()I

    .line 574
    .line 575
    .line 576
    move-result v6

    .line 577
    if-ne v6, v12, :cond_24

    .line 578
    .line 579
    const/4 v6, 0x3

    .line 580
    goto/16 :goto_a

    .line 581
    .line 582
    :cond_24
    invoke-virtual {v13}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 583
    .line 584
    .line 585
    move-result-object v6

    .line 586
    instance-of v10, v6, Ljava/net/UnknownHostException;

    .line 587
    .line 588
    if-eqz v10, :cond_25

    .line 589
    .line 590
    const/4 v6, 0x6

    .line 591
    goto/16 :goto_a

    .line 592
    .line 593
    :cond_25
    instance-of v6, v6, Ljava/net/SocketTimeoutException;

    .line 594
    .line 595
    if-eqz v6, :cond_26

    .line 596
    .line 597
    const/4 v6, 0x7

    .line 598
    goto/16 :goto_a

    .line 599
    .line 600
    :cond_26
    if-eqz v8, :cond_27

    .line 601
    .line 602
    check-cast v13, LvQs_w$S_;

    .line 603
    .line 604
    iget v6, v13, LvQs_w$S_;->vaIue:I

    .line 605
    .line 606
    if-ne v6, v12, :cond_27

    .line 607
    .line 608
    const/4 v6, 0x4

    .line 609
    goto/16 :goto_a

    .line 610
    .line 611
    :cond_27
    const/16 v6, 0x8

    .line 612
    .line 613
    goto/16 :goto_a

    .line 614
    .line 615
    :cond_28
    if-eqz v10, :cond_29

    .line 616
    .line 617
    const/16 v6, 0x23

    .line 618
    .line 619
    if-eqz v8, :cond_14

    .line 620
    .line 621
    if-ne v8, v12, :cond_29

    .line 622
    .line 623
    goto/16 :goto_a

    .line 624
    .line 625
    :cond_29
    if-eqz v10, :cond_2a

    .line 626
    .line 627
    if-ne v8, v11, :cond_2a

    .line 628
    .line 629
    const/16 v6, 0xf

    .line 630
    .line 631
    goto/16 :goto_a

    .line 632
    .line 633
    :cond_2a
    if-eqz v10, :cond_2b

    .line 634
    .line 635
    if-ne v8, v9, :cond_2b

    .line 636
    .line 637
    goto :goto_e

    .line 638
    :cond_2b
    instance-of v6, v13, LnItem5697;

    .line 639
    .line 640
    if-eqz v6, :cond_2c

    .line 641
    .line 642
    check-cast v13, LnItem5697;

    .line 643
    .line 644
    iget-object v6, v13, LnItem5697;->jPos3709:Ljava/lang/String;

    .line 645
    .line 646
    invoke-static {v6}, LnPos2706;->pCXDYg(Ljava/lang/String;)I

    .line 647
    .line 648
    .line 649
    move-result v6

    .line 650
    move v8, v6

    .line 651
    const/16 v6, 0xd

    .line 652
    .line 653
    goto :goto_10

    .line 654
    :cond_2c
    instance-of v6, v13, L_PJjMì;

    .line 655
    .line 656
    const/16 v8, 0xe

    .line 657
    .line 658
    if-eqz v6, :cond_2d

    .line 659
    .line 660
    check-cast v13, L_PJjMì;

    .line 661
    .line 662
    iget v6, v13, L_PJjMì;->yON3x:I

    .line 663
    .line 664
    move v8, v6

    .line 665
    const/16 v6, 0xe

    .line 666
    .line 667
    goto :goto_10

    .line 668
    :cond_2d
    instance-of v6, v13, Ljava/lang/OutOfMemoryError;

    .line 669
    .line 670
    if-eqz v6, :cond_2e

    .line 671
    .line 672
    const/16 v6, 0xe

    .line 673
    .line 674
    goto/16 :goto_a

    .line 675
    .line 676
    :cond_2e
    instance-of v6, v13, LwÈfe;

    .line 677
    .line 678
    if-eqz v6, :cond_2f

    .line 679
    .line 680
    check-cast v13, LwÈfe;

    .line 681
    .line 682
    iget v6, v13, LwÈfe;->yON3x:I

    .line 683
    .line 684
    const/16 v8, 0x11

    .line 685
    .line 686
    move v8, v6

    .line 687
    const/16 v6, 0x11

    .line 688
    .line 689
    goto :goto_10

    .line 690
    :cond_2f
    instance-of v6, v13, Ln1I;

    .line 691
    .line 692
    if-eqz v6, :cond_30

    .line 693
    .line 694
    check-cast v13, Ln1I;

    .line 695
    .line 696
    iget v6, v13, Ln1I;->yON3x:I

    .line 697
    .line 698
    const/16 v8, 0x12

    .line 699
    .line 700
    move v8, v6

    .line 701
    const/16 v6, 0x12

    .line 702
    .line 703
    goto :goto_10

    .line 704
    :cond_30
    instance-of v6, v13, Landroid/media/MediaCodec$CryptoException;

    .line 705
    .line 706
    if-eqz v6, :cond_31

    .line 707
    .line 708
    check-cast v13, Landroid/media/MediaCodec$CryptoException;

    .line 709
    .line 710
    invoke-virtual {v13}, Landroid/media/MediaCodec$CryptoException;->getErrorCode()I

    .line 711
    .line 712
    .line 713
    move-result v6

    .line 714
    invoke-static {v6}, LnPos2706;->valuI(I)I

    .line 715
    .line 716
    .line 717
    move-result v8

    .line 718
    packed-switch v8, :pswitch_data_1

    .line 719
    .line 720
    .line 721
    goto/16 :goto_c

    .line 722
    .line 723
    :cond_31
    const/16 v6, 0x16

    .line 724
    .line 725
    goto/16 :goto_a

    .line 726
    .line 727
    :goto_10
    iget-object v10, v1, Lk6x_8$a_;->jPos3709:Landroid/media/metrics/PlaybackSession;

    .line 728
    .line 729
    invoke-static {}, LShH$1_1$;->JKEoÙX()Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 730
    .line 731
    .line 732
    move-result-object v13

    .line 733
    iget-wide v14, v1, Lk6x_8$a_;->iOffset934:J

    .line 734
    .line 735
    sub-long v14, v3, v14

    .line 736
    .line 737
    invoke-static {v13, v14, v15}, LnPos5502;->tmpData3485(Landroid/media/metrics/PlaybackErrorEvent$Builder;J)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 738
    .line 739
    .line 740
    move-result-object v13

    .line 741
    invoke-static {v13, v6}, LnPos5502;->JKEoÙX(Landroid/media/metrics/PlaybackErrorEvent$Builder;I)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 742
    .line 743
    .line 744
    move-result-object v6

    .line 745
    invoke-static {v6, v8}, LnPos5502;->K0I(Landroid/media/metrics/PlaybackErrorEvent$Builder;I)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 746
    .line 747
    .line 748
    move-result-object v6

    .line 749
    invoke-static {v6, v2}, LnPos5502;->sKey7917(Landroid/media/metrics/PlaybackErrorEvent$Builder;Ljava/lang/Exception;)Landroid/media/metrics/PlaybackErrorEvent$Builder;

    .line 750
    .line 751
    .line 752
    move-result-object v2

    .line 753
    invoke-static {v2}, LnPos5502;->DDù8(Landroid/media/metrics/PlaybackErrorEvent$Builder;)Landroid/media/metrics/PlaybackErrorEvent;

    .line 754
    .line 755
    .line 756
    move-result-object v2

    .line 757
    invoke-static {v10, v2}, LnPos5502;->valuI(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackErrorEvent;)V

    .line 758
    .line 759
    .line 760
    iput-boolean v12, v1, Lk6x_8$a_;->l1:Z

    .line 761
    .line 762
    iput-object v5, v1, Lk6x_8$a_;->UC_n_:LjValue5229;

    .line 763
    .line 764
    :goto_11
    invoke-virtual {v0, v9}, Lll1lliI;->sKey6064(I)Z

    .line 765
    .line 766
    .line 767
    move-result v2

    .line 768
    if-eqz v2, :cond_32

    .line 769
    .line 770
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->vIndex5686()LSc_bl_;

    .line 771
    .line 772
    .line 773
    move-result-object v2

    .line 774
    invoke-virtual {v2, v9}, LSc_bl_;->e8$mp_s$(I)Z

    .line 775
    .line 776
    .line 777
    move-result v6

    .line 778
    invoke-virtual {v2, v12}, LSc_bl_;->e8$mp_s$(I)Z

    .line 779
    .line 780
    .line 781
    move-result v8

    .line 782
    invoke-virtual {v2, v11}, LSc_bl_;->e8$mp_s$(I)Z

    .line 783
    .line 784
    .line 785
    move-result v2

    .line 786
    if-nez v6, :cond_33

    .line 787
    .line 788
    if-nez v8, :cond_33

    .line 789
    .line 790
    if-eqz v2, :cond_32

    .line 791
    .line 792
    const/4 v10, 0x1

    .line 793
    goto :goto_12

    .line 794
    :cond_32
    move-object v8, v5

    .line 795
    const/4 v13, 0x4

    .line 796
    goto :goto_1a

    .line 797
    :cond_33
    move v10, v2

    .line 798
    :goto_12
    if-nez v6, :cond_36

    .line 799
    .line 800
    iget-object v2, v1, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 801
    .line 802
    invoke-static {v2, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 803
    .line 804
    .line 805
    move-result v2

    .line 806
    if-eqz v2, :cond_34

    .line 807
    .line 808
    goto :goto_14

    .line 809
    :cond_34
    iget-object v2, v1, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 810
    .line 811
    if-nez v2, :cond_35

    .line 812
    .line 813
    const/4 v6, 0x1

    .line 814
    goto :goto_13

    .line 815
    :cond_35
    const/4 v6, 0x0

    .line 816
    :goto_13
    iput-object v5, v1, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 817
    .line 818
    const/4 v2, 0x1

    .line 819
    const/4 v13, 0x4

    .line 820
    invoke-virtual/range {v1 .. v6}, Lk6x_8$a_;->valuI(IJLgItem9321;I)V

    .line 821
    .line 822
    .line 823
    goto :goto_15

    .line 824
    :cond_36
    :goto_14
    const/4 v13, 0x4

    .line 825
    :goto_15
    if-nez v8, :cond_39

    .line 826
    .line 827
    iget-object v2, v1, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 828
    .line 829
    invoke-static {v2, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 830
    .line 831
    .line 832
    move-result v2

    .line 833
    if-eqz v2, :cond_37

    .line 834
    .line 835
    goto :goto_17

    .line 836
    :cond_37
    iget-object v2, v1, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 837
    .line 838
    if-nez v2, :cond_38

    .line 839
    .line 840
    const/4 v6, 0x1

    .line 841
    goto :goto_16

    .line 842
    :cond_38
    const/4 v6, 0x0

    .line 843
    :goto_16
    iput-object v5, v1, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 844
    .line 845
    const/4 v2, 0x0

    .line 846
    invoke-virtual/range {v1 .. v6}, Lk6x_8$a_;->valuI(IJLgItem9321;I)V

    .line 847
    .line 848
    .line 849
    :cond_39
    :goto_17
    if-nez v10, :cond_3c

    .line 850
    .line 851
    iget-object v2, v1, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 852
    .line 853
    invoke-static {v2, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 854
    .line 855
    .line 856
    move-result v2

    .line 857
    if-eqz v2, :cond_3a

    .line 858
    .line 859
    goto :goto_19

    .line 860
    :cond_3a
    iget-object v2, v1, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 861
    .line 862
    if-nez v2, :cond_3b

    .line 863
    .line 864
    const/4 v6, 0x1

    .line 865
    goto :goto_18

    .line 866
    :cond_3b
    const/4 v6, 0x0

    .line 867
    :goto_18
    iput-object v5, v1, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 868
    .line 869
    const/4 v2, 0x2

    .line 870
    invoke-virtual/range {v1 .. v6}, Lk6x_8$a_;->valuI(IJLgItem9321;I)V

    .line 871
    .line 872
    .line 873
    :cond_3c
    :goto_19
    move-object v8, v5

    .line 874
    :goto_1a
    iget-object v2, v1, Lk6x_8$a_;->kCount1402:Lavt$p$;

    .line 875
    .line 876
    invoke-virtual {v1, v2}, Lk6x_8$a_;->pCXDYg(Lavt$p$;)Z

    .line 877
    .line 878
    .line 879
    move-result v2

    .line 880
    if-eqz v2, :cond_3f

    .line 881
    .line 882
    iget-object v2, v1, Lk6x_8$a_;->kCount1402:Lavt$p$;

    .line 883
    .line 884
    iget-object v2, v2, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 885
    .line 886
    move-object v5, v2

    .line 887
    check-cast v5, LgItem9321;

    .line 888
    .line 889
    iget v2, v5, LgItem9321;->Qp_Hp$i_:I

    .line 890
    .line 891
    const/4 v6, -0x1

    .line 892
    if-eq v2, v6, :cond_3f

    .line 893
    .line 894
    iget-object v2, v1, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 895
    .line 896
    invoke-static {v2, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 897
    .line 898
    .line 899
    move-result v2

    .line 900
    if-eqz v2, :cond_3d

    .line 901
    .line 902
    goto :goto_1c

    .line 903
    :cond_3d
    iget-object v2, v1, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 904
    .line 905
    if-nez v2, :cond_3e

    .line 906
    .line 907
    const/4 v6, 0x1

    .line 908
    goto :goto_1b

    .line 909
    :cond_3e
    const/4 v6, 0x0

    .line 910
    :goto_1b
    iput-object v5, v1, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 911
    .line 912
    const/4 v2, 0x1

    .line 913
    invoke-virtual/range {v1 .. v6}, Lk6x_8$a_;->valuI(IJLgItem9321;I)V

    .line 914
    .line 915
    .line 916
    :goto_1c
    iput-object v8, v1, Lk6x_8$a_;->kCount1402:Lavt$p$;

    .line 917
    .line 918
    :cond_3f
    iget-object v2, v1, Lk6x_8$a_;->$ÒcdS:Lavt$p$;

    .line 919
    .line 920
    invoke-virtual {v1, v2}, Lk6x_8$a_;->pCXDYg(Lavt$p$;)Z

    .line 921
    .line 922
    .line 923
    move-result v2

    .line 924
    if-eqz v2, :cond_42

    .line 925
    .line 926
    iget-object v2, v1, Lk6x_8$a_;->$ÒcdS:Lavt$p$;

    .line 927
    .line 928
    iget-object v2, v2, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 929
    .line 930
    move-object v5, v2

    .line 931
    check-cast v5, LgItem9321;

    .line 932
    .line 933
    iget-object v2, v1, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 934
    .line 935
    invoke-static {v2, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 936
    .line 937
    .line 938
    move-result v2

    .line 939
    if-eqz v2, :cond_40

    .line 940
    .line 941
    goto :goto_1e

    .line 942
    :cond_40
    iget-object v2, v1, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 943
    .line 944
    if-nez v2, :cond_41

    .line 945
    .line 946
    const/4 v6, 0x1

    .line 947
    goto :goto_1d

    .line 948
    :cond_41
    const/4 v6, 0x0

    .line 949
    :goto_1d
    iput-object v5, v1, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 950
    .line 951
    const/4 v2, 0x0

    .line 952
    invoke-virtual/range {v1 .. v6}, Lk6x_8$a_;->valuI(IJLgItem9321;I)V

    .line 953
    .line 954
    .line 955
    :goto_1e
    iput-object v8, v1, Lk6x_8$a_;->$ÒcdS:Lavt$p$;

    .line 956
    .line 957
    :cond_42
    iget-object v2, v1, Lk6x_8$a_;->Q1_f_:Lavt$p$;

    .line 958
    .line 959
    invoke-virtual {v1, v2}, Lk6x_8$a_;->pCXDYg(Lavt$p$;)Z

    .line 960
    .line 961
    .line 962
    move-result v2

    .line 963
    if-eqz v2, :cond_45

    .line 964
    .line 965
    iget-object v2, v1, Lk6x_8$a_;->Q1_f_:Lavt$p$;

    .line 966
    .line 967
    iget-object v2, v2, Lavt$p$;->e8$mp_s$:Ljava/lang/Object;

    .line 968
    .line 969
    move-object v5, v2

    .line 970
    check-cast v5, LgItem9321;

    .line 971
    .line 972
    iget-object v2, v1, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 973
    .line 974
    invoke-static {v2, v5}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 975
    .line 976
    .line 977
    move-result v2

    .line 978
    if-eqz v2, :cond_43

    .line 979
    .line 980
    goto :goto_20

    .line 981
    :cond_43
    iget-object v2, v1, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 982
    .line 983
    if-nez v2, :cond_44

    .line 984
    .line 985
    const/4 v6, 0x1

    .line 986
    goto :goto_1f

    .line 987
    :cond_44
    const/4 v6, 0x0

    .line 988
    :goto_1f
    iput-object v5, v1, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 989
    .line 990
    const/4 v2, 0x2

    .line 991
    invoke-virtual/range {v1 .. v6}, Lk6x_8$a_;->valuI(IJLgItem9321;I)V

    .line 992
    .line 993
    .line 994
    :goto_20
    iput-object v8, v1, Lk6x_8$a_;->Q1_f_:Lavt$p$;

    .line 995
    .line 996
    :cond_45
    iget-object v2, v1, Lk6x_8$a_;->yON3x:Landroid/content/Context;

    .line 997
    .line 998
    invoke-static {v2}, LgOffset3699;->jPos3709(Landroid/content/Context;)LgOffset3699;

    .line 999
    .line 1000
    .line 1001
    move-result-object v2

    .line 1002
    invoke-virtual {v2}, LgOffset3699;->POOl()I

    .line 1003
    .line 1004
    .line 1005
    move-result v2

    .line 1006
    packed-switch v2, :pswitch_data_2

    .line 1007
    .line 1008
    .line 1009
    :pswitch_4
    const/4 v2, 0x1

    .line 1010
    goto :goto_21

    .line 1011
    :pswitch_5
    const/4 v2, 0x7

    .line 1012
    goto :goto_21

    .line 1013
    :pswitch_6
    const/16 v2, 0x8

    .line 1014
    .line 1015
    goto :goto_21

    .line 1016
    :pswitch_7
    const/4 v2, 0x3

    .line 1017
    goto :goto_21

    .line 1018
    :pswitch_8
    const/4 v2, 0x6

    .line 1019
    goto :goto_21

    .line 1020
    :pswitch_9
    const/4 v2, 0x5

    .line 1021
    goto :goto_21

    .line 1022
    :pswitch_a
    const/4 v2, 0x4

    .line 1023
    goto :goto_21

    .line 1024
    :pswitch_b
    const/4 v2, 0x2

    .line 1025
    goto :goto_21

    .line 1026
    :pswitch_c
    const/16 v2, 0x9

    .line 1027
    .line 1028
    goto :goto_21

    .line 1029
    :pswitch_d
    const/4 v2, 0x0

    .line 1030
    :goto_21
    iget v5, v1, Lk6x_8$a_;->Qp_Hp$i_:I

    .line 1031
    .line 1032
    if-eq v2, v5, :cond_46

    .line 1033
    .line 1034
    iput v2, v1, Lk6x_8$a_;->Qp_Hp$i_:I

    .line 1035
    .line 1036
    iget-object v5, v1, Lk6x_8$a_;->jPos3709:Landroid/media/metrics/PlaybackSession;

    .line 1037
    .line 1038
    invoke-static {}, LShH$1_1$;->POOl()Landroid/media/metrics/NetworkEvent$Builder;

    .line 1039
    .line 1040
    .line 1041
    move-result-object v6

    .line 1042
    invoke-static {v6, v2}, LnPos5502;->waiBKÀ(Landroid/media/metrics/NetworkEvent$Builder;I)Landroid/media/metrics/NetworkEvent$Builder;

    .line 1043
    .line 1044
    .line 1045
    move-result-object v2

    .line 1046
    iget-wide v14, v1, Lk6x_8$a_;->iOffset934:J

    .line 1047
    .line 1048
    sub-long v14, v3, v14

    .line 1049
    .line 1050
    invoke-static {v2, v14, v15}, LnPos5502;->rz__9J_(Landroid/media/metrics/NetworkEvent$Builder;J)Landroid/media/metrics/NetworkEvent$Builder;

    .line 1051
    .line 1052
    .line 1053
    move-result-object v2

    .line 1054
    invoke-static {v2}, LnPos5502;->POOl(Landroid/media/metrics/NetworkEvent$Builder;)Landroid/media/metrics/NetworkEvent;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v2

    .line 1058
    invoke-static {v5, v2}, LVlO1I;->gKey4112(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/NetworkEvent;)V

    .line 1059
    .line 1060
    .line 1061
    :cond_46
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->waiBKÀ()I

    .line 1062
    .line 1063
    .line 1064
    move-result v2

    .line 1065
    if-eq v2, v9, :cond_47

    .line 1066
    .line 1067
    iput-boolean v7, v1, Lk6x_8$a_;->ll:Z

    .line 1068
    .line 1069
    :cond_47
    move-object/from16 v2, p1

    .line 1070
    .line 1071
    check-cast v2, Lw0_S$wa_;

    .line 1072
    .line 1073
    iget-object v5, v2, Lw0_S$wa_;->iOffset934:LmSize5576;

    .line 1074
    .line 1075
    invoke-virtual {v5}, LmSize5576;->waiBKÀ()V

    .line 1076
    .line 1077
    .line 1078
    iget-object v2, v2, Lw0_S$wa_;->jPos3709:LmÀDjRmG;

    .line 1079
    .line 1080
    invoke-virtual {v2}, LmÀDjRmG;->vData2659()V

    .line 1081
    .line 1082
    .line 1083
    iget-object v2, v2, LmÀDjRmG;->iQ0D:LzO1D1D;

    .line 1084
    .line 1085
    iget-object v2, v2, LzO1D1D;->tmpData3485:LZ0lI;

    .line 1086
    .line 1087
    const/16 v5, 0xa

    .line 1088
    .line 1089
    if-nez v2, :cond_48

    .line 1090
    .line 1091
    iput-boolean v7, v1, Lk6x_8$a_;->oy_R$Xx_:Z

    .line 1092
    .line 1093
    goto :goto_22

    .line 1094
    :cond_48
    invoke-virtual {v0, v5}, Lll1lliI;->sKey6064(I)Z

    .line 1095
    .line 1096
    .line 1097
    move-result v2

    .line 1098
    if-eqz v2, :cond_49

    .line 1099
    .line 1100
    iput-boolean v12, v1, Lk6x_8$a_;->oy_R$Xx_:Z

    .line 1101
    .line 1102
    :cond_49
    :goto_22
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->waiBKÀ()I

    .line 1103
    .line 1104
    .line 1105
    move-result v2

    .line 1106
    iget-boolean v6, v1, Lk6x_8$a_;->ll:Z

    .line 1107
    .line 1108
    if-eqz v6, :cond_4a

    .line 1109
    .line 1110
    const/4 v8, 0x5

    .line 1111
    goto :goto_23

    .line 1112
    :cond_4a
    iget-boolean v6, v1, Lk6x_8$a_;->oy_R$Xx_:Z

    .line 1113
    .line 1114
    if-eqz v6, :cond_4b

    .line 1115
    .line 1116
    const/16 v8, 0xd

    .line 1117
    .line 1118
    goto :goto_23

    .line 1119
    :cond_4b
    if-ne v2, v13, :cond_4c

    .line 1120
    .line 1121
    const/16 v8, 0xb

    .line 1122
    .line 1123
    goto :goto_23

    .line 1124
    :cond_4c
    const/16 v8, 0xc

    .line 1125
    .line 1126
    if-ne v2, v9, :cond_51

    .line 1127
    .line 1128
    iget v2, v1, Lk6x_8$a_;->K0I:I

    .line 1129
    .line 1130
    if-eqz v2, :cond_4d

    .line 1131
    .line 1132
    if-eq v2, v9, :cond_4d

    .line 1133
    .line 1134
    if-ne v2, v8, :cond_4e

    .line 1135
    .line 1136
    :cond_4d
    const/4 v8, 0x2

    .line 1137
    goto :goto_23

    .line 1138
    :cond_4e
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->isData1637()Z

    .line 1139
    .line 1140
    .line 1141
    move-result v2

    .line 1142
    if-nez v2, :cond_4f

    .line 1143
    .line 1144
    const/4 v8, 0x7

    .line 1145
    goto :goto_23

    .line 1146
    :cond_4f
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->tmpData3485()I

    .line 1147
    .line 1148
    .line 1149
    move-result v2

    .line 1150
    if-eqz v2, :cond_50

    .line 1151
    .line 1152
    const/16 v8, 0xa

    .line 1153
    .line 1154
    goto :goto_23

    .line 1155
    :cond_50
    const/4 v8, 0x6

    .line 1156
    goto :goto_23

    .line 1157
    :cond_51
    if-ne v2, v11, :cond_54

    .line 1158
    .line 1159
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->isData1637()Z

    .line 1160
    .line 1161
    .line 1162
    move-result v2

    .line 1163
    if-nez v2, :cond_52

    .line 1164
    .line 1165
    const/4 v8, 0x4

    .line 1166
    goto :goto_23

    .line 1167
    :cond_52
    invoke-virtual/range {p1 .. p1}, LHDl0DI;->tmpData3485()I

    .line 1168
    .line 1169
    .line 1170
    move-result v2

    .line 1171
    if-eqz v2, :cond_53

    .line 1172
    .line 1173
    const/16 v8, 0x9

    .line 1174
    .line 1175
    goto :goto_23

    .line 1176
    :cond_53
    const/4 v8, 0x3

    .line 1177
    goto :goto_23

    .line 1178
    :cond_54
    if-ne v2, v12, :cond_55

    .line 1179
    .line 1180
    iget v2, v1, Lk6x_8$a_;->K0I:I

    .line 1181
    .line 1182
    if-eqz v2, :cond_55

    .line 1183
    .line 1184
    goto :goto_23

    .line 1185
    :cond_55
    iget v8, v1, Lk6x_8$a_;->K0I:I

    .line 1186
    .line 1187
    :goto_23
    iget v2, v1, Lk6x_8$a_;->K0I:I

    .line 1188
    .line 1189
    if-eq v2, v8, :cond_56

    .line 1190
    .line 1191
    iput v8, v1, Lk6x_8$a_;->K0I:I

    .line 1192
    .line 1193
    iput-boolean v12, v1, Lk6x_8$a_;->l1:Z

    .line 1194
    .line 1195
    iget-object v2, v1, Lk6x_8$a_;->jPos3709:Landroid/media/metrics/PlaybackSession;

    .line 1196
    .line 1197
    invoke-static {}, LShH$1_1$;->DDù8()Landroid/media/metrics/PlaybackStateEvent$Builder;

    .line 1198
    .line 1199
    .line 1200
    move-result-object v5

    .line 1201
    iget v6, v1, Lk6x_8$a_;->K0I:I

    .line 1202
    .line 1203
    invoke-static {v5, v6}, LShH$1_1$;->yON3x(Landroid/media/metrics/PlaybackStateEvent$Builder;I)Landroid/media/metrics/PlaybackStateEvent$Builder;

    .line 1204
    .line 1205
    .line 1206
    move-result-object v5

    .line 1207
    iget-wide v6, v1, Lk6x_8$a_;->iOffset934:J

    .line 1208
    .line 1209
    sub-long/2addr v3, v6

    .line 1210
    invoke-static {v5, v3, v4}, LShH$1_1$;->vaIue(Landroid/media/metrics/PlaybackStateEvent$Builder;J)Landroid/media/metrics/PlaybackStateEvent$Builder;

    .line 1211
    .line 1212
    .line 1213
    move-result-object v3

    .line 1214
    invoke-static {v3}, LShH$1_1$;->jPos3709(Landroid/media/metrics/PlaybackStateEvent$Builder;)Landroid/media/metrics/PlaybackStateEvent;

    .line 1215
    .line 1216
    .line 1217
    move-result-object v3

    .line 1218
    invoke-static {v2, v3}, LnPos5502;->yàÒZ(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackStateEvent;)V

    .line 1219
    .line 1220
    .line 1221
    :cond_56
    const/16 v2, 0x404

    .line 1222
    .line 1223
    invoke-virtual {v0, v2}, Lll1lliI;->sKey6064(I)Z

    .line 1224
    .line 1225
    .line 1226
    move-result v3

    .line 1227
    if-eqz v3, :cond_57

    .line 1228
    .line 1229
    iget-object v3, v1, Lk6x_8$a_;->vaIue:LisPos6698;

    .line 1230
    .line 1231
    iget-object v0, v0, Lll1lliI;->jPos3709:Ljava/lang/Object;

    .line 1232
    .line 1233
    check-cast v0, Landroid/util/SparseArray;

    .line 1234
    .line 1235
    invoke-virtual {v0, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 1236
    .line 1237
    .line 1238
    move-result-object v0

    .line 1239
    check-cast v0, LjPRÒÒI;

    .line 1240
    .line 1241
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1242
    .line 1243
    .line 1244
    invoke-virtual {v3, v0}, LisPos6698;->waiBKÀ(LjPRÒÒI;)V

    .line 1245
    .line 1246
    .line 1247
    :cond_57
    :goto_24
    return-void

    .line 1248
    nop

    .line 1249
    :pswitch_data_0
    .packed-switch 0x1772
        :pswitch_2
        :pswitch_3
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    :pswitch_data_1
    .packed-switch 0x1772
        :pswitch_2
        :pswitch_3
        :pswitch_1
        :pswitch_0
    .end packed-switch

    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    :pswitch_data_2
    .packed-switch 0x0
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_4
        :pswitch_7
        :pswitch_4
        :pswitch_6
        :pswitch_5
    .end packed-switch
.end method

.method public final valuI(IJLgItem9321;I)V
    .locals 2

    .line 1
    invoke-static {p1}, LShH$1_1$;->iOffset934(I)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    iget-wide v0, p0, Lk6x_8$a_;->iOffset934:J

    .line 6
    .line 7
    sub-long/2addr p2, v0

    .line 8
    invoke-static {p1, p2, p3}, LnPos5502;->iOffset934(Landroid/media/metrics/TrackChangeEvent$Builder;J)Landroid/media/metrics/TrackChangeEvent$Builder;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    const/4 p2, 0x1

    .line 13
    if-eqz p4, :cond_b

    .line 14
    .line 15
    invoke-static {p1}, LShH$1_1$;->oy_R$Xx_(Landroid/media/metrics/TrackChangeEvent$Builder;)V

    .line 16
    .line 17
    .line 18
    const/4 p3, 0x2

    .line 19
    if-eq p5, p2, :cond_0

    .line 20
    .line 21
    const/4 p5, 0x1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 p5, 0x2

    .line 24
    :goto_0
    invoke-static {p1, p5}, LShH$1_1$;->kCount1402(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    .line 25
    .line 26
    .line 27
    iget-object p5, p4, LgItem9321;->iOffset934:Ljava/lang/String;

    .line 28
    .line 29
    if-eqz p5, :cond_1

    .line 30
    .line 31
    invoke-static {p1, p5}, LVlO1I;->kO_6X_(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    .line 32
    .line 33
    .line 34
    :cond_1
    iget-object p5, p4, LgItem9321;->kQy:Ljava/lang/String;

    .line 35
    .line 36
    if-eqz p5, :cond_2

    .line 37
    .line 38
    invoke-static {p1, p5}, LVlO1I;->ll(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :cond_2
    iget-object p5, p4, LgItem9321;->vaIue:Ljava/lang/String;

    .line 42
    .line 43
    if-eqz p5, :cond_3

    .line 44
    .line 45
    invoke-static {p1, p5}, LVlO1I;->oy_R$Xx_(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    :cond_3
    iget p5, p4, LgItem9321;->yON3x:I

    .line 49
    .line 50
    const/4 v0, -0x1

    .line 51
    if-eq p5, v0, :cond_4

    .line 52
    .line 53
    invoke-static {p1, p5}, LnPos5502;->gKey4112(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    .line 54
    .line 55
    .line 56
    :cond_4
    iget p5, p4, LgItem9321;->K0I:I

    .line 57
    .line 58
    if-eq p5, v0, :cond_5

    .line 59
    .line 60
    invoke-static {p1, p5}, LnPos5502;->kCount1402(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    .line 61
    .line 62
    .line 63
    :cond_5
    iget p5, p4, LgItem9321;->Qp_Hp$i_:I

    .line 64
    .line 65
    if-eq p5, v0, :cond_6

    .line 66
    .line 67
    invoke-static {p1, p5}, LnPos5502;->Q1_f_(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    .line 68
    .line 69
    .line 70
    :cond_6
    iget p5, p4, LgItem9321;->tzKù7Ol1:I

    .line 71
    .line 72
    if-eq p5, v0, :cond_7

    .line 73
    .line 74
    invoke-static {p1, p5}, LnPos5502;->sKey6064(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    .line 75
    .line 76
    .line 77
    :cond_7
    iget p5, p4, LgItem9321;->ll:I

    .line 78
    .line 79
    if-eq p5, v0, :cond_8

    .line 80
    .line 81
    invoke-static {p1, p5}, LnPos5502;->ll(Landroid/media/metrics/TrackChangeEvent$Builder;I)V

    .line 82
    .line 83
    .line 84
    :cond_8
    iget-object p5, p4, LgItem9321;->POOl:Ljava/lang/String;

    .line 85
    .line 86
    if-eqz p5, :cond_a

    .line 87
    .line 88
    sget v1, LnPos2706;->e8$mp_s$:I

    .line 89
    .line 90
    const-string v1, "-"

    .line 91
    .line 92
    invoke-virtual {p5, v1, v0}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    .line 93
    .line 94
    .line 95
    move-result-object p5

    .line 96
    const/4 v0, 0x0

    .line 97
    aget-object v0, p5, v0

    .line 98
    .line 99
    array-length v1, p5

    .line 100
    if-lt v1, p3, :cond_9

    .line 101
    .line 102
    aget-object p3, p5, p2

    .line 103
    .line 104
    goto :goto_1

    .line 105
    :cond_9
    const/4 p3, 0x0

    .line 106
    :goto_1
    invoke-static {v0, p3}, Landroid/util/Pair;->create(Ljava/lang/Object;Ljava/lang/Object;)Landroid/util/Pair;

    .line 107
    .line 108
    .line 109
    move-result-object p3

    .line 110
    iget-object p5, p3, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 111
    .line 112
    check-cast p5, Ljava/lang/String;

    .line 113
    .line 114
    invoke-static {p1, p5}, LnPos5502;->kO_6X_(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    .line 115
    .line 116
    .line 117
    iget-object p3, p3, Landroid/util/Pair;->second:Ljava/lang/Object;

    .line 118
    .line 119
    if-eqz p3, :cond_a

    .line 120
    .line 121
    check-cast p3, Ljava/lang/String;

    .line 122
    .line 123
    invoke-static {p1, p3}, LShH$1_1$;->$ÒcdS(Landroid/media/metrics/TrackChangeEvent$Builder;Ljava/lang/String;)V

    .line 124
    .line 125
    .line 126
    :cond_a
    iget p3, p4, LgItem9321;->UC_n_:F

    .line 127
    .line 128
    const/high16 p4, -0x40800000    # -1.0f

    .line 129
    .line 130
    cmpl-float p4, p3, p4

    .line 131
    .line 132
    if-eqz p4, :cond_c

    .line 133
    .line 134
    invoke-static {p1, p3}, LShH$1_1$;->UC_n_(Landroid/media/metrics/TrackChangeEvent$Builder;F)V

    .line 135
    .line 136
    .line 137
    goto :goto_2

    .line 138
    :cond_b
    invoke-static {p1}, LShH$1_1$;->Qp_Hp$i_(Landroid/media/metrics/TrackChangeEvent$Builder;)V

    .line 139
    .line 140
    .line 141
    :cond_c
    :goto_2
    iput-boolean p2, p0, Lk6x_8$a_;->l1:Z

    .line 142
    .line 143
    iget-object p2, p0, Lk6x_8$a_;->jPos3709:Landroid/media/metrics/PlaybackSession;

    .line 144
    .line 145
    invoke-static {p1}, LShH$1_1$;->kQy(Landroid/media/metrics/TrackChangeEvent$Builder;)Landroid/media/metrics/TrackChangeEvent;

    .line 146
    .line 147
    .line 148
    move-result-object p1

    .line 149
    invoke-static {p2, p1}, LShH$1_1$;->K0I(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/TrackChangeEvent;)V

    .line 150
    .line 151
    .line 152
    return-void
.end method

.method public final waiBKÀ(Ljava/io/IOException;)V
    .locals 0

    .line 1
    return-void
.end method

.method public final yON3x()V
    .locals 7

    .line 1
    iget-object v0, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_3

    .line 5
    .line 6
    iget-boolean v2, p0, Lk6x_8$a_;->l1:Z

    .line 7
    .line 8
    if-eqz v2, :cond_3

    .line 9
    .line 10
    iget v2, p0, Lk6x_8$a_;->Iii:I

    .line 11
    .line 12
    invoke-static {v0, v2}, LnPos5502;->tmpSize211(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 13
    .line 14
    .line 15
    iget-object v0, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 16
    .line 17
    iget v2, p0, Lk6x_8$a_;->yPN$A_n$:I

    .line 18
    .line 19
    invoke-static {v0, v2}, LnPos5502;->tzKù7Ol1(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 23
    .line 24
    iget v2, p0, Lk6x_8$a_;->Oey:I

    .line 25
    .line 26
    invoke-static {v0, v2}, LnPos5502;->oy_R$Xx_(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 27
    .line 28
    .line 29
    iget-object v0, p0, Lk6x_8$a_;->valuI:Ljava/util/HashMap;

    .line 30
    .line 31
    iget-object v2, p0, Lk6x_8$a_;->yàÒZ:Ljava/lang/String;

    .line 32
    .line 33
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Ljava/lang/Long;

    .line 38
    .line 39
    iget-object v2, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 40
    .line 41
    const-wide/16 v3, 0x0

    .line 42
    .line 43
    if-nez v0, :cond_0

    .line 44
    .line 45
    move-wide v5, v3

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 48
    .line 49
    .line 50
    move-result-wide v5

    .line 51
    :goto_0
    invoke-static {v2, v5, v6}, LShH$1_1$;->kO_6X_(Landroid/media/metrics/PlaybackMetrics$Builder;J)V

    .line 52
    .line 53
    .line 54
    iget-object v0, p0, Lk6x_8$a_;->pCXDYg:Ljava/util/HashMap;

    .line 55
    .line 56
    iget-object v2, p0, Lk6x_8$a_;->yàÒZ:Ljava/lang/String;

    .line 57
    .line 58
    invoke-virtual {v0, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    check-cast v0, Ljava/lang/Long;

    .line 63
    .line 64
    iget-object v2, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 65
    .line 66
    if-nez v0, :cond_1

    .line 67
    .line 68
    move-wide v5, v3

    .line 69
    goto :goto_1

    .line 70
    :cond_1
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 71
    .line 72
    .line 73
    move-result-wide v5

    .line 74
    :goto_1
    invoke-static {v2, v5, v6}, LShH$1_1$;->ll(Landroid/media/metrics/PlaybackMetrics$Builder;J)V

    .line 75
    .line 76
    .line 77
    iget-object v2, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 78
    .line 79
    if-eqz v0, :cond_2

    .line 80
    .line 81
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    .line 82
    .line 83
    .line 84
    move-result-wide v5

    .line 85
    cmp-long v0, v5, v3

    .line 86
    .line 87
    if-lez v0, :cond_2

    .line 88
    .line 89
    const/4 v0, 0x1

    .line 90
    goto :goto_2

    .line 91
    :cond_2
    const/4 v0, 0x0

    .line 92
    :goto_2
    invoke-static {v2, v0}, LShH$1_1$;->gKey4112(Landroid/media/metrics/PlaybackMetrics$Builder;I)V

    .line 93
    .line 94
    .line 95
    iget-object v0, p0, Lk6x_8$a_;->jPos3709:Landroid/media/metrics/PlaybackSession;

    .line 96
    .line 97
    iget-object v2, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 98
    .line 99
    invoke-static {v2}, LShH$1_1$;->sKey7917(Landroid/media/metrics/PlaybackMetrics$Builder;)Landroid/media/metrics/PlaybackMetrics;

    .line 100
    .line 101
    .line 102
    move-result-object v2

    .line 103
    invoke-static {v0, v2}, LnPos5502;->pCXDYg(Landroid/media/metrics/PlaybackSession;Landroid/media/metrics/PlaybackMetrics;)V

    .line 104
    .line 105
    .line 106
    :cond_3
    const/4 v0, 0x0

    .line 107
    iput-object v0, p0, Lk6x_8$a_;->gKey4112:Landroid/media/metrics/PlaybackMetrics$Builder;

    .line 108
    .line 109
    iput-object v0, p0, Lk6x_8$a_;->yàÒZ:Ljava/lang/String;

    .line 110
    .line 111
    iput v1, p0, Lk6x_8$a_;->Iii:I

    .line 112
    .line 113
    iput v1, p0, Lk6x_8$a_;->yPN$A_n$:I

    .line 114
    .line 115
    iput v1, p0, Lk6x_8$a_;->Oey:I

    .line 116
    .line 117
    iput-object v0, p0, Lk6x_8$a_;->tmpSize211:LgItem9321;

    .line 118
    .line 119
    iput-object v0, p0, Lk6x_8$a_;->sKey6064:LgItem9321;

    .line 120
    .line 121
    iput-object v0, p0, Lk6x_8$a_;->tzKù7Ol1:LgItem9321;

    .line 122
    .line 123
    iput-boolean v1, p0, Lk6x_8$a_;->l1:Z

    .line 124
    .line 125
    return-void
.end method
