.class public abstract LI1i1li1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final e8$mp_s$:LvSize4545;

.field public static final waiBKÀ:LvSize4545;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    const-string v0, "gads:ad_key_enabled"

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-static {v0, v1}, LvSize4545;->kCount1402(Ljava/lang/String;Z)LvSize4545;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sput-object v0, LI1i1li1;->e8$mp_s$:LvSize4545;

    .line 9
    .line 10
    const-string v0, "gads:adshield:enable_adshield_instrumentation"

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    invoke-static {v0, v1}, LvSize4545;->kCount1402(Ljava/lang/String;Z)LvSize4545;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    sput-object v0, LI1i1li1;->waiBKÀ:LvSize4545;

    .line 18
    .line 19
    return-void
.end method
