.class public interface abstract Loz$A_1$;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LvOffset4792;
