.class public final LID;
.super LsA8$j$;


# instance fields
.field public final synthetic iOffset934:I

.field public kQy:Z


# direct methods
.method public synthetic constructor <init>(I)V
    .locals 0

    .line 1
    iput p1, p0, LID;->iOffset934:I

    invoke-direct {p0}, LIQ;-><init>()V

    return-void
.end method

.method private final iOffset934(LvKey4670;Ljava/lang/String;)V
    .locals 0

    .line 1
    return-void
.end method


# virtual methods
.method public final DDù8(LvKey4670;Ljava/lang/String;Lorg/xml/sax/Attributes;)V
    .locals 8

    .line 1
    iget v0, p0, LID;->iOffset934:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    const-string p2, "key"

    .line 7
    .line 8
    invoke-interface {p3, p2}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 9
    .line 10
    .line 11
    move-result-object p2

    .line 12
    invoke-static {p2}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x1

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    const-string v0, "Attribute named [key] cannot be empty"

    .line 20
    .line 21
    invoke-virtual {p0, v0}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    iput-boolean v1, p0, LID;->kQy:Z

    .line 25
    .line 26
    :cond_0
    const-string v0, "datePattern"

    .line 27
    .line 28
    invoke-interface {p3, v0}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-static {v0}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    if-eqz v2, :cond_1

    .line 37
    .line 38
    const-string v2, "Attribute named [datePattern] cannot be empty"

    .line 39
    .line 40
    invoke-virtual {p0, v2}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    iput-boolean v1, p0, LID;->kQy:Z

    .line 44
    .line 45
    :cond_1
    const-string v2, "timeReference"

    .line 46
    .line 47
    invoke-interface {p3, v2}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 48
    .line 49
    .line 50
    move-result-object v2

    .line 51
    const-string v3, "contextBirth"

    .line 52
    .line 53
    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 54
    .line 55
    .line 56
    move-result v2

    .line 57
    if-eqz v2, :cond_2

    .line 58
    .line 59
    const-string v2, "Using context birth as time reference."

    .line 60
    .line 61
    invoke-virtual {p0, v2}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 62
    .line 63
    .line 64
    iget-object v2, p0, LIQ;->vaIue:LZN$P$;

    .line 65
    .line 66
    iget-wide v2, v2, LZN$P$;->yON3x:J

    .line 67
    .line 68
    goto :goto_0

    .line 69
    :cond_2
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 70
    .line 71
    .line 72
    move-result-wide v2

    .line 73
    const-string v4, "Using current interpretation time, i.e. now, as time reference."

    .line 74
    .line 75
    invoke-virtual {p0, v4}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    :goto_0
    iget-boolean v4, p0, LID;->kQy:Z

    .line 79
    .line 80
    if-eqz v4, :cond_3

    .line 81
    .line 82
    goto/16 :goto_3

    .line 83
    .line 84
    :cond_3
    const-string v4, "scope"

    .line 85
    .line 86
    invoke-interface {p3, v4}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 87
    .line 88
    .line 89
    move-result-object p3

    .line 90
    invoke-static {p3}, LvItem3158;->zAt$p(Ljava/lang/String;)I

    .line 91
    .line 92
    .line 93
    move-result p3

    .line 94
    sget-object v4, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 95
    .line 96
    new-instance v5, Ljava/text/SimpleDateFormat;

    .line 97
    .line 98
    invoke-direct {v5, v0, v4}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    .line 99
    .line 100
    .line 101
    const-wide/16 v6, -0x1

    .line 102
    .line 103
    cmp-long v0, v2, v6

    .line 104
    .line 105
    if-eqz v0, :cond_4

    .line 106
    .line 107
    new-instance v0, Ljava/util/Date;

    .line 108
    .line 109
    invoke-direct {v0, v2, v3}, Ljava/util/Date;-><init>(J)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v5, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    goto :goto_1

    .line 117
    :cond_4
    const/4 v0, 0x0

    .line 118
    :goto_1
    const-string v2, "\" and value=\""

    .line 119
    .line 120
    const-string v3, "\" to the "

    .line 121
    .line 122
    const-string v4, "Adding property to the context with key=\""

    .line 123
    .line 124
    invoke-static {v4, p2, v2, v0, v3}, LRQU_K6$Kv_;->yàÒZ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 125
    .line 126
    .line 127
    move-result-object v2

    .line 128
    const/4 v3, 0x1

    .line 129
    if-eq p3, v3, :cond_7

    .line 130
    .line 131
    const/4 v3, 0x2

    .line 132
    if-eq p3, v3, :cond_6

    .line 133
    .line 134
    const/4 v3, 0x3

    .line 135
    if-eq p3, v3, :cond_5

    .line 136
    .line 137
    const-string v3, "null"

    .line 138
    .line 139
    goto :goto_2

    .line 140
    :cond_5
    const-string v3, "SYSTEM"

    .line 141
    .line 142
    goto :goto_2

    .line 143
    :cond_6
    const-string v3, "CONTEXT"

    .line 144
    .line 145
    goto :goto_2

    .line 146
    :cond_7
    const-string v3, "LOCAL"

    .line 147
    .line 148
    :goto_2
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 149
    .line 150
    .line 151
    const-string v3, " scope"

    .line 152
    .line 153
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 154
    .line 155
    .line 156
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    invoke-virtual {p0, v2}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 161
    .line 162
    .line 163
    invoke-static {p3}, LBRK_m_;->UC_n_(I)I

    .line 164
    .line 165
    .line 166
    move-result p3

    .line 167
    if-eqz p3, :cond_a

    .line 168
    .line 169
    if-eq p3, v1, :cond_9

    .line 170
    .line 171
    const/4 v1, 0x2

    .line 172
    if-eq p3, v1, :cond_8

    .line 173
    .line 174
    goto :goto_3

    .line 175
    :cond_8
    :try_start_0
    invoke-static {p2, v0}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/SecurityException; {:try_start_0 .. :try_end_0} :catch_0

    .line 176
    .line 177
    .line 178
    goto :goto_3

    .line 179
    :catch_0
    move-exception p3

    .line 180
    new-instance v0, Ljava/lang/StringBuilder;

    .line 181
    .line 182
    const-string v1, "Failed to set system property ["

    .line 183
    .line 184
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    .line 189
    .line 190
    const-string p2, "]"

    .line 191
    .line 192
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object p2

    .line 199
    invoke-virtual {p1, p2, p3}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 200
    .line 201
    .line 202
    goto :goto_3

    .line 203
    :cond_9
    iget-object p1, p1, LIQ;->vaIue:LZN$P$;

    .line 204
    .line 205
    iget-object p3, p1, LZN$P$;->iOffset934:Ljava/util/HashMap;

    .line 206
    .line 207
    invoke-virtual {p3, p2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 208
    .line 209
    .line 210
    new-instance p2, Ljava/util/HashMap;

    .line 211
    .line 212
    iget-object p1, p1, LZN$P$;->iOffset934:Ljava/util/HashMap;

    .line 213
    .line 214
    invoke-direct {p2, p1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    .line 215
    .line 216
    .line 217
    goto :goto_3

    .line 218
    :cond_a
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 219
    .line 220
    .line 221
    if-eqz p2, :cond_c

    .line 222
    .line 223
    if-nez v0, :cond_b

    .line 224
    .line 225
    goto :goto_3

    .line 226
    :cond_b
    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 227
    .line 228
    .line 229
    move-result-object p3

    .line 230
    iget-object p1, p1, LvKey4670;->Ialue:Ljava/util/HashMap;

    .line 231
    .line 232
    invoke-virtual {p1, p2, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    :cond_c
    :goto_3
    return-void

    .line 236
    :pswitch_0
    const-string p1, "About to instantiate shutdown hook of type ["

    .line 237
    .line 238
    const/4 p2, 0x0

    .line 239
    iput-boolean p2, p0, LID;->kQy:Z

    .line 240
    .line 241
    const-string p2, "class"

    .line 242
    .line 243
    invoke-interface {p3, p2}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 244
    .line 245
    .line 246
    move-result-object p2

    .line 247
    invoke-static {p2}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 248
    .line 249
    .line 250
    move-result p3

    .line 251
    const-string v0, "]"

    .line 252
    .line 253
    const-class v1, Lza_n$F_;

    .line 254
    .line 255
    if-eqz p3, :cond_d

    .line 256
    .line 257
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 258
    .line 259
    .line 260
    move-result-object p2

    .line 261
    new-instance p3, Ljava/lang/StringBuilder;

    .line 262
    .line 263
    const-string v2, "Assuming className ["

    .line 264
    .line 265
    invoke-direct {p3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 269
    .line 270
    .line 271
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 272
    .line 273
    .line 274
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 275
    .line 276
    .line 277
    move-result-object p3

    .line 278
    invoke-virtual {p0, p3}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 279
    .line 280
    .line 281
    :cond_d
    :try_start_1
    new-instance p3, Ljava/lang/StringBuilder;

    .line 282
    .line 283
    invoke-direct {p3, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 284
    .line 285
    .line 286
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 287
    .line 288
    .line 289
    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 290
    .line 291
    .line 292
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 293
    .line 294
    .line 295
    move-result-object p1

    .line 296
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 297
    .line 298
    .line 299
    iget-object p1, p0, LIQ;->vaIue:LZN$P$;

    .line 300
    .line 301
    invoke-static {p2, v1, p1}, LdbÙLJ;->gKey4112(Ljava/lang/String;Ljava/lang/Class;LZN$P$;)Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object p1

    .line 305
    if-nez p1, :cond_e

    .line 306
    .line 307
    const/4 p1, 0x0

    .line 308
    throw p1

    .line 309
    :catch_1
    move-exception p1

    .line 310
    goto :goto_4

    .line 311
    :cond_e
    new-instance p1, Ljava/lang/ClassCastException;

    .line 312
    .line 313
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 314
    .line 315
    .line 316
    throw p1
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1

    .line 317
    :goto_4
    const/4 p3, 0x1

    .line 318
    iput-boolean p3, p0, LID;->kQy:Z

    .line 319
    .line 320
    new-instance p3, Ljava/lang/StringBuilder;

    .line 321
    .line 322
    const-string v0, "Could not create a shutdown hook of type ["

    .line 323
    .line 324
    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 325
    .line 326
    .line 327
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 328
    .line 329
    .line 330
    const-string p2, "]."

    .line 331
    .line 332
    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 333
    .line 334
    .line 335
    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 336
    .line 337
    .line 338
    move-result-object p2

    .line 339
    invoke-virtual {p0, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 340
    .line 341
    .line 342
    new-instance p2, LXÒiDZdXm;

    .line 343
    .line 344
    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 345
    .line 346
    .line 347
    throw p2

    .line 348
    :pswitch_1
    const-string v0, "About to instantiate receiver of type ["

    .line 349
    .line 350
    const-string v1, "class"

    .line 351
    .line 352
    invoke-interface {p3, v1}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 353
    .line 354
    .line 355
    move-result-object p3

    .line 356
    invoke-static {p3}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 357
    .line 358
    .line 359
    move-result v1

    .line 360
    const/4 v2, 0x1

    .line 361
    if-eqz v1, :cond_f

    .line 362
    .line 363
    const-string p3, "Missing class name for receiver. Near ["

    .line 364
    .line 365
    const-string v0, "] line "

    .line 366
    .line 367
    invoke-static {p3, p2, v0}, LBRK_m_;->Ialue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 368
    .line 369
    .line 370
    move-result-object p2

    .line 371
    invoke-static {p1}, LsA8$j$;->jPos3709(LvKey4670;)I

    .line 372
    .line 373
    .line 374
    move-result p1

    .line 375
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 376
    .line 377
    .line 378
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object p1

    .line 382
    invoke-virtual {p0, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 383
    .line 384
    .line 385
    iput-boolean v2, p0, LID;->kQy:Z

    .line 386
    .line 387
    return-void

    .line 388
    :cond_f
    :try_start_2
    new-instance p1, Ljava/lang/StringBuilder;

    .line 389
    .line 390
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 391
    .line 392
    .line 393
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 394
    .line 395
    .line 396
    const-string p2, "]"

    .line 397
    .line 398
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object p1

    .line 405
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 406
    .line 407
    .line 408
    const-class p1, LhasData2323;

    .line 409
    .line 410
    iget-object p2, p0, LIQ;->vaIue:LZN$P$;

    .line 411
    .line 412
    invoke-static {p3, p1, p2}, LdbÙLJ;->gKey4112(Ljava/lang/String;Ljava/lang/Class;LZN$P$;)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object p1

    .line 416
    if-nez p1, :cond_10

    .line 417
    .line 418
    const/4 p1, 0x0

    .line 419
    throw p1

    .line 420
    :catch_2
    move-exception p1

    .line 421
    goto :goto_5

    .line 422
    :cond_10
    new-instance p1, Ljava/lang/ClassCastException;

    .line 423
    .line 424
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 425
    .line 426
    .line 427
    throw p1
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    .line 428
    :goto_5
    iput-boolean v2, p0, LID;->kQy:Z

    .line 429
    .line 430
    new-instance p2, Ljava/lang/StringBuilder;

    .line 431
    .line 432
    const-string v0, "Could not create a receiver of type ["

    .line 433
    .line 434
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 435
    .line 436
    .line 437
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 438
    .line 439
    .line 440
    const-string p3, "]."

    .line 441
    .line 442
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 443
    .line 444
    .line 445
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 446
    .line 447
    .line 448
    move-result-object p2

    .line 449
    invoke-virtual {p0, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 450
    .line 451
    .line 452
    new-instance p2, LXÒiDZdXm;

    .line 453
    .line 454
    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 455
    .line 456
    .line 457
    throw p2

    .line 458
    :pswitch_2
    const-string p2, "Adding LoggerContextListener of type ["

    .line 459
    .line 460
    const/4 v0, 0x0

    .line 461
    iput-boolean v0, p0, LID;->kQy:Z

    .line 462
    .line 463
    const-string v0, "class"

    .line 464
    .line 465
    invoke-interface {p3, v0}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 466
    .line 467
    .line 468
    move-result-object p3

    .line 469
    invoke-static {p3}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 470
    .line 471
    .line 472
    move-result v0

    .line 473
    const/4 v1, 0x1

    .line 474
    if-eqz v0, :cond_11

    .line 475
    .line 476
    const-string p1, "Mandatory \"class\" attribute not set for <loggerContextListener> element"

    .line 477
    .line 478
    invoke-virtual {p0, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 479
    .line 480
    .line 481
    iput-boolean v1, p0, LID;->kQy:Z

    .line 482
    .line 483
    goto :goto_7

    .line 484
    :cond_11
    :try_start_3
    const-class v0, LKYKz7;

    .line 485
    .line 486
    iget-object v2, p0, LIQ;->vaIue:LZN$P$;

    .line 487
    .line 488
    invoke-static {p3, v0, v2}, LdbÙLJ;->gKey4112(Ljava/lang/String;Ljava/lang/Class;LZN$P$;)Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    if-nez v0, :cond_12

    .line 493
    .line 494
    const/4 v0, 0x0

    .line 495
    invoke-virtual {p1, v0}, LvKey4670;->vaIue(Ljava/lang/Object;)V

    .line 496
    .line 497
    .line 498
    new-instance p1, Ljava/lang/StringBuilder;

    .line 499
    .line 500
    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 501
    .line 502
    .line 503
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 504
    .line 505
    .line 506
    const-string p2, "] to the object stack"

    .line 507
    .line 508
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 509
    .line 510
    .line 511
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 512
    .line 513
    .line 514
    move-result-object p1

    .line 515
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 516
    .line 517
    .line 518
    goto :goto_7

    .line 519
    :catch_3
    move-exception p1

    .line 520
    goto :goto_6

    .line 521
    :cond_12
    new-instance p1, Ljava/lang/ClassCastException;

    .line 522
    .line 523
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 524
    .line 525
    .line 526
    throw p1
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_3

    .line 527
    :goto_6
    iput-boolean v1, p0, LID;->kQy:Z

    .line 528
    .line 529
    new-instance p2, Ljava/lang/StringBuilder;

    .line 530
    .line 531
    const-string v0, "Could not create LoggerContextListener of type "

    .line 532
    .line 533
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 534
    .line 535
    .line 536
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 537
    .line 538
    .line 539
    const-string p3, "]."

    .line 540
    .line 541
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 542
    .line 543
    .line 544
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 545
    .line 546
    .line 547
    move-result-object p2

    .line 548
    invoke-virtual {p0, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 549
    .line 550
    .line 551
    :goto_7
    return-void

    .line 552
    :pswitch_3
    const-string v0, "About to instantiate appender of type ["

    .line 553
    .line 554
    const/4 v1, 0x0

    .line 555
    iput-boolean v1, p0, LID;->kQy:Z

    .line 556
    .line 557
    const-string v1, "class"

    .line 558
    .line 559
    invoke-interface {p3, v1}, Lorg/xml/sax/Attributes;->getValue(Ljava/lang/String;)Ljava/lang/String;

    .line 560
    .line 561
    .line 562
    move-result-object p3

    .line 563
    invoke-static {p3}, LdbÙLJ;->UC_n_(Ljava/lang/String;)Z

    .line 564
    .line 565
    .line 566
    move-result v1

    .line 567
    const/4 v2, 0x1

    .line 568
    if-eqz v1, :cond_13

    .line 569
    .line 570
    const-string p3, "Missing class name for appender. Near ["

    .line 571
    .line 572
    const-string v0, "] line "

    .line 573
    .line 574
    invoke-static {p3, p2, v0}, LBRK_m_;->Ialue(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 575
    .line 576
    .line 577
    move-result-object p2

    .line 578
    invoke-static {p1}, LsA8$j$;->jPos3709(LvKey4670;)I

    .line 579
    .line 580
    .line 581
    move-result p1

    .line 582
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 583
    .line 584
    .line 585
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 586
    .line 587
    .line 588
    move-result-object p1

    .line 589
    invoke-virtual {p0, p1}, LIQ;->rz__9J_(Ljava/lang/String;)V

    .line 590
    .line 591
    .line 592
    iput-boolean v2, p0, LID;->kQy:Z

    .line 593
    .line 594
    return-void

    .line 595
    :cond_13
    :try_start_4
    new-instance p1, Ljava/lang/StringBuilder;

    .line 596
    .line 597
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 598
    .line 599
    .line 600
    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 601
    .line 602
    .line 603
    const-string p2, "]"

    .line 604
    .line 605
    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 606
    .line 607
    .line 608
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 609
    .line 610
    .line 611
    move-result-object p1

    .line 612
    invoke-virtual {p0, p1}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 613
    .line 614
    .line 615
    const-string p1, "ch.qos.logback.core.ConsoleAppender"

    .line 616
    .line 617
    invoke-virtual {p3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 618
    .line 619
    .line 620
    move-result p1

    .line 621
    if-eqz p1, :cond_14

    .line 622
    .line 623
    const-string p1, "ConsoleAppender is deprecated for LogcatAppender"

    .line 624
    .line 625
    invoke-virtual {p0, p1}, LIQ;->sKey7917(Ljava/lang/String;)V

    .line 626
    .line 627
    .line 628
    :cond_14
    const-class p1, LDìdLm;

    .line 629
    .line 630
    iget-object p2, p0, LIQ;->vaIue:LZN$P$;

    .line 631
    .line 632
    invoke-static {p3, p1, p2}, LdbÙLJ;->gKey4112(Ljava/lang/String;Ljava/lang/Class;LZN$P$;)Ljava/lang/Object;

    .line 633
    .line 634
    .line 635
    move-result-object p1

    .line 636
    if-nez p1, :cond_15

    .line 637
    .line 638
    const/4 p1, 0x0

    .line 639
    throw p1

    .line 640
    :catch_4
    move-exception p1

    .line 641
    goto :goto_8

    .line 642
    :cond_15
    new-instance p1, Ljava/lang/ClassCastException;

    .line 643
    .line 644
    invoke-direct {p1}, Ljava/lang/ClassCastException;-><init>()V

    .line 645
    .line 646
    .line 647
    throw p1
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_4

    .line 648
    :goto_8
    iput-boolean v2, p0, LID;->kQy:Z

    .line 649
    .line 650
    new-instance p2, Ljava/lang/StringBuilder;

    .line 651
    .line 652
    const-string v0, "Could not create an Appender of type ["

    .line 653
    .line 654
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 655
    .line 656
    .line 657
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 658
    .line 659
    .line 660
    const-string p3, "]."

    .line 661
    .line 662
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 663
    .line 664
    .line 665
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 666
    .line 667
    .line 668
    move-result-object p2

    .line 669
    invoke-virtual {p0, p2, p1}, LIQ;->POOl(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 670
    .line 671
    .line 672
    new-instance p2, LXÒiDZdXm;

    .line 673
    .line 674
    invoke-direct {p2, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    .line 675
    .line 676
    .line 677
    throw p2

    .line 678
    nop

    .line 679
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public final vaIue(LvKey4670;Ljava/lang/String;)V
    .locals 2

    .line 1
    iget p2, p0, LID;->iOffset934:I

    .line 2
    .line 3
    packed-switch p2, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    return-void

    .line 7
    :pswitch_0
    iget-boolean p2, p0, LID;->kQy:Z

    .line 8
    .line 9
    if-eqz p2, :cond_0

    .line 10
    .line 11
    goto :goto_0

    .line 12
    :cond_0
    iget-object p2, p1, LvKey4670;->iOffset934:Ljava/util/Stack;

    .line 13
    .line 14
    invoke-virtual {p2}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p2

    .line 18
    if-eqz p2, :cond_1

    .line 19
    .line 20
    const-string p1, "The object at the of the stack is not the hook pushed earlier."

    .line 21
    .line 22
    invoke-virtual {p0, p1}, LIQ;->sKey7917(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    goto :goto_0

    .line 26
    :cond_1
    invoke-virtual {p1}, LvKey4670;->yON3x()V

    .line 27
    .line 28
    .line 29
    new-instance p1, Ljava/lang/Thread;

    .line 30
    .line 31
    new-instance p2, Ljava/lang/StringBuilder;

    .line 32
    .line 33
    const-string v0, "Logback shutdown hook ["

    .line 34
    .line 35
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, LIQ;->vaIue:LZN$P$;

    .line 39
    .line 40
    iget-object v0, v0, LZN$P$;->vaIue:Ljava/lang/String;

    .line 41
    .line 42
    const-string v1, "]"

    .line 43
    .line 44
    invoke-static {p2, v0, v1}, LBRK_m_;->iOffset934(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p2

    .line 48
    const/4 v0, 0x0

    .line 49
    invoke-direct {p1, v0, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    const-string p2, "Registering shutdown hook with JVM runtime"

    .line 53
    .line 54
    invoke-virtual {p0, p2}, LIQ;->JKEoÙX(Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    iget-object p2, p0, LIQ;->vaIue:LZN$P$;

    .line 58
    .line 59
    const-string v0, "SHUTDOWN_HOOK"

    .line 60
    .line 61
    invoke-virtual {p2, v0, p1}, LZN$P$;->POOl(Ljava/lang/String;Ljava/lang/Object;)V

    .line 62
    .line 63
    .line 64
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    .line 65
    .line 66
    .line 67
    move-result-object p2

    .line 68
    invoke-virtual {p2, p1}, Ljava/lang/Runtime;->addShutdownHook(Ljava/lang/Thread;)V

    .line 69
    .line 70
    .line 71
    :goto_0
    return-void

    .line 72
    :pswitch_1
    iget-boolean p2, p0, LID;->kQy:Z

    .line 73
    .line 74
    if-eqz p2, :cond_2

    .line 75
    .line 76
    return-void

    .line 77
    :cond_2
    iget-object p1, p1, LIQ;->vaIue:LZN$P$;

    .line 78
    .line 79
    invoke-virtual {p1}, LZN$P$;->waiBKÀ()LJw_Mi$Hk_;

    .line 80
    .line 81
    .line 82
    move-result-object p1

    .line 83
    iget-object p1, p1, LJw_Mi$Hk_;->vaIue:Ljava/lang/Object;

    .line 84
    .line 85
    check-cast p1, Ljava/util/HashSet;

    .line 86
    .line 87
    const/4 p2, 0x0

    .line 88
    invoke-virtual {p1, p2}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    throw p2

    .line 92
    :pswitch_2
    iget-boolean p2, p0, LID;->kQy:Z

    .line 93
    .line 94
    if-eqz p2, :cond_3

    .line 95
    .line 96
    goto :goto_1

    .line 97
    :cond_3
    iget-object p2, p1, LvKey4670;->iOffset934:Ljava/util/Stack;

    .line 98
    .line 99
    invoke-virtual {p2}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 100
    .line 101
    .line 102
    move-result-object p2

    .line 103
    if-eqz p2, :cond_4

    .line 104
    .line 105
    const-string p1, "The object on the top the of the stack is not the LoggerContextListener pushed earlier."

    .line 106
    .line 107
    invoke-virtual {p0, p1}, LIQ;->sKey7917(Ljava/lang/String;)V

    .line 108
    .line 109
    .line 110
    goto :goto_1

    .line 111
    :cond_4
    iget-object p2, p0, LIQ;->vaIue:LZN$P$;

    .line 112
    .line 113
    const/4 v0, 0x0

    .line 114
    iget-object p2, p2, LZN$P$;->Qp_Hp$i_:Ljava/util/ArrayList;

    .line 115
    .line 116
    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    invoke-virtual {p1}, LvKey4670;->yON3x()V

    .line 120
    .line 121
    .line 122
    :goto_1
    return-void

    .line 123
    :pswitch_3
    iget-boolean p2, p0, LID;->kQy:Z

    .line 124
    .line 125
    if-eqz p2, :cond_5

    .line 126
    .line 127
    goto :goto_2

    .line 128
    :cond_5
    iget-object p2, p1, LvKey4670;->iOffset934:Ljava/util/Stack;

    .line 129
    .line 130
    invoke-virtual {p2}, Ljava/util/Stack;->peek()Ljava/lang/Object;

    .line 131
    .line 132
    .line 133
    move-result-object p2

    .line 134
    if-nez p2, :cond_6

    .line 135
    .line 136
    invoke-virtual {p1}, LvKey4670;->yON3x()V

    .line 137
    .line 138
    .line 139
    :goto_2
    return-void

    .line 140
    :cond_6
    const/4 p1, 0x0

    .line 141
    throw p1

    .line 142
    nop

    .line 143
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
