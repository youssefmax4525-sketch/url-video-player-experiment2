.class public final synthetic LI1lil;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic vaIue:LKkmORP;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(LKkmORP;I)V
    .locals 0

    .line 1
    iput p2, p0, LI1lil;->yON3x:I

    iput-object p1, p0, LI1lil;->vaIue:LKkmORP;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 1
    iget v0, p0, LI1lil;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LI1lil;->vaIue:LKkmORP;

    .line 7
    .line 8
    iget-object v0, v0, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, LxLUÙOj;

    .line 11
    .line 12
    iget-object v0, v0, LxLUÙOj;->JKEoÙX:LmOffset4892;

    .line 13
    .line 14
    invoke-virtual {v0}, LmOffset4892;->YOD0()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_0
    iget-object v0, p0, LI1lil;->vaIue:LKkmORP;

    .line 19
    .line 20
    iget-object v0, v0, LKkmORP;->Ialue:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v0, LxLUÙOj;

    .line 23
    .line 24
    iget-object v0, v0, LxLUÙOj;->POOl:LAq$$_M$;

    .line 25
    .line 26
    invoke-virtual {v0}, LAq$$_M$;->YOD0()V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    nop

    .line 31
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
