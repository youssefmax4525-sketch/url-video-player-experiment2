.class public interface abstract LxIlIDO;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract POOl(Ljavax/net/ssl/SSLSocket;)Lu10l;
.end method

.method public abstract waiBKÀ(Ljavax/net/ssl/SSLSocket;)Z
.end method
