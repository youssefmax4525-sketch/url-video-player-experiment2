.class public final synthetic LuQI;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LH2h_go_;


# instance fields
.field public final synthetic jPos3709:I

.field public final synthetic vaIue:Lgp_T_;

.field public final synthetic yON3x:I


# direct methods
.method public synthetic constructor <init>(Lgp_T_;II)V
    .locals 0

    .line 1
    const/4 p3, 0x1

    iput p3, p0, LuQI;->yON3x:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuQI;->vaIue:Lgp_T_;

    iput p2, p0, LuQI;->jPos3709:I

    return-void
.end method

.method public synthetic constructor <init>(Lgp_T_;ILjava/util/List;)V
    .locals 0

    .line 2
    const/4 p3, 0x0

    iput p3, p0, LuQI;->yON3x:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuQI;->vaIue:Lgp_T_;

    iput p2, p0, LuQI;->jPos3709:I

    return-void
.end method

.method public synthetic constructor <init>(Lgp_T_;ILjava/util/List;Z)V
    .locals 0

    .line 3
    const/4 p3, 0x2

    iput p3, p0, LuQI;->yON3x:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LuQI;->vaIue:Lgp_T_;

    iput p2, p0, LuQI;->jPos3709:I

    return-void
.end method

.method private final POOl()Ljava/lang/Object;
    .locals 3

    .line 1
    iget-object v0, p0, LuQI;->vaIue:Lgp_T_;

    .line 2
    .line 3
    iget v1, p0, LuQI;->jPos3709:I

    .line 4
    .line 5
    iget-object v2, v0, Lgp_T_;->kO_6X_:LplQQD0;

    .line 6
    .line 7
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    monitor-enter v0

    .line 11
    :try_start_0
    iget-object v2, v0, Lgp_T_;->Iii:Ljava/util/LinkedHashSet;

    .line 12
    .line 13
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-interface {v2, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 18
    .line 19
    .line 20
    monitor-exit v0

    .line 21
    sget-object v0, LplQQD0;->valuI:LplQQD0;

    .line 22
    .line 23
    return-object v0

    .line 24
    :catchall_0
    move-exception v1

    .line 25
    monitor-exit v0

    .line 26
    throw v1
.end method

.method private final rz__9J_()Ljava/lang/Object;
    .locals 4

    .line 1
    iget-object v0, p0, LuQI;->vaIue:Lgp_T_;

    .line 2
    .line 3
    iget v1, p0, LuQI;->jPos3709:I

    .line 4
    .line 5
    iget-object v2, v0, Lgp_T_;->kO_6X_:LplQQD0;

    .line 6
    .line 7
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    :try_start_0
    iget-object v2, v0, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 11
    .line 12
    const/16 v3, 0x9

    .line 13
    .line 14
    invoke-virtual {v2, v1, v3}, LoìMB;->pCXDYg(II)V

    .line 15
    .line 16
    .line 17
    monitor-enter v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 18
    :try_start_1
    iget-object v2, v0, Lgp_T_;->Iii:Ljava/util/LinkedHashSet;

    .line 19
    .line 20
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    invoke-interface {v2, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 25
    .line 26
    .line 27
    :try_start_2
    monitor-exit v0

    .line 28
    goto :goto_0

    .line 29
    :catchall_0
    move-exception v1

    .line 30
    monitor-exit v0

    .line 31
    throw v1
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 32
    :catch_0
    :goto_0
    sget-object v0, LplQQD0;->valuI:LplQQD0;

    .line 33
    .line 34
    return-object v0
.end method


# virtual methods
.method public final e8$mp_s$()Ljava/lang/Object;
    .locals 4

    .line 1
    iget v0, p0, LuQI;->yON3x:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, LuQI;->vaIue:Lgp_T_;

    .line 7
    .line 8
    iget v1, p0, LuQI;->jPos3709:I

    .line 9
    .line 10
    iget-object v2, v0, Lgp_T_;->kO_6X_:LplQQD0;

    .line 11
    .line 12
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    :try_start_0
    iget-object v2, v0, Lgp_T_;->yPN$A_n$:LoìMB;

    .line 16
    .line 17
    const/16 v3, 0x9

    .line 18
    .line 19
    invoke-virtual {v2, v1, v3}, LoìMB;->pCXDYg(II)V

    .line 20
    .line 21
    .line 22
    monitor-enter v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    .line 23
    :try_start_1
    iget-object v2, v0, Lgp_T_;->Iii:Ljava/util/LinkedHashSet;

    .line 24
    .line 25
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-interface {v2, v1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 30
    .line 31
    .line 32
    :try_start_2
    monitor-exit v0

    .line 33
    goto :goto_0

    .line 34
    :catchall_0
    move-exception v1

    .line 35
    monitor-exit v0

    .line 36
    throw v1
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    .line 37
    :catch_0
    :goto_0
    sget-object v0, LplQQD0;->valuI:LplQQD0;

    .line 38
    .line 39
    return-object v0

    .line 40
    :pswitch_0
    invoke-direct {p0}, LuQI;->POOl()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v0

    .line 44
    return-object v0

    .line 45
    :pswitch_1
    invoke-direct {p0}, LuQI;->rz__9J_()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    return-object v0

    .line 50
    nop

    .line 51
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
