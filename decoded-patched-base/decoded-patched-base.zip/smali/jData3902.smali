.class public final LjData3902;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic e8$mp_s$:LsQllOQ;


# direct methods
.method public constructor <init>(LsQllOQ;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, LjData3902;->e8$mp_s$:LsQllOQ;

    .line 5
    .line 6
    return-void
.end method
